# SSELFIE Editorial Brand — Copilot Rules of the Road

Hey Copilot (and any devs who join later),

If you’re reading this, you’re building on Sandra’s personal brand system. This isn’t just a website—it’s a *living magazine* that thousands of women trust. Every pixel, word, and style token here is intentional. Here’s what you need to know before you touch a line of code:

---

## 1. Use the System (Don’t “Improve” It)

- **Only use the color, spacing, font, and utility tokens defined in `globals.css` and `tailwind.config.js`.**
- **Never add** Tailwind default colors, border radii, shadows, or spacing (like `gray-700`, `blue-500`, `rounded-lg`, `p-8`, etc.)
- **Do not** import DaisyUI, TailwindUI, shadcn, or any other UI/plugin themes.

---

## 2. Components Must Match Editorial Style

- Use only the provided classes (`section-padding`, `luxury-headline`, `body-copy`, etc.) and custom utilities.
- **If a component doesn’t look “editorial” or “magazine,”** adapt it to the SSELFIE system. *Never* adapt the system to the component.
- Imagery must always be high contrast, slightly desaturated, with sharp corners—no overlays, no fun filters.

---

## 3. Hovers, Animations, and Interactions

- Hovers: Only use border-bottom, underline, or soft opacity. No fills, scales, glows, or color pops.
- Animations: Only use those defined in our config. No bounce, spin, or parallax.
- Transitions: Use editorial cubic-bezier (see config), keep everything subtle and smooth.

---

## 4. Voice and Copy

- Don’t change any copy unless you know how to write like Sandra (see Editorial Style Guide).
- If you need to add words, ask: “Would Sandra actually say this to a friend over coffee?”

---

## 5. If You Don’t Know—Ask

- If you’re unsure whether something matches the brand, ask Sandra or Victoria before pushing a change.
- Never assume “default” is good enough—luxury is in the details.

---

## 6. Final Word

If you see a Tailwind class that isn’t defined in our config, or a style that feels “template,” flag it.  
If you’re tempted to “modernize” or “fix” something with a quick Tailwind/JS hack—don’t.  
This is Sandra’s house. Treat it like the Chanel bag you only wear on special days.

Let’s build something real together.

---