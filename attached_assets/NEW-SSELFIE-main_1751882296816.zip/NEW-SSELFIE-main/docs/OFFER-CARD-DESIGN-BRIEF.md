# OFFER CARD COMPONENT - DESIGN BRIEF FOR VICTORIA

## STATUS: AWAITING VICTORIA DESIGN
**Priority:** HIGH - Critical homepage conversion element  
**Location:** `/src/components/OfferCard.tsx`  
**Usage:** Homepage offers section  

## CURRENT ISSUE
The existing card components aren't quite right for this specific use case. We need a perfect OfferCard that combines selfie backgrounds with luxury text overlays that actually display properly.

## DESIGN REQUIREMENTS

### Visual Hierarchy
- **Selfie images as hero backgrounds** (60-70% visual weight)
- **Clean text overlays** with guaranteed readability
- **Luxury pricing display** using Bodoni font
- **Prominent CTA buttons** with hover effects

### Content Structure (Per Card)
```
[Number: 01, 02, 03]
[Title: Free Guide, Studio, Big Thing]
[Price: My gift to you, $47/month, By invitation only]
[Description: 2-3 lines max]
[CTA Button: Get The Guide, Start Today, Join Waitlist]
```

### Design System Requirements
- ✅ NO rounded corners (sharp edges only)
- ✅ Luxury black (#171719) / white (#F1F1F1) / gray (#B5B5B3) palette
- ✅ Bodoni headers, Inter body text
- ✅ Mobile-first responsive (1 col mobile, 3 col desktop)
- ✅ Luxury hover effects with smooth transitions
- ✅ Proper z-index layering for text readability

### Technical Specs
- **Height:** 500px consistent
- **Spacing:** 8px gap between cards
- **Typography:** 
  - Numbers: Small, uppercase, tracked
  - Titles: Bodoni, 32px, light weight
  - Prices: Bodoni, 24px, italic
  - Descriptions: Inter, 16px, line-height 1.5
- **Buttons:** Luxury white buttons with black text, hover to invert

### Example Images to Use
1. **Free Guide:** `https://i.postimg.cc/50bQ0Frk/out-0-20.webp`
2. **Studio:** `https://i.postimg.cc/fLc7qNG1/out-0-12.webp`  
3. **Big Thing:** `https://i.postimg.cc/9ftzvQfP/out-0-18.webp`

## INSPIRATION
Think luxury magazine editorial meets e-commerce product cards. The selfies should feel like fashion editorials with text that's impossible to miss.

## CURRENT PLACEHOLDER
A basic gray placeholder is showing now at `/src/components/OfferCard.tsx`

## NEXT STEPS
1. Victoria designs the perfect OfferCard component
2. Replace placeholder with Victoria's design
3. Test on homepage
4. Ensure text displays properly with selfie backgrounds

---

**Note:** This is the final piece needed to complete the homepage offers section. All the content and structure is ready - just needs Victoria's luxury design touch.
