-- SSELFIE Platform Database Schema
-- Run this in your Supabase SQL editor

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create custom types
CREATE TYPE subscription_tier AS ENUM ('free', 'premium', 'enterprise');
CREATE TYPE content_status AS ENUM ('draft', 'scheduled', 'published', 'archived');
CREATE TYPE content_type AS ENUM ('post', 'story', 'reel', 'video', 'blog');
CREATE TYPE platform AS ENUM ('instagram', 'tiktok', 'youtube', 'linkedin', 'blog');

-- Profiles table (extends Supabase auth.users)
CREATE TABLE profiles (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE NOT NULL,
  email TEXT NOT NULL,
  full_name TEXT,
  avatar_url TEXT,
  bio TEXT,
  website TEXT,
  instagram_handle TEXT,
  tiktok_handle TEXT,
  youtube_handle TEXT,
  linkedin_handle TEXT,
  goals TEXT[],
  interests TEXT[],
  is_verified BOOLEAN DEFAULT FALSE,
  subscription_tier subscription_tier DEFAULT 'free',
  onboarding_completed BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Glow Checks table
CREATE TABLE glow_checks (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  date DATE NOT NULL,
  energy_level INTEGER CHECK (energy_level >= 1 AND energy_level <= 10) NOT NULL,
  mood_rating INTEGER CHECK (mood_rating >= 1 AND mood_rating <= 10) NOT NULL,
  skin_quality INTEGER CHECK (skin_quality >= 1 AND skin_quality <= 10) NOT NULL,
  sleep_hours DECIMAL(3,1) CHECK (sleep_hours >= 0 AND sleep_hours <= 24) NOT NULL,
  water_intake INTEGER CHECK (water_intake >= 0) NOT NULL, -- in ml
  exercise_minutes INTEGER CHECK (exercise_minutes >= 0) NOT NULL,
  notes TEXT,
  photo_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, date)
);

-- Content Calendar table
CREATE TABLE content_calendar (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  title TEXT NOT NULL,
  content_type content_type NOT NULL,
  platform platform NOT NULL,
  scheduled_date TIMESTAMPTZ NOT NULL,
  status content_status DEFAULT 'draft',
  content TEXT,
  media_urls TEXT[],
  hashtags TEXT[],
  ai_generated BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Wellness Tracking table
CREATE TABLE wellness_tracking (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  date DATE NOT NULL,
  weight DECIMAL(5,2) CHECK (weight > 0),
  body_fat_percentage DECIMAL(4,1) CHECK (body_fat_percentage >= 0 AND body_fat_percentage <= 100),
  muscle_mass DECIMAL(5,2) CHECK (muscle_mass > 0),
  steps INTEGER CHECK (steps >= 0),
  calories_burned INTEGER CHECK (calories_burned >= 0),
  meditation_minutes INTEGER CHECK (meditation_minutes >= 0),
  journal_entry TEXT,
  gratitude_notes TEXT[],
  goals_completed TEXT[],
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, date)
);

-- Row Level Security (RLS) Policies
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE glow_checks ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_calendar ENABLE ROW LEVEL SECURITY;
ALTER TABLE wellness_tracking ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can view own profile" ON profiles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can update own profile" ON profiles FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own profile" ON profiles FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Glow checks policies
CREATE POLICY "Users can view own glow checks" ON glow_checks FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own glow checks" ON glow_checks FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own glow checks" ON glow_checks FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own glow checks" ON glow_checks FOR DELETE USING (auth.uid() = user_id);

-- Content calendar policies
CREATE POLICY "Users can view own content" ON content_calendar FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own content" ON content_calendar FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own content" ON content_calendar FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own content" ON content_calendar FOR DELETE USING (auth.uid() = user_id);

-- Wellness tracking policies
CREATE POLICY "Users can view own wellness data" ON wellness_tracking FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own wellness data" ON wellness_tracking FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own wellness data" ON wellness_tracking FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own wellness data" ON wellness_tracking FOR DELETE USING (auth.uid() = user_id);

-- Functions
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (user_id, email, full_name)
  VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data->>'full_name');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to create profile on user signup
CREATE OR REPLACE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Update triggers for updated_at columns
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_content_calendar_updated_at
  BEFORE UPDATE ON content_calendar
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Indexes for performance
CREATE INDEX idx_profiles_user_id ON profiles(user_id);
CREATE INDEX idx_glow_checks_user_id ON glow_checks(user_id);
CREATE INDEX idx_glow_checks_date ON glow_checks(date);
CREATE INDEX idx_content_calendar_user_id ON content_calendar(user_id);
CREATE INDEX idx_content_calendar_scheduled_date ON content_calendar(scheduled_date);
CREATE INDEX idx_wellness_tracking_user_id ON wellness_tracking(user_id);
CREATE INDEX idx_wellness_tracking_date ON wellness_tracking(date);
