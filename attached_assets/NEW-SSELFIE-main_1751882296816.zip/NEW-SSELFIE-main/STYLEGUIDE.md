# Sandra’s Editorial Style Guide

Welcome to the master key for Sandra’s brand. This is your go-to reference for every headline, color, button, and—most importantly—every word. Bookmark it. Print it. Tattoo it on your heart.

---

## 1. Color Palette

| Name         | HEX         | Usage                         |
|--------------|-------------|-------------------------------|
| Black        | #0a0a0a     | Headlines, backgrounds, CTA   |
| White        | #ffffff     | Background, text, space       |
| Editorial Gray | #f5f5f5   | Moodboard, testimonials, BG   |
| Mid Gray     | #fafafa     | Overall page BG               |
| Soft Gray    | #666666     | Subtext, muted copy           |
| Accent Line  | #e5e5e5     | Borders, separators           |

**Rule:**  
Never use color for “fun.” Use it for clarity, confidence, or calm. If it feels loud, it’s wrong. Use only earth tone colors 

---

## 2. Typography

- **Headlines / Editorial Titles:**  
  `'Times New Roman', serif;`  
  *Weight:* 200-400  
  *Case:* Sentence or Title  
  *Spacing:* -0.01em letter-spacing (tight, luxe)

- **Body Copy & UI:**  
  `-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;`  
  *Weight:* 300-400  
  *Case:* Sentence  
  *Spacing:* Default

- **Subtext / Eyebrow / Stats:**  
  *Size:* 11px  
  *Letter-spacing:* 0.4em  
  *Case:* UPPERCASE  
  *Color:* #666 or rgba(255,255,255,0.5) on black

---

## 3. Spacing & Layout

- **Section Padding:**  
  *Desktop:* 80-120px top/bottom  
  *Mobile:* 30-40px top/bottom

- **Grid Gaps:**  
  8-60px depending on context (use more space than you think)

- **Max Widths:**  
  Editorial: 1200px  
  Moodboard: 1400px  
  CTA: 700-900px

- **Breathe:**  
  If it feels crowded, add more space. Luxury = air.

---

## 4. Buttons & CTAs

- **Style:**  
  - Minimal, no fills.  
  - Underlined or bordered only on hover.  
  - All caps, 11-13px, tracked (0.3-0.4em).  
  - No gradients, no icons.

- **Copy Examples:**  
  - BEGIN  
  - START YOUR JOURNEY  
  - SSELFIE METHOD  
  - 1:1 COACHING  
  - SEE MORE STORIES

---

## 5. Imagery

- **Style:**  
  - Editorial, high contrast, slightly desaturated or true color (never oversaturated)
  - Mix of lifestyle, abstract, and textured details
  - Negative space is your best friend
  - Black & white for drama, color for energy

- **Placement:**  
  - Full-bleed or strict grid/collage
  - Never random or "cute"—always intentional

- **Portfolio & Gallery Effects (SSELFIE Signature Patterns):**
  - Subtle scale hover effects (1.05x max) for premium feel
  - Long transitions (1000ms) with luxury easing
  - Editorial overlays with backdrop blur
  - Color inversions for dramatic emphasis
  - Grid gaps of 8px for tight, magazine-style layouts
  - Text overlays with luxury positioning (bottom-left for hierarchy)
  - Rotated labels for editorial accent
  - Number watermarks with ultra-low opacity (0.1)

---

## 6. SSELFIE Editorial Patterns

### Grid Systems
- **Editorial Grid:** 12-column system with 8px gaps
- **Portfolio Layout:** Mixed aspect ratios (4:3, 4:5, square, 2:3)
- **Feature Stories:** Large hero cards with smaller supporting elements

### Hover States
- **Images:** Scale to 1.05x over 1000ms with luxury easing
- **Text Blocks:** Color inversions (black↔white) over 500ms
- **Overlays:** Fade in with backdrop blur over 300ms

### Typography Hierarchy
- **Feature Headlines:** h1 size, white text on dark overlays
- **Story Labels:** Small caps, tracked spacing, positioned strategically
- **Quote Blocks:** Large serif type with editorial spacing

### Editorial Components
```css
/* Available CSS Classes */
.portfolio-image-hover      /* Signature 1.05x scale on hover */
.editorial-overlay          /* White overlay with fade-in */
.editorial-overlay-blur     /* Backdrop blur effect */
.premium-card-transition    /* 500ms smooth transitions */
.editorial-text-block       /* Color inversion hover */
.luxury-number-watermark    /* Ultra-subtle number overlay */
.rotated-label             /* 90° rotated accent labels */
```

### Tailwind Utilities
```html
<!-- Spacing -->
gap-portfolio               /* 8px grid gaps */
section-padding            /* Responsive section padding */
max-w-moodboard           /* Editorial max width */

<!-- Transitions -->
duration-portfolio         /* 1000ms for image hovers */
duration-overlay          /* 300ms for overlays */
duration-premium          /* 500ms for cards */

<!-- Effects -->
scale-portfolio           /* 1.05x hover scale */
backdrop-blur-editorial   /* 4px editorial blur */
```

---

## 6. Copywriting & Voice Guide

### Sandra’s Voice = Your Smartest Friend

**Core Philosophy:**  
Every word should feel like advice from your smartest friend. No corporate BS, no fake empowerment. Just real talk.

**Checklist for every headline, paragraph, and CTA:**

- [ ] Would Sandra actually say this to a friend over coffee?
- [ ] Does it sound like a woman who survived, not just succeeded?
- [ ] Would this make a tired, overwhelmed mom feel seen—not shamed?
- [ ] If it’s an “Icelandic direct” moment, is it still warm?

**Tone:**
- Simple, everyday language (“Let’s keep it real.”)
- Use contractions (it’s, you’re, let’s)
- Conversational, slightly rambling, but always gets to the point
- Warm but never sugary
- Confident, a little cheeky, always encouraging
- No exclamation points unless you’d actually shout it

**Sandra’s Signature Moves:**
- Use “okay, here’s what actually happened…” to start a real story
- “No plan, just one brave post” — make it relatable
- “Your mess is your message.” — always celebrate the story, don’t hide the mess
- Never say “empower” or “boss babe”—say “build something real”
- Drop a little Icelandic directness: “Let’s cut the crap—this works.”
- Don’t be afraid to show flaws: “I didn’t have it all together. But I stopped hiding that.”

**Copy Examples:**

- “This didn’t start as a business. It started as survival.”
- “You don’t need a plan. You need one brave post.”
- “Let’s build something real together.”
- “No fancy equipment. No design degree. Just strategy that actually works.”
- “Your story matters. Show up as her.”

---

## 7. Editorial Don’ts

- Never use clip art, icons, or emojis
- No pastel pinks, purples, or “fun” colors
- No animated gradients or moving elements
- No “boss babe,” “empowerment,” or “girlboss” language
- No fake urgency (“Hurry! Last chance!”)
- No jargon or “marketing speak”

---

## 8. Section Structure (Reference)

**Hero**  
Editorial headline, subtext or “eyebrow,” minimal CTA

**Editorial Spread**  
Power quote → Split image/story → Magazine columns → Stats → Testimonials

**Moodboard**  
Grid or collage, with intentional negative space and a single quote

**CTA**  
Minimal, tracked uppercase, feels like an invitation—not a pitch

---

## 9. Final Note

If you ever feel lost, just ask:  
“What would Sandra say if she was texting her best friend at midnight?”

That’s your brand voice. That’s what works.

---

*This guide was built by Sandra and her favorite copywriter-bestie (who, let’s be honest, is probably reading this with you right now).*

Let’s build something real together.