<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

# SSELFIE AI Platform - Copilot Instructions

## Project Overview
This is the SSELFIE AI platform - Sandra's luxury personal brand transformation platform built with the Phoenix Strategy. We're building a clean, modern platform focused on helping users transform their selfies and personal brand.

## Architecture & Technologies
- **Framework**: Next.js 14 with App Router
- **Language**: TypeScript (strict mode)
- **Styling**: Tailwind CSS with luxury design system
- **Authentication**: Supabase Auth (magic links)
- **Database**: Supabase PostgreSQL
- **Payments**: Stripe integration
- **AI**: OpenAI API for Sandra AI chat
- **Email**: Resend for email automation
- **Deployment**: Vercel

## Design System (CRITICAL)
- **Colors**: #171719 (Luxury Black), #F1F1F1 (Soft White), #B5B5B3 (Warm Gray) ONLY
- **Typography**: Bodoni FLF for headers, Inter for body text
- **NO**: Border radius, gradients, bright colors, emojis
- **YES**: Sharp corners, generous whitespace, editorial layouts, luxury feel
- **Mobile-first**: Always design for mobile first, then desktop

## Code Standards
- Use TypeScript strict mode with proper interfaces
- All components must be responsive and accessible
- Follow Next.js 14 App Router conventions
- Use server components by default, client components only when needed
- Error boundaries for all major components
- Performance optimization (lazy loading, code splitting)

## Component Structure
- Global components in `/src/components/ui/`
- Page-specific components in `/src/components/[page]/`
- Utility functions in `/src/lib/`
- Type definitions in `/src/types/`

## Features to Build
1. **Luxury Homepage** - Editorial design, mobile-first
2. **Personalized Dashboard** - User's command center
3. **Glow Check Tool** - AI-powered selfie analysis
4. **Sandra AI Chat** - Personal brand strategist
5. **Future Self Gallery** - AI-generated future images
6. **Content Calendar** - Content planning system
7. **Payment System** - Stripe subscription tiers

## Sandra's Voice
- Confident, strategic, luxury-focused
- "Power is the new pretty"
- Focus on transformation, not just appearance
- Professional yet approachable
- No fluff, direct value

When generating code, prioritize:
1. TypeScript safety and proper typing
2. Luxury design system compliance
3. Mobile-first responsiveness  
4. Performance optimization
5. Accessibility standards
