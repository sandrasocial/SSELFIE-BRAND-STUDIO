# SSELFIE ORGANIZATION & CLEANUP PLAN
*Diana's Strategic Repository Organization*
*Date: June 26, 2025*

## 🎯 MISSION: ORGANIZE FOR SUCCESS

Transform this workspace into a clean, organized foundation for Sandra's Claude Victoria design workflow and the SSELFIE Mastery Program launch.

## 📊 CURRENT STATE ANALYSIS

### ✅ WHAT'S WORKING (Keep & Enhance)
- Next.js 14 App Router structure is solid
- Supabase integration is set up
- Basic page structure exists
- TypeScript configuration is good

### 🔄 WHAT NEEDS ORGANIZING
- Scattered legacy files (fix-*.js scripts)
- Mixed page states (some placeholders, some old versions)
- No clear distinction between ready vs placeholder pages
- Missing key business model pages

### 🗑️ WHAT TO ARCHIVE
- Development fix scripts (move to `/archive/dev-scripts/`)
- Old page versions (move to `/archive/old-pages/`)
- Unused configuration files

## 🏗️ NEW ORGANIZATION STRUCTURE

### Core Business Pages (Priority Order)
```
src/app/
├── page.tsx                    # Homepage (READY - Keep existing)
├── about/page.tsx              # About (READY - Keep existing)
├── pricing/page.tsx            # Pricing (PLACEHOLDER - Redesign needed)
├── freebie/
│   └── selfie-guide/page.tsx   # Free Guide (PLACEHOLDER - New design)
├── membership/
│   ├── page.tsx                # SSELFIE Mastery Program (NEW - CRITICAL)
│   ├── checkout/page.tsx       # Checkout Flow (NEW - CRITICAL)
│   └── thank-you/page.tsx      # Success Page (NEW)
├── tools/
│   ├── pose-coach/page.tsx     # Pose Coach (MIGRATE from old repo)
│   ├── glow-check/page.tsx     # Glow Check (MIGRATE from old repo)
│   └── future-self/page.tsx    # Future Self Generator (PLACEHOLDER)
├── dashboard/
│   ├── page.tsx                # Member Dashboard (PLACEHOLDER)
│   ├── profile/page.tsx        # Profile Settings (PLACEHOLDER)
│   └── billing/page.tsx        # Subscription Management (PLACEHOLDER)
├── login/page.tsx              # Auth (READY - Keep existing)
└── api/                        # API Routes (Enhance existing)
```

### Component Organization
```
src/components/
├── global/                     # Shared components (READY)
├── business/                   # Business logic components
│   ├── MembershipOffer.tsx     # SSELFIE Mastery Program offer
│   ├── PricingCards.tsx        # Subscription options
│   ├── UsageTracker.tsx        # API usage limits
│   └── PaymentFlow.tsx         # Stripe integration
├── tools/                      # Tool-specific components
│   ├── PoseCoach.tsx           # Pose coaching interface
│   ├── GlowCheck.tsx           # Glow analysis tool
│   └── FutureSelf.tsx          # AI selfie generation
├── dashboard/                  # Member dashboard components
└── marketing/                  # Marketing page components
```

### Archive Structure
```
archive/
├── dev-scripts/                # All fix-*.js files
├── old-pages/                  # Legacy page versions
└── unused-configs/             # Unused configuration files
```

## 🚀 IMPLEMENTATION PHASES

### Phase 1: Clean & Archive (30 minutes)
1. Move all `fix-*.js` files to `/archive/dev-scripts/`
2. Move `page-old-victoria.tsx` to `/archive/old-pages/`
3. Identify and archive unused files
4. Clean up root directory

### Phase 2: Business Model Pages (2 hours)
1. Create `/membership/` directory with core business pages
2. Create placeholder structure for SSELFIE Mastery Program
3. Set up checkout and payment flow placeholders
4. Design member dashboard structure

### Phase 3: Tool Migration Planning (1 hour)
1. Audit existing tools in old repo
2. Create migration plan for Pose Coach
3. Create migration plan for Glow Check
4. Plan Future Self Generator integration

### Phase 4: Claude Victoria Workflow Setup (1 hour)
1. Create clear placeholder templates
2. Set up design requirements documentation
3. Create paste-and-replace workflow
4. Test integration process

## 📋 DETAILED ACTION ITEMS

### 1. IMMEDIATE CLEANUP
- [ ] Archive development scripts
- [ ] Remove duplicate page versions
- [ ] Clean up root directory
- [ ] Update .gitignore for archive folder

### 2. BUSINESS MODEL IMPLEMENTATION
- [ ] Create `/membership/` page structure
- [ ] Design SSELFIE Mastery Program landing page placeholder
- [ ] Set up Stripe integration placeholders
- [ ] Create usage tracking system placeholders

### 3. TOOL INTEGRATION
- [ ] Migrate Pose Coach from old repo
- [ ] Migrate Glow Check with Safari bug fix
- [ ] Create Future Self Generator placeholder
- [ ] Set up API usage limiting

### 4. MEMBER EXPERIENCE
- [ ] Design member dashboard placeholder
- [ ] Create profile management placeholder
- [ ] Set up billing management placeholder
- [ ] Plan member onboarding flow

## 🎨 CLAUDE VICTORIA INTEGRATION WORKFLOW

### Page Status System
Each page will have clear status indicators:
- `🟢 READY` - Production ready, designed by Claude Victoria
- `🟡 PLACEHOLDER` - Awaiting Claude Victoria design
- `🔴 NEEDS MIGRATION` - Requires migration from old repo
- `🔵 NEW FEATURE` - Brand new functionality needed

### Placeholder Template
Every placeholder page will include:
- Clear design requirements
- Business context and goals
- Reference to existing brand examples
- Step-by-step implementation instructions
- Success criteria

### Design Requirements Document
For each page Sandra designs with Claude Victoria:
- Target audience and use case
- Conversion goals and CTAs
- Integration requirements
- Mobile-first considerations
- Brand compliance checklist

## 💰 BUSINESS MODEL INTEGRATION

### SSELFIE Mastery Program Structure
- **Landing Page**: Showcase complete system value
- **Pricing Options**: Monthly/Annual/Lifetime with usage limits
- **Feature Overview**: All tools and training included
- **Member Testimonials**: Social proof and success stories
- **FAQ Section**: Address common concerns
- **Risk Reversal**: Guarantee and refund policy

### Revenue Optimization
- **Usage Tracking**: Monitor API costs per member
- **Upgrade Prompts**: Encourage annual subscriptions
- **Add-on Services**: Premium support, 1:1 coaching
- **Affiliate Program**: Partner revenue sharing
- **Corporate Packages**: Team subscriptions

## 🔧 TECHNICAL INFRASTRUCTURE

### API Integration
- Stripe for payment processing
- Supabase for user management
- Usage tracking for AI tools
- Email automation for onboarding
- Analytics for conversion optimization

### Performance Optimization
- Image optimization for all selfie tools
- Lazy loading for member content
- Caching for frequently accessed data
- Mobile-first responsive design
- Core Web Vitals optimization

## 📈 SUCCESS METRICS

### Immediate Goals (Week 1)
- Clean, organized repository structure
- All placeholder pages created
- Migration plan documented
- Claude Victoria workflow tested

### Business Goals (Week 2-3)
- SSELFIE Mastery Program pages designed
- Payment flow implemented
- Member dashboard functional
- Tools migrated and working

### Growth Goals (Month 1)
- First paying members onboarded
- Usage tracking operational
- Member retention optimized
- Revenue reporting automated

---

**NEXT STEP**: Sandra approves this plan, then DIANA executes the cleanup and creates all placeholder pages for Claude Victoria design sessions.

*"We're not just organizing code - we're building the foundation for SSELFIE's $350K+ revenue transformation."* - DIANA
