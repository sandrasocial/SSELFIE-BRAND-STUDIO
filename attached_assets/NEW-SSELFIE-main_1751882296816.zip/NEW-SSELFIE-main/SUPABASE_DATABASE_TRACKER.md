# SSELFIE SUPABASE DATABASE STRUCTURE TRACKER
*DIANA & MAYA Database Management*
*Updated: June 26, 2025*

## 🎯 CURRENT STATUS: DESIGN PHASE (Mock Data Only)

**IMPORTANT**: We are in **DESIGN FIRST** mode. All pages use mock data until Week 3.

## 📋 MOCK DATA STRUCTURE (For Claude Victoria Designs)

### User Mock Data
```typescript
const MOCK_USER = {
  id: "user_123",
  name: "Sarah Johnson",
  email: "sarah@example.com",
  avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786",
  joined: "2025-06-01",
  timezone: "America/New_York"
}
```

### Subscription Mock Data
```typescript
const MOCK_SUBSCRIPTION = {
  plan: "monthly", // monthly | annual | lifetime
  status: "active", // active | canceled | past_due
  amount: 47,
  nextBilling: "2025-07-26",
  billingHistory: [
    { date: "2025-06-26", amount: 47, status: "paid" },
    { date: "2025-05-26", amount: 47, status: "paid" }
  ]
}
```

### Usage Tracking Mock Data
```typescript
const MOCK_USAGE = {
  aiGenerations: {
    used: 23,
    limit: 50,
    resetDate: "2025-07-01"
  },
  features: {
    poseCoach: { used: 15, unlimited: true },
    glowCheck: { used: 8, unlimited: true },
    communityAccess: true,
    monthlyTemplates: { downloaded: 3, available: 5 }
  }
}
```

### Training Progress Mock Data
```typescript
const MOCK_TRAINING = {
  totalModules: 6,
  completedModules: 2,
  progressPercentage: 33,
  modules: [
    { id: 1, title: "Understanding Your Brand", completed: true, completedAt: "2025-06-15" },
    { id: 2, title: "Camera Basics & Settings", completed: true, completedAt: "2025-06-20" },
    { id: 3, title: "Advanced Posing Techniques", completed: false },
    { id: 4, title: "Lighting & Environment", completed: false },
    { id: 5, title: "Content Strategy", completed: false },
    { id: 6, title: "Building Your Empire", completed: false }
  ]
}
```

## 🗄️ FUTURE DATABASE STRUCTURE (Week 3 Implementation)

### Authentication Tables (Supabase Built-in)
```sql
-- auth.users (Supabase managed)
-- We'll extend with profiles table
```

### Core Business Tables
```sql
-- User Profiles (extends auth.users)
CREATE TABLE profiles (
  id UUID REFERENCES auth.users(id) PRIMARY KEY,
  full_name TEXT,
  avatar_url TEXT,
  timezone TEXT DEFAULT 'America/New_York',
  onboarding_completed BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Subscription Management
CREATE TABLE subscriptions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  stripe_customer_id TEXT UNIQUE,
  stripe_subscription_id TEXT UNIQUE,
  plan_type TEXT CHECK (plan_type IN ('monthly', 'annual', 'lifetime')),
  status TEXT CHECK (status IN ('active', 'canceled', 'past_due', 'incomplete')),
  current_period_start TIMESTAMP WITH TIME ZONE,
  current_period_end TIMESTAMP WITH TIME ZONE,
  cancel_at_period_end BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Usage Tracking
CREATE TABLE usage_tracking (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  month_year TEXT, -- Format: '2025-06'
  ai_generations_used INTEGER DEFAULT 0,
  ai_generations_limit INTEGER DEFAULT 50,
  feature_usage JSONB DEFAULT '{}', -- Track other feature usage
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  UNIQUE(user_id, month_year)
);

-- Training Progress
CREATE TABLE training_progress (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  module_id INTEGER,
  module_title TEXT,
  completed BOOLEAN DEFAULT false,
  completed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  UNIQUE(user_id, module_id)
);

-- Payment History
CREATE TABLE payment_history (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  stripe_payment_intent_id TEXT UNIQUE,
  amount INTEGER, -- Amount in cents
  currency TEXT DEFAULT 'usd',
  status TEXT CHECK (status IN ('succeeded', 'failed', 'pending')),
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### Row Level Security (RLS) Policies
```sql
-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE usage_tracking ENABLE ROW LEVEL SECURITY;
ALTER TABLE training_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_history ENABLE ROW LEVEL SECURITY;

-- Users can only see/edit their own data
CREATE POLICY "Users can view own profile" ON profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can view own subscription" ON subscriptions
  FOR SELECT USING (auth.uid() = user_id);

-- Similar policies for other tables...
```

## 📊 API USAGE LIMITS BY PLAN

```typescript
const PLAN_LIMITS = {
  monthly: {
    aiGenerations: 50,
    price: 47,
    features: ['poseCoach', 'glowCheck', 'community', 'templates']
  },
  annual: {
    aiGenerations: 75,
    price: 297,
    features: ['poseCoach', 'glowCheck', 'community', 'templates', 'prioritySupport']
  },
  lifetime: {
    aiGenerations: 100,
    price: 497,
    features: ['poseCoach', 'glowCheck', 'community', 'templates', 'prioritySupport', 'exclusiveContent']
  }
}
```

## 🔄 DATABASE IMPLEMENTATION TIMELINE

### Week 1 (DESIGN PHASE) - CURRENT
- ✅ Use mock data in all components
- ✅ No database dependencies
- ✅ Focus purely on UX design with Claude Victoria

### Week 2 (BASIC AUTH + PAYMENTS)
- [ ] Create new clean Supabase project
- [ ] Set up basic authentication (email/password)
- [ ] Create minimal profiles table
- [ ] Integrate Stripe for payments
- [ ] Basic subscription tracking

### Week 3 (FULL DATABASE IMPLEMENTATION)
- [ ] Implement complete schema above
- [ ] Add usage tracking functionality
- [ ] Set up training progress tracking
- [ ] Implement payment history
- [ ] Add RLS policies
- [ ] Data migration if needed

## 🔧 MAYA'S TECHNICAL NOTES

### Environment Variables Needed (Week 2)
```bash
# Supabase
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=

# Stripe
STRIPE_PUBLISHABLE_KEY=
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=

# API Keys (Week 3)
REPLICATE_API_TOKEN=  # For AI generation
RESEND_API_KEY=       # For emails
```

### Migration Strategy
1. **Fresh Start**: New Supabase project (no legacy data)
2. **Clean Schema**: Purpose-built for SSELFIE Mastery Program
3. **Usage Tracking**: Built-in from day one
4. **Scalable**: Designed for 1000+ members

## 📝 DEVELOPMENT NOTES

### Current Mock Data Files
- `/lib/mock-data.ts` - All mock data for components
- Components import from this single source
- Easy to replace with real API calls later

### Database Functions Needed (Week 3)
```sql
-- Function to check usage limits
CREATE OR REPLACE FUNCTION check_usage_limit(user_id UUID, feature_type TEXT)
RETURNS BOOLEAN AS $$
-- Implementation details
$$ LANGUAGE plpgsql;

-- Function to increment usage
CREATE OR REPLACE FUNCTION increment_usage(user_id UUID, feature_type TEXT)
RETURNS BOOLEAN AS $$
-- Implementation details
$$ LANGUAGE plpgsql;
```

## 🚨 IMPORTANT REMINDERS

### For DIANA:
- ✅ All placeholder pages use mock data
- ✅ No database calls in Week 1
- ✅ Focus on Claude Victoria designs

### For MAYA:
- 🔄 Prepare Supabase setup for Week 2
- 🔄 Plan Stripe integration strategy
- 🔄 Design API structure for usage tracking

### For SANDRA:
- 🎯 Design with realistic mock data
- 🎯 Don't worry about database until Week 3
- 🎯 Focus on conversion optimization

---

**Next Update**: After Week 1 designs are complete
**Database Setup**: Week 2 (basic auth + payments)
**Full Implementation**: Week 3 (complete schema)

*DIANA's Database Strategy: Design → Revenue → Perfect Implementation*
