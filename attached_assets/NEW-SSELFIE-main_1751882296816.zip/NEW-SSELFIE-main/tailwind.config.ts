import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        // SSELFIE Luxury Color Palette - THESE ARE THE ONLY COLORS ALLOWED
        'luxury-black': '#171719',
        'soft-white': '#F1F1F1', 
        'warm-gray': '#B5B5B3',
        'pure-white': '#FFFFFF',
        // Editorial color tokens from globals-clean.css
        'editorial-gray': '#f5f5f5',
        'mid-gray': '#fafafa',
        'soft-gray': '#666666',
        'accent-line': '#e5e5e5',
        // Semantic color mapping
        background: '#F1F1F1',
        foreground: '#171719',
        border: '#B5B5B3',
        ring: '#171719',
      },
      fontFamily: {
        // Typography system - Updated to match admin resources
        'bodoni': ['Bodoni Moda', 'Georgia', 'serif'], // Headers (updated to match admin resources)
        'playfair': ['Playfair Display', 'Georgia', 'serif'], // Editorial accent font
        'inter': ['Inter', '-apple-system', 'BlinkMacSystemFont', 'sans-serif'], // Body text
        'bebas': ['Bebas Neue', 'Impact', 'Arial Black', 'sans-serif'], // Stats and bold numbers
        'sans': ['Inter', '-apple-system', 'BlinkMacSystemFont', 'sans-serif'],
        'serif': ['Bodoni Moda', 'Georgia', 'serif'],
      },
      fontSize: {
        'display': ['4rem', { lineHeight: '1.1', letterSpacing: '-0.04em' }],
        'h1': ['3rem', { lineHeight: '1.2', letterSpacing: '-0.04em' }],
        'h2': ['2.25rem', { lineHeight: '1.3', letterSpacing: '-0.04em' }],
        'h3': ['1.875rem', { lineHeight: '1.4', letterSpacing: '-0.04em' }],
        'h4': ['1.5rem', { lineHeight: '1.4' }],
        'large': ['1.25rem', { lineHeight: '1.5' }],
        'base': ['1rem', { lineHeight: '1.6' }],
        'small': ['0.875rem', { lineHeight: '1.5' }],
        'tiny': ['0.75rem', { lineHeight: '1.4' }],
      },
      spacing: {
        '15': '3.75rem', // 60px
        '18': '4.5rem',  // 72px
        '22': '5.5rem',  // 88px
        '26': '6.5rem',  // 104px
        '30': '7.5rem',  // 120px
        '34': '8.5rem',  // 136px
        '38': '9.5rem',  // 152px
        '42': '10.5rem', // 168px
        'section-mobile': '2.25rem',    // 36px
        'section-desktop': '6.25rem',   // 100px
        'grid-gap': '2rem',             // 32px
        'portfolio-gap': '0.5rem',      // 8px for portfolio grids
      },
      borderRadius: {
        // NO BORDER RADIUS - Sharp corners only for luxury aesthetic
        'none': '0',
      },
      transitionDuration: {
        '400': '400ms',
        '600': '600ms',
        '800': '800ms',
        'portfolio': '1000ms',    // Portfolio image hover
        'overlay': '300ms',       // Overlay transitions
        'premium': '500ms',       // Premium card transitions
      },
      transitionTimingFunction: {
        'luxury': 'cubic-bezier(0.16, 1, 0.3, 1)',
        'sharp': 'cubic-bezier(0.4, 0, 0.2, 1)',
      },
      transitionDelay: {
        '100': '100ms',
      },
      transitionProperty: {
        'width': 'width',
        'left': 'left',
      },
      backgroundImage: {
        'shimmer': 'linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1) 50%, transparent)',
      },
      boxShadow: {
        'lift': '0 20px 40px -20px rgba(23, 23, 25, 0.3)',
        'focus': '0 0 0 2px #F1F1F1, 0 0 0 4px #171719',
      },
      animation: {
        'fade-in': 'fadeIn 0.6s ease-in-out',
        'slide-up': 'slideUp 0.8s ease-out',
        'fadeInUp': 'fadeInUp 0.8s ease-out forwards',
        'float': 'float 3s ease-in-out infinite',
        'luxury-spin': 'luxury-spin 1s cubic-bezier(0.16, 1, 0.3, 1) infinite',
        'loading-slide': 'loading-slide 2s ease-in-out infinite',
        'portfolio-hover': 'portfolio-scale 1000ms ease',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(20px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        fadeInUp: {
          '0%': { transform: 'translateY(20px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        'luxury-spin': {
          'to': { transform: 'rotate(360deg)' }
        },
        'loading-slide': {
          '0%': { left: '-30%' },
          '100%': { left: '100%' },
        },
        'portfolio-scale': {
          '0%': { transform: 'scale(1)' },
          '100%': { transform: 'scale(1.05)' },
        },
      },
      transformOrigin: {
        'left': 'left',
        'right': 'right',
      },
      blur: {
        'xl': '20px',
      },
      scale: {
        '98': '0.98',
        '101': '1.01',
        '102': '1.02',
        'portfolio': '1.05',      // Portfolio hover scale
      },
      opacity: {
        '80': '0.8',
        '90': '0.9',
        '95': '0.95',
      },
      zIndex: {
        '2': '2',
      },
      screens: {
        'xs': '475px',
      },
      maxWidth: {
        'editorial': '75rem',     // 1200px
        'moodboard': '87.5rem',   // 1400px
        'cta': '56.25rem',        // 900px
        'content': '65rem',       // 1040px
        'reading': '40rem',       // 640px for optimal reading
      },
    },
  },
  plugins: [
    // Custom utility classes for SSELFIE design system
    function({ addUtilities }: { addUtilities: (utilities: Record<string, any>) => void }) {
      const newUtilities = {
        '.transform-lift': {
          transform: 'translateY(-3px) scale(1.02)',
        },
        '.transform-subtle': {
          transform: 'translateY(-2px)',
        },
        '.transform-slide': {
          transform: 'translateX(4px)',
        },
        '.transform-press': {
          transform: 'translateY(-1px) scale(1.01)',
        },
        '.transform-center': {
          transform: 'translate(-50%, -50%)',
        },
        // Portfolio editorial effects - SSELFIE signature patterns
        '.portfolio-scale-hover': {
          transform: 'scale(1.05)',
          transition: 'transform 1000ms cubic-bezier(0.4, 0, 0.2, 1)',
        },
        '.portfolio-image-base': {
          transition: 'transform 1000ms cubic-bezier(0.4, 0, 0.2, 1)',
        },
        '.editorial-backdrop-blur': {
          backdropFilter: 'blur(2px)',
        },
        '.ease-luxury': {
          transitionTimingFunction: 'cubic-bezier(0.16, 1, 0.3, 1)',
        },
        '.transition-width': {
          transitionProperty: 'width',
        },
        '.transition-left': {
          transitionProperty: 'left',
        },
        '.grayscale-100': {
          filter: 'grayscale(100%)',
        },
        // Aspect ratio utilities for About page image containers
        '.aspect-square': {
          aspectRatio: '1 / 1',
        },
        '.aspect-\\[3\\/4\\]': {
          aspectRatio: '3 / 4',
        },
        '.aspect-\\[4\\/5\\]': {
          aspectRatio: '4 / 5',
        },
      }
      addUtilities(newUtilities)
    },
  ],
}

export default config