# Editorial Images

This folder contains all editorial images for the SSELFIE platform.

## Current Images Needed:
- rock-bottom-sandra.jpg - Used in BeginningStory component
- welcome-editorial.png - Used in WelcomeEditorial component

## Migration Status:
- Currently using external URLs
- Ready to move to local storage when images are provided

## Image Guidelines:
- Use descriptive names
- Optimize for web (WebP preferred)
- Maintain editorial luxury aesthetic
- Sharp, high-quality images only
