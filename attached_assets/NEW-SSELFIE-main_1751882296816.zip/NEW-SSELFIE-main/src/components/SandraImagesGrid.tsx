import React from "react";
import Image from "next/image";
import { SandraImages } from "@/components/sandra-image-library";

export const SandraImagesGrid = () => {
  // Pick images from each category for a true "Sandra moodboard" feel
  const images = [
    SandraImages.editorial.laptop1,
    SandraImages.editorial.laptop2,
    SandraImages.editorial.phone1,
    SandraImages.editorial.mirror,
    SandraImages.journey.rockBottom,
    SandraImages.journey.success,
    SandraImages.flatlays.workspace1,
    SandraImages.flatlays.beauty,
    SandraImages.aiGallery[0],
    SandraImages.aiGallery[1],
    SandraImages.aiGallery[2],
    SandraImages.aiGallery[3],
  ];

  return (
    <section className="section-padding bg-mid-gray">
      <div className="max-width-moodboard mx-auto px-6">
        <div className="mb-12 md:mb-16 text-center">
          <span className="section-label mb-6 block">
            SSELFIE MOODBOARD
          </span>
          <h2 className="h2 mb-6">
            The Editorial Grid
          </h2>
          <p className="body-copy text-soft-gray max-w-[600px] mx-auto">
            Real women. Real moments. A grid that feels like you—because it is.
          </p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 grid-gap">
          {images.map((src, i) => (
            <div
              key={i}
              className="relative aspect-[3/4] bg-white overflow-hidden group"
            >
              <Image
                src={src}
                alt={`Sandra grid image ${i + 1}`}
                fill
                className="editorial-image transition-transform duration-700 group-hover:scale-105"
                sizes="(max-width: 1024px) 100vw, 300px"
                priority={i < 4}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SandraImagesGrid;