import React from "react";
import Image from "next/image";
import { SandraImages } from "@/components/sandra-image-library";

export default function SignupGift() {
  return (
    <section className="section-padding bg-mid-gray">
      <div className="max-width-editorial mx-auto px-6">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          {/* Left: Image */}
          <div className="w-full lg:w-1/2 relative h-80 lg:h-96 overflow-hidden">
            <Image
              src={SandraImages.editorial.phone2}
              alt="Sandra Selfie Queen Guide"
              fill
              className="editorial-image"
              priority
              sizes="(max-width: 1024px) 100vw, 400px"
            />
            <div className="absolute inset-0 bg-black/20" />
          </div>

          {/* Right: Copy & Form */}
          <div className="w-full lg:w-1/2">
            <span className="section-label mb-6 block">My gift to you</span>
            <h2 className="h2 mb-6 max-w-xs">The Selfie Queen Guide</h2>
            <p className="body-copy text-soft-gray mb-8 max-w-md">
              Not just another PDF. This is everything I wish someone handed me
              when I started—angles, light, editing, confidence, and a challenge
              for when you&apos;re ready to show up for real. No fluff, no spam,
              just real value in your inbox.
            </p>

            <form
              className="flex flex-col sm:flex-row gap-4 mb-4"
              autoComplete="off"
            >
              <input
                type="email"
                placeholder="Your email"
                className="px-4 py-3 body-text border border-accent-line bg-white focus:outline-none focus:ring-2 focus:ring-black/20 flex-1"
                required
              />
              <button type="submit" className="cta-link whitespace-nowrap">
                Get the Guide
              </button>
            </form>

            <p className="body-copy text-soft-gray text-sm">
              No spam. Unsubscribe anytime. Your secrets are safe here.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}