import React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { cn } from '@/lib/utils';

interface ToolsMethodExplanationProps {
  title?: string;
  description?: string;
  quote?: string;
  imageSrc?: string;
  ctaText?: string;
  ctaLink?: string;
  className?: string;
}

export const ToolsMethodExplanation: React.FC<ToolsMethodExplanationProps> = ({
  title = "The Phoenix Method",
  description = "Behind every tool is Sandra's proven Phoenix Method — a strategic approach to brand building that transforms your personal story into your most powerful business asset. These tools work together to help you rise from the ashes of what was, into who you're meant to be.",
  quote = "Your tools should work as hard as you do.",
  imageSrc = "https://i.postimg.cc/HkNwfjh8/out-2-14.jpg", // Sandra teaching mode
  ctaText = "EXPLORE THE METHOD",
  ctaLink = "/method",
  className,
}) => {
  return (
    <section className={cn("bg-[#f5f5f5]", className)}>
      <div className="container mx-auto px-6 max-w-[1200px]">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-16 lg:gap-28 items-center">
          <div>
            <h2 className="font-bodoni text-[3.2rem] text-luxury-black mb-8 leading-tight">
              {title}
            </h2>
            <p className="text-[18px] md:text-[21px] text-[#666] mb-10 leading-relaxed">
              {description}
            </p>
            
            <p className="font-bodoni text-[32px] text-luxury-black italic mb-12">
              &ldquo;{quote}&rdquo;
            </p>
            
            <Link
              href={ctaLink}
              className={cn(
                "cta",
                "text-[13px] tracking-[0.3em] uppercase font-light text-luxury-black",
                "border-b-[1.5px] border-transparent hover:border-luxury-black",
                "transition-all duration-[0.22s]"
              )}
            >
              {ctaText}
            </Link>
          </div>
          
          {/* Image */}
          <div className="relative h-[480px] lg:h-[580px] w-full overflow-hidden">
            <Image
              src={imageSrc}
              alt="The Phoenix Method"
              fill
              className="object-cover object-center filter saturate-[0.95]"
            />
          </div>
        </div>
      </div>
    </section>
  );
};
