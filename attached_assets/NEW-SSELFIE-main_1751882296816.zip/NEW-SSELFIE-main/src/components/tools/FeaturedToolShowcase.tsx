import React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { cn } from '@/lib/utils';

interface FeaturedToolShowcaseProps {
  title?: string;
  description?: string;
  imageSrc?: string;
  ctaText?: string;
  ctaLink?: string;
  status?: 'new' | 'updated' | 'coming-soon';
  className?: string;
}

export const FeaturedToolShowcase: React.FC<FeaturedToolShowcaseProps> = ({
  title = "Show up as her",
  description = "Transform your everyday selfies into editorial brand moments that capture your essence. Our AI-powered Selfie Generator helps you create consistent, on-brand imagery without the need for professional photoshoots or complicated editing software.",
  imageSrc = "https://i.postimg.cc/Vk6M70XM/out-1_(20).jpg", // Sandra taking selfie
  ctaText = "START",
  ctaLink = "/tools/selfie-generator",
  status = 'new',
  className,
}) => {
  return (
    <section className={cn("bg-[#f5f5f5]", className)}>
      <div className="container mx-auto px-6 max-w-[1200px]">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-16 lg:gap-28 items-center">
          {/* Image */}
          <div className="relative h-[480px] lg:h-[640px] w-full overflow-hidden">
            <Image
              src={imageSrc}
              alt={title}
              fill
              className="object-cover hover:scale-[1.03] transition-transform duration-[0.4s] filter saturate-[0.95]"
              priority
            />
            <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/20" />
            
            {status && (
              <div className="absolute top-6 left-6 bg-luxury-black text-soft-white py-1 px-3 text-[10px] uppercase tracking-[0.2em]">
                {status === 'new' ? 'NEW' : 
                 status === 'updated' ? 'UPDATED' : 'COMING SOON'}
              </div>
            )}
          </div>
          
          {/* Content */}
          <div>
            <h2 className="font-bodoni text-[3.2rem] text-luxury-black mb-10 leading-tight">
              {title}
            </h2>
            <p className="text-[18px] md:text-[21px] text-[#666] mb-12 leading-relaxed">
              {description}
            </p>
            
            <Link
              href={ctaLink}
              className={cn(
                "cta",
                "text-[13px] tracking-[0.3em] uppercase font-light text-luxury-black",
                "border-b-[1.5px] border-transparent hover:border-luxury-black",
                "transition-all duration-[0.22s]",
                status === 'coming-soon' && "opacity-50 pointer-events-none"
              )}
            >
              {ctaText}
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};
