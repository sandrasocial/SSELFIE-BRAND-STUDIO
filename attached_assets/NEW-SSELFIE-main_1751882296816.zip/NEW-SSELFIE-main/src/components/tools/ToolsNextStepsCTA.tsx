import React from 'react';
import Link from 'next/link';
import { cn } from '@/lib/utils';

interface ToolsNextStepsCTAProps {
  title?: string;
  description?: string;
  quote?: string;
  ctaText?: string;
  ctaLink?: string;
  className?: string;
}

export const ToolsNextStepsCTA: React.FC<ToolsNextStepsCTAProps> = ({
  title = "Ready to transform your story?",
  description = "Start with one tool, or use them all. Your brand transformation begins with a single brave step.",
  quote = "You don't need a plan. You need one brave post.",
  ctaText = "GET STARTED",
  ctaLink = "/tools/selfie-generator",
  className,
}) => {
  return (
    <section className={cn("bg-luxury-black text-soft-white", className)}>
      <div className="container mx-auto px-6 max-w-[1200px] py-24 md:py-32 lg:py-40">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="font-bodoni text-[3.2rem] mb-8 leading-tight">
            {title}
          </h2>
          
          <p className="text-[18px] md:text-[21px] mb-12 leading-relaxed opacity-85">
            {description}
          </p>
          
          <p className="font-bodoni text-[32px] italic mb-16 leading-relaxed">
            &ldquo;{quote}&rdquo;
          </p>
          
          <div>
            <Link
              href={ctaLink}
              className={cn(
                "cta",
                "text-[13px] tracking-[0.3em] uppercase font-light",
                "border-b-[1.5px] border-transparent hover:border-soft-white",
                "transition-all duration-[0.22s]"
              )}
            >
              {ctaText}
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};
