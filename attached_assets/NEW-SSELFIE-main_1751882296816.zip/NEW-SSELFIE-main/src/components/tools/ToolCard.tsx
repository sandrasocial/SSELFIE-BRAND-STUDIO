import React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { cn } from '@/lib/utils';

interface ToolCardProps {
  title: string;
  description: string;
  imageSrc: string;
  ctaText?: string;
  ctaLink: string;
  status?: 'new' | 'updated' | 'coming-soon';
  className?: string;
}

export const ToolCard: React.FC<ToolCardProps> = ({
  title,
  description,
  imageSrc,
  ctaText = "START",
  ctaLink,
  status,
  className,
}) => {
  return (
    <div 
      className={cn(
        "tool-card",
        status === 'coming-soon' && "pointer-events-none",
        className
      )}
    >
      {/* Editorial Image - 64x64px, left-aligned on desktop, stacked on mobile */}
      <div className="w-16 h-16 relative flex-shrink-0">
        <Image
          src={imageSrc}
          alt={title}
          fill
          className="object-cover filter saturate-[0.95]"
        />
      </div>
      
      {/* Content */}
      <div className="md:ml-8 ml-0 mt-4 md:mt-0 flex-1">
        {status && (
          <div className="text-[10px] uppercase tracking-[0.2em] mb-2 text-[#666]">
            {status === 'new' ? 'NEW' : 
             status === 'updated' ? 'UPDATED' : 'COMING SOON'}
          </div>
        )}
        
        <h3 className="font-bodoni text-[2.2rem] md:text-[2.6rem] text-luxury-black mb-3 leading-tight">
          {title}
        </h3>
        
        <p className="text-[#666] mb-6 leading-relaxed max-w-prose">
          {description}
        </p>
        
        <Link 
          href={ctaLink} 
          className={cn(
            "cta",
            status === 'coming-soon' && "opacity-50"
          )}
        >
          {ctaText}
        </Link>
      </div>
    </div>
  );
};
