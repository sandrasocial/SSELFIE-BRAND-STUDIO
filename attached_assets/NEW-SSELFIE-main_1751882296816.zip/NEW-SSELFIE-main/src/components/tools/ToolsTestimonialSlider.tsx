import React, { useState } from 'react';
import Image from 'next/image';
import { cn } from '@/lib/utils';

interface Testimonial {
  id: string;
  quote: string;
  author: string;
  role: string;
  imageSrc: string;
  toolUsed: string;
}

interface ToolsTestimonialSliderProps {
  testimonials?: Testimonial[];
  className?: string;
}

export const ToolsTestimonialSlider: React.FC<ToolsTestimonialSliderProps> = ({
  testimonials = [
    {
      id: '1',
      quote: "I never thought I could create content that looked this professional. Sandra's Selfie Generator gave me the confidence to show up online in a way that feels like me, but elevated.",
      author: "Michelle T.",
      role: "Health Coach",
      imageSrc: "https://i.postimg.cc/7hcLgCB4/out-1-25.webp",
      toolUsed: "Selfie Generator"
    },
    {
      id: '2',
      quote: "The Content Calendar tool helped me go from posting randomly to having a strategy that feels doable. I'm finally consistent, and my audience has grown by 300% in three months.",
      author: "Jessica M.",
      role: "Design Consultant",
      imageSrc: "https://i.postimg.cc/sgmtqFrQ/out-0-1.webp",
      toolUsed: "Content Calendar"
    },
    {
      id: '3',
      quote: "I struggled to find my brand voice for years. Sandra's Brand Voice tool helped me discover a way of communicating that feels authentic but still professional. Game changer.",
      author: "Alicia K.",
      role: "Financial Advisor",
      imageSrc: "https://i.postimg.cc/s2cDTHnw/out-0-22.webp",
      toolUsed: "Brand Voice"
    }
  ],
  className,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  
  const nextSlide = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1
    );
  };
  
  const prevSlide = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex === 0 ? testimonials.length - 1 : prevIndex - 1
    );
  };

  return (
    <section className={cn("bg-white", className)}>
      <div className="container mx-auto px-6 max-w-[1200px]">
        <h2 className="font-bodoni text-[3.2rem] text-luxury-black mb-16 text-center leading-tight">
          Stories of Transformation
        </h2>
        
        <div className="max-w-5xl mx-auto relative">
          {/* Testimonial */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16 items-center">
            {/* Image */}
            <div className="relative h-[400px] lg:h-[480px] w-full overflow-hidden">
              <Image
                src={testimonials[currentIndex].imageSrc}
                alt={testimonials[currentIndex].author}
                fill
                className="object-cover object-center filter saturate-[0.95]"
              />
            </div>
            
            {/* Content */}
            <div>
              <p className="text-[10px] uppercase tracking-[0.3em] text-[#666] mb-4">
                Tool Used: {testimonials[currentIndex].toolUsed}
              </p>
              
              <p className="font-bodoni text-[32px] text-luxury-black italic mb-8 leading-relaxed">
                &ldquo;{testimonials[currentIndex].quote}&rdquo;
              </p>
              
              <div>
                <p className="text-lg font-medium text-luxury-black">
                  {testimonials[currentIndex].author}
                </p>
                <p className="text-[#666]">
                  {testimonials[currentIndex].role}
                </p>
              </div>
            </div>
          </div>
          
          {/* Navigation */}
          <div className="flex justify-center mt-16 space-x-6">
            <button 
              onClick={prevSlide}
              className="w-12 h-12 border border-[#e5e5e5] flex items-center justify-center 
                         hover:bg-[#f5f5f5] transition-colors duration-200"
              aria-label="Previous testimonial"
            >
              <span className="sr-only">Previous</span>
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                width="24" 
                height="24" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="1.5" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <path d="M15 18l-6-6 6-6" />
              </svg>
            </button>
            
            <button 
              onClick={nextSlide}
              className="w-12 h-12 border border-[#e5e5e5] flex items-center justify-center 
                         hover:bg-[#f5f5f5] transition-colors duration-200"
              aria-label="Next testimonial"
            >
              <span className="sr-only">Next</span>
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                width="24" 
                height="24" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="1.5" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <path d="M9 18l6-6-6-6" />
              </svg>
            </button>
          </div>
          
          {/* Indicators */}
          <div className="flex justify-center mt-6">
            {testimonials.map((_, index) => (
              <button
                key={index}
                className={cn(
                  "w-2 h-2 mx-1 rounded-full transition-all duration-200",
                  index === currentIndex ? "bg-luxury-black w-6" : "bg-[#e5e5e5]"
                )}
                onClick={() => setCurrentIndex(index)}
                aria-label={`Go to testimonial ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
