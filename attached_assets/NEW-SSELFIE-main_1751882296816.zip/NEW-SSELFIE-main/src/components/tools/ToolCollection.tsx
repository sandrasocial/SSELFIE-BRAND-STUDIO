import React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { cn } from '@/lib/utils';
import { SandraImages } from '@/components/sandra-image-library';

interface Tool {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  ctaText: string;
  ctaLink: string;
  status?: 'new' | 'updated' | 'coming-soon';
}

interface ToolCollectionProps {
  tools?: Tool[];
  className?: string;
}

export const ToolCollection: React.FC<ToolCollectionProps> = ({
  tools = [
    // Not including Selfie Generator as it's in the featured section
    {
      id: 'future-self',
      title: "Future Self",
      description: "Visualize where your brand journey is taking you. See the future you're building today.",
      imageUrl: SandraImages.aiGallery[2], // Using a unique AI gallery image
      ctaText: 'START',
      ctaLink: '/tools/future-self',
      status: 'new'
    },
    {
      id: 'content-calendar',
      title: "Content Calendar",
      description: "Plan your content strategy with templates that feel uniquely you, not cookie-cutter.",
      imageUrl: SandraImages.flatlays.planning,
      ctaText: 'START',
      ctaLink: '/tools/content-calendar'
    },
    {
      id: 'landing-page',
      title: "Landing Page",
      description: "Create a homepage that feels like you, without the tech headache.",
      imageUrl: SandraImages.editorial.laptop1,
      ctaText: 'START',
      ctaLink: '/tools/landing-page'
    },
    {
      id: 'brand-voice',
      title: "Brand Voice",
      description: "Craft your message in a voice that feels authentic to your story and business goals.",
      imageUrl: SandraImages.editorial.laptop2,
      ctaText: 'START',
      ctaLink: '/tools/brand-voice'
    },
    {
      id: 'social-blueprint',
      title: "Social Blueprint",
      description: "Create a framework for showing up consistently while staying true to yourself.",
      imageUrl: SandraImages.aiGallery[7], // Using another unique AI gallery image
      ctaText: 'START',
      ctaLink: '/tools/social-blueprint',
      status: 'coming-soon'
    }
  ],
  className,
}) => {
  return (
    <section className={cn("bg-white py-24 md:py-32 lg:py-40", className)}>
      <div className="container mx-auto px-6 max-w-[1200px]">
        <h2 className="font-bodoni text-[3.2rem] text-luxury-black mb-16 text-center leading-tight">
          Your Complete Toolkit
        </h2>
        <p className="text-[#666] text-center max-w-2xl mx-auto mb-20 text-lg">
          Pick a tool to get started. You can always come back.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-12 lg:gap-12">
          {tools.map((tool) => (
            <div 
              key={tool.id}
              className="bg-white border-[1.5px] border-[#e5e5e5] rounded-[8px] overflow-hidden flex flex-col 
                        hover:shadow-[0_8px_32px_0_#e5e5e580] hover:scale-[1.025] transition-all duration-[0.22s] 
                        transform"
              style={{ transitionTimingFunction: 'cubic-bezier(0.4, 0, 0.2, 1)' }}
            >
              {/* Image */}
              <div className="relative h-72 w-full overflow-hidden">
                <Image
                  src={tool.imageUrl}
                  alt={tool.title}
                  fill
                  className="object-cover hover:scale-[1.03] transition-transform duration-[0.4s] filter saturate-[0.95]"
                />
                <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/20" />
                
                {tool.status && (
                  <div className="absolute top-6 right-6 bg-luxury-black text-soft-white py-1 px-3 text-[10px] uppercase tracking-[0.2em]">
                    {tool.status === 'new' ? 'New' : 
                     tool.status === 'updated' ? 'Updated' : 'Coming Soon'}
                  </div>
                )}
              </div>
              
              {/* Content */}
              <div className="p-12 md:p-14 lg:p-16 flex-grow flex flex-col">
                {tool.status && (
                  <div className="text-[10px] uppercase tracking-[0.2em] mb-2 text-[#666]">
                    {tool.status === 'new' ? 'NEW' : 
                    tool.status === 'updated' ? 'UPDATED' : 'COMING SOON'}
                  </div>
                )}
                <h3 className="font-bodoni text-[2.2rem] md:text-[2.6rem] text-luxury-black mb-4 leading-tight">
                  {tool.title}
                </h3>
                <p className="text-[#666] mb-10 flex-grow leading-relaxed">
                  {tool.description}
                </p>
                
                <div className="flex justify-start">
                  <Link
                    href={tool.ctaLink}
                    className={cn(
                      "cta",
                      "text-[13px] tracking-[0.3em] uppercase font-light text-luxury-black",
                      "border-b-[1.5px] border-transparent hover:border-luxury-black",
                      "transition-all duration-[0.22s]",
                      tool.status === 'coming-soon' && "opacity-50 pointer-events-none"
                    )}
                  >
                    {tool.ctaText}
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
