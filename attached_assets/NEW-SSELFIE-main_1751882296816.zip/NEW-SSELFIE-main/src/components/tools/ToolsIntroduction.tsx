import React from 'react';
import { cn } from '@/lib/utils';

interface ToolsIntroductionProps {
  quote?: string;
  description?: string;
  className?: string;
}

export const ToolsIntroduction: React.FC<ToolsIntroductionProps> = ({
  quote = "Tools don't build brands. Stories do.",
  description = "Each tool in this collection is designed to help you transform your everyday moments into a cohesive brand story that resonates with your audience. No complicated tech, just strategic simplicity.",
  className,
}) => {
  return (
    <section className={cn("bg-white", className)}>
      <div className="container mx-auto px-6 max-w-[1200px]">
        <div className="max-w-3xl mx-auto text-center">
          <p className="font-bodoni text-[32px] md:text-[42px] text-luxury-black italic mb-10 leading-relaxed">
            &ldquo;{quote}&rdquo;
          </p>
          
          <p className="text-[18px] md:text-[21px] text-[#666] leading-relaxed max-w-2xl mx-auto">
            {description}
          </p>
        </div>
      </div>
    </section>
  );
};
