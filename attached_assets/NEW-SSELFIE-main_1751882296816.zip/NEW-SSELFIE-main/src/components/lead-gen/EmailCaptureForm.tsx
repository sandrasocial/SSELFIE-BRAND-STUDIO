'use client'

import React, { useState } from 'react'
import { cn } from '@/lib/utils'

export interface EmailCaptureFormProps {
  variant?: 'default' | 'dark'
  title?: string
  subtitle?: string
  buttonText?: string
  successTitle?: string
  successMessage?: string
  onSubmit?: (data: { firstName: string; email: string }) => Promise<void>
  className?: string
}

export const EmailCaptureForm: React.FC<EmailCaptureFormProps> = ({
  variant = 'default',
  title = 'Ready to take the kind of selfies that make people stop scrolling?',
  subtitle = "Drop your email—I'll send you my actual guide. No fluff, just the moves I use every day to show up online (and in life).",
  buttonText = "Send Me The Guide",
  successTitle = "Check your inbox (and maybe spam, just in case)",
  successMessage = "Your guide's on its way. Pour yourself a coffee, check your email, and get ready to glow differently.",
  onSubmit,
  className
}) => {
  const [formData, setFormData] = useState({
    firstName: '',
    email: ''
  })
  const [isLoading, setIsLoading] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setIsLoading(true)
    try {
      if (onSubmit) {
        await onSubmit(formData)
      } else {
        // Simulate API call for demo
        await new Promise(resolve => setTimeout(resolve, 2000))
      }
      setIsSuccess(true)
      setTimeout(() => {
        setIsSuccess(false)
        setFormData({ firstName: '', email: '' })
      }, 5000)
    } catch (err) {
      setError("Something went sideways. Try again—or DM me if tech's being stubborn.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
    setError('')
  }

  const isDark = variant === 'dark'

  // Success State
  if (isSuccess) {
    return (
      <div className={cn(
        'max-w-[600px] mx-auto text-center p-16 animate-fadeIn',
        className
      )}>
        <div className="w-16 h-16 mx-auto mb-6 border-2 border-luxury-black flex items-center justify-center rounded-full bg-pure-white/70">
          <svg 
            className="w-8 h-8 text-luxury-black" 
            fill="none" 
            stroke="currentColor" 
            viewBox="0 0 24 24"
          >
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth={2} 
              d="M5 13l4 4L19 7" 
            />
          </svg>
        </div>
        <h3 className="font-bodoni text-[32px] font-light tracking-[-0.02em] mb-4">
          {successTitle}
        </h3>
        <p className="text-lg text-luxury-black/80">
          {successMessage}
        </p>
      </div>
    )
  }

  // Form State
  return (
    <div className={cn(
      'max-w-[600px] mx-auto text-center p-12 lg:p-16',
      isDark && 'bg-luxury-black text-pure-white',
      className
    )}>
      <h3 className={cn(
        'font-bodoni text-4xl font-light tracking-[-0.02em] mb-4',
        isDark ? 'text-pure-white' : 'text-luxury-black'
      )}>
        {title}
      </h3>
      <p className={cn(
        'text-lg mb-8',
        isDark ? 'text-soft-white/90' : 'text-luxury-black/80'
      )}>
        {subtitle}
      </p>
      <form onSubmit={handleSubmit} className="space-y-0">
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <input
            type="text"
            name="firstName"
            value={formData.firstName}
            onChange={handleInputChange}
            placeholder="First name"
            required
            disabled={isLoading}
            className={cn(
              'flex-1 px-0 py-4 bg-transparent border-0 border-b transition-all duration-300',
              'placeholder:text-sm placeholder:tracking-[0.1em] placeholder:uppercase',
              'focus:outline-none focus:border-b-2',
              isDark ? [
                'border-b-soft-white/30 text-pure-white placeholder:text-soft-white/50',
                'focus:border-b-pure-white'
              ] : [
                'border-b-warm-gray text-luxury-black placeholder:text-warm-gray',
                'focus:border-b-luxury-black'
              ],
              isLoading && 'opacity-50'
            )}
            autoComplete="given-name"
          />
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleInputChange}
            placeholder="Email address"
            required
            disabled={isLoading}
            className={cn(
              'flex-1 px-0 py-4 bg-transparent border-0 border-b transition-all duration-300',
              'placeholder:text-sm placeholder:tracking-[0.1em] placeholder:uppercase',
              'focus:outline-none focus:border-b-2',
              isDark ? [
                'border-b-soft-white/30 text-pure-white placeholder:text-soft-white/50',
                'focus:border-b-pure-white'
              ] : [
                'border-b-warm-gray text-luxury-black placeholder:text-warm-gray',
                'focus:border-b-luxury-black'
              ],
              isLoading && 'opacity-50'
            )}
            autoComplete="email"
          />
        </div>
        {error && (
          <p className="text-sm text-red-600 mb-4 animate-fadeIn">
            {error}
          </p>
        )}
        <button
          type="submit"
          disabled={isLoading}
          className={cn(
            'w-full py-5 px-10 text-xs tracking-[0.3em] uppercase font-medium font-inter',
            'relative overflow-hidden transition-all duration-500',
            'disabled:opacity-70 disabled:cursor-not-allowed',
            isDark ? [
              'bg-pure-white text-luxury-black',
              'hover:bg-soft-white'
            ] : [
              'bg-luxury-black text-pure-white',
              'hover:bg-luxury-black/90'
            ],
            'before:absolute before:inset-0 before:bg-white/10',
            'before:translate-x-[-100%] hover:before:translate-x-[100%]',
            'before:transition-transform before:duration-700'
          )}
        >
          {isLoading ? (
            <span className="inline-flex items-center gap-2">
              <span className="inline-block w-1 h-1 bg-current rounded-full animate-pulse" />
              <span className="inline-block w-1 h-1 bg-current rounded-full animate-pulse delay-75" />
              <span className="inline-block w-1 h-1 bg-current rounded-full animate-pulse delay-150" />
            </span>
          ) : (
            buttonText
          )}
        </button>
        <p className={cn(
          'text-sm mt-6',
          isDark ? 'text-soft-white/70' : 'text-luxury-black/70'
        )}>
          No spam. No fake “empowerment.” Just the real guide and real weekly tips—straight from my phone to yours.
        </p>
      </form>
    </div>
  )
}

// Preset variants for common use cases
export const EmailCaptureHero: React.FC<Omit<EmailCaptureFormProps, 'variant'>> = (props) => (
  <section className="relative bg-luxury-black text-pure-white overflow-hidden">
    <div className="absolute inset-0 opacity-30">
      <img 
        src="https://i.postimg.cc/YqG0t39C/out-1-24.webp" 
        alt="" 
        className="w-full h-full object-cover"
      />
    </div>
    <div className="absolute inset-0 bg-gradient-to-br from-luxury-black/95 via-luxury-black/80 to-luxury-black/95" />
    <div className="relative z-10 py-24 lg:py-32">
      <EmailCaptureForm variant="dark" {...props} />
    </div>
  </section>
)

export const EmailCaptureBlog: React.FC<EmailCaptureFormProps> = (props) => (
  <div className="my-16 lg:my-24">
    <div className="bg-soft-white">
      <EmailCaptureForm {...props} />
    </div>
  </div>
)

export const EmailCapturePopup: React.FC<EmailCaptureFormProps & { isOpen: boolean; onClose: () => void }> = ({ 
  isOpen, 
  onClose, 
  ...props 
}) => {
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div 
        className="absolute inset-0 bg-luxury-black/50 backdrop-blur-sm"
        onClick={onClose}
      />
      <div className="relative bg-pure-white max-w-lg w-full animate-slideUp">
        <button
          onClick={onClose}
          className="absolute top-6 right-6 w-8 h-8 flex items-center justify-center text-luxury-black/50 hover:text-luxury-black transition-colors"
          aria-label="Close signup popup"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
        <EmailCaptureForm {...props} />
      </div>
    </div>
  )
}