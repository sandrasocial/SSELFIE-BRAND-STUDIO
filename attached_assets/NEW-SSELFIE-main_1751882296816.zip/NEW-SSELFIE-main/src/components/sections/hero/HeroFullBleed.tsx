import React from 'react'
import Image from 'next/image'

interface HeroFullBleedProps {
  backgroundImage: string
  title: string
  subtitle: string
  tagline?: string
  ctaText?: string
  ctaLink?: string
  overlay?: number
  alignment?: 'left' | 'center'
  fullHeight?: boolean
}

export const HeroFullBleed: React.FC<HeroFullBleedProps> = ({
  backgroundImage,
  title,
  subtitle,
  tagline,
  ctaText,
  ctaLink,
  overlay = 0.7,
  alignment = 'center',
  fullHeight = true
}) => {
  return (
    <section
      className={`relative w-full ${fullHeight ? 'h-[90vh] md:h-screen' : 'min-h-[600px]'} flex items-center overflow-hidden`}
    >
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <Image
          src={backgroundImage}
          alt=""
          fill
          className="object-cover"
          priority
          sizes="100vw"
        />
      </div>

      {/* Gradient Overlay */}
      <div
        className="absolute inset-0 z-10 pointer-events-none"
        style={{
          background: `linear-gradient(to top, rgba(10,10,10,${overlay}) 0%, rgba(10,10,10,${overlay * 0.3}) 40%, transparent 80%)`
        }}
      />

      {/* Content */}
      <div className="relative z-20 w-full flex items-center justify-center">
        <div className={`w-full px-6 sm:px-10 md:px-20 py-20 flex flex-col items-center ${alignment === 'center' ? 'text-center' : 'text-left'}`}>
          {/* Tagline */}
          {tagline && (
            <div className="section-label text-white/70 mb-6">
              {tagline}
            </div>
          )}

          {/* Main Title */}
          <h1 className="luxury-headline text-white text-[clamp(2.5rem,12vw,8rem)] tracking-[0.32em] leading-[0.95] uppercase mb-3">
            {title}
          </h1>

          {/* Subheadline */}
          <div className="section-label text-white/70 mb-10 text-base md:text-lg">
            {subtitle}
          </div>

          {/* CTA */}
          {ctaText && ctaLink && (
            <a
              href={ctaLink}
              className="cta-link text-white/90 border-b border-white/30 hover:border-white"
            >
              {ctaText}
            </a>
          )}
        </div>
      </div>
    </section>
  )
}

// Usage Example for Homepage
export const HomepageHero = () => (
  <HeroFullBleed
    backgroundImage="https://i.postimg.cc/rwTG02cZ/out-1_(23).png" // TODO: Move to /public/hero/ soon
    tagline="It starts with your selfie."
    title="SSELFIE"
    subtitle="STUDIO"
    ctaText="Selfies aren’t the story, how you use them is"
    ctaLink="/tools"
  />
)