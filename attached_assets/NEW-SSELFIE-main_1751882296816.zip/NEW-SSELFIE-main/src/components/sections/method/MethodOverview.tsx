import React from 'react'

export const MethodOverview = () => {
  return (
    <section>
      {/* The 3-step process */}
      <h2>Method Overview - Coming Soon</h2>
    </section>
  )
}
