export default function StatsSpread() {
  return (
    <section className="section-padding">
      <div className="max-width-editorial px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-16">
          <div className="text-center">
            <h3 className="luxury-headline text-4xl md:text-5xl mb-4">120K</h3>
            <p className="stat-label">Followers in 90 Days</p>
          </div>
          <div className="text-center">
            <h3 className="luxury-headline text-4xl md:text-5xl mb-4">3</h3>
            <p className="stat-label">Kids I&apos;m Raising</p>
          </div>
          <div className="text-center">
            <h3 className="luxury-headline text-4xl md:text-5xl mb-4">1</h3>
            <p className="stat-label">Phone That Changed Everything</p>
          </div>
          <div className="text-center">
            <h3 className="luxury-headline text-4xl md:text-5xl mb-4">100%</h3>
            <p className="stat-label">Real, No BS</p>
          </div>
        </div>
      </div>
    </section>
  );
}
