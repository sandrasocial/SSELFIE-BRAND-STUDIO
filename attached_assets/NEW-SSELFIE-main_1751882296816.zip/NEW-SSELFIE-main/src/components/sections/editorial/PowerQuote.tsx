export default function PowerQuote() {
  return (
    <section className="section-padding bg-editorial-gray">
      <div className="max-width-cta px-6 text-center">
        <h2 className="luxury-quote mb-8">
          &ldquo;I didn&apos;t need a full plan.<br />
          I needed one brave post.<br />
          One real story.<br />
          One step back to myself.&rdquo;
        </h2>
        <span className="section-label">
          Sandra Sigurjonsdottir
        </span>
      </div>
    </section>
  )
}
