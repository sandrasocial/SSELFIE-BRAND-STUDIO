import React from 'react';

export default function EditorialTestimonials() {
  return (
    <section className="section-padding bg-editorial-gray">
      <div className="max-width-editorial mx-auto px-6">
        <div className="grid md:grid-cols-3 grid-gap">
          {/* Testimonial 1 */}
          <div className="flex flex-col items-center text-center">
            <blockquote className="luxury-quote mb-8">
              &ldquo;Thank you for sharing your knowledge and being so true. I feel so motivated to start taking pictures of myself. I heard the words that I&apos;ve always wanted to say but never expressed before. Today, I posted three stories talking about my journey in a raw and authentic way. I&apos;m pursuing my dream. Thank you so much.&rdquo;
            </blockquote>
            <span className="section-label text-soft-gray">
              Olha
            </span>
          </div>

          {/* Testimonial 2 */}
          <div className="flex flex-col items-center text-center">
            <blockquote className="luxury-quote mb-8">
              &ldquo;You literally changed my picture taking from boring selfies to professional pictures. Like, HOW?&rdquo;
            </blockquote>
            <span className="section-label text-soft-gray">
              Sarah on Instagram
            </span>
          </div>

          {/* Testimonial 3 */}
          <div className="flex flex-col items-center text-center">
            <blockquote className="luxury-quote mb-8">
              &ldquo;You&apos;re helping me develop my &apos;just do it&apos; attitude. No more waiting for perfect!&rdquo;
            </blockquote>
            <span className="section-label text-soft-gray">
              Roxanne
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}