import Image from 'next/image'

export default function WelcomeEditorial() {
  return (
    <section className="section-padding bg-white">
      <div className="max-width-editorial px-6">
        <div className="grid lg:grid-cols-2 grid-gap items-center">
          {/* Editorial Image */}
          <div className="relative aspect-[4/5] lg:aspect-square min-h-[360px] max-h-[500px] overflow-hidden">
            <Image
              src="https://i.postimg.cc/0j0cpxZ5/out-0-10.png" // TODO: Move to /public/editorial/welcome-editorial.png soon
              alt="Sandra's SSELFIE editorial example"
              fill
              className="editorial-image"
              priority
              sizes="(max-width: 1024px) 100vw, 600px"
            />
          </div>
          {/* Editorial Copy */}
          <div className="lg:pl-16 mt-8 lg:mt-0 flex flex-col justify-center">
            <span className="section-label mb-6">
              welcome to sselfie studio
            </span>
            <h2 className="h2 mb-8">
              The digital studio where your face is the brand.
            </h2>
            <blockquote className="luxury-quote mb-8 border-l-4 border-accent-line pl-6">
              “Okay, here’s what actually happened…  
              One year ago my marriage ended. Single mom, three kids, zero plan.  
              But I had a phone. And I figured out that was all I needed.”
            </blockquote>
            <p className="body-copy text-soft-gray mb-2">
              SSELFIE STUDIO is for women who are done waiting for perfect. Upload your actual selfies. No fancy camera, no design degree, no pretending. My AI just brings out what’s already there. Your face. Your story. Your brand, all done in minutes.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}