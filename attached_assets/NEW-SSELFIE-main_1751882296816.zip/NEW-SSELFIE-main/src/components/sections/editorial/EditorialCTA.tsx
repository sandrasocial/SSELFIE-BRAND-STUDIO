export default function EditorialCTA() {
  return (
    <section className="section-padding bg-editorial-gray text-center">
      <div className="max-width-cta px-6">
        <p className="section-label mb-4">Ready to start?</p>
        <h2 className="luxury-headline text-3xl md:text-4xl mb-6">Your story matters.</h2>
        <p className="body-copy mb-8">
          90 days · 100K followers · One method
        </p>
        <a href="/start" className="cta-link">Begin</a>
      </div>
    </section>
  );
}