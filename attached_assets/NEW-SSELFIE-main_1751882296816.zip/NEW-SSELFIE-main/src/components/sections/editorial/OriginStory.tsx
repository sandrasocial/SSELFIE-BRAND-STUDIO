import Image from 'next/image';

export default function OriginStory() {
  return (
    <section className="section-padding">
      <div className="max-width-editorial px-6">
        <div className="grid lg:grid-cols-2 grid-gap items-center">
          <div className="relative aspect-[4/5] lg:aspect-square">
            <Image
              src="https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=900"
              alt="Sandra at home"
              fill
              className="editorial-image object-cover"
              priority
            />
          </div>
          <div className="lg:pl-16 mt-8 lg:mt-0">
            <p className="section-label mb-6">chapter one</p>
            <h2 className="luxury-headline text-2xl md:text-3xl mb-8">
              This didn&apos;t start as a business. It started as survival.
            </h2>
            <p className="body-copy mb-6">
              One year ago, I hit rock bottom. Divorced. Three kids. No backup plan. I was heartbroken, exhausted, and completely disconnected from the woman I used to be.
            </p>
            <p className="body-copy mb-8">
              And one day, in the middle of all that mess—I picked up my phone. Took a selfie. Posted something honest. Not perfect. Just true.
            </p>
            <a href="#" className="cta-link">Read My Full Story</a>
          </div>
        </div>
      </div>
    </section>
  );
}
