export default function MethodOverview() {
  return (
    <section className="section-padding bg-mid-gray">
      <div className="max-width-editorial px-6">
        <div className="text-center mb-16">
          <h2 className="luxury-headline text-3xl md:text-4xl mb-4">The SSELFIE Method</h2>
          <p className="section-label">90 Days to Your First 100K</p>
        </div>
        <div className="grid md:grid-cols-2 grid-gap">
          <div className="body-copy text-lg">
            That one moment sparked something. I didn't need a full plan. I needed one brave post. One real story. One step back to myself. From there, I kept showing up—camera in one hand, coffee in the other.
          </div>
          <div className="body-copy text-lg">
            And over time, I built a real audience, a real brand, and eventually, a real business. Not because I had it all together. But because I didn't—and I stopped hiding that.
          </div>
        </div>
      </div>
    </section>
  );
}
