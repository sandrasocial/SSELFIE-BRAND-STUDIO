import Image from 'next/image';

export default function EditorialMoodboard() {
  return (
    <div>
      {/* Moodboard Grid */}
      <section className="section-padding bg-white">
        <div className="max-width-moodboard px-6">
          <div className="text-center mb-16">
            <h2 className="luxury-headline text-3xl md:text-4xl mb-4">The Journey</h2>
            <p className="section-label">From Rock Bottom to CEO</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-16">
            <div className="aspect-square">
              <Image src="https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=400" alt="Fashion" width={400} height={400} className="editorial-image object-cover w-full h-full" />
            </div>
            <div className="col-span-2 aspect-[2/1]">
              <Image src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=800" alt="Style" width={800} height={400} className="editorial-image object-cover w-full h-full" />
            </div>
            <div className="flex items-center justify-center bg-editorial-gray p-6 aspect-square">
              <blockquote className="luxury-headline text-center text-lg">
                "If it makes you happy,<br />
                it's not a waste of time."
              </blockquote>
            </div>
            <div className="aspect-square">
              <Image src="https://images.unsplash.com/photo-1509631179647-0177331693ae?w=400" alt="Minimal" width={400} height={400} className="editorial-image object-cover w-full h-full" />
            </div>
            <div className="aspect-square">
              <Image src="https://images.unsplash.com/photo-1495385794356-15371f348c31?w=400" alt="Architecture" width={400} height={400} className="editorial-image object-cover w-full h-full" />
            </div>
            <div className="row-span-2 aspect-[1/2]">
              <Image src="https://images.unsplash.com/photo-1483985988355-763728e1935b?w=400" alt="Portrait" width={400} height={800} className="editorial-image object-cover w-full h-full" />
            </div>
            <div className="aspect-square">
              <Image src="https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=400" alt="Fashion" width={400} height={400} className="editorial-image object-cover w-full h-full" />
            </div>
            <div className="aspect-square">
              <Image src="https://images.unsplash.com/photo-1445205170230-053b83016050?w=400" alt="Style" width={400} height={400} className="editorial-image object-cover w-full h-full" />
            </div>
          </div>
        </div>
      </section>

      {/* Moodboard Layers */}
      <section className="section-padding bg-editorial-gray">
        <div className="max-width-editorial px-6">
          <div className="relative overflow-hidden min-h-[400px] bg-luxury-black">
            <div className="absolute inset-0 opacity-30">
              <Image src="https://images.unsplash.com/photo-1483985988355-763728e1935b?w=600" alt="Layer 1" fill className="editorial-image object-cover" />
            </div>
            <div className="absolute top-8 right-8 w-48 h-64 opacity-60">
              <Image src="https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=500" alt="Layer 2" fill className="editorial-image object-cover" />
            </div>
            <div className="relative z-10 flex items-center justify-center min-h-[400px] text-white text-center p-8">
              <div>
                <h3 className="luxury-headline text-2xl md:text-3xl mb-6 text-white">SSELFIE Method</h3>
                <p className="body-copy text-white max-w-md">
                  Not because I had it all together. But because I didn't—and I stopped hiding that.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}