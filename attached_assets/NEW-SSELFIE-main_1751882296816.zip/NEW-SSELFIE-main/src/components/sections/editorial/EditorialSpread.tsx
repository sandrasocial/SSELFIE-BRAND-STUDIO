import Image from 'next/image';

export default function EditorialSpread() {
  return (
    <div>
      {/* Power Quote */}
      <section className="section-padding bg-editorial-gray">
        <div className="max-width-cta px-6 text-center">
          <h2 className="luxury-headline text-3xl md:text-4xl mb-8 leading-tight">
            "I didn't need a full plan.<br />
            I needed one brave post.<br />
            One real story.<br />
            One step back to myself."
          </h2>
          <p className="section-label">Sandra Sigurjonsdottir</p>
        </div>
      </section>

      {/* Split Layout */}
      <section className="section-padding">
        <div className="max-width-editorial px-6">
          <div className="grid lg:grid-cols-2 grid-gap items-center">
            <div className="relative aspect-[4/5] lg:aspect-square">
              <Image
                src="https://i.postimg.cc/0j0cpxZ5/out-0-10.png"
                alt="Sandra's SSELFIE editorial example"
                fill
                className="editorial-image object-cover"
                priority
              />
            </div>
            <div className="lg:pl-16 mt-8 lg:mt-0">
              <p className="section-label mb-6">welcome to sselfie studio</p>
              <h2 className="luxury-headline text-2xl md:text-3xl mb-8">
                The digital studio where your face is the brand.
              </h2>
              <blockquote className="text-xl mb-8 font-light italic">
                &ldquo;One year ago my marriage ended. Single mom, three kids, zero plan. But I had a phone. And I figured out that was all I needed.&rdquo;
              </blockquote>
              <p className="body-copy mb-8">
                SSELFIE STUDIO is for women who are done waiting for perfect. Upload your actual selfies. No fancy camera, no design degree, no pretending. My AI just brings out what&apos;s already there. Your face. Your story. Your brand, all done in minutes.
              </p>
              <h2 className="luxury-headline text-2xl md:text-3xl mb-6">
                This didn't start as a business. It started as survival.
              </h2>
              <p className="body-copy mb-6">
                One year ago, I hit rock bottom. Divorced. Three kids. No backup plan. I was heartbroken, exhausted, and completely disconnected from the woman I used to be.
              </p>
              <p className="body-copy mb-8">
                And one day, in the middle of all that mess—I picked up my phone. Took a selfie. Posted something honest. Not perfect. Just true.
              </p>
              <a href="#" className="cta-link">Read My Full Story</a>
            </div>
          </div>
        </div>
      </section>

      {/* Magazine Columns */}
      <section className="section-padding bg-mid-gray">
        <div className="max-width-editorial px-6">
          <div className="text-center mb-16">
            <h2 className="luxury-headline text-3xl md:text-4xl mb-4">The SSELFIE Method</h2>
            <p className="section-label">90 Days to Your First 100K</p>
          </div>
          <div className="grid md:grid-cols-2 grid-gap">
            <div className="body-copy text-lg">
              That one moment sparked something. I didn't need a full plan. I needed one brave post. One real story. One step back to myself. From there, I kept showing up—camera in one hand, coffee in the other.
            </div>
            <div className="body-copy text-lg">
              And over time, I built a real audience, a real brand, and eventually, a real business. Not because I had it all together. But because I didn't—and I stopped hiding that.
            </div>
          </div>
        </div>
      </section>

      {/* Stats Spread */}
      <section className="section-padding">
        <div className="max-width-editorial px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-16">
            <div className="text-center">
              <h3 className="luxury-headline text-4xl md:text-5xl mb-4">120K</h3>
              <p className="stat-label">Followers in 90 Days</p>
            </div>
            <div className="text-center">
              <h3 className="luxury-headline text-4xl md:text-5xl mb-4">3</h3>
              <p className="stat-label">Kids I'm Raising</p>
            </div>
            <div className="text-center">
              <h3 className="luxury-headline text-4xl md:text-5xl mb-4">1</h3>
              <p className="stat-label">Phone That Changed Everything</p>
            </div>
            <div className="text-center">
              <h3 className="luxury-headline text-4xl md:text-5xl mb-4">100%</h3>
              <p className="stat-label">Real, No BS</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="section-padding bg-editorial-gray">
        <div className="max-width-editorial px-6">
          <div className="grid md:grid-cols-3 grid-gap">
            <div className="text-center">
              <p className="body-copy text-lg mb-6 italic">
                "Sandra showed me that my mess was actually my message. Now I have a business that works around my life, not the other way around."
              </p>
              <p className="section-label">Maria, Single Mom of Two</p>
            </div>
            <div className="text-center">
              <p className="body-copy text-lg mb-6 italic">
                "I went from hiding my divorce to sharing my story. 60K followers later, I have clients begging to work with me."
              </p>
              <p className="section-label">Jessica, Divorce Coach</p>
            </div>
            <div className="text-center">
              <p className="body-copy text-lg mb-6 italic">
                "The SSELFIE method isn't just about selfies. It's about finally showing up as yourself and getting paid for it."
              </p>
              <p className="section-label">Anna, Business Owner</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}