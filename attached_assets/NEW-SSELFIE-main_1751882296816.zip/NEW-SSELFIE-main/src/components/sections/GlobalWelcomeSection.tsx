'use client'

import React from 'react'
import Image from 'next/image'
import { SandraImages } from '../sandra-image-library'

export default function GlobalWelcomeSection() {
  return (
    <section className="w-full bg-[#fafafa] py-20 px-4 flex justify-center">
      <div className="max-w-4xl w-full grid md:grid-cols-2 gap-16 items-center">
        <div>
          <span className="block text-xs tracking-widest uppercase font-bold text-[#666] mb-4">
            welcome to sselfie studio
          </span>
          <h2 className="font-serif text-3xl md:text-4xl font-light text-[#0a0a0a] mb-6 leading-tight">
            The digital studio where your face is the brand.
          </h2>
          <blockquote className="italic text-lg text-[#666] border-l-4 border-[#e5e5e5] pl-4 mb-6">
            &ldquo;One year ago my marriage ended. Single mom, three kids, zero plan.<br /><br />But I had a phone. And I figured out that was all I needed.&rdquo;
          </blockquote>
          <p className="text-base text-[#666] mb-8">
            SSELFIE STUDIO is for women who are done waiting for perfect. Upload your actual selfies. No fancy camera, no design degree, no pretending. My AI just brings out what&apos;s already there. Your face. Your story. Your brand, all done in minutes.
          </p>
        </div>
        <div className="flex justify-center">
          <div className="w-full h-80 bg-[#f5f5f5] border border-[#e5e5e5] overflow-hidden relative">
            <Image 
              src={SandraImages.journey.building}
              alt="Sandra's SSELFIE editorial example" 
              fill
              className="object-cover z-10"
              sizes="(max-width: 768px) 100vw, 50vw"
              priority
            />
          </div>
        </div>
      </div>
    </section>
  )
}
