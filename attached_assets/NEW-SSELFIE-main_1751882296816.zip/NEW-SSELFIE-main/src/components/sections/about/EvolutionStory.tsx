'use client'

import React from 'react'
import Image from 'next/image'
import { SandraImages } from '@/components/sandra-image-library'

export function EvolutionStory() {
  return (
    <section className="py-24 md:py-32">
      <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-7xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20">
          {/* Left - Large Image */}
          <div className="lg:col-span-7">
            <div style={{ position: 'relative', width: '100%', height: '600px' }}>
              <Image
                src={SandraImages.journey.today}
                alt="Sandra Today - Confident Shot"
                fill
                className="object-cover rounded-none"
                priority
              />
            </div>
          </div>

          {/* Right - The Now */}
          <div className="lg:col-span-5 lg:pt-20">
            <p className="font-inter text-xs tracking-[0.3em] uppercase text-luxury-black/50 mb-8">
              The Now
            </p>
            
            <h2 className="font-bodoni text-3xl md:text-4xl font-light leading-tight text-luxury-black mb-12">
              From there, I kept showing up—camera in one hand, coffee in the other.
            </h2>
            
            <div className="space-y-6">
              <p className="font-inter text-base font-light text-luxury-black/70 leading-relaxed">
                And over time, I built a real audience, a real brand, and eventually, a real business.
              </p>
              
              <p className="font-inter text-base font-light text-luxury-black/70 leading-relaxed">
                Not because I had it all together. But because I didn&apos;t—and I stopped hiding that.
              </p>
              
              <div className="pt-8">
                <div className="h-px w-full bg-luxury-black/10 mb-8" />
                <p className="font-inter text-lg font-light text-luxury-black italic">
                  That&apos;s where SSELFIE was born.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
