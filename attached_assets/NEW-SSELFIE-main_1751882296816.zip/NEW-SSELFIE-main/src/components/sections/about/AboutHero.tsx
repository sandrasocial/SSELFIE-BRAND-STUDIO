'use client'

import React from 'react'
import { HeroFullBleed } from "@/components/sections/hero/HeroFullBleed"
import { SandraImages } from '@/components/sandra-image-library'

export function AboutHero() {
  return (
    <HeroFullBleed
      backgroundImage={SandraImages.hero.about}
      tagline="The Icelandic Selfie Queen"
      title="SANDRA"
      subtitle="SIGURJONSDOTTIR"
      ctaText="Let's build something real"
      ctaLink="#story"
    />
  )
}
