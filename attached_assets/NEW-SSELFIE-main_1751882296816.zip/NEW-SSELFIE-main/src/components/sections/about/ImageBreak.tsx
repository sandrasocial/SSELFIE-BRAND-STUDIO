'use client'

import React from 'react'
import Image from 'next/image'

interface ImageBreakProps {
  src: string
  alt: string
  height?: string
}

export function ImageBreak({ src, alt, height = '70vh' }: ImageBreakProps) {
  return (
    <section className="relative" style={{ height }}>
      <Image
        src={src}
        alt={alt}
        fill
        className="editorial-image"
        priority
      />
    </section>
  )
}
