'use client'

import React from 'react'

export function PhilosophySection() {
  return (
    <section className="py-24 bg-luxury-black text-white">
      <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-4xl text-center">
        <div className="space-y-12">
          <h2 className="font-bodoni text-4xl md:text-5xl lg:text-6xl font-light leading-tight">
            SSELFIE isn&apos;t just<br />
            about pictures.
          </h2>
          
          <div className="space-y-4">
            <p className="font-inter text-xl font-light text-white/80">
              It&apos;s about power.
            </p>
            <p className="font-inter text-lg font-light text-white/70 max-w-3xl mx-auto">
              It&apos;s about building something real from the version of you that almost gave up—but didn&apos;t.
            </p>
          </div>
          
          <div className="pt-12">
            <p className="font-bodoni text-2xl md:text-3xl font-light italic text-white/90">
              Because when you show up as her?<br />
              Everything changes.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
