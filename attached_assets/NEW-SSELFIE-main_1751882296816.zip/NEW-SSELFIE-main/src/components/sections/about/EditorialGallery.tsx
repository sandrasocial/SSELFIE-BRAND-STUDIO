'use client'

import React from 'react'
import Image from 'next/image'
import { SandraImages } from '@/components/sandra-image-library'

export function EditorialGallery() {
  const galleryImages = [
    SandraImages.flatlays.workspace1,
    SandraImages.flatlays.workspace2,
    SandraImages.flatlays.beauty,
    SandraImages.flatlays.planning,
    SandraImages.editorial.laptop1,
    SandraImages.editorial.phone2,
    SandraImages.editorial.laughing,
    SandraImages.editorial.thinking
  ]

  return (
    <section className="py-2">
      <div className="grid grid-cols-2 gap-0">
        {galleryImages.map((src, i) => (
          <div key={i} className="relative w-full h-48">
            <Image
              src={src}
              alt={`BTS ${i + 1}`}
              fill
              className="object-cover"
              priority={i === 0}
            />
          </div>
        ))}
      </div>
    </section>
  )
}
