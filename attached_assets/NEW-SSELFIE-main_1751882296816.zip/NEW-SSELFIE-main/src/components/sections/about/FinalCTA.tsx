'use client'

import React from 'react'
import Link from 'next/link'

interface FinalCTAProps {
  title?: string
  ctaText?: string
  ctaLink?: string
}

export function FinalCTA({ 
  title = "Your mess is your message.\nLet's turn it into money.",
  ctaText = "Start Your Journey",
  ctaLink = "/pricing"
}: FinalCTAProps) {
  return (
    <section className="py-24 md:py-32">
      <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-4xl text-center">
        <div className="space-y-12">
          <p className="font-inter text-xs tracking-[0.3em] uppercase text-luxury-black/50">
            Ready to start?
          </p>
          
          <h2 className="font-bodoni text-4xl md:text-5xl font-light text-luxury-black">
            {title.split('\n').map((line, i) => (
              <React.Fragment key={i}>
                {line}
                {i < title.split('\n').length - 1 && <br />}
              </React.Fragment>
            ))}
          </h2>
          
          <Link 
            href={ctaLink}
            className="inline-block mt-8 px-12 py-4 bg-luxury-black text-white font-inter text-sm tracking-wider uppercase hover:bg-luxury-black/90 transition-colors"
          >
            {ctaText}
          </Link>
        </div>
      </div>
    </section>
  )
}
