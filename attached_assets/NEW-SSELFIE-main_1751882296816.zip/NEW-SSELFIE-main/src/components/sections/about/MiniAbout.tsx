import React from 'react'

export const MiniAbout = () => {
  return (
    <section>
      {/* Sandra's story preview for homepage */}
      <h2>Mini About - Coming Soon</h2>
    </section>
  )
}
