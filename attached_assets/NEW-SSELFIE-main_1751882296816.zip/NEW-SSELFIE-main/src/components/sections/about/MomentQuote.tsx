'use client'

import React from 'react'

export function MomentQuote() {
  return (
    <section className="py-24 md:py-32">
      <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-7xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20 items-center">
          {/* Left - Quote */}
          <div className="lg:col-span-6 order-2 lg:order-1">
            <div className="lg:pl-12">
              <div className="border-l-2 border-luxury-black/20 pl-8">
                <h3 className="font-bodoni text-3xl md:text-4xl font-light text-luxury-black leading-relaxed">
                  &ldquo;And one day, in the middle of all that mess—I picked up my phone. Took a selfie. Posted something honest.&rdquo;
                </h3>
                
                <p className="font-inter text-lg font-light text-luxury-black/60 mt-8">
                  Not perfect. Just true.
                </p>
              </div>
            </div>
          </div>

          {/* Right - Image Grid */}
          <div className="lg:col-span-6 order-1 lg:order-2">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
              <div style={{ 
                width: '100%', 
                height: '160px', 
                backgroundColor: 'black',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <p style={{ 
                  color: 'rgba(255,255,255,0.2)', 
                  fontSize: '10px',
                  textTransform: 'uppercase',
                  letterSpacing: '0.1em',
                  textAlign: 'center'
                }}>
                  First<br />Selfie
                </p>
              </div>
              <div style={{ 
                width: '100%', 
                height: '160px', 
                backgroundColor: 'black',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <p style={{ 
                  color: 'rgba(255,255,255,0.2)', 
                  fontSize: '10px',
                  textTransform: 'uppercase',
                  letterSpacing: '0.1em',
                  textAlign: 'center'
                }}>
                  Day 30
                </p>
              </div>
              <div style={{ 
                width: '100%', 
                height: '160px', 
                backgroundColor: 'black',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <p style={{ 
                  color: 'rgba(255,255,255,0.2)', 
                  fontSize: '10px',
                  textTransform: 'uppercase',
                  letterSpacing: '0.1em',
                  textAlign: 'center'
                }}>
                  Day 60
                </p>
              </div>
              <div style={{ 
                width: '100%', 
                height: '160px', 
                backgroundColor: 'black',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <p style={{ 
                  color: 'rgba(255,255,255,0.2)', 
                  fontSize: '10px',
                  textTransform: 'uppercase',
                  letterSpacing: '0.1em',
                  textAlign: 'center'
                }}>
                  Day 90
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
