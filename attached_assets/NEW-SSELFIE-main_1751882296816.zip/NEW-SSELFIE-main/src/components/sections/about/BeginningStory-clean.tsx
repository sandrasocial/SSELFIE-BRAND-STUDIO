'use client'

import React from 'react'
import Link from 'next/link'
import Image from 'next/image'

export function BeginningStory() {
  return (
    <section className="section-padding bg-white">
      <div className="max-width-editorial px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 grid-gap lg:gap-20 items-center">
          {/* Editorial Image */}
          <div className="lg:col-span-5">
            <div className="relative w-full h-[420px] md:h-[500px] overflow-hidden">
              <Image
                src="/editorial/rock-bottom-sandra.jpg" // TODO: Update to use your local image when ready
                alt="Sandra looking real, not perfect"
                fill
                className="editorial-image object-cover"
                priority
                sizes="(max-width: 1024px) 100vw, 500px"
              />
            </div>
          </div>

          {/* Story Copy */}
          <div className="lg:col-span-7">
            <span className="section-label mb-6 block">
              Chapter One
            </span>
            <h2 className="luxury-headline text-2xl md:text-3xl lg:text-4xl mb-10">
              This didn&apos;t start<br />
              as a business.
            </h2>
            <div className="space-y-6">
              <p className="body-copy text-lg">
                It started as survival.
              </p>
              <p className="body-copy text-black/80">
                One year ago, I hit rock bottom. Divorced. Three kids. No backup plan.
                I was heartbroken, exhausted, and completely disconnected from the woman I used to be.
              </p>
              <p className="body-copy text-black/70 italic">
                I didn&apos;t recognize myself. Not in the mirror. Not in my life.
              </p>
              {/* Ghost Button */}
              <div className="pt-8">
                <Link 
                  href="/about"
                  className="cta-link group"
                >
                  Continue reading
                  <svg 
                    className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform duration-300"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                  </svg>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
