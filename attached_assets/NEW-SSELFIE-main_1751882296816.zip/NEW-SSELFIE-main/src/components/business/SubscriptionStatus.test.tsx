// Test usage of SubscriptionStatus component
import { SubscriptionStatus, SubscriptionData } from '@/components/business/SubscriptionStatus'

// Test data
const testSubscription: SubscriptionData = {
  plan: 'monthly',
  status: 'active',
  price: '$47/month',
  billingCycle: 'monthly',
  nextBillingDate: new Date('2025-07-26'),
  paymentMethod: {
    brand: 'Visa',
    last4: '4242'
  },
  usage: {
    current: 25,
    limit: 50,
    resetDate: new Date('2025-07-26')
  }
}

// Usage examples
export const SubscriptionStatusExamples = () => {
  return (
    <div className="space-y-8 p-8">
      {/* Widget variant */}
      <SubscriptionStatus 
        subscription={testSubscription}
        variant="widget"
        onManage={() => console.log('Manage clicked')}
        onUpgrade={() => console.log('Upgrade clicked')}
      />
      
      {/* Card variant */}
      <SubscriptionStatus 
        subscription={testSubscription}
        variant="card"
        onManage={() => console.log('Manage clicked')}
        onUpgrade={() => console.log('Upgrade clicked')}
      />
      
      {/* Inline variant */}
      <SubscriptionStatus 
        subscription={testSubscription}
        variant="inline"
        onManage={() => console.log('Manage clicked')}
        onUpgrade={() => console.log('Upgrade clicked')}
      />
      
      {/* Upgrade prompt variant */}
      <SubscriptionStatus 
        subscription={testSubscription}
        variant="upgrade"
        onUpgrade={() => console.log('Upgrade clicked')}
      />
    </div>
  )
}
