"use client";

import React from "react";
import { cn } from "@/lib/utils"; // For className merging
import { PlanBadge } from "@/components/ui/badge"; // Plan badge
import { ProgressBar } from "@/components/ui/progress"; // For usage display

// -- Types & Interfaces --

export type PlanType = "free" | "monthly" | "annual" | "lifetime";
export type SubscriptionStatusType = "active" | "cancelled" | "past_due" | "expired";

export interface SubscriptionData {
  plan: PlanType;
  status: SubscriptionStatusType;
  price?: string;
  billingCycle?: string;
  nextBillingDate?: Date;
  cancelAtPeriodEnd?: boolean;
  paymentMethod?: {
    brand: string;
    last4: string;
  };
  purchaseDate?: Date;
  usage?: {
    current: number;
    limit: number;
    resetDate?: Date;
  };
}

type Variant = "widget" | "card" | "inline" | "upgrade";

export interface SubscriptionStatusProps {
  subscription?: SubscriptionData;
  variant?: Variant;
  showUsage?: boolean;
  showActions?: boolean;
  onManage?: () => void;
  onUpgrade?: () => void;
  onCancel?: () => void;
  darkMode?: boolean;
  className?: string;
}

// -- Helpers --

function formatDate(date?: Date) {
  if (!date) return null;
  return date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

// -- Layout Variants --

function WidgetView({
  subscription,
  showUsage,
  showActions,
  onManage,
  onUpgrade,
  darkMode,
}: SubscriptionStatusProps) {
  if (!subscription) {
    return (
      <div className={cn("ssub-widget", darkMode && "ssub-dark")}>
        <div className="ssub-widget-header">
          <PlanBadge plan="free" />
          <span className="ssub-plan">No plan</span>
        </div>
        <div className="ssub-widget-cta">
          <button onClick={onUpgrade} className="ssub-btn">Upgrade</button>
        </div>
      </div>
    );
  }
  return (
    <div className={cn("ssub-widget", darkMode && "ssub-dark")}>
      <div className="ssub-widget-header">
        <PlanBadge plan={subscription.plan} />
        <span className="ssub-plan">{subscription.plan === "free" ? "Free Plan" : subscription.price}</span>
      </div>
      {showUsage && subscription.usage && (
        <div className="ssub-widget-usage">
          <ProgressBar value={Math.min(100, (subscription.usage.current / subscription.usage.limit) * 100)} />
          <span className="ssub-usage-text">
            {subscription.usage.current} / {subscription.usage.limit} AI generations
          </span>
        </div>
      )}
      {showActions && (
        <div className="ssub-widget-actions">
          <button onClick={onManage} className="ssub-btn">Manage</button>
          {subscription.plan !== "lifetime" && (
            <button onClick={onUpgrade} className="ssub-btn-alt">Upgrade</button>
          )}
        </div>
      )}
    </div>
  );
}

function CardView({
  subscription,
  showUsage,
  showActions,
  onManage,
  onUpgrade,
  onCancel,
  darkMode,
}: SubscriptionStatusProps) {
  if (!subscription) return null;
  const isLifetime = subscription.plan === "lifetime";
  return (
    <div className={cn("ssub-card", darkMode && "ssub-dark")}>
      <div className="ssub-card-header">
        <PlanBadge plan={subscription.plan} />
        <h2 className="ssub-card-plan">
          {isLifetime ? "Lifetime Access" : subscription.plan.charAt(0).toUpperCase() + subscription.plan.slice(1) + " Plan"}
        </h2>
        <span className="ssub-card-price">{subscription.price}</span>
      </div>
      <div className="ssub-card-details">
        {isLifetime ? (
          <div className="ssub-card-row">
            <span>Purchased:</span>
            <span>{formatDate(subscription.purchaseDate)}</span>
          </div>
        ) : (
          <>
            <div className="ssub-card-row">
              <span>Next Billing:</span>
              <span>{formatDate(subscription.nextBillingDate)}</span>
            </div>
            {subscription.paymentMethod && (
              <div className="ssub-card-row">
                <span>Payment:</span>
                <span>
                  {subscription.paymentMethod.brand} ••••{subscription.paymentMethod.last4}
                </span>
              </div>
            )}
          </>
        )}
        {showUsage && subscription.usage && (
          <div className="ssub-card-usage">
            <span className="ssub-card-usage-label">AI Usage</span>
            <ProgressBar value={Math.min(100, (subscription.usage.current / subscription.usage.limit) * 100)} />
            <span className="ssub-usage-text">
              {subscription.usage.current} / {subscription.usage.limit} used
              {subscription.usage.resetDate && (
                <span> · Resets {formatDate(subscription.usage.resetDate)}</span>
              )}
            </span>
          </div>
        )}
      </div>
      {showActions && (
        <div className="ssub-card-actions">
          <button onClick={onManage} className="ssub-btn">Manage</button>
          {!isLifetime && <button onClick={onUpgrade} className="ssub-btn-alt">Upgrade</button>}
          {!isLifetime && <button onClick={onCancel} className="ssub-btn-link">Cancel</button>}
        </div>
      )}
    </div>
  );
}

function InlineView({
  subscription,
  onManage,
  onUpgrade,
  darkMode,
}: SubscriptionStatusProps) {
  if (!subscription) return null;
  return (
    <div className={cn("ssub-inline", darkMode && "ssub-dark")}>
      <PlanBadge plan={subscription.plan} />
      <span className="ssub-inline-info">
        {subscription.price} {subscription.billingCycle && <span>· {subscription.billingCycle}</span>}
      </span>
      <button onClick={onManage} className="ssub-btn-link">Manage</button>
      {subscription.plan !== "lifetime" && (
        <button onClick={onUpgrade} className="ssub-btn-link">Upgrade</button>
      )}
    </div>
  );
}

function UpgradePromptView({
  onUpgrade,
  darkMode,
}: SubscriptionStatusProps) {
  return (
    <div className={cn("ssub-upgrade", darkMode && "ssub-dark")}>
      <span className="ssub-upgrade-headline">Upgrade for more magic</span>
      <button onClick={onUpgrade} className="ssub-btn">Upgrade</button>
    </div>
  );
}

// -- Main Component --

export const SubscriptionStatus: React.FC<SubscriptionStatusProps> = ({
  subscription,
  variant = "widget",
  showUsage = true,
  showActions = true,
  onManage,
  onUpgrade,
  onCancel,
  darkMode = false,
  className,
}) => {
  switch (variant) {
    case "card":
      return (
        <CardView
          subscription={subscription}
          showUsage={showUsage}
          showActions={showActions}
          onManage={onManage}
          onUpgrade={onUpgrade}
          onCancel={onCancel}
          darkMode={darkMode}
          className={className}
        />
      );
    case "inline":
      return (
        <InlineView
          subscription={subscription}
          onManage={onManage}
          onUpgrade={onUpgrade}
          darkMode={darkMode}
          className={className}
        />
      );
    case "upgrade":
      return (
        <UpgradePromptView
          onUpgrade={onUpgrade}
          darkMode={darkMode}
          className={className}
        />
      );
    case "widget":
    default:
      return (
        <WidgetView
          subscription={subscription}
          showUsage={showUsage}
          showActions={showActions}
          onManage={onManage}
          onUpgrade={onUpgrade}
          darkMode={darkMode}
          className={className}
        />
      );
  }
};

export default SubscriptionStatus;