"use client";

import React from "react";
import clsx from "clsx";

interface PricingCardProps {
  title: string;
  description: string;
  price: string;
  frequency?: string;
  features: string[];
  ctaText?: string;
  ctaHref?: string;
  highlight?: boolean;
  className?: string;
}

const PricingCard: React.FC<PricingCardProps> = ({
  title,
  description,
  price,
  frequency = "/month",
  features,
  ctaText = "Get Access",
  ctaHref = "#",
  highlight = false,
  className,
}) => {
  return (
    <section
      className={clsx(
        "",
        highlight && "",
        className
      )}
    >
      <div className={""}>
        <h3 className={""}>{title}</h3>
        <p className={""}>{description}</p>
      </div>
      <div className={""}>
        <span className={""}>{price}</span>
        <span className={""}>{frequency}</span>
      </div>
      <ul className={""}>
        {features.map((feature, i) => (
          <li key={i} className={""}>
            {feature}
          </li>
        ))}
      </ul>
      <a href={ctaHref} className={""}>
        {ctaText}
      </a>
    </section>
  );
};

export default PricingCard;