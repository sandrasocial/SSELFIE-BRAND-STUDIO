"use client";

import React from "react";
import clsx from "clsx";

interface FreebiePreviewProps {
  title: string;
  description: string;
  imageUrl: string;
  ctaText?: string;
  ctaHref?: string;
  className?: string;
}

const FreebiePreview: React.FC<FreebiePreviewProps> = ({
  title,
  description,
  imageUrl,
  ctaText = "Get Your Freebie",
  ctaHref = "#",
  className,
}) => {
  return (
    <section className={clsx("", className)}>
      <header className={""}>
        <h2 className={""}>{title}</h2>
        <p className={""}>{description}</p>
      </header>
      <div className={""}>
        <img src={imageUrl} alt={title} className={""} />
      </div>
      <a href={ctaHref} className={""}>
        {ctaText}
      </a>
      <footer className={""}>
        <span>No spam. No cringe. Just real help.</span>
      </footer>
    </section>
  );
};

export default FreebiePreview;