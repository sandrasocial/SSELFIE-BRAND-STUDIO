"use client";

import React from "react";
import clsx from "clsx";

type Step = {
  number: number;
  title: string;
  description: string;
};

const OnboardingSteps: React.FC<{
  steps: Step[];
  className?: string;
}> = ({
  steps,
  className = "",
}) => {
  return (
    <section className={clsx("section-padding bg-white", className)}>
      <div className="max-width-editorial px-6">
        <header className="text-center mb-16">
          <h2 className="luxury-headline text-3xl md:text-4xl mb-4">Let's Get You Set Up</h2>
          <p className="body-copy text-lg">
            You don't need to overthink this. Just follow these steps and you'll be up and running before your coffee gets cold.
          </p>
        </header>
        <ol className="space-y-8">
          {steps.map((step) => (
            <li className="flex gap-6 items-start" key={step.number}>
              <span className="section-label bg-luxury-black text-white px-3 py-2 text-xs">{String(step.number).padStart(2, "0")}</span>
              <div>
                <h3 className="luxury-headline text-xl mb-2">{step.title}</h3>
                <p className="body-copy">{step.description}</p>
              </div>
            </li>
          ))}
        </ol>
        <footer className="text-center mt-16">
          <span className="section-label">Stuck? DM Sandra on Instagram. There's always a way forward.</span>
        </footer>
      </div>
    </section>
  );
};

export default OnboardingSteps;