"use client";

import React from "react";
import clsx from "clsx";

type BillingEntry = {
  id: string;
  date: string; // e.g. "2025-06-15"
  description: string; // e.g. "SSELFIE Pro Membership"
  amount: string; // e.g. "$97"
  status: "Paid" | "Upcoming" | "Failed";
};

interface BillingHistoryProps {
  entries: BillingEntry[];
  className?: string;
}

const BillingHistory: React.FC<BillingHistoryProps> = ({
  entries,
  className
}) => {
  return (
    <section className={clsx("", className)}>
      <header className={""}>
        <h1 className={""}>Your Investments</h1>
        <p className={""}>
          Every payment here is a step closer to your next big thing. Real talk—thank you for betting on yourself.
        </p>
      </header>
      <div className={""}>
        <div className={""}>
          <span>Date</span>
          <span>Description</span>
          <span className={""}>Amount</span>
          <span>Status</span>
        </div>
        <div className={""}>
          {entries.length === 0 ? (
            <div className={""}>
              <p>No billing history yet. When you invest, it’ll show up here.</p>
            </div>
          ) : (
            entries.map((entry) => (
              <div className={clsx("", styles[`status${entry.status}`])} key={entry.id}>
                <span className={""}>{entry.date}</span>
                <span className={""}>{entry.description}</span>
                <span className={clsx("", "")}>{entry.amount}</span>
                <span className={""}>{entry.status}</span>
              </div>
            ))
          )}
        </div>
      </div>
      <footer className={""}>
        <p>
          Need help with billing? <a href="mailto:sandra@sselfie.com" className={""}>Email Sandra directly</a>. No robots, just real answers.
        </p>
      </footer>
    </section>
  );
};

export default BillingHistory;