"use client";

import React from "react";
import clsx from "clsx";

interface ContactSectionProps {
  headline?: string;
  subtitle?: string;
  ctaText?: string;
  email?: string;
  instagram?: string;
  children?: React.ReactNode;
  className?: string;
}

const ContactSection: React.FC<ContactSectionProps> = ({
  headline = "Let’s Chat",
  subtitle = "Got a question? Something you’re stuck on? Or just want to say hi? My inbox is as open as my DMs.",
  ctaText = "Email Sandra",
  email = "hello@sselfie.ai",
  instagram = "sandra.social",
  children,
  className,
}) => (
  <section className={clsx("", className)}>
    <header className={""}>
      <h2 className={""}>{headline}</h2>
      <p className={""}>{subtitle}</p>
    </header>
    <div className={""}>
      <a href={`mailto:${email}`} className={""}>
        {ctaText}
      </a>
      <span className={""}>or</span>
      <a
        href={`https://instagram.com/${instagram.replace(/^@/, "")}`}
        target="_blank"
        rel="noopener noreferrer"
        className={""}
      >
        DM on Instagram
      </a>
    </div>
    {children && <div className={""}>{children}</div>}
    <footer className={""}>
      <span>
        No bots. No auto-replies. Just a real conversation with someone who gets it.
      </span>
    </footer>
  </section>
);

export default ContactSection;