"use client";

import React from "react";
import clsx from "clsx";

type Testimonial = {
  text: string;
  name?: string; // Optional—use if you want to show their @handle, first name, or leave anonymous.
  context?: string; // e.g. "DM", "Instagram", "Email", etc. (optional)
};

interface SocialProofProps {
  testimonials: Testimonial[];
  className?: string;
}

const SocialProof: React.FC<SocialProofProps> = ({
  testimonials,
  className,
}) => (
  <section className={clsx("", className)}>
    <header className={""}>
      <h2 className={""}>Real Women, Real Results</h2>
      <p className={""}>
        Every message here is 100% real—no fake names, no stock photos, just the stories of women who decided to show up for themselves.
      </p>
    </header>
    <div className={""}>
      {testimonials.map((t, idx) => (
        <blockquote className={""} key={idx}>
          <p className={""}>&ldquo;{t.text}&rdquo;</p>
          {t.name && (
            <footer className={""}>
              <span className={""}>{t.name}</span>
              {t.context && <span className={""}> · {t.context}</span>}
            </footer>
          )}
        </blockquote>
      ))}
    </div>
    <div className={""}>
      <span>
        Want to see more? Check my DMs. This is what happens when you show up for yourself.
      </span>
    </div>
  </section>
);

export default SocialProof;