"use client";

import React from "react";
import clsx from "clsx";

interface SuccessMessageProps {
  headline?: string;
  message?: string;
  ctaText?: string;
  ctaHref?: string;
  className?: string;
}

const SuccessMessage: React.FC<SuccessMessageProps> = ({
  headline = "You’re In!",
  message = "Check your inbox for next steps. If you don’t see it, check your spam (sometimes tech gets weird). Either way, you did the brave thing—now let’s get to the good part.",
  ctaText = "Back to Home",
  ctaHref = "/",
  className,
}) => (
  <section className={clsx("", className)}>
    <div className={""}>✨</div>
    <h2 className={""}>{headline}</h2>
    <p className={""}>{message}</p>
    <a href={ctaHref} className={""}>
      {ctaText}
    </a>
    <footer className={""}>
      <span>
        Still stuck? DM me on Instagram <b>@sandra.social</b>—I actually answer.
      </span>
    </footer>
  </section>
);

export default SuccessMessage;