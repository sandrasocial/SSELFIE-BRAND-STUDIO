# SubscriptionStatus Component

A comprehensive subscription management component that displays subscription information with multiple layout variants and interactive features.

## Features

- **Multiple Variants**: Widget, Card, Inline, and Upgrade Prompt layouts
- **Plan Support**: Free, Monthly, Annual, and Lifetime plans
- **Usage Tracking**: AI generation limits and current usage display
- **Interactive Actions**: Manage, upgrade, and cancellation options
- **Dark Mode Support**: Full theming support
- **TypeScript Safe**: Complete type definitions and interfaces

## Usage

```tsx
import { SubscriptionStatus, SubscriptionData } from '@/components/business/SubscriptionStatus'

const subscription: SubscriptionData = {
  plan: 'monthly',
  status: 'active',
  price: '$47/month',
  billingCycle: 'monthly',
  nextBillingDate: new Date('2025-07-26'),
  paymentMethod: {
    brand: 'Visa',
    last4: '4242'
  },
  usage: {
    current: 25,
    limit: 50,
    resetDate: new Date('2025-07-26')
  }
}

// Widget variant (compact)
<SubscriptionStatus 
  subscription={subscription}
  variant="widget"
  onManage={() => console.log('Manage clicked')}
  onUpgrade={() => console.log('Upgrade clicked')}
/>

// Full card variant
<SubscriptionStatus 
  subscription={subscription}
  variant="card"
  showUsage={true}
  showActions={true}
  onManage={() => console.log('Manage clicked')}
  onUpgrade={() => console.log('Upgrade clicked')}
/>

// Inline variant
<SubscriptionStatus 
  subscription={subscription}
  variant="inline"
  onManage={() => console.log('Manage clicked')}
  onUpgrade={() => console.log('Upgrade clicked')}
/>

// Upgrade prompt variant
<SubscriptionStatus 
  subscription={subscription}
  variant="upgrade"
  onUpgrade={() => console.log('Upgrade clicked')}
/>
```

## Props

### SubscriptionStatusProps

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `subscription` | `SubscriptionData` | - | Subscription data object |
| `variant` | `'widget' \| 'card' \| 'inline' \| 'upgrade'` | `'widget'` | Layout variant |
| `showUsage` | `boolean` | `true` | Show usage information |
| `showActions` | `boolean` | `true` | Show action buttons |
| `onManage` | `() => void` | - | Manage subscription callback |
| `onUpgrade` | `() => void` | - | Upgrade subscription callback |
| `onCancel` | `() => void` | - | Cancel subscription callback |
| `darkMode` | `boolean` | `false` | Enable dark mode styling |
| `className` | `string` | - | Additional CSS classes |

### SubscriptionData

| Property | Type | Description |
|----------|------|-------------|
| `plan` | `'free' \| 'monthly' \| 'annual' \| 'lifetime'` | Subscription plan type |
| `status` | `'active' \| 'cancelled' \| 'past_due' \| 'expired'` | Current status |
| `price` | `string` | Display price (optional) |
| `billingCycle` | `string` | Billing frequency (optional) |
| `nextBillingDate` | `Date` | Next billing date (optional) |
| `cancelAtPeriodEnd` | `boolean` | Cancel at period end flag (optional) |
| `paymentMethod` | `{ brand: string; last4: string }` | Payment method info (optional) |
| `purchaseDate` | `Date` | Purchase date for lifetime plans (optional) |
| `usage` | `{ current: number; limit: number; resetDate?: Date }` | Usage tracking (optional) |

## Variants

### Widget (`variant="widget"`)
Compact display suitable for dashboards and sidebar widgets.

### Card (`variant="card"`)  
Full-featured card with detailed information, usage charts, and feature lists.

### Inline (`variant="inline"`)
Minimal inline display for tight spaces and summary views.

### Upgrade Prompt (`variant="upgrade"`)
Call-to-action focused variant to encourage upgrades.

## Styling

The component uses:
- **Luxury Design**: Consistent with SSELFIE brand guidelines
- **Typography**: Serif headings, clean sans-serif body text
- **Colors**: Luxury black, pure white, soft whites, warm grays
- **Animations**: Hover effects and smooth transitions
- **Responsive**: Mobile-first design approach

## Dependencies

- `@/components/ui/badge` - Badge and PlanBadge components
- `@/components/ui/progress` - Progress bar component  
- `@/lib/utils` - Utility functions (cn for className merging)

## Examples

See `SubscriptionStatus.test.tsx` for complete usage examples and test cases.
