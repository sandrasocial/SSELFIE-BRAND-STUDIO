# Sandra’s Editorial & UI Components

Hey Diana—this is your *no-stress, all-style* guide to dropping Sandra’s new editorial magic into our Next.js codebase.  
If you’ve got a question, this file probably answers it (and if it doesn’t, you know where to find me).

---

## What’s Inside

- **EditorialSpread.tsx / .module.css**  
  Editorial layouts (quotes, splits, magazine columns, stats, testimonials).
- **EditorialMoodboard.tsx / .module.css**  
  Magazine-style inspiration grid/collage.
- **EditorialCTA.tsx / .module.css**  
  Luxe, minimal call-to-action.
- **OfferCard.tsx, OfferCardsGrid.tsx / .module.css**  
  “Work With Me” grid, including optional badges (“NEW”, “Waitlist”, etc).
- **UI Kit:**  
  - Button, Input, Textarea, Checkbox, CheckboxGroup, TermsCheckbox, Radio, RadioGroup, Select, ToggleSwitch, Tabs, ProgressLabel, Badge, Sonner (toast), FeatureCard, TestimonialCard, MinimalCard, HeroCard, ProductCard.
- **Business Components:**  
  - Everything in `/components/business` — billing, onboarding, pricing cards, testimonials, etc.
- **Sandra Image Library:**  
  All the brand images (and their URLs) you’ll need—update these in `/sandra-image-library.ts` as needed.
- **Styleguide:**  
  Color codes, spacing, font stacks, and all the little rules that keep it feeling “editorial, not corporate.”  
  *(If you’re not sure about a color or spacing—peek here.)*

---

## Quick Start

1. **All shared components live in `/components` or `/components/ui` (never `/app/components`).**
2. **Update images in `/components/sandra-image-library.ts` (swap URLs as needed).**
3. **Import and use components anywhere—see usage below!**

---

## Hero Component Patterns

```tsx
// For long names
<HeroFullBleed
  backgroundImage={image}
  tagline="The Icelandic Selfie Queen"
  title="SANDRA"
  subtitle="SIGURJONSDOTTIR"
/>

// For single words
<HeroFullBleed
  backgroundImage={image}
  tagline="Turn your selfies into a CEO shot"
  title="SSELFIE"
  subtitle="STUDIO"
/>
```

---

## Usage Examples

#### Editorial Components

```tsx
import EditorialSpread from "./EditorialSpread";
import EditorialMoodboard from "./EditorialMoodboard";
import EditorialCTA from "./EditorialCTA";

<EditorialSpread />
<EditorialMoodboard />
<EditorialCTA />
```

#### UI Kit (copy-paste these as needed)

**Buttons**
```tsx
import Button from "@/components/ui/Button";
<Button variant="primary">Let’s Go</Button>
<Button variant="secondary">See More</Button>
<Button variant="ghost" fullWidth>Start Now</Button>
```

**Cards**
```tsx
import { HeroCard, ProductCard, TestimonialCard, FeatureCard, MinimalCard } from "@/components/ui/Card";

// Hero
<HeroCard imageSrc="/your-image.jpg" imageAlt="Sandra, actual" meta="REAL STORY" title="Your mess is your message" description="Not perfect. Just true. That’s how we build something real." />

// Product
<ProductCard imageSrc="/offer.jpg" imageAlt="VIP Day" title="VIP Day" price="$497" period="/ per session" buttonText="Book Now" />

// Testimonial
<TestimonialCard testimonialImage="/clients/jessica.jpg" testimonialAlt="Client selfie" quote="Sandra’s method changed everything for me. I finally feel like myself—on camera and in life." name="Jessica S." handle="@jessica.social" />

// Feature
<FeatureCard imageSrc="/feature.jpg" imageAlt="The process" number="01" title="You Show Up" description="Start where you are. Your story is enough." />

// Minimal
<MinimalCard>
  <blockquote>“Building a brand is just showing up—again and again.”</blockquote>
</MinimalCard>
```

**Inputs, Textarea, Select**
```tsx
import Input from "@/components/ui/Input";
import Textarea from "@/components/ui/Textarea";
import Select from "@/components/ui/Select";

<Input label="Email Address" placeholder="you@email.com" type="email" />
<Textarea label="Your Story" placeholder="Okay, here’s what actually happened…" />
<Select label="Choose your vibe" options={[{ value: "", label: "Select..." }, { value: "confident", label: "Confident" }, { value: "warm", label: "Warm" }, { value: "direct", label: "Direct" }]} error="Don't forget to pick your vibe!" fullWidth />
```

**Checkboxes, Radio, Toggle, Terms**
```tsx
import Checkbox from "@/components/ui/Checkbox";
import CheckboxGroup from "@/components/ui/CheckboxGroup";
import TermsCheckbox from "@/components/ui/TermsCheckbox";
import Radio from "@/components/ui/Radio";
import RadioGroup from "@/components/ui/RadioGroup";
import ToggleSwitch from "@/components/ui/ToggleSwitch";

<Checkbox label="I promise this is my real story." />
<CheckboxGroup label="What do you want more of?" orientation="vertical">
  <Checkbox label="Confidence" />
  <Checkbox label="Strategy" />
  <Checkbox label="Real Talk" />
</CheckboxGroup>
<TermsCheckbox error="You gotta agree, babe—it's the law." />
<Radio name="vibe" label="Confident" />
<RadioGroup label="Pick your vibe" orientation="horizontal">
  <Radio name="vibe" label="Confident" />
  <Radio name="vibe" label="Warm" />
  <Radio name="vibe" label="Direct" />
</RadioGroup>
<ToggleSwitch label="Show my real side" />
```

**Tabs**
```tsx
import Tabs from "@/components/ui/Tabs";
<Tabs tabs={[
  { label: "About", content: <div>Story time...</div> },
  { label: "Results", content: <div>Proof, not promises.</div> },
  { label: "FAQ", content: <div>Ask me anything.</div> },
]} />
```

**ProgressLabel & Usage Progress**
```tsx
import ProgressLabel from "@/components/ui/ProgressLabel";
import { UsageProgressBar } from "@/components/ui/usage_progress_bar";

<ProgressLabel value={78} label="Profile Complete" />
<UsageProgressBar usage={{ used: 45, total: 100, plan: "monthly" }} variant="widget" />
```

**Badge**
```tsx
import Badge from "@/components/ui/Badge";
<Badge>NEW</Badge>
<Badge color="success">Success</Badge>
<Badge color="error">Sold Out</Badge>
<Badge color="info">Waitlist</Badge>
```

**Toasts**
```tsx
import { SonnerProvider, useSonner } from "@/components/ui/Sonner";

<SonnerProvider>
  <App />
</SonnerProvider>

const { notify } = useSonner();
<button onClick={() => notify("success", "Your real story was saved!")}>Show Success Toast</button>
```

**Offer Cards Grid**
```tsx
import OfferCardsGrid from "@/components/ui/OfferCardsGrid";
<OfferCardsGrid />
```

---

## Styleguide, Fonts & Brand Notes

- **Fonts:** Bodoni for headlines, Inter for everything else (see CSS modules for exact stacks)
- **Colors:** See `/styleguide` for the full palette and usage notes
- **Spacing/Editorial Rhythm:** 2.5–4rem for main sections, keep cards & spreads airy
- **Image Library:** Swap/update in `/components/sandra-image-library.ts`
- **Accessibility:** Alt tags, label props, and semantic HTML are already baked in—just keep it up

---

## Troubleshooting

- **Something looks weird?**  
  Check the CSS module for that component—sometimes a quick tweak does the trick.
- **Getting a TypeScript error?**  
  Double-check your prop names, or peek at the prop interfaces at the top of each `.tsx` file.
- **Image not showing up?**  
  Make sure the path/URL in the component is valid and matches what’s in the image library.
- **Still lost?**  
  DM Sandra or drop your question in Slack. You know there’s no such thing as a dumb question here.

---

## Final Tips (Because I Love You)

- If you need a new component, copy one you like and tweak the vibe. Consistency = luxury.
- If you’re rebranding or tweaking colors/fonts, start in the styleguide and cascade changes in `.module.css` files.
- Always test new UI bits on mobile—because Sandra’s people are always on their phones.
- And if you ever wonder “What would Sandra do?”—make it bold, make it warm, and make it real.

---

*Okay, go build something beautiful (and DM me if you get stuck).*

---

## BUSINESS COMPONENTS — HOW TO USE

**Import business components from `/components/business/` and use them like this:**

```tsx
import BillingHistory from "@/components/business/BillingHistory";

<BillingHistory
  entries={[
    {
      id: "1",
      date: "2025-06-15",
      description: "SSELFIE Pro Membership",
      amount: "$97",
      status: "Paid"
    },
    {
      id: "2",
      date: "2025-07-01",
      description: "VIP Workshop",
      amount: "$297",
      status: "Upcoming"
    }
  ]}
/>

// Freebie Preview
import FreebiePreview from "@/components/business/FreebiePreview";
<FreebiePreview
  title="SELFIE AI™: Becoming a Selfie Queen"
  description="My best secrets for camera confidence, lighting, and posing—no fancy equipment or filters needed. It’s the exact guide that took me from hiding to showing up (and building a real brand). Ready to step in front of the camera like you own it?"
  imageUrl="/selfie-ai-cover.jpg" // or your actual cover image URL
  ctaText="Download the Guide"
  ctaHref="/freebie-download"
/>

// Onboarding Steps
import OnboardingSteps from "@/components/business/OnboardingSteps";
<OnboardingSteps
  steps={[
    {
      number: 1,
      title: "Confirm Your Email",
      description: "Check your inbox (and spam, just in case). Click that confirmation link so we know it’s really you."
    },
    {
      number: 2,
      title: "Tell Us About You",
      description: "A few quick questions so we can actually help (not just guess what you need)."
    },
    {
      number: 3,
      title: "Download Your Freebie",
      description: "Grab your guide and start showing up. No fluff, no waiting."
    }
  ]}
/>

// Pricing Card
import PricingCard from "@/components/business/PricingCard";
<PricingCard
  title="SSELFIE STUDIO"
  description="Your monthly pass to the only studio where showing up as yourself is the whole point."
  price="$47"
  frequency="/month"
  features={[
    "All workshops, challenges & content",
    "Private community (women who actually show up)",
    "New resources added monthly"
  ]}
  ctaText="Join Monthly"
  ctaHref="/join-studio-monthly"
/>

<PricingCard
  title="SSELFIE STUDIO"
  description="Get two months free, because your future self deserves a little bonus."
  price="$297"
  frequency="/year"
  features={[
    "All workshops, challenges & content",
    "Private community (women who actually show up)",
    "New resources added monthly"
  ]}
  ctaText="Join Yearly"
  ctaHref="/join-studio-annual"
/>

<PricingCard
  title="SSELFIE STUDIO"
  description="Lifetime access for the woman who’s all in. Limited spots, because this is personal."
  price="$497"
  frequency="one-time"
  features={[
    "All workshops, challenges & content",
    "Private community (women who actually show up)",
    "New resources added monthly"
  ]}
  ctaText="Claim Lifetime Spot"
  ctaHref="/join-studio-lifetime"
/>

// Social Proof
import SocialProof from "@/components/business/SocialProof";
<SocialProof
  testimonials={[
    {
      text: "I just took the BEST photo of myself that I've taken in YEARS…",
      name: "Anonymous",
      context: "Instagram DM",
    },
    {
      text: "Watching your journey is helping me figure out a new path for myself. Thank you.",
      name: "Anonymous",
      context: "DM",
    },
    {
      text: "Your posts are so inspiring. I can't believe I didn't find you sooner! Relatable & love your content!",
      name: "Anonymous",
      context: "Instagram",
    },
    {
      text: "Thank you so much for recording this. So many of us are stuck thinking and doubting. But no one else can make us do it until we make this decision.",
      name: "Anonymous",
      context: "Instagram",
    },
    {
      text: "You have literally changed my picture taking from boring selfies to professional pictures!!! Thank you.",
      name: "Anonymous",
      context: "Instagram DM",
    },
    {
      text: "I just tried what you teach on your account and even in my pyjamas I made the most beautiful selfie since I have an iPhone.",
      name: "Medina Sandra",
      context: "Instagram DM",
    },
    {
      text: "I'm also just doing the same. Rebuilding myself in silence since 2 years. As you said keep showing up is key.",
      name: "saminxita",
      context: "Instagram",
    },
    {
      text: "Just purchased the selfie starter kit last night and it's amazing!!!!",
      name: "what.holly.likes",
      context: "Instagram",
    },
    {
      text: "You're absolutely incredible - I could listen to you all day!",
      name: "dinka_social_and_stories",
      context: "Instagram",
    },
    {
      text: "Thank you for all the value you give us.",
      name: "gunnsmenes_",
      context: "Instagram",
    },
    // …add as many as you want, keep it real!
  ]}
/>

// Contact Section
import ContactSection from "@/components/business/ContactSection";
<ContactSection
  headline="Let’s Build Something Real"
  subtitle="If you’re stuck, curious, or just want to share your story—slide into my inbox or my DMs. I actually read them."
  ctaText="Email Me"
  email="hello@sselfie.ai"
  instagram="sandra.social"
/>

// Success Message
import SuccessMessage from "@/components/business/SuccessMessage";
<SuccessMessage
  headline="You’re all set!"
  message="I see you, I’m cheering for you, and your download is on the way. If it’s not there, check your spam or shoot me a DM. Either way, you did the big thing—now go take a selfie (seriously)."
  ctaText="Return Home"
  ctaHref="/"
/>

// Example for custom styles
import styles from './FreebiePreview.module.css';
<div className={styles.card}>
  <h3 className={styles.headline}>{title}</h3>
  ...
</div>

// Using the Sandra Image Library
import { SandraImages } from "@/components/sandra-image-library";

// Example:
<HeroFullBleed backgroundImage={SandraImages.hero.homepage} ... />