'use client'

import React, { useState } from 'react'
import Link from 'next/link'
import { cn } from '@/lib/utils'

export interface ForgotPasswordProps {
  onSubmit?: (email: string) => Promise<void>
  className?: string
}

export const ForgotPassword: React.FC<ForgotPasswordProps> = ({
  onSubmit,
  className
}) => {
  const [email, setEmail] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  const [isSubmitted, setIsSubmitted] = useState(false)
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setIsLoading(true)
    
    try {
      if (onSubmit) {
        await onSubmit(email)
      } else {
        // Default behavior - simulate API call
        await new Promise(resolve => setTimeout(resolve, 2000))
      }
      
      setIsSubmitted(true)
      
    } catch (err: any) {
      setError(err.message || "That didn't work. Let's try again.")
    } finally {
      setIsLoading(false)
    }
  }
  
  return (
    <div className={cn('w-full max-w-md', className)}>
      {isSubmitted ? (
        <div className="text-center">
          <h2 className="font-serif text-2xl mb-4 text-soft-white">Reset link sent</h2>
          <p className="text-soft-white/70 mb-8">
            We've sent a reset link to {email}. 
            Check your inbox and follow the instructions.
          </p>
          <Link 
            href="/login" 
            className="inline-block py-3 px-8 border border-soft-white text-soft-white text-xs tracking-[0.3em] uppercase hover:bg-soft-white hover:text-luxury-black transition-all"
          >
            BACK TO SIGN IN
          </Link>
        </div>
      ) : (
        <>
          <h2 className="font-serif text-2xl mb-2 text-soft-white">Reset your password</h2>
          <p className="text-soft-white/70 mb-6">
            We'll send you a reset link. No drama.
          </p>
          
          {error && (
            <div className="bg-red-50 border-l-[3px] border-red-500 px-5 py-4 mb-6 text-sm text-red-800">
              {error}
            </div>
          )}
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-3">
              <label className="block text-xs tracking-[0.2em] uppercase text-soft-white/70">
                Email
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                required
                disabled={isLoading}
                className={cn(
                  'w-full px-0 py-4 bg-transparent border-0 border-b border-soft-white/40',
                  'placeholder:text-soft-white/30 focus:outline-none focus:border-b-2 focus:border-soft-white',
                  'transition-all duration-300 text-soft-white',
                  isLoading && 'opacity-50'
                )}
              />
            </div>
            
            <button
              type="submit"
              disabled={isLoading}
              className={cn(
                'w-full py-5 border border-soft-white text-soft-white',
                'text-xs tracking-[0.3em] uppercase font-light',
                'transition-all duration-300 hover:bg-soft-white hover:text-luxury-black',
                'disabled:opacity-70 disabled:cursor-not-allowed disabled:hover:bg-transparent disabled:hover:text-soft-white'
              )}
            >
              {isLoading ? (
                <span className="inline-flex items-center gap-2">
                  <span className="inline-block w-1 h-1 bg-current rounded-full animate-pulse" />
                  <span className="inline-block w-1 h-1 bg-current rounded-full animate-pulse delay-75" />
                  <span className="inline-block w-1 h-1 bg-current rounded-full animate-pulse delay-150" />
                </span>
              ) : (
                'SEND RESET LINK'
              )}
            </button>
          </form>
          
          <div className="mt-8 text-center">
            <Link 
              href="/login" 
              className="text-soft-white/70 hover:text-soft-white transition-colors"
            >
              Back to sign in
            </Link>
          </div>
        </>
      )}
    </div>
  )
}
