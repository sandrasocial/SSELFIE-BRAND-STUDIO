'use client'

import React, { useState } from 'react'
import Link from 'next/link'
import { cn } from '@/lib/utils'

export interface AuthFormProps {
  type: 'login' | 'signup'
  onSubmit?: (data: { name?: string; email: string; password: string }) => Promise<void>
  redirectUrl?: string
  className?: string
}

export const AuthForm: React.FC<AuthFormProps> = ({
  type,
  onSubmit,
  redirectUrl = '/dashboard',
  className
}) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
  })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setIsLoading(true)
    
    try {
      if (onSubmit) {
        if (type === 'login') {
          await onSubmit({ email: formData.email, password: formData.password })
        } else {
          await onSubmit(formData)
        }
      } else {
        // Default behavior - simulate API call
        await new Promise(resolve => setTimeout(resolve, 2000))
      }
      
      // Redirect on success
      window.location.href = redirectUrl
      
    } catch (err: any) {
      setError(err.message || "That doesn't look right. Let's try that again.")
    } finally {
      setIsLoading(false)
    }
  }
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
    setError('') // Clear error on input change
  }
  
  return (
    <div className={cn('w-full max-w-md', className)}>
      {error && (
        <div className="bg-red-50 border-l-[3px] border-red-500 px-5 py-4 mb-6 text-sm text-red-800 animate-fadeIn">
          {error}
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="space-y-6">
        {type === 'signup' && (
          <div className="space-y-3">
            <label className="block text-xs tracking-[0.2em] uppercase text-soft-white/70">
              Name
            </label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              placeholder="Your name"
              required
              disabled={isLoading}
              className={cn(
                'w-full px-0 py-4 bg-transparent border-0 border-b border-soft-white/40',
                'placeholder:text-soft-white/30 focus:outline-none focus:border-b-2 focus:border-soft-white',
                'transition-all duration-300 text-soft-white',
                isLoading && 'opacity-50'
              )}
            />
          </div>
        )}
        
        <div className="space-y-3">
          <label className="block text-xs tracking-[0.2em] uppercase text-soft-white/70">
            Email
          </label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleInputChange}
            placeholder="you@example.com"
            required
            disabled={isLoading}
            className={cn(
              'w-full px-0 py-4 bg-transparent border-0 border-b border-soft-white/40',
              'placeholder:text-soft-white/30 focus:outline-none focus:border-b-2 focus:border-soft-white',
              'transition-all duration-300 text-soft-white',
              isLoading && 'opacity-50'
            )}
          />
        </div>
        
        <div className="space-y-3">
          <label className="block text-xs tracking-[0.2em] uppercase text-soft-white/70">
            Password
          </label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleInputChange}
            placeholder="••••••••"
            required
            disabled={isLoading}
            className={cn(
              'w-full px-0 py-4 bg-transparent border-0 border-b border-soft-white/40',
              'placeholder:text-soft-white/30 focus:outline-none focus:border-b-2 focus:border-soft-white',
              'transition-all duration-300 text-soft-white',
              isLoading && 'opacity-50'
            )}
          />
        </div>
        
        {type === 'login' && (
          <div className="flex justify-end">
            <Link
              href="/forgot-password"
              className="text-sm text-soft-white/70 hover:text-soft-white transition-colors"
            >
              Forgot your password?
            </Link>
          </div>
        )}
        
        <button
          type="submit"
          disabled={isLoading}
          className={cn(
            'w-full py-5 border border-soft-white text-soft-white',
            'text-xs tracking-[0.3em] uppercase font-light',
            'transition-all duration-300 hover:bg-soft-white hover:text-luxury-black',
            'disabled:opacity-70 disabled:cursor-not-allowed disabled:hover:bg-transparent disabled:hover:text-soft-white'
          )}
        >
          {isLoading ? (
            <span className="inline-flex items-center gap-2">
              <span className="inline-block w-1 h-1 bg-current rounded-full animate-pulse" />
              <span className="inline-block w-1 h-1 bg-current rounded-full animate-pulse delay-75" />
              <span className="inline-block w-1 h-1 bg-current rounded-full animate-pulse delay-150" />
            </span>
          ) : (
            type === 'login' ? 'SIGN IN' : 'BEGIN'
          )}
        </button>
      </form>
      
      <div className="mt-8 text-center">
        <p className="text-soft-white/70">
          {type === 'login' 
            ? "Don't have an account?" 
            : "Already have an account?"}
          {' '}
          <Link 
            href={type === 'login' ? '/signup' : '/login'} 
            className="text-soft-white hover:underline transition-all"
          >
            {type === 'login' ? 'Start here' : 'Sign in'}
          </Link>
        </p>
      </div>
    </div>
  )
}
