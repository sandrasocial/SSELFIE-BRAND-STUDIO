'use client'

import { useState, useEffect } from 'react'
import Image from 'next/image'
import { Sparkles, Calendar, Camera, ChevronRight, Eye, Edit3, Download, Share2 } from 'lucide-react'
import Link from 'next/link'
import type { FutureSelfImage } from '@/types/user'

interface FutureSelfHeroProps {
  userName: string
  futureSelfImage: FutureSelfImage | null
  confidenceScore: number
  streakDays?: number
  postsReady?: number
  followersCount?: number
  todaysFocus?: string
}

export function FutureSelfHero({ 
  userName, 
  futureSelfImage, 
  confidenceScore,
  streakDays = 14,
  postsReady = 3,
  followersCount = 12547,
  todaysFocus = "Share your morning routine"
}: FutureSelfHeroProps) {
  const [currentTime, setCurrentTime] = useState('')
  const [greeting, setGreeting] = useState('')
  const [imageLoaded, setImageLoaded] = useState(false)
  const [showActions, setShowActions] = useState(false)

  // Dynamic greeting based on time
  useEffect(() => {
    const updateTimeAndGreeting = () => {
      const now = new Date()
      const hours = now.getHours()
      
      // Set greeting based on time
      if (hours < 12) setGreeting('Good morning')
      else if (hours < 17) setGreeting('Good afternoon')
      else setGreeting('Good evening')
      
      // Format time
      setCurrentTime(now.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true 
      }))
    }
    
    updateTimeAndGreeting()
    const interval = setInterval(updateTimeAndGreeting, 60000) // Update every minute
    
    return () => clearInterval(interval)
  }, [])

  // Motivational messages based on confidence score
  const getMotivationalMessage = () => {
    if (confidenceScore >= 90) return "You're absolutely glowing! Time to share that energy."
    if (confidenceScore >= 75) return "Your confidence is magnetic. Let's capture it."
    if (confidenceScore >= 60) return "You're building momentum. Keep showing up."
    return "Every journey starts with a single selfie. Today's yours."
  }

  // Quick action items
  const quickActions = [
    { icon: <Camera className="w-4 h-4" />, label: 'Take Selfie', href: '/tools/camera' },
    { icon: <Sparkles className="w-4 h-4" />, label: 'Glow Check', href: '/tools/glow-check' },
    { icon: <Calendar className="w-4 h-4" />, label: 'Schedule Post', href: '/dashboard/calendar' },
    { icon: <Eye className="w-4 h-4" />, label: 'View Analytics', href: '/dashboard/analytics' }
  ]

  return (
    <section className="relative min-h-screen bg-gradient-to-br from-luxury-black via-luxury-black to-luxury-black/95 overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-10 w-96 h-96 bg-white/10 blur-3xl animate-pulse" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-white/5 blur-3xl animate-pulse animation-delay-2000" />
      </div>

      <div className="relative z-10 grid lg:grid-cols-2 min-h-screen">
        {/* Content Side */}
        <div className="flex flex-col justify-between px-6 sm:px-8 md:px-12 lg:px-20 py-20 lg:py-24">
          {/* Header */}
          <div>
            <div className="flex items-center gap-4 text-warm-gray text-[11px] uppercase tracking-[0.3em] mb-8">
              <span>{currentTime}</span>
              <span className="w-1 h-1 bg-warm-gray/50" />
              <span>Day {streakDays} 🔥</span>
              <span className="w-1 h-1 bg-warm-gray/50" />
              <span>Your HQ</span>
            </div>

            <h1 className="font-bodoni text-5xl sm:text-6xl lg:text-7xl xl:text-8xl text-white leading-[0.9] mb-6">
              {greeting},<br />
              <span className="font-bodoni italic opacity-90">{userName}</span>
            </h1>

            <p className="font-inter text-lg sm:text-xl text-white/70 max-w-xl leading-relaxed mb-10">
              {getMotivationalMessage()}
            </p>

            {/* Today's Focus */}
            <div className="bg-white/5 backdrop-blur-sm border border-white/10 p-6 max-w-lg mb-10">
              <p className="font-inter text-[11px] uppercase tracking-[0.3em] text-warm-gray mb-3">
                Today's Focus
              </p>
              <p className="font-bodoni text-2xl text-white mb-4">
                {todaysFocus}
              </p>
              <Link 
                href="/dashboard/calendar"
                className="inline-flex items-center gap-2 text-white/80 hover:text-white transition-colors group"
              >
                <span className="font-inter text-sm">View your content plan</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>

            {/* Quick Actions */}
            <div className="flex flex-wrap gap-3">
              {quickActions.map((action) => (
                <Link
                  key={action.label}
                  href={action.href}
                  className="inline-flex items-center gap-2 px-6 py-3 bg-white/10 backdrop-blur-sm border border-white/20 text-white hover:bg-white hover:text-luxury-black transition-all duration-300 group"
                >
                  <span className="transition-transform group-hover:scale-110">{action.icon}</span>
                  <span className="font-inter text-[11px] uppercase tracking-[0.2em]">{action.label}</span>
                </Link>
              ))}
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-3 gap-6 sm:gap-8 mt-12">
            <div className="text-center sm:text-left">
              <div className="font-bodoni text-4xl sm:text-5xl text-white mb-1">
                {confidenceScore}%
              </div>
              <div className="font-inter text-[10px] uppercase tracking-[0.2em] text-warm-gray">
                Glow Score
              </div>
            </div>
            <div className="text-center sm:text-left">
              <div className="font-bodoni text-4xl sm:text-5xl text-white mb-1">
                {followersCount.toLocaleString().slice(0, -3)}K
              </div>
              <div className="font-inter text-[10px] uppercase tracking-[0.2em] text-warm-gray">
                Followers
              </div>
            </div>
            <div className="text-center sm:text-left">
              <div className="font-bodoni text-4xl sm:text-5xl text-white mb-1">
                {postsReady}
              </div>
              <div className="font-inter text-[10px] uppercase tracking-[0.2em] text-warm-gray">
                Ready
              </div>
            </div>
          </div>
        </div>

        {/* Future Self Image Side */}
        <div className="relative h-[600px] lg:h-full order-first lg:order-last">
          {/* Background Pattern */}
          <div className="absolute inset-0 bg-gradient-to-br from-warm-gray/20 to-luxury-black/50" />
          
          {/* Future Self Image */}
          <div className="absolute inset-0">
            {futureSelfImage?.image_url ? (
              <>
                <Image 
                  src={futureSelfImage.image_url}
                  alt="Your Future Self Vision"
                  fill
                  className={`object-cover transition-all duration-1000 ${
                    imageLoaded ? 'grayscale-0 scale-100' : 'grayscale scale-110'
                  }`}
                  onLoad={() => setImageLoaded(true)}
                  priority
                />
                
                {/* Overlay Gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-luxury-black via-transparent to-transparent opacity-60" />
                
                {/* Image Actions */}
                <div 
                  className="absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity duration-300 bg-luxury-black/40"
                  onMouseEnter={() => setShowActions(true)}
                  onMouseLeave={() => setShowActions(false)}
                >
                  <div className="flex gap-4">
                    <button className="p-4 bg-white/90 backdrop-blur-sm hover:bg-white transition-colors group">
                      <Download className="w-5 h-5 text-luxury-black group-hover:scale-110 transition-transform" />
                    </button>
                    <button className="p-4 bg-white/90 backdrop-blur-sm hover:bg-white transition-colors group">
                      <Share2 className="w-5 h-5 text-luxury-black group-hover:scale-110 transition-transform" />
                    </button>
                    <Link 
                      href="/tools/sselfie-ai"
                      className="p-4 bg-white/90 backdrop-blur-sm hover:bg-white transition-colors group"
                    >
                      <Edit3 className="w-5 h-5 text-luxury-black group-hover:scale-110 transition-transform" />
                    </Link>
                  </div>
                </div>
              </>
            ) : (
              <Link 
                href="/tools/sselfie-ai"
                className="w-full h-full flex items-center justify-center bg-gradient-to-br from-warm-gray/10 to-warm-gray/5 group cursor-pointer"
              >
                <div className="text-center">
                  <div className="inline-flex items-center justify-center w-24 h-24 bg-white/10 backdrop-blur-sm mb-6 group-hover:scale-110 transition-transform">
                    <Sparkles className="w-12 h-12 text-white" />
                  </div>
                  <p className="font-bodoni text-3xl text-white mb-2">Create Your Vision</p>
                  <p className="font-inter text-white/60">See your future self</p>
                </div>
              </Link>
            )}
          </div>

          {/* Editorial Number */}
          <div className="absolute bottom-10 left-10 pointer-events-none">
            <div className="font-lingerie text-[150px] sm:text-[200px] leading-none text-white/[0.05]">
              01
            </div>
          </div>

          {/* Vision Quote */}
          {futureSelfImage?.scenario && (
            <div className={`absolute top-10 right-10 transition-all duration-500 ${
              showActions ? 'opacity-0 translate-y-4' : 'opacity-100 translate-y-0'
            }`}>
              <div className="bg-white/90 backdrop-blur-sm p-6 max-w-sm">
                <p className="font-bodoni italic text-lg text-luxury-black mb-2">
                  "{futureSelfImage.scenario}"
                </p>
                <p className="font-inter text-[11px] uppercase tracking-[0.2em] text-warm-gray">
                  — Your Future Self
                </p>
              </div>
            </div>
          )}

          {/* Progress Indicator */}
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/10">
            <div 
              className="h-full bg-white transition-all duration-1000"
              style={{ width: `${(streakDays / 90) * 100}%` }}
            />
          </div>
        </div>
      </div>

      <style jsx>{`
        .animation-delay-2000 {
          animation-delay: 2s;
        }
      `}</style>
    </section>
  )
}