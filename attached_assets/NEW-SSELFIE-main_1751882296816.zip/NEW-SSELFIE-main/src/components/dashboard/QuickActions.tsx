'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Camera, Sparkles, Calendar, MessageSquare, Upload, Edit3, BookOpen, TrendingUp, Plus, ArrowRight, Zap } from 'lucide-react'

interface QuickAction {
  id: string
  title: string
  description: string
  icon: React.ReactNode
  href: string
  color?: string
  badge?: string
  shortcut?: string
}

interface QuickActionsProps {
  userId?: string
  variant?: 'grid' | 'list' | 'compact'
  maxItems?: number
}

export function QuickActions({ variant = 'grid', maxItems = 8 }: QuickActionsProps) {
  const [hoveredAction, setHoveredAction] = useState<string | null>(null)

  const quickActions: QuickAction[] = [
    {
      id: 'selfie',
      title: 'Take a Selfie',
      description: 'Capture your daily glow',
      icon: <Camera className="w-5 h-5" />,
      href: '/tools/camera',
      shortcut: 'C',
      badge: 'Daily'
    },
    {
      id: 'glow-check',
      title: 'Glow Check',
      description: 'AI selfie analysis',
      icon: <Sparkles className="w-5 h-5" />,
      href: '/tools/glow-check',
      shortcut: 'G',
      color: 'luxury'
    },
    {
      id: 'schedule',
      title: 'Schedule Post',
      description: 'Plan your content',
      icon: <Calendar className="w-5 h-5" />,
      href: '/dashboard/calendar',
      shortcut: 'S'
    },
    {
      id: 'caption',
      title: 'Write Caption',
      description: 'AI-powered captions',
      icon: <MessageSquare className="w-5 h-5" />,
      href: '/tools/caption',
      shortcut: 'W'
    },
    {
      id: 'upload',
      title: 'Upload Photos',
      description: 'Add to your vault',
      icon: <Upload className="w-5 h-5" />,
      href: '/tools/photo-vault',
      badge: 'New'
    },
    {
      id: 'edit-profile',
      title: 'Edit Profile',
      description: 'Update your brand',
      icon: <Edit3 className="w-5 h-5" />,
      href: '/dashboard/profile'
    },
    {
      id: 'learn',
      title: 'Learn & Grow',
      description: 'Access your courses',
      icon: <BookOpen className="w-5 h-5" />,
      href: '/dashboard/learning'
    },
    {
      id: 'analytics',
      title: 'View Analytics',
      description: 'Track your growth',
      icon: <TrendingUp className="w-5 h-5" />,
      href: '/dashboard/analytics'
    }
  ]

  const displayActions = quickActions.slice(0, maxItems)

  if (variant === 'list') {
    return (
      <div className="space-y-2">
        {displayActions.map((action) => (
          <Link
            key={action.id}
            href={action.href}
            className="group flex items-center justify-between p-4 bg-white hover:bg-soft-white border border-luxury-black/10 hover:border-luxury-black/20 transition-all duration-300"
            onMouseEnter={() => setHoveredAction(action.id)}
            onMouseLeave={() => setHoveredAction(null)}
          >
            <div className="flex items-center gap-4">
              <div className="p-2 bg-soft-white group-hover:bg-luxury-black group-hover:text-white transition-all duration-300">
                {action.icon}
              </div>
              <div>
                <h4 className="font-inter text-sm font-medium text-luxury-black">
                  {action.title}
                </h4>
                <p className="font-inter text-xs text-warm-gray">
                  {action.description}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {action.badge && (
                <span className="px-2 py-1 bg-luxury-black text-white font-inter text-[9px] uppercase tracking-wider">
                  {action.badge}
                </span>
              )}
              {action.shortcut && (
                <kbd className="hidden sm:block px-2 py-1 bg-soft-white text-luxury-black font-inter text-[10px]">
                  ⌘{action.shortcut}
                </kbd>
              )}
              <ArrowRight className={`w-4 h-4 text-warm-gray transition-transform duration-300 ${
                hoveredAction === action.id ? 'translate-x-1' : ''
              }`} />
            </div>
          </Link>
        ))}
      </div>
    )
  }

  if (variant === 'compact') {
    return (
      <div className="flex flex-wrap gap-2">
        {displayActions.map((action) => (
          <Link
            key={action.id}
            href={action.href}
            className="inline-flex items-center gap-2 px-4 py-2 bg-white hover:bg-luxury-black hover:text-white border border-luxury-black/10 hover:border-luxury-black transition-all duration-300 group"
          >
            <span className="transition-transform duration-300 group-hover:scale-110">
              {action.icon}
            </span>
            <span className="font-inter text-[11px] uppercase tracking-[0.2em]">
              {action.title}
            </span>
          </Link>
        ))}
      </div>
    )
  }

  // Default grid variant
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
        {displayActions.map((action) => (
          <Link
            key={action.id}
            href={action.href}
            className="group relative bg-white hover:bg-soft-white border border-luxury-black/10 hover:border-luxury-black/20 p-6 transition-all duration-300 hover:shadow-lg overflow-hidden"
            onMouseEnter={() => setHoveredAction(action.id)}
            onMouseLeave={() => setHoveredAction(null)}
          >
            {/* Background Pattern */}
            <div className="absolute -top-8 -right-8 text-[120px] font-lingerie text-luxury-black/[0.02] select-none pointer-events-none">
              {action.id.charAt(0).toUpperCase()}
            </div>
            
            {/* Badge */}
            {action.badge && (
              <div className="absolute top-4 right-4">
                <span className="px-2 py-1 bg-luxury-black text-white font-inter text-[9px] uppercase tracking-wider">
                  {action.badge}
                </span>
              </div>
            )}
            
            {/* Content */}
            <div className="relative z-10">
              <div className="mb-4 p-3 bg-soft-white group-hover:bg-luxury-black group-hover:text-white transition-all duration-300 w-fit">
                {action.icon}
              </div>
              
              <h4 className="font-inter text-sm font-medium text-luxury-black mb-1">
                {action.title}
              </h4>
              
              <p className="font-inter text-xs text-warm-gray mb-4">
                {action.description}
              </p>
              
              {/* Shortcut */}
              {action.shortcut && (
                <div className="absolute bottom-4 left-6 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <kbd className="px-2 py-1 bg-luxury-black/10 text-luxury-black font-inter text-[10px]">
                    ⌘{action.shortcut}
                  </kbd>
                </div>
              )}
              
              {/* Arrow */}
              <div className="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-all duration-300">
                <ArrowRight className="w-4 h-4 text-luxury-black" />
              </div>
            </div>
          </Link>
        ))}
        
        {/* View All Card */}
        {quickActions.length > maxItems && (
          <Link
            href="/dashboard/tools"
            className="group relative bg-luxury-black text-white p-6 transition-all duration-300 hover:shadow-lg flex flex-col items-center justify-center"
          >
            <Plus className="w-8 h-8 mb-2 group-hover:rotate-90 transition-transform duration-300" />
            <span className="font-inter text-[11px] uppercase tracking-[0.2em]">
              View All Tools
            </span>
          </Link>
        )}
      </div>
      
      {/* Floating Action Button (Mobile) */}
      <div className="fixed bottom-6 right-6 sm:hidden">
        <button className="w-14 h-14 bg-luxury-black text-white flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-300 group">
          <Zap className="w-6 h-6 group-hover:scale-110 transition-transform" />
        </button>
      </div>
    </div>
  )
}