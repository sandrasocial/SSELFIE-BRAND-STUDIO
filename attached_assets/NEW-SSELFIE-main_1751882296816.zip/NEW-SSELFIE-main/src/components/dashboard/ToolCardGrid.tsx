import React from 'react'
import Image from 'next/image'
import Link from 'next/link'
import { SandraImages } from '@/components/sandra-image-library'
import { cn } from '@/lib/utils'

interface ToolCard {
  id: string
  title: string
  description: string
  imageUrl: string
  ctaText: string
  ctaLink: string
  status?: 'new' | 'updated' | 'coming-soon'
}

interface ToolCardGridProps {
  tools?: ToolCard[]
  className?: string
}

export const ToolCardGrid: React.FC<ToolCardGridProps> = ({
  tools = [
    {
      id: 'selfie-generator',
      title: 'Show up as her',
      description: 'Transform your everyday selfies into editorial brand moments that capture your essence.',
      imageUrl: SandraImages.editorial.phone2,
      ctaText: 'START',
      ctaLink: '/tools/selfie-generator',
      status: 'new'
    },
    {
      id: 'content-calendar',
      title: 'Content Calendar',
      description: 'Plan your content strategy with templates that feel uniquely you, not cookie-cutter.',
      imageUrl: SandraImages.flatlays.planning,
      ctaText: 'START',
      ctaLink: '/tools/content-calendar'
    },
    {
      id: 'brand-voice',
      title: 'Brand Voice',
      description: 'Craft your message in a voice that feels authentic to your story and business goals.',
      imageUrl: SandraImages.editorial.laptop2,
      ctaText: 'START',
      ctaLink: '/tools/brand-voice'
    },
    {
      id: 'future-self',
      title: 'Future Self',
      description: "Visualize where your brand journey is taking you. See the future you're building today.",
      imageUrl: SandraImages.aiGallery[2], // Using a unique AI gallery image
      ctaText: 'START',
      ctaLink: '/tools/future-self',
      status: 'coming-soon'
    },
    {
      id: 'landing-page',
      title: 'Landing Page',
      description: 'Create a homepage that feels like you, without the tech headache.',
      imageUrl: SandraImages.editorial.laptop1,
      ctaText: 'START',
      ctaLink: '/tools/landing-page'
    },
    {
      id: 'social-blueprint',
      title: 'Social Blueprint',
      description: 'Create a framework for showing up consistently while staying true to yourself.',
      imageUrl: SandraImages.aiGallery[7], // Using another unique AI gallery image
      ctaText: 'START',
      ctaLink: '/tools/social-blueprint'
    }
  ],
  className
}) => {
  return (
    <section className={cn("bg-[#f5f5f5] py-24 md:py-28 lg:py-32", className)}>
      <div className="container mx-auto px-6">
        <h2 className="font-bodoni text-5xl md:text-6xl lg:text-7xl text-luxury-black mb-16 text-center leading-tight">
          Your Magic Toolbox
        </h2>
        <p className="text-xl text-warm-gray max-w-2xl mx-auto mb-20 text-center">
          Everything you need to transform your selfies into your brand story.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-16 md:gap-24 lg:gap-28">
          {tools.map((tool) => (
            <div 
              key={tool.id}
              className="bg-white border-[1.5px] border-[#e5e5e5] rounded-[8px] overflow-hidden flex flex-col 
                        shadow-sm hover:shadow-xl hover:scale-[1.025] transition-all duration-[0.22s] 
                        transform"
              style={{ transitionTimingFunction: 'cubic-bezier(0.4, 0, 0.2, 1)' }}
            >
              {/* Image */}
              <div className="relative h-72 w-full overflow-hidden">
                <Image
                  src={tool.imageUrl}
                  alt={tool.title}
                  fill
                  className="object-cover hover:scale-[1.03] transition-transform duration-[0.4s] filter saturate-[0.95]"
                  priority
                />
                <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/20" />
                
                {tool.status && (
                  <div className="absolute top-6 right-6 bg-luxury-black text-soft-white py-1 px-3 text-[10px] uppercase tracking-[0.2em]">
                    {tool.status === 'new' ? 'New' : 
                     tool.status === 'updated' ? 'Updated' : 'Coming Soon'}
                  </div>
                )}
              </div>
              
              {/* Content */}
              <div className="p-12 md:p-14 lg:p-16 flex-grow flex flex-col">
                <h3 className="font-bodoni text-3xl md:text-[2.6rem] text-luxury-black mb-4 leading-tight">
                  {tool.title}
                </h3>
                <p className="text-lg md:text-xl text-[#666] mb-10 flex-grow leading-relaxed">
                  {tool.description}
                </p>
                
                <div className="flex justify-end">
                  <Link
                    href={tool.ctaLink}
                    className={cn(
                      "text-[13px] tracking-[0.3em] uppercase font-light text-luxury-black",
                      "border-b-[1.5px] border-transparent hover:border-luxury-black",
                      "transition-all duration-[0.22s] relative",
                      "after:content-[''] after:absolute after:bottom-[-1.5px] after:left-0",
                      "after:w-0 after:h-[1.5px] after:bg-luxury-black",
                      "hover:after:w-full after:transition-all after:duration-[0.22s]",
                      tool.status === 'coming-soon' && "opacity-50 pointer-events-none"
                    )}
                  >
                    {tool.ctaText}
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
