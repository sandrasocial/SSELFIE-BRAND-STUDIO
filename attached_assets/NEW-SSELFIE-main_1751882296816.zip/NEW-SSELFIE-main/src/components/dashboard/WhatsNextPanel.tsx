import React from 'react'
import Link from 'next/link'
import { cn } from '@/lib/utils'

interface NextStep {
  text: string
  link?: string
}

interface WhatsNextPanelProps {
  steps?: NextStep[]
  className?: string
}

export const WhatsNextPanel: React.FC<WhatsNextPanelProps> = ({
  steps = [
    { text: "Want to try something new? Use the Selfie Generator.", link: "/tools/selfie-generator" },
    { text: "Ready to update your landing page? Click here.", link: "/tools/landing-page" },
    { text: "Not sure where to start? Just ask Sandra.", link: "/ask-sandra" },
  ],
  className
}) => {
  return (
    <section className={cn("bg-[#fafafa] py-24 md:py-28 lg:py-36", className)}>
      <div className="container mx-auto px-6 md:px-12">
        <div className="max-w-4xl mx-auto">
          <h2 className="font-bodoni text-[2.5rem] text-luxury-black mb-16 text-center leading-tight">
            What&apos;s next?
          </h2>
          
          <ul className="space-y-10 mb-20">
            {steps.map((step, index) => (
              <li key={index} className="text-xl md:text-2xl text-[#666] leading-relaxed">
                {step.link ? (
                  <Link 
                    href={step.link} 
                    className="border-b border-transparent hover:border-luxury-black transition-all duration-300 hover:text-luxury-black"
                  >
                    {step.text}
                  </Link>
                ) : (
                  step.text
                )}
              </li>
            ))}
          </ul>
          
          <div className="text-center mt-16">
            <Link 
              href="/support"
              className="inline-block py-4 px-16 border-2 border-luxury-black text-luxury-black
                       hover:bg-luxury-black hover:text-white text-[13px] tracking-[0.3em] 
                       uppercase font-light transition-all duration-300
                       transform hover:translate-y-[-2px] hover:shadow-md
                       focus:outline-none focus:ring-2 focus:ring-luxury-black focus:ring-offset-2"
              aria-label="Get support"
            >
              NEED HELP?
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
