'use client'

import React, { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'

interface NavItem {
  label: string
  href: string
}

interface DashboardLayoutProps {
  children: React.ReactNode
  className?: string
}

export function DashboardLayout({ children, className }: DashboardLayoutProps) {
  const pathname = usePathname()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  
  // Navigation items following the design guide
  const navItems: NavItem[] = [
    { label: 'Dashboard', href: '/dashboard' },
    { label: 'My Tools', href: '/dashboard/tools' },
    { label: 'Billing', href: '/dashboard/billing' },
    { label: 'Profile', href: '/dashboard/profile' },
    { label: 'Support', href: '/support' },
  ]
  
  return (
    <div className="min-h-screen bg-white flex overflow-hidden">
      {/* Desktop Sidebar - Always visible on desktop */}
      <div className="hidden md:block flex-shrink-0">
        <nav className="sidebar-nav h-full py-16 px-10 w-72">
          <div className="mb-14">
            <p className="font-bodoni text-2xl text-luxury-black tracking-wider">SSELFIE</p>
          </div>
          
          <ul className="space-y-8">
            {navItems.map((item, index) => {
              const isActive = pathname === item.href || pathname?.startsWith(`${item.href}/`)
              
              return (
                <li key={index}>
                  <Link
                    href={item.href}
                    className={cn(
                      "sidebar-link",
                      isActive && "active"
                    )}
                  >
                    {item.label}
                  </Link>
                </li>
              )
            })}
          </ul>
        </nav>
      </div>
      
      {/* Mobile Hamburger Menu */}
      <div className="md:hidden fixed top-8 right-8 z-50">
        <button 
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="w-12 h-12 flex flex-col justify-center items-center gap-[6px] bg-white border border-[#e5e5e5] rounded-none shadow-sm"
          aria-label={mobileMenuOpen ? "Close menu" : "Open menu"}
        >
          <span className={cn(
            "w-6 h-[1.5px] bg-luxury-black transition-all duration-300",
            mobileMenuOpen && "transform rotate-45 translate-y-[4px]"
          )}></span>
          <span className={cn(
            "w-6 h-[1.5px] bg-luxury-black transition-all duration-300",
            mobileMenuOpen && "opacity-0"
          )}></span>
          <span className={cn(
            "w-6 h-[1.5px] bg-luxury-black transition-all duration-300",
            mobileMenuOpen && "transform -rotate-45 -translate-y-[4px]"
          )}></span>
        </button>
      </div>
      
      {/* Mobile Menu Panel */}
      <div className={cn(
        "sidebar-nav md:hidden",
        mobileMenuOpen ? "open" : "collapsed"
      )}>
        <div className="h-full py-16 px-10">
          <div className="mb-14">
            <p className="font-bodoni text-2xl text-luxury-black tracking-wider">SSELFIE</p>
          </div>
          
          <nav>
            <ul className="space-y-8">
              {navItems.map((item, index) => {
                const isActive = pathname === item.href || pathname?.startsWith(`${item.href}/`)
                
                return (
                  <li key={index}>
                    <Link
                      href={item.href}
                      className={cn(
                        "sidebar-link",
                        isActive && "active"
                      )}
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      {item.label}
                    </Link>
                  </li>
                )
              })}
            </ul>
          </nav>
        </div>
      </div>

      {/* Mobile Overlay */}
      {mobileMenuOpen && (
        <div 
          className="sidebar-overlay md:hidden"
          onClick={() => setMobileMenuOpen(false)}
          aria-hidden="true"
        />
      )}
      
      {/* Main content */}
      <div className={cn("flex-1 min-h-screen overflow-x-hidden overflow-y-auto", className)}>
        {children}
      </div>
    </div>
  )
}

export default DashboardLayout