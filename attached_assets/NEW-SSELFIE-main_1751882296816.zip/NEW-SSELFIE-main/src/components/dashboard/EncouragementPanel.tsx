import React from 'react'
import { cn } from '@/lib/utils'

interface EncouragementPanelProps {
  message?: string
  className?: string
}

export const EncouragementPanel: React.FC<EncouragementPanelProps> = ({
  message = "Your mess is your message. Keep building.",
  className
}) => {
  return (
    <div className={cn("my-16 md:my-24 py-20 text-center bg-white", className)}>
      <div className="container mx-auto px-6">
        <div className="max-w-3xl mx-auto border-t border-b border-[#e5e5e5] py-16">
          <p className="font-bodoni text-2xl md:text-3xl lg:text-4xl text-luxury-black mx-auto leading-tight italic">
            &ldquo;{message}&rdquo;
          </p>
        </div>
      </div>
    </div>
  )
}
