'use client'

import { useState, useEffect } from 'react'
import { Bell, Heart, UserPlus, Award, X, CheckCircle, Info } from 'lucide-react'

interface Notification {
  id: string
  type: 'success' | 'info' | 'warning' | 'achievement' | 'social'
  title: string
  message: string
  timestamp: Date
  read: boolean
  icon?: React.ReactNode
  action?: {
    label: string
    href: string
  }
}

interface RealtimeNotificationsProps {
  userId?: string
  position?: 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left'
  maxVisible?: number
}

export function RealtimeNotifications({ 
  userId, 
  position = 'top-right',
  maxVisible = 3 
}: RealtimeNotificationsProps) {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [isOpen, setIsOpen] = useState(false)
  const [unreadCount, setUnreadCount] = useState(0)

  // Mock notifications for demo
  useEffect(() => {
    const mockNotifications: Notification[] = [
      {
        id: '1',
        type: 'success',
        title: 'Glow Check Complete!',
        message: 'Your confidence score is 92%. Keep shining!',
        timestamp: new Date(),
        read: false,
        icon: <CheckCircle className="w-5 h-5" />
      },
      {
        id: '2',
        type: 'social',
        title: 'New Follower Milestone',
        message: "You&apos;ve reached 10K followers! 🎉",
        timestamp: new Date(Date.now() - 1000 * 60 * 5),
        read: false,
        icon: <UserPlus className="w-5 h-5" />
      },
      {
        id: '3',
        type: 'achievement',
        title: 'Streak Achievement',
        message: '7-day posting streak! Keep it up!',
        timestamp: new Date(Date.now() - 1000 * 60 * 30),
        read: true,
        icon: <Award className="w-5 h-5" />,
        action: {
          label: 'View Stats',
          href: '/dashboard/analytics'
        }
      }
    ]

    setNotifications(mockNotifications)
    setUnreadCount(mockNotifications.filter(n => !n.read).length)

    // Simulate real-time notifications
    const interval = setInterval(() => {
      const newNotif: Notification = {
        id: Date.now().toString(),
        type: ['success', 'info', 'social'][Math.floor(Math.random() * 3)] as any,
        title: 'New Activity',
        message: 'Someone liked your recent post',
        timestamp: new Date(),
        read: false,
        icon: <Heart className="w-5 h-5" />
      }
      
      setNotifications(prev => [newNotif, ...prev].slice(0, 10))
      setUnreadCount(prev => prev + 1)
    }, 30000) // Every 30 seconds

    return () => clearInterval(interval)
  }, [])

  const markAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(n => n.id === id ? { ...n, read: true } : n)
    )
    setUnreadCount(prev => Math.max(0, prev - 1))
  }

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })))
    setUnreadCount(0)
  }

  const clearNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id))
    const notif = notifications.find(n => n.id === id)
    if (notif && !notif.read) {
      setUnreadCount(prev => Math.max(0, prev - 1))
    }
  }

  const getNotificationStyle = (type: string) => {
    switch (type) {
      case 'success':
        return 'border-l-4 border-l-green-500'
      case 'warning':
        return 'border-l-4 border-l-amber-500'
      case 'achievement':
        return 'border-l-4 border-l-purple-500'
      case 'social':
        return 'border-l-4 border-l-blue-500'
      default:
        return 'border-l-4 border-l-luxury-black'
    }
  }

  const getTimeAgo = (date: Date) => {
    const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000)
    if (seconds < 60) return 'just now'
    const minutes = Math.floor(seconds / 60)
    if (minutes < 60) return `${minutes}m ago`
    const hours = Math.floor(minutes / 60)
    if (hours < 24) return `${hours}h ago`
    return `${Math.floor(hours / 24)}d ago`
  }

  const positionClasses = {
    'top-right': 'top-4 right-4',
    'top-left': 'top-4 left-4',
    'bottom-right': 'bottom-4 right-4',
    'bottom-left': 'bottom-4 left-4'
  }

  return (
    <>
      {/* Notification Bell */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 hover:bg-soft-white transition-colors duration-200 group"
        aria-label="Notifications"
      >
        <Bell className="w-5 h-5 text-luxury-black group-hover:scale-110 transition-transform" />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 w-5 h-5 bg-luxury-black text-white text-[10px] flex items-center justify-center font-inter">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {/* Notifications Panel */}
      {isOpen && (
        <div className={`fixed ${positionClasses[position]} z-50 w-96 max-w-[calc(100vw-2rem)]`}>
          <div className="bg-white shadow-2xl border border-luxury-black/10 max-h-[80vh] flex flex-col">
            {/* Header */}
            <div className="px-6 py-4 border-b border-luxury-black/10 flex items-center justify-between">
              <h3 className="font-bodoni text-xl text-luxury-black">Notifications</h3>
              <div className="flex items-center gap-2">
                {unreadCount > 0 && (
                  <button
                    onClick={markAllAsRead}
                    className="font-inter text-[11px] uppercase tracking-[0.2em] text-warm-gray hover:text-luxury-black transition-colors"
                  >
                    Mark all read
                  </button>
                )}
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-1 hover:bg-soft-white transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Notifications List */}
            <div className="flex-1 overflow-y-auto">
              {notifications.length > 0 ? (
                <div className="divide-y divide-luxury-black/10">
                  {notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-4 hover:bg-soft-white transition-all duration-200 ${
                        !notification.read ? 'bg-soft-white' : ''
                      } ${getNotificationStyle(notification.type)}`}
                      onClick={() => markAsRead(notification.id)}
                    >
                      <div className="flex gap-3">
                        <div className="flex-shrink-0 mt-1">
                          {notification.icon || <Info className="w-5 h-5" />}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-inter text-sm font-medium text-luxury-black mb-1">
                            {notification.title}
                          </h4>
                          <p className="font-inter text-xs text-warm-gray mb-2">
                            {notification.message}
                          </p>
                          <div className="flex items-center justify-between">
                            <span className="font-inter text-[10px] text-warm-gray">
                              {getTimeAgo(notification.timestamp)}
                            </span>
                            {notification.action && (
                              <a
                                href={notification.action.href}
                                className="font-inter text-[11px] uppercase tracking-[0.2em] text-luxury-black hover:underline"
                              >
                                {notification.action.label}
                              </a>
                            )}
                          </div>
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation()
                            clearNotification(notification.id)
                          }}
                          className="flex-shrink-0 p-1 hover:bg-luxury-black/5 transition-colors"
                        >
                          <X className="w-3 h-3 text-warm-gray" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 text-center">
                  <Bell className="w-12 h-12 text-warm-gray mx-auto mb-3" />
                  <p className="font-inter text-sm text-warm-gray">
                    No notifications yet
                  </p>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="px-6 py-3 border-t border-luxury-black/10">
              <a
                href="/dashboard/notifications"
                className="font-inter text-[11px] uppercase tracking-[0.2em] text-luxury-black hover:underline"
              >
                View all notifications
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Toast Notifications */}
      <div className={`fixed ${positionClasses[position]} z-40 pointer-events-none`}>
        <div className="space-y-2">
          {notifications
            .filter(n => !n.read)
            .slice(0, maxVisible)
            .map((notification, index) => (
              <div
                key={notification.id}
                className={`
                  pointer-events-auto bg-white shadow-lg border border-luxury-black/10 
                  p-4 min-w-[300px] max-w-md
                  transform transition-all duration-500 ease-out
                  ${getNotificationStyle(notification.type)}
                  animate-slideIn
                `}
                style={{
                  animationDelay: `${index * 100}ms`
                }}
              >
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0">
                    {notification.icon}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-inter text-sm font-medium text-luxury-black">
                      {notification.title}
                    </h4>
                    <p className="font-inter text-xs text-warm-gray mt-1">
                      {notification.message}
                    </p>
                  </div>
                  <button
                    onClick={() => clearNotification(notification.id)}
                    className="flex-shrink-0 p-1 hover:bg-luxury-black/5 transition-colors"
                  >
                    <X className="w-3 h-3 text-warm-gray" />
                  </button>
                </div>
              </div>
            ))}
        </div>
      </div>

      <style jsx>{`
        @keyframes slideIn {
          from {
            opacity: 0;
            transform: translateX(100%);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }
        
        .animate-slideIn {
          animation: slideIn 0.3s ease-out forwards;
        }
      `}</style>
    </>
  )
}