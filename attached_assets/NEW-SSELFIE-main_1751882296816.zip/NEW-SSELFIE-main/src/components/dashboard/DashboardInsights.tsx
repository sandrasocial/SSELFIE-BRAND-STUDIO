'use client'

import { useState, useEffect } from 'react'
import { createClient } from '@/utils/supabase/client'
import { 
  TrendingUp, 
  Clock, 
  Sparkles, 
  Activity,
  Eye,
  Heart,
  MessageSquare,
  Camera,
  X,
  ArrowUp,
  ArrowDown,
  ChevronRight
} from 'lucide-react'

interface DashboardAnalytics {
  // Engagement Metrics
  totalFollowers: number
  followersGrowth: number
  engagementRate: number
  engagementChange: number
  
  // Content Performance
  totalPosts: number
  avgLikes: number
  avgComments: number
  topPostEngagement: number
  
  // Tool Usage
  glowChecksToday: number
  contentCreated: number
  mostUsedTool: string
  toolUsageScore: number
  
  // Time Analytics
  avgSessionTime: number
  peakActiveHour: string
  streakDays: number
  
  // Weekly Data
  weeklyFollowers: number[]
  weeklyEngagement: number[]
  weeklyPosts: number[]
}

interface InsightCardProps {
  icon: React.ReactNode
  label: string
  value: string | number
  change?: number
  suffix?: string
  trend?: 'up' | 'down' | 'neutral'
}

function InsightCard({ icon, label, value, change, suffix = '', trend }: InsightCardProps) {
  return (
    <div className="bg-white p-6 hover:shadow-lg transition-all duration-300 group">
      <div className="flex items-start justify-between mb-4">
        <div className="p-2 bg-soft-white text-luxury-black group-hover:bg-luxury-black group-hover:text-white transition-all duration-300">
          {icon}
        </div>
        {change !== undefined && (
          <div className={`flex items-center gap-1 text-sm ${
            trend === 'up' ? 'text-green-600' : 
            trend === 'down' ? 'text-red-600' : 
            'text-warm-gray'
          }`}>
            {trend === 'up' ? <ArrowUp className="w-3 h-3" /> : 
             trend === 'down' ? <ArrowDown className="w-3 h-3" /> : null}
            <span>{Math.abs(change)}%</span>
          </div>
        )}
      </div>
      <p className="font-inter text-[10px] uppercase tracking-[0.2em] text-warm-gray mb-1">
        {label}
      </p>
      <p className="font-bodoni text-3xl text-luxury-black">
        {value}{suffix}
      </p>
    </div>
  )
}

export function DashboardInsights({}: { }) {
  const [analytics, setAnalytics] = useState<DashboardAnalytics | null>(null)
  const [isVisible, setIsVisible] = useState(false)
  const [activeTab, setActiveTab] = useState<'overview' | 'engagement' | 'tools'>('overview')
  const [selectedPeriod, setSelectedPeriod] = useState<'day' | 'week' | 'month'>('week')
  useEffect(() => {
    fetchAnalytics()
  }, [userId, selectedPeriod])

  const fetchAnalytics = async () => {
    try {
      // Enhanced mock analytics data
      const mockAnalytics: DashboardAnalytics = {
        totalFollowers: 12547,
        followersGrowth: 12.5,
        engagementRate: 8.7,
        engagementChange: 0.8,
        totalPosts: 156,
        avgLikes: 1843,
        avgComments: 92,
        topPostEngagement: 15.2,
        glowChecksToday: 7,
        contentCreated: 3,
        mostUsedTool: 'Glow Check',
        toolUsageScore: 94,
        avgSessionTime: 12.5,
        peakActiveHour: '9:00 AM',
        streakDays: 14,
        weeklyFollowers: [11800, 11950, 12100, 12180, 12300, 12420, 12547],
        weeklyEngagement: [7.2, 7.8, 8.1, 8.3, 8.0, 8.5, 8.7],
        weeklyPosts: [2, 3, 2, 4, 3, 2, 3]
      }

      setAnalytics(mockAnalytics)
      
      // Show insights after delay
      setTimeout(() => setIsVisible(true), 2000)
    } catch (error) {
      console.error('Error fetching analytics:', error)
    }
  }

  if (!analytics) return null

  // Calculate chart heights
  const maxFollowers = Math.max(...analytics.weeklyFollowers)
  return (
    <>
      {/* Main Insights Section */}
      <section className="mb-12">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
          <div>
            <h2 className="font-bodoni text-3xl md:text-4xl text-luxury-black mb-2">
              Your Brand Performance
            </h2>
            <p className="font-inter text-warm-gray">
              Real-time insights to guide your growth
            </p>
          </div>
          
          {/* Period Selector */}
          <div className="flex items-center gap-2 bg-white px-1 py-1">
            {(['day', 'week', 'month'] as const).map((period) => (
              <button
                key={period}
                onClick={() => setSelectedPeriod(period)}
                className={`px-4 py-2 font-inter text-[11px] uppercase tracking-[0.2em] transition-all duration-300 ${
                  selectedPeriod === period 
                    ? 'bg-luxury-black text-white' 
                    : 'text-warm-gray hover:text-luxury-black'
                }`}
              >
                {period}
              </button>
            ))}
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex gap-8 mb-8 border-b border-luxury-black/10">
          {(['overview', 'engagement', 'tools'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`pb-4 font-inter text-sm uppercase tracking-wider transition-all duration-300 relative ${
                activeTab === tab 
                  ? 'text-luxury-black' 
                  : 'text-warm-gray hover:text-luxury-black'
              }`}
            >
              {tab}
              {activeTab === tab && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-luxury-black" />
              )}
            </button>
          ))}
        </div>

        {/* Content based on active tab */}
        {activeTab === 'overview' && (
          <div className="space-y-8">
            {/* Key Metrics Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <InsightCard
                icon={<Eye className="w-5 h-5" />}
                label="Total Followers"
                value={analytics.totalFollowers.toLocaleString()}
                change={analytics.followersGrowth}
                trend="up"
              />
              <InsightCard
                icon={<Activity className="w-5 h-5" />}
                label="Engagement Rate"
                value={analytics.engagementRate}
                suffix="%"
                change={analytics.engagementChange}
                trend="up"
              />
              <InsightCard
                icon={<Camera className="w-5 h-5" />}
                label="Total Posts"
                value={analytics.totalPosts}
                change={23}
                trend="up"
              />
              <InsightCard
                icon={<Sparkles className="w-5 h-5" />}
                label="Glow Score"
                value={analytics.toolUsageScore}
                suffix="/100"
              />
            </div>

            {/* Charts Section */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Followers Growth Chart */}
              <div className="bg-white p-8">
                <h3 className="font-bodoni text-2xl text-luxury-black mb-6">Follower Growth</h3>
                <div className="relative h-48">
                  <div className="absolute inset-0 flex items-end justify-between gap-2">
                    {analytics.weeklyFollowers.map((count, index) => {
                      const height = (count / maxFollowers) * 100
                      return (
                        <div key={index} className="flex-1 flex flex-col items-center gap-2">
                          <div 
                            className="w-full bg-luxury-black hover:bg-luxury-black/80 transition-all duration-300 cursor-pointer relative group"
                            style={{ height: `${height}%` }}
                          >
                            <div className="absolute -top-8 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-luxury-black text-white px-2 py-1 text-xs whitespace-nowrap">
                              {count.toLocaleString()}
                            </div>
                          </div>
                          <span className="text-[10px] text-warm-gray">
                            {['M', 'T', 'W', 'T', 'F', 'S', 'S'][index]}
                          </span>
                        </div>
                      )
                    })}
                  </div>
                </div>
                <div className="mt-6 flex items-center justify-between">
                  <p className="font-inter text-sm text-warm-gray">7-day trend</p>
                  <p className="font-inter text-sm text-luxury-black">
                    +{analytics.weeklyFollowers[6] - analytics.weeklyFollowers[0]} followers
                  </p>
                </div>
              </div>

              {/* Engagement Chart */}
              <div className="bg-white p-8">
                <h3 className="font-bodoni text-2xl text-luxury-black mb-6">Engagement Trend</h3>
                <div className="relative h-48">
                  {/* Line Chart Background */}
                  <div className="absolute inset-0 flex flex-col justify-between">
                    {[10, 8, 6, 4, 2, 0].map((value) => (
                      <div key={value} className="flex items-center gap-2">
                        <span className="text-[10px] text-warm-gray w-4">{value}</span>
                        <div className="flex-1 h-px bg-luxury-black/10" />
                      </div>
                    ))}
                  </div>
                  
                  {/* Line Chart */}
                  <svg className="absolute inset-0 w-full h-full" style={{ marginLeft: '24px' }}>
                    <polyline
                      fill="none"
                      stroke="#171719"
                      strokeWidth="2"
                      points={analytics.weeklyEngagement.map((value, index) => {
                        const x = (index / (analytics.weeklyEngagement.length - 1)) * (100 - 10) + 5
                        const y = 100 - ((value / 10) * 90 + 5)
                        return `${x}%,${y}%`
                      }).join(' ')}
                    />
                    {analytics.weeklyEngagement.map((value, index) => {
                      const x = (index / (analytics.weeklyEngagement.length - 1)) * (100 - 10) + 5
                      const y = 100 - ((value / 10) * 90 + 5)
                      return (
                        <circle
                          key={index}
                          cx={`${x}%`}
                          cy={`${y}%`}
                          r="4"
                          fill="#171719"
                          className="hover:r-6 transition-all cursor-pointer"
                        />
                      )
                    })}
                  </svg>
                </div>
                <div className="mt-6 flex items-center justify-between">
                  <p className="font-inter text-sm text-warm-gray">Average</p>
                  <p className="font-inter text-sm text-luxury-black">{analytics.engagementRate}%</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'engagement' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Post Performance */}
            <div className="lg:col-span-2 bg-white p-8">
              <h3 className="font-bodoni text-2xl text-luxury-black mb-6">Content Performance</h3>
              
              <div className="space-y-6">
                <div className="flex items-center justify-between pb-4 border-b border-luxury-black/10">
                  <div>
                    <p className="font-inter text-sm text-warm-gray mb-1">Average Likes</p>
                    <p className="font-bodoni text-3xl text-luxury-black">{analytics.avgLikes.toLocaleString()}</p>
                  </div>
                  <Heart className="w-8 h-8 text-red-500" fill="currentColor" />
                </div>
                
                <div className="flex items-center justify-between pb-4 border-b border-luxury-black/10">
                  <div>
                    <p className="font-inter text-sm text-warm-gray mb-1">Average Comments</p>
                    <p className="font-bodoni text-3xl text-luxury-black">{analytics.avgComments}</p>
                  </div>
                  <MessageSquare className="w-8 h-8 text-luxury-black" />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-inter text-sm text-warm-gray mb-1">Top Post Engagement</p>
                    <p className="font-bodoni text-3xl text-luxury-black">{analytics.topPostEngagement}%</p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-green-600" />
                </div>
              </div>
            </div>

            {/* Best Posting Times */}
            <div className="bg-white p-8">
              <h3 className="font-bodoni text-2xl text-luxury-black mb-6">Peak Hours</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-luxury-black text-white">
                  <span className="font-inter text-sm">{analytics.peakActiveHour}</span>
                  <span className="font-inter text-xs uppercase tracking-wider">Best</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-soft-white">
                  <span className="font-inter text-sm">2:00 PM</span>
                  <span className="font-inter text-xs uppercase tracking-wider text-warm-gray">Good</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-soft-white">
                  <span className="font-inter text-sm">7:00 PM</span>
                  <span className="font-inter text-xs uppercase tracking-wider text-warm-gray">Good</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'tools' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <InsightCard
              icon={<Camera className="w-5 h-5" />}
              label="Glow Checks Today"
              value={analytics.glowChecksToday}
            />
            <InsightCard
              icon={<Sparkles className="w-5 h-5" />}
              label="Content Created"
              value={analytics.contentCreated}
            />
            <InsightCard
              icon={<Clock className="w-5 h-5" />}
              label="Avg Session Time"
              value={analytics.avgSessionTime}
              suffix="m"
            />
          </div>
        )}
      </section>

      {/* Floating Quick Stats Widget */}
      {isVisible && (
        <div className="fixed bottom-6 right-6 bg-white shadow-2xl p-6 w-80 transform transition-all duration-500 z-40">
          <div className="flex justify-between items-start mb-4">
            <h3 className="font-bodoni text-xl text-luxury-black">Quick Stats</h3>
            <button 
              onClick={() => setIsVisible(false)}
              className="text-warm-gray hover:text-luxury-black transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-inter text-sm text-warm-gray">Today's Growth</span>
              <span className="font-bodoni text-lg text-luxury-black">+{Math.floor(analytics.followersGrowth * 10)} followers</span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="font-inter text-sm text-warm-gray">Current Streak</span>
              <span className="font-bodoni text-lg text-luxury-black">{analytics.streakDays} days 🔥</span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="font-inter text-sm text-warm-gray">Glow Score</span>
              <span className="font-bodoni text-lg text-luxury-black">{analytics.toolUsageScore}/100</span>
            </div>

            <button 
              onClick={() => setIsVisible(false)}
              className="w-full bg-luxury-black text-white py-3 font-inter text-[11px] uppercase tracking-[0.2em] hover:bg-luxury-black/90 transition-all duration-300 flex items-center justify-center gap-2"
            >
              View Full Dashboard
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </>
  )
}