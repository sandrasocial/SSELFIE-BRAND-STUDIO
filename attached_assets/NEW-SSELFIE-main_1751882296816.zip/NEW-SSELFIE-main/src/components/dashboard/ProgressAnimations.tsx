'use client'

import { useEffect, useState } from 'react'
import { Trophy, Star, Target, Zap, TrendingUp, Award } from 'lucide-react'

interface ProgressAnimationsProps {
  type: 'milestone' | 'achievement' | 'levelup' | 'streak' | 'goal'
  title: string
  description?: string
  value?: number
  maxValue?: number
  onComplete?: () => void
}

export function ProgressAnimations({ 
  type, 
  title, 
  description, 
  value = 0, 
  maxValue = 100,
  onComplete 
}: ProgressAnimationsProps) {
  const [isVisible, setIsVisible] = useState(false)
  const [currentValue, setCurrentValue] = useState(0)
  const [showCelebration, setShowCelebration] = useState(false)

  useEffect(() => {
    setIsVisible(true)
    
    // Animate progress value
    const duration = 2000
    const steps = 60
    const increment = value / steps
    let current = 0
    
    const timer = setInterval(() => {
      current += increment
      if (current >= value) {
        setCurrentValue(value)
        clearInterval(timer)
        
        // Show celebration for completed goals
        if (value >= maxValue) {
          setTimeout(() => setShowCelebration(true), 500)
          setTimeout(() => {
            onComplete?.()
          }, 3000)
        }
      } else {
        setCurrentValue(Math.floor(current))
      }
    }, duration / steps)
    
    return () => clearInterval(timer)
  }, [value, maxValue, onComplete])

  const getIcon = () => {
    switch (type) {
      case 'milestone':
        return <Trophy className="w-12 h-12" />
      case 'achievement':
        return <Award className="w-12 h-12" />
      case 'levelup':
        return <TrendingUp className="w-12 h-12" />
      case 'streak':
        return <Zap className="w-12 h-12" />
      case 'goal':
        return <Target className="w-12 h-12" />
      default:
        return <Star className="w-12 h-12" />
    }
  }

  const getColor = () => {
    switch (type) {
      case 'milestone': return 'text-purple-600'
      case 'achievement': return 'text-yellow-600'
      case 'levelup': return 'text-blue-600'
      case 'streak': return 'text-orange-600'
      case 'goal': return 'text-green-600'
      default: return 'text-luxury-black'
    }
  }

  const percentage = maxValue > 0 ? (currentValue / maxValue) * 100 : 0

  return (
    <div className={`relative transition-all duration-500 ${
      isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
    }`}>
      {/* Celebration Particles */}
      {showCelebration && (
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(12)].map((_, i) => (
            <div
              key={i}
              className="absolute w-2 h-2 bg-luxury-black animate-particle"
              style={{
                left: '50%',
                top: '50%',
                animation: `particle ${1 + i * 0.1}s ease-out forwards`,
                transform: `rotate(${i * 30}deg) translateX(0)`
              }}
            />
          ))}
        </div>
      )}

      {/* Main Card */}
      <div className="bg-white p-8 border border-luxury-black/10 hover:shadow-xl transition-all duration-500 overflow-hidden">
        {/* Background Number */}
        <div className="absolute -top-10 -right-10 font-lingerie text-[200px] text-luxury-black/[0.02] select-none pointer-events-none">
          {currentValue}
        </div>

        {/* Content */}
        <div className="relative z-10">
          {/* Icon */}
          <div className={`mb-6 ${getColor()} ${showCelebration ? 'animate-bounce' : ''}`}>
            {getIcon()}
          </div>

          {/* Text */}
          <h3 className="font-bodoni text-2xl text-luxury-black mb-2">
            {title}
          </h3>
          
          {description && (
            <p className="font-inter text-sm text-warm-gray mb-6">
              {description}
            </p>
          )}

          {/* Progress Bar */}
          {maxValue > 0 && (
            <div className="space-y-3">
              <div className="flex justify-between items-baseline">
                <span className="font-bodoni text-4xl text-luxury-black">
                  {currentValue}
                </span>
                <span className="font-inter text-sm text-warm-gray">
                  / {maxValue}
                </span>
              </div>
              
              <div className="relative h-3 bg-luxury-black/10 overflow-hidden">
                <div 
                  className="absolute left-0 top-0 h-full bg-gradient-to-r from-luxury-black to-luxury-black/80 transition-all duration-2000 ease-out"
                  style={{ width: `${percentage}%` }}
                />
                {/* Shimmer Effect */}
                <div 
                  className="absolute left-0 top-0 h-full w-full bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shimmer"
                  style={{ transform: 'translateX(-100%)' }}
                />
              </div>
              
              <p className="font-inter text-[11px] uppercase tracking-[0.2em] text-warm-gray">
                {percentage.toFixed(0)}% Complete
              </p>
            </div>
          )}

          {/* Achievement Stars */}
          {showCelebration && (
            <div className="flex justify-center gap-2 mt-6 animate-fadeIn">
              {[...Array(5)].map((_, i) => (
                <Star 
                  key={i}
                  className={`w-5 h-5 ${i < 3 ? 'text-yellow-500 fill-yellow-500' : 'text-warm-gray'}`}
                  style={{
                    animationDelay: `${i * 100}ms`
                  }}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      <style jsx>{`
        @keyframes particle {
          0% {
            transform: rotate(var(--rotation)) translateX(0) scale(1);
            opacity: 1;
          }
          100% {
            transform: rotate(var(--rotation)) translateX(100px) scale(0);
            opacity: 0;
          }
        }
        
        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(200%); }
        }
        
        .animate-shimmer {
          animation: shimmer 2s infinite;
        }
        
        .animate-particle {
          --rotation: 0deg;
        }
        
        .animate-fadeIn {
          animation: fadeIn 0.5s ease-out forwards;
        }
      `}</style>
    </div>
  )
}

// Animated Progress Ring Component
export function ProgressRing({ 
  value, 
  maxValue = 100, 
  size = 120, 
  strokeWidth = 8,
  label 
}: { 
  value: number
  maxValue?: number
  size?: number
  strokeWidth?: number
  label?: string
}) {
  const [currentValue, setCurrentValue] = useState(0)
  const radius = (size - strokeWidth) / 2
  const circumference = radius * 2 * Math.PI
  const offset = circumference - (currentValue / maxValue) * circumference

  useEffect(() => {
    const duration = 2000
    const steps = 60
    const increment = value / steps
    let current = 0
    
    const timer = setInterval(() => {
      current += increment
      if (current >= value) {
        setCurrentValue(value)
        clearInterval(timer)
      } else {
        setCurrentValue(current)
      }
    }, duration / steps)
    
    return () => clearInterval(timer)
  }, [value])

  return (
    <div className="relative inline-flex items-center justify-center">
      <svg width={size} height={size} className="transform -rotate-90">
        {/* Background Circle */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="currentColor"
          strokeWidth={strokeWidth}
          fill="none"
          className="text-luxury-black/10"
        />
        {/* Progress Circle */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="currentColor"
          strokeWidth={strokeWidth}
          fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          className="text-luxury-black transition-all duration-2000 ease-out"
          strokeLinecap="round"
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-bodoni text-3xl text-luxury-black">
          {Math.floor(currentValue)}
        </span>
        {label && (
          <span className="font-inter text-[10px] uppercase tracking-[0.2em] text-warm-gray">
            {label}
          </span>
        )}
      </div>
    </div>
  )
}

// Streak Counter Component
export function StreakCounter({ days, isActive = true }: { days: number; isActive?: boolean }) {
  const [displayDays, setDisplayDays] = useState(0)

  useEffect(() => {
    const duration = 1000
    const steps = 30
    const increment = days / steps
    let current = 0
    
    const timer = setInterval(() => {
      current += increment
      if (current >= days) {
        setDisplayDays(days)
        clearInterval(timer)
      } else {
        setDisplayDays(Math.floor(current))
      }
    }, duration / steps)
    
    return () => clearInterval(timer)
  }, [days])

  return (
    <div className="inline-flex items-center gap-3 px-6 py-3 bg-white border border-luxury-black/10">
      <div className={`${isActive ? 'animate-pulse' : ''}`}>
        <Zap className={`w-6 h-6 ${isActive ? 'text-orange-500' : 'text-warm-gray'}`} />
      </div>
      <div>
        <p className="font-bodoni text-2xl text-luxury-black">
          {displayDays} Days
        </p>
        <p className="font-inter text-[10px] uppercase tracking-[0.2em] text-warm-gray">
          Current Streak
        </p>
      </div>
      {isActive && (
        <div className="ml-2 text-2xl animate-bounce">
          🔥
        </div>
      )}
    </div>
  )
}