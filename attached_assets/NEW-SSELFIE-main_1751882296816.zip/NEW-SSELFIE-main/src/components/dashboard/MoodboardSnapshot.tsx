import React from 'react'
import Image from 'next/image'
import { cn } from '@/lib/utils'

interface ColorSwatch {
  color: string
  name?: string
}

interface MoodboardSnapshotProps {
  colors?: ColorSwatch[]
  fontFamily?: string
  selfieUrl?: string
  className?: string
}

export const MoodboardSnapshot: React.FC<MoodboardSnapshotProps> = ({
  colors = [
    { color: '#171719', name: 'Primary' },
    { color: '#F1F1F1', name: 'Secondary' },
    { color: '#B5B5B3', name: 'Accent' },
  ],
  fontFamily = 'Times New Roman',
  selfieUrl,
  className
}) => {
  return (
    <section className={cn("bg-white", className)}>
      <div className="h-full flex flex-col">
        <h2 className="font-bodoni text-3xl text-luxury-black mb-10">Your Brand Snapshot</h2>
        
        <div className="flex flex-col space-y-12 mb-10">
          {/* Color Swatches */}
          <div>
            <p className="text-sm uppercase tracking-[0.4em] text-warm-gray mb-5">Brand Colors</p>
            <div className="flex gap-7">
              {colors.map((swatch, index) => (
                <div key={index} className="relative">
                  <div 
                    className="w-14 h-14 border border-[#e5e5e5] shadow-sm" 
                    style={{ backgroundColor: swatch.color }}
                    aria-label={`Color swatch: ${swatch.name || swatch.color}`}
                  />
                  {swatch.name && (
                    <span className="absolute -bottom-7 left-0 text-xs text-warm-gray whitespace-nowrap tracking-wider">
                      {swatch.name}
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
          
          {/* Font Preview */}
          <div>
            <p className="text-sm uppercase tracking-[0.4em] text-warm-gray mb-5">Typography</p>
            <div className="flex items-center gap-7">
              <div className="text-5xl text-luxury-black" style={{ fontFamily }}>
                aa
              </div>
              <div className="text-sm text-warm-gray tracking-wider">
                {fontFamily || 'Default Font'}
              </div>
            </div>
          </div>
          
          {/* Selfie Preview */}
          <div>
            <p className="text-sm uppercase tracking-[0.4em] text-warm-gray mb-5">Latest Selfie</p>
            <div className="w-32 h-32 rounded-full overflow-hidden border border-[#e5e5e5] shadow-sm">
              {selfieUrl ? (
                <Image
                  src={selfieUrl}
                  alt="Your latest selfie"
                  width={128}
                  height={128}
                  className="object-cover w-full h-full hover:scale-[1.05] transition-transform duration-300"
                />
              ) : (
                <div className="w-full h-full bg-[#f5f5f5] flex items-center justify-center text-warm-gray text-sm">
                  No selfie
                </div>
              )}
            </div>
          </div>
        </div>
        
        <p className="text-luxury-black/80 text-base italic mt-auto font-bodoni">
          This is your vibe. Update it anytime.
        </p>
      </div>
    </section>
  )
}
