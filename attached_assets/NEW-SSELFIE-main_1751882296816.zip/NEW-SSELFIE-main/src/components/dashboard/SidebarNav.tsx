'use client'

import React, { useState, useEffect } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'

interface NavItem {
  label: string
  href: string
}

interface SidebarNavProps {
  items?: NavItem[]
  className?: string
}

export const SidebarNav: React.FC<SidebarNavProps> = ({
  items = [
    { label: 'Dashboard', href: '/dashboard' },
    { label: 'My Tools', href: '/dashboard/tools' },
    { label: 'Billing', href: '/dashboard/billing' },
    { label: 'Profile', href: '/dashboard/profile' },
    { label: 'Support', href: '/support' },
  ],
  className
}) => {
  const pathname = usePathname()
  const [isCollapsed, setIsCollapsed] = useState(false)
  const [isMobile, setIsMobile] = useState(false)
  
  // Handle responsive state
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 900)
      setIsCollapsed(window.innerWidth < 900)
    }
    
    handleResize()
    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [])
  
  return (
    <>
      {/* Hamburger Menu for Mobile */}
      {isMobile && (
        <button 
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="fixed top-8 right-8 z-50 w-12 h-12 flex flex-col justify-center items-center gap-[6px] bg-white border border-[#e5e5e5] rounded-none shadow-sm"
          aria-label={isCollapsed ? "Open menu" : "Close menu"}
        >
          <span className={cn(
            "w-6 h-[1.5px] bg-luxury-black transition-all duration-300",
            !isCollapsed && "transform rotate-45 translate-y-[4px]"
          )}></span>
          <span className={cn(
            "w-6 h-[1.5px] bg-luxury-black transition-all duration-300",
            !isCollapsed && "opacity-0"
          )}></span>
          <span className={cn(
            "w-6 h-[1.5px] bg-luxury-black transition-all duration-300",
            !isCollapsed && "transform -rotate-45 -translate-y-[4px]"
          )}></span>
        </button>
      )}
      
      {/* Sidebar Navigation */}
      <nav className={cn(
        "h-full bg-[#f5f5f5] py-16 px-10",
        "transition-all duration-300 ease-in-out",
        isCollapsed ? "w-0 overflow-hidden opacity-0 md:w-auto md:opacity-100" : "w-72 opacity-100",
        isMobile && !isCollapsed && "fixed inset-y-0 left-0 z-40 shadow-xl",
        className
      )}
      style={{ transitionTimingFunction: 'cubic-bezier(0.4, 0, 0.2, 1)' }}
      >
        <ul className="space-y-10">
          {items.map((item, index) => {
            const isActive = pathname === item.href || pathname?.startsWith(`${item.href}/`)
            
            return (
              <li key={index}>
                <Link
                  href={item.href}
                  className={cn(
                    "block text-[13px] tracking-[0.3em] uppercase font-light",
                    "transition-all duration-300",
                    "relative",
                    isActive ? 
                      "text-luxury-black after:content-[''] after:absolute after:bottom-[-6px] after:left-0 after:w-full after:h-[2px] after:bg-luxury-black" : 
                      "text-luxury-black/70 hover:text-luxury-black after:content-[''] after:absolute after:bottom-[-6px] after:left-0 after:w-0 after:h-[2px] after:bg-luxury-black hover:after:w-full after:transition-all after:duration-300"
                  )}
                  onClick={() => isMobile && setIsCollapsed(true)}
                >
                  {item.label}
                </Link>
              </li>
            )
          })}
        </ul>
      </nav>
      
      {/* Overlay for mobile */}
      {isMobile && !isCollapsed && (
        <div 
          className="fixed inset-0 bg-black/40 z-30 backdrop-blur-sm"
          onClick={() => setIsCollapsed(true)}
          aria-hidden="true"
        />
      )}
    </>
  )
}
