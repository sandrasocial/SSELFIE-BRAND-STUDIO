import React from 'react'
import { cn } from '@/lib/utils'

interface StatItem {
  label: string
  value: string | number
  change?: 'up' | 'down' | 'neutral'
}

interface QuickStatsPanelProps {
  stats?: StatItem[]
  className?: string
}

export const QuickStatsPanel: React.FC<QuickStatsPanelProps> = ({
  stats = [
    { label: 'Landing Page Views', value: '0', change: 'neutral' },
    { label: 'Email Signups', value: '0', change: 'neutral' },
    { label: 'Last Selfie Upload', value: 'Never', change: 'neutral' },
  ],
  className
}) => {
  return (
    <section className={cn("bg-white", className)}>
      <div className="h-full flex flex-col">
        <h2 className="font-bodoni text-3xl text-luxury-black mb-10">Quick Stats</h2>
        
        <div className="flex flex-col space-y-12 mb-10">
          {stats.map((stat, index) => (
            <div key={index} className="border-b border-[#e5e5e5] pb-7">
              <p className="text-sm uppercase tracking-[0.4em] text-warm-gray mb-4">
                {stat.label}
              </p>
              <div className="flex items-baseline gap-3">
                <span className="text-3xl font-bodoni text-luxury-black">
                  {stat.value}
                </span>
                
                {stat.change !== 'neutral' && (
                  <span className={cn(
                    "text-sm tracking-wider",
                    stat.change === 'up' ? "text-[#2A6D4F]" : "text-red-700"
                  )}>
                    {stat.change === 'up' ? '↑' : '↓'}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
        
        <p className="text-luxury-black/80 text-base italic mt-auto font-bodoni">
          Don&apos;t worry about the numbers. Just keep showing up.
        </p>
      </div>
    </section>
  )
}
