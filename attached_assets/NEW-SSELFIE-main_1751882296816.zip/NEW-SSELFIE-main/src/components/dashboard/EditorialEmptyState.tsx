import React from 'react'
import Link from 'next/link'
import { cn } from '@/lib/utils'

interface EditorialEmptyStateProps {
  message?: string
  ctaText?: string
  ctaLink?: string
  className?: string
}

export const EditorialEmptyState: React.FC<EditorialEmptyStateProps> = ({
  message = "Looks like you haven't uploaded any selfies yet. Want a little help?",
  ctaText = "UPLOAD YOUR FIRST SELFIE",
  ctaLink = "/tools/selfie-generator",
  className
}) => {
  return (
    <div className={cn(
      "py-24 px-16 text-center border border-warm-gray/30 mx-auto max-w-3xl bg-[#fafafa]",
      "shadow-sm",
      className
    )}>
      <p className="text-xl md:text-2xl font-bodoni text-luxury-black mb-14 leading-relaxed italic">
        {message}
      </p>
      
      {ctaText && ctaLink && (
        <Link 
          href={ctaLink}
          className={cn(
            "inline-block py-4 px-16 border-2 border-luxury-black text-luxury-black",
            "hover:bg-luxury-black hover:text-white text-[13px] tracking-[0.3em]",
            "uppercase font-light transition-all duration-300",
            "transform hover:translate-y-[-2px] hover:shadow-md",
            "focus:outline-none focus:ring-2 focus:ring-luxury-black focus:ring-offset-2"
          )}
        >
          {ctaText}
        </Link>
      )}
    </div>
  )
}
