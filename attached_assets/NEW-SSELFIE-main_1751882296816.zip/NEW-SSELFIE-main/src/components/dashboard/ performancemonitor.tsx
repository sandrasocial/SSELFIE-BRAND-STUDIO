'use client'

import { useState, useEffect } from 'react'
import { 
  Activity,
  TrendingUp,
  TrendingDown,
  Zap,
  Globe,
  Smartphone,
  Monitor,
  AlertCircle,
  CheckCircle,
  Clock,
  RefreshCw
} from 'lucide-react'

interface PerformanceMetric {
  name: string
  value: number
  unit: string
  status: 'good' | 'warning' | 'critical'
  trend?: 'up' | 'down' | 'stable'
  target: number
}

interface PerformanceMonitorProps {
  userId?: string
  showRealtime?: boolean
}

export function PerformanceMonitor({ userId, showRealtime = true }: PerformanceMonitorProps) {
  const [metrics, setMetrics] = useState<PerformanceMetric[]>([
    {
      name: 'Page Load Time',
      value: 1.2,
      unit: 's',
      status: 'good',
      trend: 'down',
      target: 2.0
    },
    {
      name: 'Glow Check Speed',
      value: 0.8,
      unit: 's',
      status: 'good',
      trend: 'stable',
      target: 1.0
    },
    {
      name: 'API Response',
      value: 245,
      unit: 'ms',
      status: 'good',
      trend: 'down',
      target: 300
    },
    {
      name: 'Upload Speed',
      value: 2.1,
      unit: 'MB/s',
      status: 'good',
      trend: 'up',
      target: 2.0
    }
  ])

  const [deviceStats, setDeviceStats] = useState({
    desktop: 45,
    mobile: 48,
    tablet: 7
  })

  const [isLive, setIsLive] = useState(false)

  // Simulate real-time updates
  useEffect(() => {
    if (!showRealtime || !isLive) return

    const interval = setInterval(() => {
      setMetrics(prev => prev.map(metric => ({
        ...metric,
        value: metric.value + (Math.random() - 0.5) * 0.2,
        trend: Math.random() > 0.5 ? 'up' : Math.random() > 0.5 ? 'down' : 'stable'
      })))
    }, 3000)

    return () => clearInterval(interval)
  }, [showRealtime, isLive])

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'good': return 'text-green-600'
      case 'warning': return 'text-amber-600'
      case 'critical': return 'text-red-600'
      default: return 'text-warm-gray'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'good': return <CheckCircle className="w-4 h-4" />
      case 'warning': return <AlertCircle className="w-4 h-4" />
      case 'critical': return <AlertCircle className="w-4 h-4" />
      default: return null
    }
  }

  const getTrendIcon = (trend?: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="w-3 h-3" />
      case 'down': return <TrendingDown className="w-3 h-3" />
      default: return <Activity className="w-3 h-3" />
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-bodoni text-2xl text-luxury-black">
            Performance Monitor
          </h3>
          <p className="font-inter text-sm text-warm-gray mt-1">
            Real-time platform performance metrics
          </p>
        </div>
        
        {showRealtime && (
          <button
            onClick={() => setIsLive(!isLive)}
            className={`inline-flex items-center gap-2 px-4 py-2 font-inter text-[11px] uppercase tracking-[0.2em] transition-all duration-300 ${
              isLive 
                ? 'bg-luxury-black text-white' 
                : 'bg-white text-luxury-black border border-luxury-black'
            }`}
          >
            <Activity className={`w-4 h-4 ${isLive ? 'animate-pulse' : ''}`} />
            {isLive ? 'Live' : 'Paused'}
          </button>
        )}
      </div>

      {/* Core Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {metrics.map((metric, index) => (
          <div
            key={index}
            className="bg-white p-6 border border-luxury-black/10 hover:shadow-lg transition-all duration-300 group"
          >
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="font-inter text-[10px] uppercase tracking-[0.2em] text-warm-gray mb-1">
                  {metric.name}
                </p>
                <div className="flex items-baseline gap-1">
                  <span className="font-bodoni text-3xl text-luxury-black">
                    {metric.value.toFixed(1)}
                  </span>
                  <span className="font-inter text-sm text-warm-gray">
                    {metric.unit}
                  </span>
                </div>
              </div>
              <div className={`flex items-center gap-1 ${getStatusColor(metric.status)}`}>
                {getStatusIcon(metric.status)}
              </div>
            </div>
            
            {/* Progress Bar */}
            <div className="relative h-1 bg-luxury-black/10 overflow-hidden">
              <div 
                className={`absolute left-0 top-0 h-full transition-all duration-500 ${
                  metric.status === 'good' ? 'bg-green-600' :
                  metric.status === 'warning' ? 'bg-amber-600' :
                  'bg-red-600'
                }`}
                style={{ width: `${(metric.value / metric.target) * 100}%` }}
              />
            </div>
            
            {/* Trend */}
            <div className="flex items-center justify-between mt-3">
              <span className="font-inter text-[10px] text-warm-gray">
                Target: {metric.target}{metric.unit}
              </span>
              {metric.trend && (
                <div className={`flex items-center gap-1 ${
                  metric.trend === 'up' && metric.status === 'good' ? 'text-green-600' :
                  metric.trend === 'down' && metric.status === 'good' ? 'text-red-600' :
                  'text-warm-gray'
                }`}>
                  {getTrendIcon(metric.trend)}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Device Distribution */}
      <div className="bg-white p-8">
        <h4 className="font-bodoni text-xl text-luxury-black mb-6">
          Device Distribution
        </h4>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Monitor className="w-5 h-5 text-warm-gray" />
              <span className="font-inter text-sm">Desktop</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-32 h-2 bg-luxury-black/10">
                <div 
                  className="h-full bg-luxury-black transition-all duration-500"
                  style={{ width: `${deviceStats.desktop}%` }}
                />
              </div>
              <span className="font-inter text-sm text-luxury-black">
                {deviceStats.desktop}%
              </span>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Smartphone className="w-5 h-5 text-warm-gray" />
              <span className="font-inter text-sm">Mobile</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-32 h-2 bg-luxury-black/10">
                <div 
                  className="h-full bg-luxury-black transition-all duration-500"
                  style={{ width: `${deviceStats.mobile}%` }}
                />
              </div>
              <span className="font-inter text-sm text-luxury-black">
                {deviceStats.mobile}%
              </span>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Smartphone className="w-5 h-5 text-warm-gray rotate-90" />
              <span className="font-inter text-sm">Tablet</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-32 h-2 bg-luxury-black/10">
                <div 
                  className="h-full bg-luxury-black transition-all duration-500"
                  style={{ width: `${deviceStats.tablet}%` }}
                />
              </div>
              <span className="font-inter text-sm text-luxury-black">
                {deviceStats.tablet}%
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* System Health */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 border border-luxury-black/10">
          <div className="flex items-center gap-3 mb-4">
            <Zap className="w-5 h-5 text-luxury-black" />
            <h5 className="font-inter text-sm uppercase tracking-[0.2em]">
              System Status
            </h5>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-green-500 animate-pulse" />
            <span className="font-inter text-sm">All systems operational</span>
          </div>
        </div>
        
        <div className="bg-white p-6 border border-luxury-black/10">
          <div className="flex items-center gap-3 mb-4">
            <Globe className="w-5 h-5 text-luxury-black" />
            <h5 className="font-inter text-sm uppercase tracking-[0.2em]">
              CDN Status
            </h5>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-green-500" />
            <span className="font-inter text-sm">Global coverage active</span>
          </div>
        </div>
        
        <div className="bg-white p-6 border border-luxury-black/10">
          <div className="flex items-center gap-3 mb-4">
            <Clock className="w-5 h-5 text-luxury-black" />
            <h5 className="font-inter text-sm uppercase tracking-[0.2em]">
              Uptime
            </h5>
          </div>
          <div className="flex items-center gap-2">
            <span className="font-bodoni text-2xl text-luxury-black">99.9%</span>
            <span className="font-inter text-sm text-warm-gray">Last 30 days</span>
          </div>
        </div>
      </div>

      {/* Last Updated */}
      {isLive && (
        <div className="flex items-center justify-center gap-2 text-warm-gray">
          <RefreshCw className="w-3 h-3 animate-spin" />
          <span className="font-inter text-xs">Updating live</span>
        </div>
      )}
    </div>
  )
}