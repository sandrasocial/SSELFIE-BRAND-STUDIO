import React from 'react'
import Image from 'next/image'
import { SandraImages } from '@/components/sandra-image-library'

interface DashboardHeroProps {
  userName?: string
  quote?: string
  className?: string
  subtext?: string
}

export const DashboardHero: React.FC<DashboardHeroProps> = ({
  userName = 'Beautiful',
  quote = "You don't need a plan. You need one brave post.",
  subtext = "Here's what's next for your brand (and your story).",
  className
}) => {
  return (
    <section 
      className={`relative min-h-[500px] lg:min-h-[600px] flex items-center overflow-hidden ${className || ''}`}
      style={{ 
        backgroundImage: `url(${SandraImages.hero.dashboard})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        backgroundColor: '#171719' // Fallback if image doesn't load
      }}
    >
      {/* Gradient Overlay */}
      <div 
        className="absolute inset-0 z-10"
        style={{
          background: `linear-gradient(to bottom, rgba(0,0,0,0.3) 0%, rgba(0,0,0,0.5) 50%, rgba(0,0,0,0.7) 100%)`
        }}
      />
      
      {/* Content */}
      <div className="relative z-20 w-full">
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-4xl mx-auto text-center">
            {/* Tagline */}
            <p className="text-white/90 text-sm md:text-base tracking-[0.4em] uppercase font-light mb-6 lg:mb-8">
              WELCOME
            </p>
            
            {/* Main Title */}
            <h1 className="font-bodoni text-4xl md:text-5xl lg:text-6xl xl:text-7xl text-white mb-6 lg:mb-8 leading-tight tracking-wider">
              {userName.toUpperCase()}
            </h1>
            
            {/* Subtitle */}
            {subtext && (
              <p className="text-white/90 text-lg md:text-xl lg:text-2xl font-light mb-8 lg:mb-12 leading-relaxed max-w-3xl mx-auto">
                {subtext}
              </p>
            )}
            
            {/* Quote */}
            {quote && (
              <blockquote className="text-white/80 text-base md:text-lg italic font-light max-w-2xl mx-auto border-l-2 border-white/30 pl-6 ml-6">
                "{quote}"
              </blockquote>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}
