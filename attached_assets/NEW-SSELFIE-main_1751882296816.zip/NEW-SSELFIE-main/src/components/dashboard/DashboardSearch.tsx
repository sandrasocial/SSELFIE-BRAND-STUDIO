'use client'

import { useState, useEffect, useRef } from 'react'
import Link from 'next/link'
import { Camera, Sparkles, MessageSquare, Calendar, TrendingUp, Mic, Eye, Settings, User, BookOpen, FileText, Search, Command, ArrowRight, Clock, ChevronRight } from 'lucide-react'

interface SearchResult {
  id: string
  type: 'tool' | 'content' | 'action' | 'page' | 'guide'
  title: string
  description: string
  href: string
  icon: React.ReactNode
  shortcut?: string
  popularity?: number
}

interface DashboardSearchProps {
  isOpen: boolean
  onClose: () => void
  recentSearches?: string[]
}

export function DashboardSearch({ isOpen, onClose, recentSearches = [] }: DashboardSearchProps) {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<SearchResult[]>([])
  const [selectedIndex, setSelectedIndex] = useState(0)
  const [showRecent, setShowRecent] = useState(true)
  const inputRef = useRef<HTMLInputElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)

  // Comprehensive search data with proper icons
  const searchData: SearchResult[] = [
    // Tools
    {
      id: 'glow-check',
      type: 'tool',
      title: 'Glow Check',
      description: 'AI-powered selfie analysis and feedback',
      href: '/tools/glow-check',
      icon: <Sparkles className="w-5 h-5" />,
      shortcut: 'G',
      popularity: 95
    },
    {
      id: 'selfie-camera',
      type: 'tool',
      title: 'Selfie Camera',
      description: 'Capture your perfect confidence shot',
      href: '/tools/camera',
      icon: <Camera className="w-5 h-5" />,
      shortcut: 'C',
      popularity: 90
    },
    {
      id: 'caption-generator',
      type: 'tool',
      title: 'Caption Creator',
      description: 'AI-powered captions that sound like you',
      href: '/tools/caption',
      icon: <MessageSquare className="w-5 h-5" />,
      shortcut: 'W',
      popularity: 85
    },
    {
      id: 'sselfie-ai',
      type: 'tool',
      title: 'SSELFIE AI Creator',
      description: 'Transform your selfies into luxury images',
      href: '/tools/sselfie-ai',
      icon: <Eye className="w-5 h-5" />,
      popularity: 88
    },
    
    // Content & Planning
    {
      id: 'content-calendar',
      type: 'content',
      title: 'Content Calendar',
      description: 'Plan your Instagram feed like a pro',
      href: '/dashboard/calendar',
      icon: <Calendar className="w-5 h-5" />,
      shortcut: 'K',
      popularity: 92
    },
    {
      id: 'brand-guidelines',
      type: 'content',
      title: 'Brand Guidelines',
      description: 'Your personal brand rules and voice',
      href: '/dashboard/brand',
      icon: <FileText className="w-5 h-5" />,
      popularity: 75
    },
    
    // Analytics & Growth
    {
      id: 'analytics',
      type: 'page',
      title: 'Analytics Dashboard',
      description: 'Track your growth and engagement',
      href: '/dashboard/analytics',
      icon: <TrendingUp className="w-5 h-5" />,
      shortcut: 'A',
      popularity: 80
    },
    {
      id: 'insights',
      type: 'page',
      title: 'Brand Insights',
      description: 'Deep dive into your performance',
      href: '/dashboard/insights',
      icon: <Eye className="w-5 h-5" />,
      popularity: 70
    },
    
    // Learning & Guides
    {
      id: 'voice-training',
      type: 'guide',
      title: 'Find Your Voice',
      description: 'Develop your unique brand voice',
      href: '/learn/voice',
      icon: <Mic className="w-5 h-5" />,
      popularity: 82
    },
    {
      id: 'selfie-guide',
      type: 'guide',
      title: 'Selfie Mastery Guide',
      description: 'Learn the art of the perfect selfie',
      href: '/learn/selfie-guide',
      icon: <BookOpen className="w-5 h-5" />,
      popularity: 87
    },
    
    // Account & Settings
    {
      id: 'profile',
      type: 'page',
      title: 'My Profile',
      description: 'Edit your profile and preferences',
      href: '/dashboard/profile',
      icon: <User className="w-5 h-5" />,
      shortcut: 'P',
      popularity: 65
    },
    {
      id: 'settings',
      type: 'action',
      title: 'Settings',
      description: 'Account and app preferences',
      href: '/dashboard/settings',
      icon: <Settings className="w-5 h-5" />,
      shortcut: ',',
      popularity: 60
    }
  ]

  // Quick actions for empty state
  const quickActions = [
    { title: 'Take a Glow Check', icon: <Sparkles className="w-4 h-4" />, href: '/tools/glow-check' },
    { title: 'Open Camera', icon: <Camera className="w-4 h-4" />, href: '/tools/camera' },
    { title: 'View Calendar', icon: <Calendar className="w-4 h-4" />, href: '/dashboard/calendar' },
    { title: 'Check Analytics', icon: <TrendingUp className="w-4 h-4" />, href: '/dashboard/analytics' }
  ]

  // Focus input when opened
  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus()
      setQuery('')
      setShowRecent(true)
      setSelectedIndex(0)
    }
  }, [isOpen])

  // Search functionality
  useEffect(() => {
    if (query.trim() === '') {
      setResults([])
      setShowRecent(true)
      return
    }

    setShowRecent(false)
    const searchQuery = query.toLowerCase()
    
    const filteredResults = searchData
      .filter(item =>
        item.title.toLowerCase().includes(searchQuery) ||
        item.description.toLowerCase().includes(searchQuery) ||
        item.type.toLowerCase().includes(searchQuery)
      )
      .sort((a, b) => {
        // Sort by relevance and popularity
        const aRelevance = a.title.toLowerCase().startsWith(searchQuery) ? 2 : 1
        const bRelevance = b.title.toLowerCase().startsWith(searchQuery) ? 2 : 1
        
        if (aRelevance !== bRelevance) return bRelevance - aRelevance
        return (b.popularity || 0) - (a.popularity || 0)
      })

    setResults(filteredResults.slice(0, 8))
    setSelectedIndex(0)
  }, [query])

  // Keyboard navigation
  const handleKeyDown = (e: React.KeyboardEvent) => {
    switch (e.key) {
      case 'Escape':
        e.preventDefault()
        onClose()
        break
      case 'ArrowDown':
        e.preventDefault()
        setSelectedIndex(prev => Math.min(prev + 1, results.length - 1))
        break
      case 'ArrowUp':
        e.preventDefault()
        setSelectedIndex(prev => Math.max(prev - 1, 0))
        break
      case 'Enter':
        e.preventDefault()
        if (results[selectedIndex]) {
          window.location.href = results[selectedIndex].href
        }
        break
    }
  }

  // Click outside to close
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        onClose()
      }
    }

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside)
      return () => document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [isOpen, onClose])

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-luxury-black/60 backdrop-blur-sm z-50 flex items-start justify-center pt-20 px-4">
      <div 
        ref={containerRef}
        className="bg-white w-full max-w-2xl shadow-2xl overflow-hidden transform transition-all duration-300 animate-slideDown"
      >
        {/* Search Header */}
        <div className="relative">
          <div className="absolute left-6 top-1/2 -translate-y-1/2">
            <Search className="w-5 h-5 text-warm-gray" />
          </div>
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Search tools, content, or actions..."
            className="w-full pl-16 pr-6 py-6 bg-transparent text-luxury-black text-lg placeholder-warm-gray focus:outline-none font-inter"
          />
          <div className="absolute right-6 top-1/2 -translate-y-1/2 flex items-center gap-2">
            <kbd className="hidden sm:inline-block px-2 py-1 text-[10px] font-inter uppercase tracking-wider bg-soft-white text-warm-gray">
              ESC
            </kbd>
          </div>
        </div>

        {/* Divider */}
        <div className="h-px bg-luxury-black/10" />

        {/* Search Results */}
        <div className="max-h-[400px] overflow-y-auto">
          {results.length > 0 ? (
            <>
              {/* Results Header */}
              <div className="px-6 py-3 bg-soft-white">
                <p className="font-inter text-[11px] uppercase tracking-[0.2em] text-warm-gray">
                  {results.length} Result{results.length !== 1 ? 's' : ''}
                </p>
              </div>
              
              {/* Results List */}
              {results.map((result, index) => (
                <Link key={result.id} href={result.href}>
                  <div
                    className={`px-6 py-4 flex items-center gap-4 transition-all duration-200 cursor-pointer group ${
                      index === selectedIndex
                        ? 'bg-luxury-black text-white'
                        : 'hover:bg-soft-white'
                    }`}
                    onClick={onClose}
                    onMouseEnter={() => setSelectedIndex(index)}
                  >
                    {/* Icon */}
                    <div className={`p-2 transition-colors ${
                      index === selectedIndex 
                        ? 'bg-white text-luxury-black' 
                        : 'bg-soft-white text-luxury-black group-hover:bg-luxury-black group-hover:text-white'
                    }`}>
                      {result.icon}
                    </div>
                    
                    {/* Content */}
                    <div className="flex-1">
                      <div className="font-inter text-base font-medium mb-1">
                        {result.title}
                      </div>
                      <div className={`font-inter text-sm ${
                        index === selectedIndex ? 'text-white/70' : 'text-warm-gray'
                      }`}>
                        {result.description}
                      </div>
                    </div>
                    
                    {/* Meta */}
                    <div className="flex items-center gap-3">
                      {result.shortcut && (
                        <kbd className={`px-2 py-1 text-[10px] font-inter font-medium ${
                          index === selectedIndex 
                            ? 'bg-white text-luxury-black' 
                            : 'bg-soft-white text-luxury-black'
                        }`}>
                          ⌘{result.shortcut}
                        </kbd>
                      )}
                      <span className={`text-xs font-inter uppercase tracking-wider ${
                        index === selectedIndex ? 'text-white/60' : 'text-warm-gray'
                      }`}>
                        {result.type}
                      </span>
                      <ChevronRight className={`w-4 h-4 transition-transform ${
                        index === selectedIndex ? 'translate-x-1' : ''
                      }`} />
                    </div>
                  </div>
                </Link>
              ))}
            </>
          ) : showRecent ? (
            <>
              {/* Quick Actions */}
              <div className="px-6 py-4">
                <p className="font-inter text-[11px] uppercase tracking-[0.2em] text-warm-gray mb-4">
                  Quick Actions
                </p>
                <div className="grid grid-cols-2 gap-3">
                  {quickActions.map((action) => (
                    <Link key={action.href} href={action.href}>
                      <button
                        onClick={onClose}
                        className="flex items-center gap-3 p-4 bg-soft-white hover:bg-luxury-black hover:text-white transition-all duration-200 group w-full text-left"
                      >
                        <div className="p-2 bg-white group-hover:bg-white group-hover:text-luxury-black transition-colors">
                          {action.icon}
                        </div>
                        <span className="font-inter text-sm">{action.title}</span>
                      </button>
                    </Link>
                  ))}
                </div>
              </div>
              
              {/* Recent Searches */}
              {recentSearches.length > 0 && (
                <>
                  <div className="h-px bg-luxury-black/10 mx-6" />
                  <div className="px-6 py-4">
                    <p className="font-inter text-[11px] uppercase tracking-[0.2em] text-warm-gray mb-3">
                      Recent
                    </p>
                    <div className="space-y-2">
                      {recentSearches.slice(0, 3).map((search, index) => (
                        <button
                          key={index}
                          onClick={() => setQuery(search)}
                          className="flex items-center gap-3 text-left w-full py-2 text-luxury-black hover:text-luxury-black/70 transition-colors group"
                        >
                          <Clock className="w-4 h-4 text-warm-gray" />
                          <span className="font-inter text-sm">{search}</span>
                          <ArrowRight className="w-3 h-3 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
                        </button>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </>
          ) : query.trim() !== '' ? (
            <div className="px-6 py-16 text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-soft-white mb-4">
                <Search className="w-6 h-6 text-warm-gray" />
              </div>
              <p className="font-inter text-lg text-luxury-black mb-2">No results found</p>
              <p className="font-inter text-sm text-warm-gray">
                Try searching for tools, guides, or actions
              </p>
            </div>
          ) : null}
        </div>

        {/* Search Footer */}
        <div className="px-6 py-3 bg-soft-white border-t border-luxury-black/10">
          <div className="flex items-center justify-between text-[11px] font-inter text-warm-gray">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1">
                <kbd className="px-1.5 py-0.5 bg-white text-[10px]">↑</kbd>
                <kbd className="px-1.5 py-0.5 bg-white text-[10px]">↓</kbd>
                Navigate
              </span>
              <span className="flex items-center gap-1">
                <kbd className="px-1.5 py-0.5 bg-white text-[10px]">↵</kbd>
                Select
              </span>
              <span className="hidden sm:flex items-center gap-1">
                <kbd className="px-1.5 py-0.5 bg-white text-[10px]">⌘K</kbd>
                Anywhere
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Command className="w-3 h-3" />
              <span>Command Palette</span>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes slideDown {
          from {
            opacity: 0;
            transform: translateY(-20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .animate-slideDown {
          animation: slideDown 0.2s cubic-bezier(0.16, 1, 0.3, 1);
        }
      `}</style>
    </div>
  )
}