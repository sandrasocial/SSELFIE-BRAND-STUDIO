# MobileMenu Component

A comprehensive mobile navigation component with authentication states, smooth animations, and luxury design.

## Features

- **Authentication States**: Different menu layouts for guests vs authenticated users
- **User Profile Display**: Avatar, name, email, and plan badge for authenticated users
- **Smooth Animations**: Slide-in panel with backdrop blur and hover effects
- **Body Scroll Lock**: Prevents background scrolling when menu is open
- **Keyboard Support**: ESC key closes menu
- **Responsive Design**: Mobile-first with lg+ breakpoint hiding
- **Dark Mode Support**: Full theming support
- **TypeScript Safe**: Complete type definitions and hook integration

## Components

### MobileMenu
Main mobile navigation panel component.

### MobileMenuToggle
Animated hamburger/close toggle button.

### useMobileMenu Hook
State management hook with keyboard support.

## Usage

```tsx
import { MobileMenu, MobileMenuToggle, useMobileMenu } from '@/components/global/MobileMenu'

function App() {
  const menu = useMobileMenu()
  
  return (
    <>
      {/* Toggle Button */}
      <MobileMenuToggle 
        isOpen={menu.isOpen}
        onClick={menu.toggle}
        darkMode={false}
      />
      
      {/* Menu Panel */}
      <MobileMenu
        isOpen={menu.isOpen}
        onClose={menu.close}
        isAuthenticated={true}
        user={{
          name: 'Sandra Smith',
          email: 'sandra@example.com',
          avatar: '/avatar.jpg',
          plan: 'lifetime'
        }}
        darkMode={false}
      />
    </>
  )
}
```

## Props

### MobileMenuProps

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `isOpen` | `boolean` | - | Whether menu is visible |
| `onClose` | `() => void` | - | Close menu callback |
| `isAuthenticated` | `boolean` | `false` | User authentication state |
| `user` | `UserData` | - | User information (optional) |
| `darkMode` | `boolean` | `false` | Enable dark mode styling |
| `className` | `string` | - | Additional CSS classes |

### UserData

| Property | Type | Description |
|----------|------|-------------|
| `name` | `string` | User's display name (optional) |
| `email` | `string` | User's email address (optional) |
| `avatar` | `string` | Avatar image URL (optional) |
| `plan` | `'free' \| 'monthly' \| 'annual' \| 'lifetime'` | Subscription plan (optional) |

### MobileMenuToggleProps

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `isOpen` | `boolean` | - | Current menu state |
| `onClick` | `() => void` | - | Toggle callback |
| `darkMode` | `boolean` | `false` | Enable dark mode styling |
| `className` | `string` | - | Additional CSS classes |

## Menu Content

### Guest Users
- **Links**: About, How It Works, Pricing, Transformations, Blog
- **Actions**: Sign In (outline button), Start Free (solid button)

### Authenticated Users
- **Profile Section**: Avatar/initial, name, email, plan badge
- **Main Links**: Studio, My Selfies, Tools, Training, Community
- **Account Section**: Account Settings, Subscription, Help Center
- **Sign Out**: Text button at bottom

## Animations

- **Panel**: Slides in from right with `ease-editorial` timing
- **Overlay**: Fades in with backdrop blur
- **Links**: Translate right on hover (`hover:translate-x-2`)
- **Toggle Button**: Smooth hamburger → X transformation
- **Body Lock**: Prevents scroll when open

## Styling

The component follows SSELFIE's luxury design system:

- **Typography**: Serif logo, clean navigation text
- **Colors**: Luxury black, pure white, soft whites, warm grays
- **Animations**: Smooth 300ms transitions with ease-editorial
- **Layout**: Full-height panel with proper spacing
- **Mobile-first**: Hidden on lg+ breakpoints

## Accessibility

- **ARIA Labels**: Proper labeling for toggle and close buttons
- **Keyboard Support**: ESC key closes menu
- **Focus Management**: Proper tab order and focus states
- **Screen Reader**: Semantic navigation structure

## Dependencies

- `@/components/ui/badge` - PlanBadge component for user plans
- `@/lib/utils` - Utility functions (cn for className merging)
- `next/link` - Navigation routing
- `next/image` - Optimized avatar images

## Hook Usage

```tsx
const menu = useMobileMenu()

// Methods available:
menu.isOpen     // Current state
menu.open()     // Open menu
menu.close()    // Close menu  
menu.toggle()   // Toggle state

// Automatically handles:
// - ESC key closing
// - Body scroll locking
// - Cleanup on unmount
```

## Examples

### Basic Guest Menu
```tsx
<MobileMenu
  isOpen={isOpen}
  onClose={handleClose}
  isAuthenticated={false}
/>
```

### Authenticated User Menu
```tsx
<MobileMenu
  isOpen={isOpen}
  onClose={handleClose}
  isAuthenticated={true}
  user={{
    name: 'Sarah Johnson',
    email: 'sarah@sselfie.ai',
    plan: 'annual'
  }}
  darkMode={true}
/>
```

### With Custom Toggle
```tsx
<MobileMenuToggle
  isOpen={menu.isOpen}
  onClick={menu.toggle}
  darkMode={darkMode}
  className="fixed top-4 right-4"
/>
```
