'use client'

import { cn } from '@/lib/utils'

export function LoadingSpinner({ className }: { className?: string }) {
  return (
    <div className={cn("flex items-center justify-center", className)} aria-label="Loading" role="status">
      <span className="block w-9 h-9 border-2 border-luxury-black dark:border-soft-white border-t-transparent rounded-full animate-spin-slow" />
      <style jsx global>{`
        @keyframes spin-slow {
          0% { transform: rotate(0deg);}
          100% { transform: rotate(360deg);}
        }
        .animate-spin-slow {
          animation: spin-slow 1.2s linear infinite;
        }
      `}</style>
    </div>
  )
}