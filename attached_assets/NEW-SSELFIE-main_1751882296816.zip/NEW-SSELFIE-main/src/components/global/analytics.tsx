'use client'

// Example: Plausible Analytics (swap for your provider)
import Script from 'next/script'

export function Analytics() {
  return (
    <>
      <Script 
        defer 
        data-domain="sselfie.ai" 
        src="https://plausible.io/js/plausible.js"
        strategy="afterInteractive"
      />
    </>
  )
}