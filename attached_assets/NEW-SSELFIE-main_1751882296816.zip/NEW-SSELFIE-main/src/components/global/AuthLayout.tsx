'use client'

import { cn } from '@/lib/utils'
import Link from 'next/link'

export function AuthLayout({ children, className }: { children: React.ReactNode, className?: string }) {
  return (
    <main className={cn(
      'min-h-screen flex flex-col items-center justify-center bg-soft-white dark:bg-luxury-black px-6 py-12',
      className
    )}>
      <div className="w-full max-w-md bg-pure-white dark:bg-luxury-black rounded-none shadow-xl p-10 flex flex-col gap-6">
        <Link href="/" className="block mb-2 font-bodoni text-3xl text-luxury-black dark:text-pure-white text-center tracking-tight hover:opacity-90 transition">
          SSELFIE
        </Link>
        <h1 className="font-bodoni text-2xl text-luxury-black dark:text-pure-white text-center mb-1">
          Welcome Back
        </h1>
        <p className="text-center text-warm-gray dark:text-soft-white/80 text-base mb-4">
          Real talk: you don’t have to have it all together to start. Just log in and let’s get you back to building.
        </p>
        {children}
      </div>
      <p className="mt-6 text-sm text-warm-gray/80 dark:text-soft-white/60 text-center max-w-md">
        “Your mess is your message. Let’s turn it into money.”
      </p>
    </main>
  )
}