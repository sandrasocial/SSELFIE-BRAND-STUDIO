'use client'

import Link from 'next/link'
import { cn } from '@/lib/utils'

export interface MemberNavProps {
  user?: {
    name?: string
    avatar?: string
    plan?: 'free' | 'monthly' | 'annual' | 'lifetime'
  }
  className?: string
}

export function MemberNavigation({ user, className }: MemberNavProps) {
  const navLinks = [
    { href: '/studio', label: 'Studio' },
    { href: '/selfies', label: 'My Selfies' },
    { href: '/tools', label: 'Tools' },
    { href: '/community', label: 'Community' },
    { href: '/account', label: 'Account' }
  ]

  return (
    <aside
      className={cn(
        'w-full max-w-[270px] min-h-screen border-r border-warm-gray/20 bg-pure-white dark:bg-luxury-black flex flex-col py-12 px-6 gap-8',
        className
      )}
      aria-label="Member navigation"
    >
      {/* Profile Block */}
      <div className="flex flex-col items-center text-center mb-6">
        {user?.avatar ? (
          <img
            src={user.avatar}
            alt={user.name || 'Avatar'}
            className="w-16 h-16 rounded-full object-cover border border-warm-gray mb-2"
          />
        ) : (
          <div className="w-16 h-16 rounded-full bg-warm-gray/30 flex items-center justify-center font-bodoni text-2xl text-luxury-black dark:text-pure-white mb-2">
            {user?.name ? user.name[0].toUpperCase() : 'S'}
          </div>
        )}
        <div className="font-bodoni text-lg text-luxury-black dark:text-pure-white">
          {user?.name || "Welcome back!"}
        </div>
        {user?.plan && (
          <div className="mt-1 text-xs uppercase tracking-wider px-2 py-0.5 border border-luxury-black/20 dark:border-soft-white/30 rounded">
            {user.plan === 'lifetime' ? 'Lifetime Access' : user.plan.charAt(0).toUpperCase() + user.plan.slice(1)}
          </div>
        )}
      </div>
      {/* Nav Links */}
      <nav className="flex-1 flex flex-col gap-3">
        {navLinks.map(link => (
          <Link
            key={link.href}
            href={link.href}
            className="block px-3 py-3 rounded font-inter text-base text-luxury-black dark:text-soft-white hover:bg-warm-gray/10 dark:hover:bg-soft-white/10 transition-all duration-300"
          >
            {link.label}
          </Link>
        ))}
      </nav>
      {/* Sign Out */}
      <button
        className="mt-12 w-full text-left text-warm-gray font-medium text-base px-2 py-3 rounded transition-all hover:bg-warm-gray/10 dark:hover:bg-soft-white/10 focus:outline-none"
        onClick={() => {
          // TODO: Connect sign out
          alert("Signed out! (replace with real sign-out)");
        }}
      >
        Sign out
      </button>
      {/* Footer */}
      <div className="text-xs text-warm-gray/80 dark:text-soft-white/60 text-center mt-8 pb-2 italic font-inter">
        “You’re one brave post away from a new chapter.”
      </div>
    </aside>
  )
}