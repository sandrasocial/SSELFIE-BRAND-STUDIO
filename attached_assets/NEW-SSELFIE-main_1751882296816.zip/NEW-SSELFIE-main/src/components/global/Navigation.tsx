'use client'

import React, { useState } from 'react'
import Link from 'next/link'
import { MobileMenu } from './MobileMenu'

export default function Navigation() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <>
      <header className="relative z-50 bg-transparent">
        <nav className="flex justify-between items-center max-w-6xl mx-auto px-6 lg:px-16 py-8 lg:py-10">
          {/* Logo */}
          <Link 
            href="/" 
            className="tracking-[0.3em] uppercase text-xs font-light font-inter text-soft-white transition-colors duration-300 hover:text-white focus:text-white"
          >
            SSELFIE STUDIO
          </Link>

          {/* Desktop Menu */}
          <ul className="hidden lg:flex gap-12">
            <li>
              <Link 
                href="/" 
                className="text-xs tracking-[0.22em] uppercase font-inter font-light text-soft-white opacity-80 transition-all duration-200 hover:opacity-100 hover:border-b hover:border-soft-white focus:opacity-100 focus:border-b focus:border-soft-white pb-1"
              >
                Home
              </Link>
            </li>
            <li>
              <Link 
                href="/about" 
                className="text-xs tracking-[0.22em] uppercase font-inter font-light text-soft-white opacity-80 transition-all duration-200 hover:opacity-100 hover:border-b hover:border-soft-white focus:opacity-100 focus:border-b focus:border-soft-white pb-1"
              >
                About
              </Link>
            </li>
            <li>
              <Link 
                href="/pricing" 
                className="text-xs tracking-[0.22em] uppercase font-inter font-light text-soft-white opacity-80 transition-all duration-200 hover:opacity-100 hover:border-b hover:border-soft-white focus:opacity-100 focus:border-b focus:border-soft-white pb-1"
              >
                Pricing
              </Link>
            </li>
            <li>
              <Link 
                href="/stories" 
                className="text-xs tracking-[0.22em] uppercase font-inter font-light text-soft-white opacity-80 transition-all duration-200 hover:opacity-100 hover:border-b hover:border-soft-white focus:opacity-100 focus:border-b focus:border-soft-white pb-1"
              >
                Stories
              </Link>
            </li>
            <li>
              <Link 
                href="/contact" 
                className="text-xs tracking-[0.22em] uppercase font-inter font-light text-soft-white opacity-80 transition-all duration-200 hover:opacity-100 hover:border-b hover:border-soft-white focus:opacity-100 focus:border-b focus:border-soft-white pb-1"
              >
                Contact
              </Link>
            </li>
          </ul>

          {/* Mobile Hamburger */}
          <button
            className="lg:hidden flex flex-col gap-1 items-end justify-center p-2 transition-opacity duration-200 hover:opacity-80 focus:opacity-80"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle mobile menu"
          >
            <span className={`block w-6 h-0.5 bg-soft-white transition-all duration-300 ${mobileMenuOpen ? 'rotate-45 translate-y-1.5' : ''}`} />
            <span className={`block w-6 h-0.5 bg-soft-white transition-all duration-300 ${mobileMenuOpen ? 'opacity-0' : ''}`} />
            <span className={`block w-6 h-0.5 bg-soft-white transition-all duration-300 ${mobileMenuOpen ? '-rotate-45 -translate-y-1.5' : ''}`} />
          </button>
        </nav>
      </header>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <MobileMenu
          isOpen={mobileMenuOpen}
          onClose={() => setMobileMenuOpen(false)}
          isAuthenticated={false}
          user={undefined}
        />
      )}
    </>
  )
}