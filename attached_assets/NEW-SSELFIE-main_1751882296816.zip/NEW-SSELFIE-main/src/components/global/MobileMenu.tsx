'use client'

import React, { useEffect, useRef } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { cn } from '@/lib/utils'
import Badge from '@/components/ui/badge'

/** Types */
export interface UserData {
  name?: string
  email?: string
  avatar?: string
  plan?: 'free' | 'monthly' | 'annual' | 'lifetime'
}

export interface MobileMenuProps {
  isOpen: boolean
  onClose: () => void
  isAuthenticated?: boolean
  user?: UserData
  darkMode?: boolean
  className?: string
}

export interface MobileMenuToggleProps {
  isOpen: boolean
  onClick: () => void
  darkMode?: boolean
  className?: string
}

/** useMobileMenu hook — manages open/close, ESC, and body scroll lock */
export function useMobileMenu() {
  const [isOpen, setIsOpen] = React.useState(false)

  // ESC closes menu
  useEffect(() => {
    if (!isOpen) return
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setIsOpen(false)
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [isOpen])

  // Body scroll lock
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = ''
    }
    return () => { document.body.style.overflow = '' }
  }, [isOpen])

  return {
    isOpen,
    open: () => setIsOpen(true),
    close: () => setIsOpen(false),
    toggle: () => setIsOpen((v) => !v),
  }
}

/** MobileMenuToggle — animated hamburger/X */
export function MobileMenuToggle({ isOpen, onClick, darkMode, className }: MobileMenuToggleProps) {
  return (
    <button
      aria-label={isOpen ? 'Close menu' : 'Open menu'}
      aria-expanded={isOpen}
      aria-controls="mobile-menu"
      onClick={onClick}
      className={cn(
        'relative w-12 h-12 flex items-center justify-center lg:hidden z-50 group',
        'focus:outline-none focus-visible:ring-2 focus-visible:ring-luxury-black',
        className
      )}
    >
      {/* Hamburger/X lines */}
      <span className={cn(
        'block absolute h-0.5 w-7 bg-current rounded transition-all duration-300',
        isOpen ? 'rotate-45 translate-y-1.5' : '-translate-y-2'
      )} />
      <span className={cn(
        'block absolute h-0.5 w-7 bg-current rounded transition-all duration-300',
        isOpen ? 'opacity-0' : 'opacity-100'
      )} />
      <span className={cn(
        'block absolute h-0.5 w-7 bg-current rounded transition-all duration-300',
        isOpen ? '-rotate-45 -translate-y-1.5' : 'translate-y-2'
      )} />
    </button>
  )
}

/** MobileMenu main panel */
export function MobileMenu({
  isOpen,
  onClose,
  isAuthenticated = false,
  user,
  darkMode = false,
  className
}: MobileMenuProps) {
  const panelRef = useRef<HTMLDivElement>(null)

  // Focus trap (first link)
  useEffect(() => {
    if (isOpen && panelRef.current) {
      const firstLink = panelRef.current.querySelector('a, button')
      if (firstLink) (firstLink as HTMLElement).focus()
    }
  }, [isOpen])

  // Close on backdrop click
  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) onClose()
  }

  // Links
  const guestLinks = [
    { href: '/about', label: 'About' },
    { href: '/how-it-works', label: 'How It Works' },
    { href: '/pricing', label: 'Pricing' },
    { href: '/transformations', label: 'Transformations' },
    { href: '/blog', label: 'Blog' },
  ]

  const userLinks = [
    { href: '/studio', label: 'Studio' },
    { href: '/selfies', label: 'My Selfies' },
    { href: '/tools', label: 'Tools' },
    { href: '/training', label: 'Training' },
    { href: '/community', label: 'Community' },
  ]

  const accountLinks = [
    { href: '/account', label: 'Account Settings' },
    { href: '/subscription', label: 'Subscription' },
    { href: '/help', label: 'Help Center' },
  ]

  // Animations
  return (
    <div
      id="mobile-menu"
      aria-modal="true"
      role="dialog"
      tabIndex={-1}
      className={cn(
        'fixed inset-0 z-40 lg:hidden',
        isOpen ? 'pointer-events-auto' : 'pointer-events-none',
        className
      )}
      style={{ transition: 'background 0.3s' }}
    >
      {/* Overlay */}
      <div
        className={cn(
          'absolute inset-0 bg-luxury-black/60 backdrop-blur-sm transition-opacity duration-300',
          isOpen ? 'opacity-100' : 'opacity-0'
        )}
        onClick={handleBackdropClick}
      />

      {/* Slide-in panel */}
      <nav
        ref={panelRef}
        className={cn(
          'absolute top-0 right-0 h-full w-full max-w-[400px] bg-pure-white dark:bg-luxury-black shadow-2xl',
          'flex flex-col px-7 py-8 gap-8 transition-transform duration-300 ease-editorial',
          isOpen ? 'translate-x-0' : 'translate-x-full',
        )}
        aria-label="Mobile menu"
      >
        {/* Header / Logo */}
        <div className="flex items-center justify-between mb-4">
          <Link href="/" tabIndex={isOpen ? 0 : -1} aria-label="Home">
            <span className="font-bodoni text-3xl tracking-tight font-light text-luxury-black dark:text-pure-white">
              SSELFIE
            </span>
          </Link>
          <button
            aria-label="Close menu"
            className={cn(
              'w-10 h-10 flex items-center justify-center rounded focus:outline-none focus-visible:ring-2 focus-visible:ring-luxury-black/60 transition-colors hover:bg-warm-gray/10 dark:hover:bg-soft-white/10'
            )}
            onClick={onClose}
            tabIndex={isOpen ? 0 : -1}
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Authenticated */}
        {isAuthenticated && user ? (
          <div className="flex flex-col items-center text-center mb-4">
            <div className="mb-3">
              {user.avatar ? (
                <Image
                  src={user.avatar}
                  alt={user.name || 'Avatar'}
                  width={64}
                  height={64}
                  className="rounded-full object-cover border border-warm-gray"
                />
              ) : (
                <div className="w-16 h-16 rounded-full bg-warm-gray/30 flex items-center justify-center font-bodoni text-2xl text-luxury-black dark:text-pure-white">
                  {user.name ? user.name[0].toUpperCase() : 'S'}
                </div>
              )}
            </div>
            <div className="mb-1 font-bodoni text-lg text-luxury-black dark:text-pure-white">
              {user.name || 'Welcome back!'}
            </div>
            <div className="text-xs text-warm-gray dark:text-soft-white mb-2">{user.email}</div>
            {user.plan && (
              <Badge
                variant={user.plan === 'lifetime' ? 'luxury' : user.plan === 'annual' ? 'success' : user.plan === 'monthly' ? 'default' : 'outline'}
                className="uppercase tracking-wider text-[0.7em] px-2 py-0.5"
              >
                {user.plan === 'lifetime' && 'Lifetime'}
                {user.plan === 'annual' && 'Annual'}
                {user.plan === 'monthly' && 'Monthly'}
                {user.plan === 'free' && 'Free'}
              </Badge>
            )}
          </div>
        ) : null}

        {/* Menu Links */}
        <div className="flex-1 flex flex-col gap-2">
          {(isAuthenticated ? userLinks : guestLinks).map(link => (
            <Link
              key={link.href}
              href={link.href}
              tabIndex={isOpen ? 0 : -1}
              className={cn(
                'block w-full text-left px-2 py-4 rounded font-inter text-lg font-medium transition-all duration-200',
                'hover:translate-x-2 hover:bg-warm-gray/10 dark:hover:bg-soft-white/10',
                darkMode ? 'text-soft-white' : 'text-luxury-black'
              )}
              onClick={onClose}
            >
              {link.label}
            </Link>
          ))}
        </div>

        {/* Account / Auth links */}
        <div className="flex flex-col gap-2 mt-8 mb-4">
          {isAuthenticated ? (
            <>
              <div className="border-t border-warm-gray/20 dark:border-soft-white/20 pt-4 mt-2">
                {accountLinks.map(link => (
                  <Link
                    key={link.href}
                    href={link.href}
                    tabIndex={isOpen ? 0 : -1}
                    className={cn(
                      'block w-full text-left px-2 py-3 rounded font-inter text-base transition-all duration-200',
                      'hover:translate-x-2 hover:bg-warm-gray/10 dark:hover:bg-soft-white/10',
                      darkMode ? 'text-soft-white/80' : 'text-luxury-black/80'
                    )}
                    onClick={onClose}
                  >
                    {link.label}
                  </Link>
                ))}
              </div>
              <button
                className={cn(
                  'mt-4 w-full text-left text-warm-gray font-medium text-base px-2 py-3 rounded transition-all hover:bg-warm-gray/10 dark:hover:bg-soft-white/10',
                  'focus:outline-none focus-visible:ring-2 focus-visible:ring-luxury-black/60'
                )}
                tabIndex={isOpen ? 0 : -1}
                onClick={() => {
                  // replace with sign-out logic
                  alert("Signed out! (replace with real sign-out)")
                  onClose()
                }}
              >
                Sign out
              </button>
            </>
          ) : (
            <div className="flex flex-col gap-3">
              <Link
                href="/login"
                tabIndex={isOpen ? 0 : -1}
                className={cn(
                  'w-full py-4 rounded border border-luxury-black/30 dark:border-soft-white/30 bg-transparent text-luxury-black dark:text-soft-white font-inter font-medium uppercase tracking-wider text-sm hover:bg-warm-gray/10 dark:hover:bg-soft-white/10 transition-all'
                )}
                onClick={onClose}
              >
                Sign In
              </Link>
              <Link
                href="/register"
                tabIndex={isOpen ? 0 : -1}
                className={cn(
                  'w-full py-4 rounded bg-luxury-black text-pure-white font-inter font-semibold uppercase tracking-wider text-sm hover:bg-luxury-black/90 transition-all'
                )}
                onClick={onClose}
              >
                Start Free
              </Link>
            </div>
          )}
        </div>

        {/* Friendly footer copy */}
        <div className="text-xs text-warm-gray/80 dark:text-soft-white/60 text-center mt-auto pb-2 pt-4 italic font-inter">
          {isAuthenticated
            ? "Keep showing up. You’re one selfie away from something new."
            : "No spam. Just honest advice on selfies, confidence & building something real—promise."}
        </div>
      </nav>
    </div>
  )
}