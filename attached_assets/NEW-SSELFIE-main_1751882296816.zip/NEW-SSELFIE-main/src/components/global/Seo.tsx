'use client'

import Head from 'next/head'

export function Seo({ 
  title = 'SSELFIE – Build Your Brand From Your Selfie',
  description = "Real talk, real brand. Sandra's guide to showing up online when you don't have it all together (yet).",
  image = '/og-image.jpg',
  url = 'https://sselfie.ai',
  children
}: {
  title?: string
  description?: string
  image?: string
  url?: string
  children?: React.ReactNode
}) {
  return (
    <Head>
      <title>{title}</title>
      <meta name="description" content={description}/>
      <meta property="og:title" content={title}/>
      <meta property="og:description" content={description}/>
      <meta property="og:image" content={image}/>
      <meta property="og:url" content={url}/>
      <meta name="twitter:card" content="summary_large_image"/>
      <meta name="twitter:title" content={title}/>
      <meta name="twitter:description" content={description}/>
      <meta name="twitter:image" content={image}/>
      {children}
    </Head>
  )
}