'use client'

import Link from 'next/link'
import { cn } from '@/lib/utils'

export function Footer({ className }: { className?: string }) {
  return (
    <footer className={cn(
      'section-padding bg-white border-t border-accent-line',
      className
    )}>
      <div className="max-width-editorial mx-auto px-6">
        <div className="flex flex-col lg:flex-row justify-between items-start gap-16">
          {/* Brand Block */}
          <div className="luxury-headline text-2xl">SSELFIE</div>
          
          {/* Links Grid */}
          <div className="grid md:grid-cols-3 gap-16">
            <div>
              <h4 className="section-label mb-6">Start Here</h4>
              <ul className="space-y-2">
                <li><Link href="/about" className="body-copy hover:opacity-80">My Story</Link></li>
                <li><Link href="/freebie" className="body-copy hover:opacity-80">Free Selfie Guide</Link></li>
                <li><Link href="/transformations" className="body-copy hover:opacity-80">Success Stories</Link></li>
                <li><Link href="/membership" className="body-copy hover:opacity-80">Work With Me</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="section-label mb-6">Resources</h4>
              <ul className="space-y-2">
                <li><Link href="/blog" className="body-copy hover:opacity-80">Blog</Link></li>
                <li><Link href="/studio/glow-check" className="body-copy hover:opacity-80">Glow Check Tool</Link></li>
                <li><Link href="/sselfie-ai" className="body-copy hover:opacity-80">Sandra AI</Link></li>
                <li><Link href="/method" className="body-copy hover:opacity-80">The Method</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="section-label mb-6">Connect</h4>
              <ul className="space-y-2">
                <li>
                  <a 
                    href="https://instagram.com/sandra.social"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="body-copy hover:opacity-80"
                  >
                    Instagram
                  </a>
                </li>
                <li>
                  <a 
                    href="https://tiktok.com/@sandra.social"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="body-copy hover:opacity-80"
                  >
                    TikTok
                  </a>
                </li>
                <li>
                  <a 
                    href="mailto:hello@sselfie.ai"
                    className="body-copy hover:opacity-80"
                  >
                    Email Me
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        
        {/* Bottom Bar */}
        <div className="mt-16 pt-8 border-t border-accent-line flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="body-copy text-soft-gray text-sm">
            © {new Date().getFullYear()} SSELFIE. Built with coffee, real talk, and a little bit of chaos.
          </p>
          <div className="flex gap-6 text-sm">
            <Link href="/privacy" className="body-copy text-soft-gray hover:opacity-80">Privacy</Link>
            <Link href="/terms" className="body-copy text-soft-gray hover:opacity-80">Terms</Link>
            <Link href="/cookies" className="body-copy text-soft-gray hover:opacity-80">Cookies</Link>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer