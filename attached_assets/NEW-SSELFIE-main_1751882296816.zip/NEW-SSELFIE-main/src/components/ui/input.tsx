import React from "react";
import clsx from "clsx";

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  fullWidth?: boolean;
  className?: string;
}

const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ label, error, fullWidth = false, className, ...props }, ref) => (
    <div className={clsx("", fullWidth && "", className)}>
      {label && <label className={""}>{label}</label>}
      <input ref={ref} className={""} {...props} />
      {error && <span className={""}>{error}</span>}
    </div>
  )
);

Input.displayName = "Input";

export default Input;