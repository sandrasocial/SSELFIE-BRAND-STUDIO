import React from "react";
import clsx from "clsx";

interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string;
  fullWidth?: boolean;
  className?: string;
}

const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ label, error, fullWidth = false, className, ...props }, ref) => (
    <div className={clsx("", fullWidth && "", className)}>
      {label && <label className={""}>{label}</label>}
      <textarea ref={ref} className={""} {...props} />
      {error && <span className={""}>{error}</span>}
    </div>
  )
);

Textarea.displayName = "Textarea";

export default Textarea;