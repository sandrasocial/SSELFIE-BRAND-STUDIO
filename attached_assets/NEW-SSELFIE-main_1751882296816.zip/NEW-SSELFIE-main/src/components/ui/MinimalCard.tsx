import React from "react";
import clsx from "clsx";

export interface MinimalCardProps {
  children: React.ReactNode;
  dark?: boolean;
  className?: string;
}

export function MinimalCard({
  children,
  dark = false,
  className,
}: MinimalCardProps) {
  return (
    <div className={clsx("ss-card-minimal", dark && "ss-card-minimal-dark", className)}>
      {children}
    </div>
  );
}
