import React from "react";
import clsx from "clsx";

export type ButtonVariant = "primary" | "secondary" | "white" | "ghost";

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  fullWidth?: boolean;
  children: React.ReactNode;
  className?: string;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      variant = "primary",
      fullWidth = false,
      children,
      className = "",
      ...props
    },
    ref
  ) => {
    const baseClasses = "border-0 font-bodoni text-lg font-normal tracking-tight py-4 px-11 cursor-pointer transition-all duration-300 ease-out outline-none relative z-10 active:translate-y-px active:scale-98";
    
    const variantClasses = {
      primary: "bg-luxury-black text-soft-white hover:bg-black hover:shadow-lg hover:-translate-y-1 hover:scale-101 focus:bg-black focus:shadow-lg focus:-translate-y-1 focus:scale-101",
      secondary: "bg-soft-white text-luxury-black border-[1.5px] border-luxury-black hover:bg-luxury-black hover:text-soft-white hover:shadow-lg hover:-translate-y-1 hover:scale-101 focus:bg-luxury-black focus:text-soft-white focus:shadow-lg focus:-translate-y-1 focus:scale-101",
      white: "bg-soft-white text-luxury-black border-0 hover:bg-gray-50 hover:shadow-md hover:-translate-y-0.5 hover:scale-101 focus:bg-gray-50 focus:shadow-md focus:-translate-y-0.5 focus:scale-101",
      ghost: "bg-transparent text-soft-white border-[1.5px] border-soft-white hover:bg-soft-white hover:text-luxury-black hover:shadow-lg hover:-translate-y-1 hover:scale-101 focus:bg-soft-white focus:text-luxury-black focus:shadow-lg focus:-translate-y-1 focus:scale-101"
    };

    return (
      <button
        ref={ref}
        className={clsx(
          baseClasses,
          variantClasses[variant],
          fullWidth && "w-full block",
          className
        )}
        {...props}
      >
        {children}
      </button>
    );
  }
);

Button.displayName = "Button";

export default Button;