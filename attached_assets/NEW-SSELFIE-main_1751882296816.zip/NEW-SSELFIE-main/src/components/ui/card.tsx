// Card components index - exports all card variants
// Organized by Diana for better component management

// HeroCard archived - use HeroFullBleed from '@/components/sections/hero/HeroFullBleed' instead
export { MinimalCard, type MinimalCardProps } from './MinimalCard';
export { GenericCard, type GenericCardProps } from './generic-card';