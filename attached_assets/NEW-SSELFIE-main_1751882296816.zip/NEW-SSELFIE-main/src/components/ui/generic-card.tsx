import React from "react";
import clsx from "clsx";

export interface GenericCardProps {
  children: React.ReactNode;
  className?: string;
}

// Generic Card component for general use
export function GenericCard({ children, className }: GenericCardProps) {
  return (
    <div className={clsx("bg-white border border-gray-200 rounded-lg", className)}>
      {children}
    </div>
  );
}
