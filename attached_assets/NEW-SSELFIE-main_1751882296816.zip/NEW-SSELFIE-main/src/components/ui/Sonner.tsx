import React, { useEffect } from "react";
import clsx from "clsx";

export type SonnerType = "success" | "error" | "info";

export interface SonnerToast {
  id: number;
  type: SonnerType;
  message: string;
}

interface SonnerContextProps {
  notify: (type: SonnerType, message: string) => void;
}

export const SonnerContext = React.createContext<SonnerContextProps | undefined>(undefined);

export const useSonner = () => {
  const context = React.useContext(SonnerContext);
  if (!context) throw new Error("useSonner must be used within a SonnerProvider");
  return context;
};

export const SonnerProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = React.useState<SonnerToast[]>([]);

  // Remove toast after 3 seconds
  useEffect(() => {
    if (toasts.length === 0) return;
    const timer = setTimeout(() => {
      setToasts(ts => ts.slice(1));
    }, 3000);
    return () => clearTimeout(timer);
  }, [toasts]);

  const notify = (type: SonnerType, message: string) => {
    setToasts(ts => [...ts, { id: Date.now(), type, message }]);
  };

  return (
    <SonnerContext.Provider value={{ notify }}>
      {children}
      <div className={""}>
        {toasts.map(toast => (
          <div key={toast.id} className={clsx("", styles[toast.type])}>
            {toast.type === "success" && <span className={""}>✔</span>}
            {toast.type === "error" && <span className={""}>✖</span>}
            {toast.type === "info" && <span className={""}>ℹ️</span>}
            <span className={""}>{toast.message}</span>
          </div>
        ))}
      </div>
    </SonnerContext.Provider>
  );
};