import React from "react";
import clsx from "clsx";

interface ToggleSwitchProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  fullWidth?: boolean;
  className?: string;
}

const ToggleSwitch = React.forwardRef<HTMLInputElement, ToggleSwitchProps>(
  (
    { label, error, fullWidth = false, className, ...props },
    ref
  ) => (
    <div className={clsx("", fullWidth && "", className)}>
      <label className={""}>
        <input
          ref={ref}
          type="checkbox"
          className={""}
          {...props}
        />
        <span className={""} aria-hidden="true">
          <span className={""} />
        </span>
        {label && <span className={""}>{label}</span>}
      </label>
      {error && <span className={""}>{error}</span>}
    </div>
  )
);

ToggleSwitch.displayName = "ToggleSwitch";

export default ToggleSwitch;