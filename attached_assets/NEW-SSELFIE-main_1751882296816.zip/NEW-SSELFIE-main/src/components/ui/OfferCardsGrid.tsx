"use client";

import React from "react";
import OfferCard from "./OfferCard";

const offers = [
	{
		number: "01",
		title: "SSELFIE AI Images",
		price: "€47 one-time",
		description:
			"Upload 10-15 selfies, get 30 luxury AI images back. No studio needed—just your SSELFIE AI-trained AI doing the magic.",
		imageSrc: "https://i.postimg.cc/9Q0P8yJj/story-2.jpg",
		imageAlt: "Sandra with camera - AI Images",
		ctaText: "Try It Now",
		ctaHref: "/ai-images",
		badge: "SSELFIE AI",
	},
	{
		number: "02",
		title: "SSELFIE Studio",
		price: "€97/month",
		description:
			"Everything you need to build your personal brand in 20 minutes. AI images, luxury templates, instant setup.",
		imageSrc: "https://i.postimg.cc/BQMcBm5g/story1.jpg",
		imageAlt: "Sandra in studio",
		ctaText: "Start Today",
		ctaHref: "/studio",
		badge: "Founding Member",
	},
	{
		number: "03",
		title: "SSELFIE Studio",
		price: "€147/month",
		description:
			"Full platform access. For when you're ready to show up, get seen, and finally get paid for being you.",
		imageSrc: "https://i.postimg.cc/HkNwfjh8/out-2-14.jpg",
		imageAlt: "Sandra portrait",
		ctaText: "Get Started",
		ctaHref: "/studio-standard",
		badge: "Standard",
	},
];

const OfferCardsGrid: React.FC = () => (
	<section className="section-padding bg-editorial-gray">
		<div className="max-width-moodboard px-6">
			{/* Section Header */}
			<div className="text-center mb-16 md:mb-20">
				<h2 className="h2 uppercase mb-5">
					START HERE
				</h2>
				<p className="body-copy text-soft-gray max-w-[520px] mx-auto">
          Okay, so here&apos;s how this works.
        </p>
			</div>
			{/* Cards Grid */}
			<div className="grid grid-cols-1 md:grid-cols-3 grid-gap">
				{offers.map((offer) => (
					<OfferCard key={offer.number} {...offer} />
				))}
			</div>
		</div>
	</section>
);

export default OfferCardsGrid;