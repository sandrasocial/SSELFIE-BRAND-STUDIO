import React from "react";
import clsx from "clsx";

interface ProgressLabelProps {
  value: number; // out of 100
  label?: string;
  color?: string; // overrides default accent
  className?: string;
}

const ProgressLabel: React.FC<ProgressLabelProps> = ({
  value,
  label,
  color,
  className,
}) => (
  <div className={clsx("", className)}>
    <div className={""}>
      {label && <span className={""}>{label}</span>}
      <span className={""}>{value}%</span>
    </div>
    <div className={""}>
      <div
        className={""}
        style={{ width: `${value}%`, background: color || "#151515" }}
      />
    </div>
  </div>
);

export default ProgressLabel;