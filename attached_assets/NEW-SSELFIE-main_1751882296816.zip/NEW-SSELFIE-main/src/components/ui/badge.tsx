import React from "react";
import clsx from "clsx";

interface BadgeProps {
  children: React.ReactNode;
  color?: "default" | "success" | "error" | "info";
  className?: string;
}

const Badge: React.FC<BadgeProps> = ({
  children,
  color = "default",
  className,
}) => (
  <span className={clsx("", styles[color], className)}>
    {children}
  </span>
);

export default Badge;