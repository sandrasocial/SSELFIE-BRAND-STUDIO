import React from 'react'

interface SectionHeadlineProps {
  tagline?: string
  headline: string
  className?: string
}

export const SectionHeadline: React.FC<SectionHeadlineProps> = ({
  tagline,
  headline,
  className = ""
}) => {
  return (
    <div className={`text-center ${className}`}>
      {tagline && (
        <p className="font-inter text-xs tracking-[0.3em] uppercase text-luxury-black/50 mb-8">
          {tagline}
        </p>
      )}
      
      <h2 className="font-bodoni text-4xl md:text-5xl lg:text-6xl font-light leading-tight text-luxury-black tracking-[0.02em] uppercase mb-8">
        {headline}
      </h2>
    </div>
  )
}
