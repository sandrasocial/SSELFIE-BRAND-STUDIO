import React from "react";
import clsx from "clsx";

interface CheckboxProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  description?: string;
  error?: string;
  fullWidth?: boolean;
  className?: string;
}

const Checkbox = React.forwardRef<HTMLInputElement, CheckboxProps>(
  (
    { label, description, error, fullWidth = false, className, ...props },
    ref
  ) => (
    <div className={clsx(
      "flex flex-col mb-7 w-full",
      fullWidth && "w-full",
      className
    )}>
      <label className="flex items-start gap-4 cursor-pointer font-inter select-none">
        <input
          ref={ref}
          type="checkbox"
          className="absolute opacity-0 pointer-events-none peer"
          {...props}
        />
        <span 
          className="w-6 h-6 border-[1.5px] border-luxury-black bg-soft-white inline-block relative mt-0.5 mr-3 transition-all duration-200 ease-out peer-checked:bg-luxury-black peer-checked:border-luxury-black peer-focus:shadow-[0_0_0_2px_rgba(21,21,21,0.2)] after:content-[''] peer-checked:after:absolute peer-checked:after:left-1.5 peer-checked:after:top-0.5 peer-checked:after:w-2 peer-checked:after:h-3 peer-checked:after:border-soft-white peer-checked:after:border-r-2 peer-checked:after:border-b-2 peer-checked:after:rotate-45 peer-checked:after:block md:w-6 md:h-6 max-md:w-4 max-md:h-4" 
          aria-hidden="true" 
        />
        <span className="flex flex-col gap-1">
          {label && <span className="text-lg text-luxury-black font-medium tracking-tight mb-0.5 max-md:text-base">{label}</span>}
          {description && <span className="text-base text-warm-gray opacity-90 font-normal leading-snug max-md:text-sm">{description}</span>}
        </span>
      </label>
      {error && <span className="text-red-600 mt-2 text-base font-inter italic opacity-90 ml-9">{error}</span>}
    </div>
  )
);

Checkbox.displayName = "Checkbox";

export default Checkbox;