import React from "react";
import clsx from "clsx";

interface CheckboxGroupProps {
  label?: string;
  children: React.ReactNode;
  orientation?: "vertical" | "horizontal";
  className?: string;
}

const CheckboxGroup: React.FC<CheckboxGroupProps> = ({
  label,
  children,
  orientation = "vertical",
  className,
}) => (
  <fieldset className={clsx("", className)}>
    {label && <legend className={""}>{label}</legend>}
    <div
      className={clsx(
        "",
        orientation === "vertical" ? "" : ""
      )}
    >
      {children}
    </div>
  </fieldset>
);

export default CheckboxGroup;