"use client";

import React from "react";
import Image from "next/image";
import Link from "next/link";
import clsx from "clsx";

export interface OfferCardProps {
  number: string;
  title: string;
  price: string;
  description: string;
  imageSrc: string;
  imageAlt: string;
  ctaText: string;
  ctaHref: string;
  badge?: string;
  className?: string;
}

const OfferCard: React.FC<OfferCardProps> = ({
  number,
  title,
  price,
  description,
  imageSrc,
  imageAlt,
  ctaText,
  ctaHref,
  badge,
  className,
}) => (
  <div
    className={clsx(
      "flex flex-col bg-white transition-all duration-400 cursor-pointer border-0 shadow-[0_7px_28px_0_rgba(21,21,21,0.06)] hover:shadow-[0_24px_48px_0_rgba(21,21,21,0.1)] hover:-translate-y-2 hover:scale-[1.012] will-change-transform group",
      className
    )}
  >
    {/* Editorial Image */}
    <div className="relative w-full aspect-[3/4] overflow-hidden mb-9 md:mb-6 bg-[#f6f6f6]">
      <Image
        src={imageSrc}
        alt={imageAlt}
        fill
        className="object-cover transition-transform ease-luxury group-hover:scale-105"
        sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
      />

      {/* Dramatic Number Overlay */}
      <span className="absolute top-6 left-6 md:top-4 md:left-4 editorial-headline text-[1.9rem] md:text-[1.02rem] text-white opacity-80 tracking-[0.27em] text-shadow-soft z-10 pointer-events-none transition-all group-hover:opacity-100 group-hover:tracking-[0.37em]">
        {number}
      </span>

      {/* Optional Badge */}
      {badge && (
        <span className="absolute top-6 right-6 md:top-4 md:right-4 bg-luxury-black text-white text-[0.89rem] md:text-[1.02rem] px-4 py-1 md:px-3 md:py-1 tracking-[0.12em] uppercase opacity-95 z-10">
          {badge}
        </span>
      )}
    </div>

    {/* Text Content */}
    <div className="flex flex-col gap-4 px-7 pb-8 md:px-2 md:pb-5 transition-all duration-300 group-hover:translate-x-1">
      <h3 className="editorial-headline text-[2rem] md:text-[1.25rem] font-light text-luxury-black mb-1 tracking-tight leading-tight transition-colors duration-200">
        {title}
      </h3>
      <p className="editorial-headline text-[1.33rem] md:text-[1.01rem] italic text-luxury-black/80 mb-1">
        {price}
      </p>
      <p className="text-[16px] md:text-[15px] text-luxury-black/72 leading-relaxed mb-1">
        {description}
      </p>
      <Link
        href={ctaHref}
        className="inline-block text-[15px] md:text-[15px] tracking-[0.18em] uppercase text-luxury-black border-b-[1.5px] border-luxury-black pb-1 mt-2 no-underline transition-all duration-200 hover:border-luxury-black/47 hover:tracking-[0.27em] hover:translate-x-2"
      >
        {ctaText}
      </Link>
    </div>
  </div>
);

export default OfferCard;