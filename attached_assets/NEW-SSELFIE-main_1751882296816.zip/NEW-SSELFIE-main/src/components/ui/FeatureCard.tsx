import React from "react";
import clsx from "clsx";

interface FeatureCardProps {
  title: string;
  description: string;
  icon?: React.ReactNode;
  imageSrc?: string;
  imageAlt?: string;
  className?: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({
  title,
  description,
  icon,
  imageSrc,
  imageAlt,
  className,
}) => (
  <div className={clsx("", className)}>
    {imageSrc ? (
      <div className={""}>
        <img src={imageSrc} alt={imageAlt || title} className={""} />
      </div>
    ) : icon ? (
      <div className={""}>{icon}</div>
    ) : null}
    <h3 className={""}>{title}</h3>
    <p className={""}>{description}</p>
  </div>
);

export default FeatureCard;