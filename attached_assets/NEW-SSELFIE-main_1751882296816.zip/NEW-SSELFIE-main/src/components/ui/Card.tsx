import React from "react";
import clsx from "clsx";

export interface CardProps {
  children: React.ReactNode;
  className?: string;
}

// Generic Card component for general use
export function Card({ children, className }: CardProps) {
  return (
    <div className={clsx("bg-white border border-gray-200 rounded-lg", className)}>
      {children}
    </div>
  );
}
