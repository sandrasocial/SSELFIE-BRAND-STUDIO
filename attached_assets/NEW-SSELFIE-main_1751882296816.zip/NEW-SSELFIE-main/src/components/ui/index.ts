/**
 * SSELFIE UI COMPONENTS INDEX
 * 
 * Export all luxury UI components for consistent imports
 * Design Reference: SSELFIE Ultimate Design Manual
 */

// Core UI Components
export { default as Button, type ButtonVariant } from './button'

// Card Components (separated by Diana for better organization)
// HeroCard archived - use HeroFullBleed from '@/components/sections/hero/HeroFullBleed' instead
export { MinimalCard, type MinimalCardProps } from './MinimalCard'
export { GenericCard, type GenericCardProps } from './generic-card'

export { default as Input } from './input'
export { default as TestimonialCard } from './TestimonialCard'
export { default as FeatureCard } from './FeatureCard'
export { SectionHeadline } from './SectionHeadline'
