import React from "react";
import clsx from "clsx";

interface Option {
  value: string;
  label: string;
}

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  error?: string;
  options: Option[];
  fullWidth?: boolean;
  className?: string;
}

const Select = React.forwardRef<HTMLSelectElement, SelectProps>(
  ({ label, error, options, fullWidth = false, className, ...props }, ref) => (
    <div className={clsx("", fullWidth && "", className)}>
      {label && <label className={""}>{label}</label>}
      <select ref={ref} className={""} {...props}>
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
      {error && <span className={""}>{error}</span>}
    </div>
  )
);

Select.displayName = "Select";

export default Select;