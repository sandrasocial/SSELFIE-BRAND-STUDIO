'use client'

import React, { useEffect, useState } from 'react'
import Link from 'next/link'
import { cn } from '@/lib/utils'

export interface UsageData {
  used: number
  total: number
  plan: 'monthly' | 'annual' | 'lifetime'
  resetDate?: Date
}

export interface UsageProgressBarProps {
  usage: UsageData
  variant?: 'widget' | 'minimal' | 'hero' | 'circular'
  showUpgradePrompt?: boolean
  darkMode?: boolean
  onUpgrade?: () => void
  onGenerate?: () => void
  className?: string
}

// Helper to calculate percentage and status
const getUsageStatus = (used: number, total: number) => {
  const percentage = (used / total) * 100
  const remaining = total - used
  
  let status: 'good' | 'medium' | 'low' = 'good'
  if (percentage >= 90) status = 'low'
  else if (percentage >= 70) status = 'medium'
  
  return { percentage, remaining, status }
}

// Helper to format reset date
const formatResetDate = (date?: Date) => {
  if (!date) return null
  const days = Math.ceil((date.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))
  return `Resets in ${days} days`
}

// Main component with all variants
export const UsageProgressBar: React.FC<UsageProgressBarProps> = ({
  usage,
  variant = 'widget',
  showUpgradePrompt = true,
  darkMode = false,
  onUpgrade,
  onGenerate,
  className
}) => {
  const { percentage, remaining, status } = getUsageStatus(usage.used, usage.total)
  const [animatedPercentage, setAnimatedPercentage] = useState(0)
  
  // Animate progress on mount and usage change
  useEffect(() => {
    const timer = setTimeout(() => {
      setAnimatedPercentage(percentage)
    }, 100)
    return () => clearTimeout(timer)
  }, [percentage])
  
  // Variant components
  switch (variant) {
    case 'minimal':
      return <MinimalVariant {...{ usage, percentage: animatedPercentage, status, darkMode, className }} />
    case 'hero':
      return <HeroVariant {...{ usage, percentage: animatedPercentage, remaining, status, darkMode, onUpgrade, className }} />
    case 'circular':
      return <CircularVariant {...{ usage, percentage: animatedPercentage, remaining, status, darkMode, onGenerate, className }} />
    default:
      return <WidgetVariant {...{ usage, percentage: animatedPercentage, remaining, status, showUpgradePrompt, darkMode, onUpgrade, className }} />
  }
}

// Widget Variant (Default)
const WidgetVariant: React.FC<{
  usage: UsageData
  percentage: number
  remaining: number
  status: 'good' | 'medium' | 'low'
  showUpgradePrompt: boolean
  darkMode: boolean
  onUpgrade?: () => void
  className?: string
}> = ({ usage, percentage, remaining, status, showUpgradePrompt, darkMode, onUpgrade, className }) => {
  const resetText = formatResetDate(usage.resetDate)
  
  return (
    <div className={cn(
      'p-10 border',
      darkMode ? 'bg-luxury-black text-pure-white border-soft-white/20' : 'bg-pure-white border-warm-gray/50',
      className
    )}>
      <div className="flex justify-between items-baseline mb-6">
        <h3 className="text-xs tracking-[0.2em] uppercase opacity-70">
          AI Generations
        </h3>
        <span className={cn(
          'font-serif text-[32px] font-light tracking-[-0.02em]',
          status === 'low' && 'text-red-500'
        )}>
          {usage.used}/{usage.total}
        </span>
      </div>
      
      <p className="text-sm opacity-60 mb-8">
        {remaining > 0 
          ? `You've used ${usage.used} of your ${usage.total} ${usage.plan} generations`
          : 'No generations remaining this period'
        }
      </p>
      
      <div className={cn(
        'relative h-[2px] overflow-hidden',
        darkMode ? 'bg-soft-white/20' : 'bg-soft-white'
      )}>
        <div
          className={cn(
            'absolute left-0 top-0 h-full transition-all duration-1000 ease-editorial',
            status === 'low' ? 'bg-red-500' : status === 'medium' ? 'bg-warm-gray' : darkMode ? 'bg-pure-white' : 'bg-luxury-black'
          )}
          style={{ width: `${percentage}%` }}
        />
      </div>
      
      <div className="flex justify-between mt-4 text-[11px] opacity-50">
        <span>0</span>
        <span>{Math.floor(usage.total / 2)}</span>
        <span>{usage.total}</span>
      </div>
      
      {resetText && (
        <p className="text-xs opacity-50 mt-4 text-center">
          {resetText} • {usage.plan.charAt(0).toUpperCase() + usage.plan.slice(1)} Plan
        </p>
      )}
      
      {showUpgradePrompt && status === 'low' && usage.plan !== 'lifetime' && (
        <div className={cn(
          'mt-6 p-6 flex items-center justify-between gap-6',
          darkMode ? 'bg-soft-white/10' : 'bg-red-50'
        )}>
          <div>
            <p className="font-medium text-sm">Running low?</p>
            <p className="text-sm opacity-70">
              {usage.plan === 'monthly' 
                ? 'Upgrade to annual for 100 generations/month'
                : 'Upgrade to lifetime for unlimited generations'
              }
            </p>
          </div>
          <button
            onClick={onUpgrade}
            className={cn(
              'px-8 py-3 text-xs tracking-[0.2em] uppercase transition-all',
              darkMode 
                ? 'bg-pure-white text-luxury-black hover:bg-soft-white' 
                : 'bg-luxury-black text-pure-white hover:translate-y-[-2px]'
            )}
          >
            Upgrade
          </button>
        </div>
      )}
    </div>
  )
}

// Minimal Variant
const MinimalVariant: React.FC<{
  usage: UsageData
  percentage: number
  status: 'good' | 'medium' | 'low'
  darkMode: boolean
  className?: string
}> = ({ usage, percentage, status, darkMode, className }) => {
  return (
    <div className={cn(
      'flex items-center gap-6 p-6',
      darkMode ? 'bg-luxury-black text-pure-white' : 'bg-soft-white',
      className
    )}>
      <div className={cn(
        'w-10 h-10 flex items-center justify-center',
        darkMode ? 'bg-pure-white text-luxury-black' : 'bg-luxury-black text-pure-white'
      )}>
        <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
          <path d="M10 2L2 7v6c0 4.418 3.582 8 8 8s8-3.582 8-8V7l-8-5z" opacity="0.3"/>
          <path d="M10 2v18c4.418 0 8-3.582 8-8V7l-8-5z"/>
        </svg>
      </div>
      
      <div className="flex-1">
        <p className="text-sm mb-2">
          {usage.used} of {usage.total} generations used
        </p>
        <div className={cn(
          'relative h-[1px] overflow-hidden',
          darkMode ? 'bg-soft-white/20' : 'bg-warm-gray'
        )}>
          <div
            className={cn(
              'absolute left-0 top-0 h-full transition-all duration-1000 ease-editorial',
              status === 'low' ? 'bg-red-500' : darkMode ? 'bg-pure-white' : 'bg-luxury-black'
            )}
            style={{ width: `${percentage}%` }}
          />
        </div>
      </div>
    </div>
  )
}

// Hero Variant
const HeroVariant: React.FC<{
  usage: UsageData
  percentage: number
  remaining: number
  status: 'good' | 'medium' | 'low'
  darkMode: boolean
  onUpgrade?: () => void
  className?: string
}> = ({ usage, percentage, remaining, status, darkMode, onUpgrade, className }) => {
  const resetText = formatResetDate(usage.resetDate)
  
  return (
    <div className={cn(
      'relative py-16 px-10 text-center overflow-hidden',
      darkMode ? 'bg-pure-white text-luxury-black' : 'bg-luxury-black text-pure-white',
      className
    )}>
      {/* Texture background */}
      <div 
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `url('https://i.postimg.cc/1tfNMJvk/file-16.png')`,
          backgroundSize: 'cover'
        }}
      />
      
      <div className="relative z-10">
        <div className={cn(
          'font-serif text-[96px] font-light tracking-[-0.04em] leading-[0.8] mb-4',
          status === 'low' && 'text-red-500'
        )}>
          {remaining}
        </div>
        
        <p className="text-lg opacity-80 mb-10">
          AI generations remaining this month
        </p>
        
        <div className="max-w-[600px] mx-auto">
          <div className={cn(
            'relative h-1 overflow-hidden',
            darkMode ? 'bg-luxury-black/20' : 'bg-pure-white/20'
          )}>
            <div
              className={cn(
                'absolute left-0 top-0 h-full transition-all duration-[1.5s] ease-editorial',
                darkMode ? 'bg-luxury-black' : 'bg-pure-white'
              )}
              style={{ width: `${percentage}%` }}
            />
          </div>
        </div>
        
        {resetText && (
          <p className="text-sm opacity-70 mt-10">
            {resetText} • {usage.plan.charAt(0).toUpperCase() + usage.plan.slice(1)} Plan
          </p>
        )}
        
        {status === 'low' && usage.plan !== 'lifetime' && (
          <button
            onClick={onUpgrade}
            className={cn(
              'mt-8 px-10 py-4 text-xs tracking-[0.3em] uppercase transition-all',
              darkMode 
                ? 'bg-luxury-black text-pure-white hover:bg-luxury-black/90' 
                : 'bg-pure-white text-luxury-black hover:bg-soft-white'
            )}
          >
            Upgrade for More
          </button>
        )}
      </div>
    </div>
  )
}

// Circular Variant
const CircularVariant: React.FC<{
  usage: UsageData
  percentage: number
  remaining: number
  status: 'good' | 'medium' | 'low'
  darkMode: boolean
  onGenerate?: () => void
  className?: string
}> = ({ usage, percentage, remaining, status, darkMode, onGenerate, className }) => {
  const rotation = -135 + (percentage * 2.7) // 270 degrees for full circle
  
  return (
    <div className={cn(
      'p-10 text-center',
      darkMode ? 'bg-luxury-black text-pure-white' : 'bg-pure-white',
      className
    )}>
      <div className="relative w-[200px] h-[200px] mx-auto mb-8">
        {/* Track */}
        <div className={cn(
          'absolute inset-0 border-2 rounded-full',
          darkMode ? 'border-soft-white/20' : 'border-soft-white'
        )} />
        
        {/* Fill */}
        <div
          className={cn(
            'absolute inset-0 border-2 rounded-full transition-transform duration-[1.5s] ease-editorial',
            status === 'low' ? 'border-red-500' : darkMode ? 'border-pure-white' : 'border-luxury-black'
          )}
          style={{
            borderTopColor: 'transparent',
            borderRightColor: 'transparent',
            transform: `rotate(${rotation}deg)`
          }}
        />
        
        {/* Center content */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <div className="font-serif text-5xl font-light">
            {usage.used}
          </div>
          <div className="text-xs opacity-60 mt-1">
            of {usage.total} used
          </div>
        </div>
      </div>
      
      <h3 className="font-serif text-[28px] font-light tracking-[-0.02em] mb-4">
        AI Generations
      </h3>
      
      <p className="opacity-70 mb-8">
        {remaining > 0 
          ? 'Perfect for creating your next viral selfie'
          : 'Time to upgrade for more generations'
        }
      </p>
      
      <button
        onClick={onGenerate}
        disabled={remaining === 0}
        className={cn(
          'px-10 py-4 text-xs tracking-[0.3em] uppercase transition-all',
          'disabled:opacity-50 disabled:cursor-not-allowed',
          darkMode 
            ? 'bg-pure-white text-luxury-black hover:bg-soft-white hover:translate-y-[-2px]' 
            : 'bg-luxury-black text-pure-white hover:bg-luxury-black/90 hover:translate-y-[-2px]'
        )}
      >
        {remaining > 0 ? 'Generate New Selfie' : 'Upgrade to Continue'}
      </button>
    </div>
  )
}

// Export individual variants for direct use
export { WidgetVariant, MinimalVariant, HeroVariant, CircularVariant }

// Preset configurations
export const UsageWidget = (props: Omit<UsageProgressBarProps, 'variant'>) => 
  <UsageProgressBar {...props} variant="widget" />

export const UsageMinimal = (props: Omit<UsageProgressBarProps, 'variant'>) => 
  <UsageProgressBar {...props} variant="minimal" />

export const UsageHero = (props: Omit<UsageProgressBarProps, 'variant'>) => 
  <UsageProgressBar {...props} variant="hero" />

export const UsageCircular = (props: Omit<UsageProgressBarProps, 'variant'>) => 
  <UsageProgressBar {...props} variant="circular" />