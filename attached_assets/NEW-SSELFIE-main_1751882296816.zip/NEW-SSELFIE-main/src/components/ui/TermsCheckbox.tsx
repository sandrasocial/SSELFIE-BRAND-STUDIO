import React from "react";
import Checkbox from "./Checkbox";

interface TermsCheckboxProps extends React.InputHTMLAttributes<HTMLInputElement> {
  termsLink?: string;
  privacyLink?: string;
  error?: string;
  required?: boolean;
}

const TermsCheckbox: React.FC<TermsCheckboxProps> = ({
  termsLink = "/terms",
  privacyLink = "/privacy",
  error,
  required = true,
  ...props
}) => (
  <Checkbox
    error={error}
    required={required}
    {...props}
    label={
      <span>
        I agree to Sandra’s{" "}
        <a
          href={termsLink}
          target="_blank"
          rel="noopener noreferrer"
          style={{ textDecoration: "underline", color: "#151515" }}
          onClick={e => e.stopPropagation()}
        >
          Terms of Service
        </a>
        {" "}and{" "}
        <a
          href={privacyLink}
          target="_blank"
          rel="noopener noreferrer"
          style={{ textDecoration: "underline", color: "#151515" }}
          onClick={e => e.stopPropagation()}
        >
          Privacy Policy
        </a>
        {"."}
      </span>
    }
  />
);

export default TermsCheckbox;