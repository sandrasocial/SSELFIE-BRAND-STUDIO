import React from "react";
import clsx from "clsx";

interface RadioProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  description?: string;
  error?: string;
  fullWidth?: boolean;
  className?: string;
}

const Radio = React.forwardRef<HTMLInputElement, RadioProps>(
  (
    { label, description, error, fullWidth = false, className, ...props },
    ref
  ) => (
    <div className={clsx("", fullWidth && "", className)}>
      <label className={""}>
        <input
          ref={ref}
          type="radio"
          className={""}
          {...props}
        />
        <span className={""} aria-hidden="true" />
        <span className={""}>
          {label && <span className={""}>{label}</span>}
          {description && <span className={""}>{description}</span>}
        </span>
      </label>
      {error && <span className={""}>{error}</span>}
    </div>
  )
);

Radio.displayName = "Radio";

export default Radio;