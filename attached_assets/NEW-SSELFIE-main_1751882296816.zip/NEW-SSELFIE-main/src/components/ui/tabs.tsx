"use client";

import React, { useState, ReactNode } from "react";
import clsx from "clsx";

export interface Tab {
  label: string;
  content: ReactNode;
  disabled?: boolean;
}

interface TabsProps {
  tabs: Tab[];
  className?: string;
  initialIndex?: number;
}

const Tabs: React.FC<TabsProps> = ({ tabs, className, initialIndex = 0 }) => {
  const [active, setActive] = useState(initialIndex);

  return (
    <div className={clsx("", className)}>
      <div className={""} role="tablist">
        {tabs.map((tab, idx) => (
          <button
            key={tab.label}
            className={clsx("", active === idx && "", tab.disabled && "")}
            onClick={() => !tab.disabled && setActive(idx)}
            role="tab"
            aria-selected={active === idx}
            aria-disabled={tab.disabled}
            tabIndex={tab.disabled ? -1 : 0}
            type="button"
          >
            {tab.label}
          </button>
        ))}
      </div>
      <div className={""} role="tabpanel">
        {tabs[active]?.content}
      </div>
    </div>
  );
};

export default Tabs;