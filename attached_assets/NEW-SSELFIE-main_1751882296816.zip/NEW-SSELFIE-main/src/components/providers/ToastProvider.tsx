'use client'

import { Toaster } from 'react-hot-toast'

export function ToastProvider() {
  return (
    <Toaster
      position="bottom-center"
      toastOptions={{
        duration: 4000,
        style: {
          background: '#171719',
          color: '#F1F1F1',
          border: '1px solid rgba(181, 181, 179, 0.2)',
          borderRadius: '4px', // tiny radius for mobile polish
          padding: '20px 32px',
          fontSize: '15px',
          letterSpacing: '0.05em',
          fontWeight: '300',
          maxWidth: '500px',
          fontFamily: "'Inter', 'Bodoni Moda', serif, sans-serif",
          boxShadow: '0 4px 24px 0 rgba(23, 23, 25, 0.14)',
        },
        success: {
          iconTheme: {
            primary: '#F1F1F1',
            secondary: '#171719',
          },
          style: {
            background: '#171719',
            color: '#F1F1F1',
            border: '1px solid rgba(181, 181, 179, 0.2)',
          },
        },
        error: {
          iconTheme: {
            primary: '#F1F1F1',
            secondary: '#171719',
          },
          style: {
            background: '#171719',
            color: '#F1F1F1',
            border: '1px solid rgba(241, 241, 241, 0.3)',
          },
        },
        loading: {
          style: {
            background: '#171719',
            color: '#F1F1F1',
            border: '1px solid rgba(181, 181, 179, 0.2)',
          },
        },
      }}
    />
  )
}