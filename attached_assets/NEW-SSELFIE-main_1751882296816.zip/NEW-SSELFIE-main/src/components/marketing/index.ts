// Marketing Components

export { OnboardingSteps } from './OnboardingSteps'
export type { OnboardingStep, OnboardingStepsProps } from './OnboardingSteps'

export { FreebiePreview } from './FreebiePreview'
export type { FreebieItem, FreebiePreviewProps } from './FreebiePreview'