'use client'

import React from 'react'
import { cn } from '@/lib/utils'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Check, Lock } from 'lucide-react'

// Types
export interface OnboardingStep {
  id: string
  number: number
  title: string
  description: string
  status: 'completed' | 'current' | 'upcoming' | 'locked'
  icon?: React.ReactNode
  actionLabel?: string
  estimatedTime?: string
  sandraTip?: string // NEW: Personal, encouraging tip for this step
}

export interface OnboardingStepsProps {
  steps: OnboardingStep[]
  currentStep?: number
  showProgress?: boolean
  variant?: 'vertical' | 'horizontal' | 'minimal'
  darkMode?: boolean
  className?: string
  onStepClick?: (stepId: string) => void
  sandraIntro?: string // NEW: Optional warm intro line
}

// Progress indicator component
function ProgressIndicator({
  totalSteps,
  completedSteps,
  darkMode = false
}: {
  totalSteps: number
  completedSteps: number
  darkMode?: boolean
}) {
  const percentage = (completedSteps / totalSteps) * 100

  return (
    <div className="mb-8">
      <div className="flex justify-between items-center mb-3">
        <p className={cn(
          'text-sm font-medium',
          darkMode && 'text-pure-white'
        )}>
          Your Progress
        </p>
        <p className={cn(
          'text-sm',
          darkMode ? 'text-soft-white' : 'text-warm-gray'
        )}>
          {completedSteps} of {totalSteps} steps completed
        </p>
      </div>
      <div className={cn(
        'h-2 rounded-full overflow-hidden',
        darkMode ? 'bg-soft-white/20' : 'bg-warm-gray/20'
      )}>
        <div
          className={cn(
            'h-full transition-all duration-600 ease-luxury',
            darkMode ? 'bg-pure-white' : 'bg-luxury-black'
          )}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  )
}

// Vertical layout component
function VerticalSteps({
  steps,
  darkMode = false,
  onStepClick
}: {
  steps: OnboardingStep[]
  darkMode?: boolean
  onStepClick?: (stepId: string) => void
}) {
  return (
    <div className="space-y-4">
      {steps.map((step, index) => {
        const isLast = index === steps.length - 1
        const isClickable = step.status === 'completed' || step.status === 'current'

        return (
          <div key={step.id} className="relative">
            {/* Connector line */}
            {!isLast && (
              <div
                className={cn(
                  'absolute left-6 top-12 w-0.5 h-full -bottom-4',
                  step.status === 'completed'
                    ? darkMode ? 'bg-pure-white' : 'bg-luxury-black'
                    : darkMode ? 'bg-soft-white/30' : 'bg-warm-gray/30'
                )}
              />
            )}

            {/* Step content */}
            <div
              className={cn(
                'flex gap-6 p-6 rounded-none transition-all',
                isClickable && 'cursor-pointer hover:translate-x-2',
                step.status === 'current' && (
                  darkMode 
                    ? 'bg-soft-white/10 border border-soft-white/30' 
                    : 'bg-warm-gray/10 border border-warm-gray/30'
                )
              )}
              onClick={() => isClickable && onStepClick?.(step.id)}
              aria-current={step.status === 'current' ? 'step' : undefined}
            >
              {/* Step indicator */}
              <div className="flex-shrink-0">
                <div className={cn(
                  'w-12 h-12 rounded-full flex items-center justify-center transition-all',
                  step.status === 'completed' 
                    ? darkMode 
                      ? 'bg-pure-white text-luxury-black' 
                      : 'bg-luxury-black text-pure-white'
                    : step.status === 'current'
                      ? darkMode
                        ? 'bg-luxury-black border-2 border-pure-white text-pure-white'
                        : 'bg-pure-white border-2 border-luxury-black text-luxury-black'
                      : darkMode
                        ? 'bg-soft-white/20 text-soft-white/50'
                        : 'bg-warm-gray/20 text-warm-gray/50'
                )}
                aria-label={
                  step.status === 'completed'
                    ? `Step ${step.number} completed`
                    : step.status === 'locked'
                      ? `Step ${step.number} locked`
                      : `Step ${step.number}`
                }
                >
                  {step.status === 'completed' ? (
                    <Check className="w-5 h-5" aria-hidden="true" />
                  ) : step.status === 'locked' ? (
                    <Lock className="w-4 h-4" aria-hidden="true" />
                  ) : (
                    <span className="font-bodoni text-lg">{step.number}</span>
                  )}
                </div>
              </div>

              {/* Step details */}
              <div className="flex-1">
                <div className="flex items-start justify-between mb-2">
                  <h3 className={cn(
                    'font-bodoni text-xl font-light',
                    darkMode && 'text-pure-white',
                    step.status === 'upcoming' || step.status === 'locked' 
                      ? 'opacity-50' : ''
                  )}>
                    {step.title}
                  </h3>
                  {step.status === 'completed' && (
                    <Badge 
                      variant={darkMode ? 'outline' : 'solid'}
                      className="text-xs"
                    >
                      Completed
                    </Badge>
                  )}
                  {step.status === 'current' && (
                    <Badge 
                      variant="solid"
                      className="text-xs"
                    >
                      Current
                    </Badge>
                  )}
                </div>
                
                <p className={cn(
                  'text-sm mb-3',
                  darkMode ? 'text-soft-white' : 'text-warm-gray',
                  step.status === 'upcoming' || step.status === 'locked' 
                    ? 'opacity-50' : ''
                )}>
                  {step.description}
                </p>

                {step.estimatedTime && step.status !== 'completed' && (
                  <p className={cn(
                    'text-xs',
                    darkMode ? 'text-soft-white/60' : 'text-warm-gray/60'
                  )}>
                    Estimated time: {step.estimatedTime}
                  </p>
                )}

                {/* Sandra's Tip */}
                {step.sandraTip && (
                  <div className={cn(
                    'mt-2 italic text-xs',
                    darkMode ? 'text-soft-white/80' : 'text-warm-gray/70'
                  )}>
                    {step.sandraTip}
                  </div>
                )}

                {step.status === 'current' && step.actionLabel && (
                  <Button
                    variant="primary"
                    size="sm"
                    className="mt-4"
                    onClick={(e) => {
                      e.stopPropagation()
                      onStepClick?.(step.id)
                    }}
                  >
                    {step.actionLabel}
                  </Button>
                )}
              </div>
            </div>
          </div>
        )
      })}
    </div>
  )
}

// Horizontal layout component
function HorizontalSteps({
  steps,
  darkMode = false,
  onStepClick
}: {
  steps: OnboardingStep[]
  darkMode?: boolean
  onStepClick?: (stepId: string) => void
}) {
  return (
    <div className="relative">
      {/* Progress line */}
      <div className="absolute top-6 left-0 right-0 h-0.5 bg-warm-gray/20">
        <div 
          className={cn(
            'h-full transition-all duration-600',
            darkMode ? 'bg-pure-white' : 'bg-luxury-black'
          )}
          style={{
            width: `${(steps.filter(s => s.status === 'completed').length / steps.length) * 100}%`
          }}
        />
      </div>

      {/* Steps */}
      <div className="relative grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {steps.map((step) => {
          const isClickable = step.status === 'completed' || step.status === 'current'

          return (
            <div
              key={step.id}
              className={cn(
                'text-center',
                isClickable && 'cursor-pointer'
              )}
              onClick={() => isClickable && onStepClick?.(step.id)}
              aria-current={step.status === 'current' ? 'step' : undefined}
            >
              {/* Step indicator */}
              <div className="flex justify-center mb-4">
                <div className={cn(
                  'w-12 h-12 rounded-full flex items-center justify-center transition-all',
                  isClickable && 'hover:scale-110',
                  step.status === 'completed' 
                    ? darkMode 
                      ? 'bg-pure-white text-luxury-black' 
                      : 'bg-luxury-black text-pure-white'
                    : step.status === 'current'
                      ? darkMode
                        ? 'bg-luxury-black border-2 border-pure-white text-pure-white'
                        : 'bg-pure-white border-2 border-luxury-black text-luxury-black'
                      : darkMode
                        ? 'bg-soft-white/20 text-soft-white/50'
                        : 'bg-warm-gray/20 text-warm-gray/50'
                )}
                aria-label={
                  step.status === 'completed'
                    ? `Step ${step.number} completed`
                    : step.status === 'locked'
                      ? `Step ${step.number} locked`
                      : `Step ${step.number}`
                }
                >
                  {step.status === 'completed' ? (
                    <Check className="w-5 h-5" aria-hidden="true" />
                  ) : step.status === 'locked' ? (
                    <Lock className="w-4 h-4" aria-hidden="true" />
                  ) : (
                    <span className="font-bodoni text-lg">{step.number}</span>
                  )}
                </div>
              </div>

              {/* Step title */}
              <h3 className={cn(
                'font-medium text-sm mb-1',
                darkMode && 'text-pure-white',
                step.status === 'upcoming' || step.status === 'locked' 
                  ? 'opacity-50' : ''
              )}>
                {step.title}
              </h3>

              {/* Estimated time */}
              {step.estimatedTime && step.status !== 'completed' && (
                <p className={cn(
                  'text-xs',
                  darkMode ? 'text-soft-white/60' : 'text-warm-gray/60'
                )}>
                  {step.estimatedTime}
                </p>
              )}

              {/* Sandra's Tip */}
              {step.sandraTip && (
                <div className={cn(
                  'mt-1 italic text-xs',
                  darkMode ? 'text-soft-white/80' : 'text-warm-gray/70'
                )}>
                  {step.sandraTip}
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}

// Minimal layout component
function MinimalSteps({
  steps,
  darkMode = false,
  onStepClick
}: {
  steps: OnboardingStep[]
  darkMode?: boolean
  onStepClick?: (stepId: string) => void
}) {
  const currentStepIndex = steps.findIndex(s => s.status === 'current')
  const currentStep = steps[currentStepIndex]

  if (!currentStep) return null

  return (
    <div className={cn(
      'p-6 border rounded-none',
      darkMode 
        ? 'bg-luxury-black border-soft-white/20' 
        : 'bg-pure-white border-warm-gray/50'
    )}>
      <div className="flex items-center justify-between mb-4">
        <div>
          <p className={cn(
            'text-xs uppercase tracking-[0.2em] mb-1',
            darkMode ? 'text-soft-white' : 'text-warm-gray'
          )}>
            Step {currentStep.number} of {steps.length}
          </p>
          <h3 className={cn(
            'font-bodoni text-2xl font-light',
            darkMode && 'text-pure-white'
          )}>
            {currentStep.title}
          </h3>
        </div>
        {currentStep.actionLabel && (
          <Button
            variant="primary"
            size="sm"
            onClick={() => onStepClick?.(currentStep.id)}
          >
            {currentStep.actionLabel}
          </Button>
        )}
      </div>

      {/* Progress dots */}
      <div className="flex gap-2 mb-2">
        {steps.map((step, index) => (
          <div
            key={step.id}
            className={cn(
              'h-1 flex-1 rounded-full transition-all',
              index <= currentStepIndex
                ? darkMode ? 'bg-pure-white' : 'bg-luxury-black'
                : darkMode ? 'bg-soft-white/20' : 'bg-warm-gray/20'
            )}
          />
        ))}
      </div>
      {/* Sandra's Tip */}
      {currentStep.sandraTip && (
        <div className={cn(
          'mt-3 italic text-xs',
          darkMode ? 'text-soft-white/80' : 'text-warm-gray/70'
        )}>
          {currentStep.sandraTip}
        </div>
      )}
    </div>
  )
}

// Main component
export function OnboardingSteps({
  steps,
  showProgress = true,
  variant = 'vertical',
  darkMode = false,
  className,
  onStepClick,
  sandraIntro // NEW: Optional intro message
}: OnboardingStepsProps) {
  // Calculate completed steps
  const completedSteps = steps.filter(s => s.status === 'completed').length

  return (
    <div className={className}>
      {/* Sandra-style intro */}
      {variant !== 'minimal' && (
        <div className={cn(
          'mb-6 text-lg font-bodoni italic tracking-tight',
          darkMode ? 'text-soft-white' : 'text-luxury-black'
        )}>
          {sandraIntro || (
            <>You’re not behind, you’re just getting started. One step at a time—let’s go.</>
          )}
        </div>
      )}

      {/* Progress indicator */}
      {showProgress && variant !== 'minimal' && (
        <ProgressIndicator
          totalSteps={steps.length}
          completedSteps={completedSteps}
          darkMode={darkMode}
        />
      )}

      {/* Steps layout */}
      {variant === 'vertical' && (
        <VerticalSteps
          steps={steps}
          darkMode={darkMode}
          onStepClick={onStepClick}
        />
      )}

      {variant === 'horizontal' && (
        <HorizontalSteps
          steps={steps}
          darkMode={darkMode}
          onStepClick={onStepClick}
        />
      )}

      {variant === 'minimal' && (
        <MinimalSteps
          steps={steps}
          darkMode={darkMode}
          onStepClick={onStepClick}
        />
      )}
    </div>
  )
}

export default OnboardingSteps