// CENTRALIZED MOCK DATA FOR SSELFIE STUDIO COMPONENTS
// All data written in Sandra's voice - confident, direct, no fluff

/**
 * MOCK DATA FOR SSELFIE STUDIO DESIGN PHASE
 * 
 * This file contains realistic mock data for all components during the design phase.
 * All components should import from this file to ensure consistency.
 * 
 * Week 1: Design with mock data
 * Week 2: Replace with real API calls
 * Week 3: Full database integration
 */

// User Profile Mock Data
export const MOCK_USER = {
  id: "user_123",
  name: "Sarah Mitchell",
  email: "sarah@sarahmitchellbrand.com",
  avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400&h=400&fit=crop&crop=face",
  joined: "2024-01-15",
  timezone: "America/New_York",
  memberSince: "January 15, 2024",
  tier: "Annual VIP",
  bio: "Building my empire one selfie at a time. Started over at 39 with three kids and zero followers. Now I teach women how to stop hiding and start building.",
  industry: "Business Coaching",
  location: "Austin, TX",
  website: "sarahmitchellbrand.com",
  instagram: "@sarahmitchellbrand",
  isOnline: true,
  lastActive: "2024-06-26T10:30:00Z"
}

// Subscription Mock Data
export const MOCK_SUBSCRIPTION = {
  id: "sub_123",
  plan: "annual", // monthly | annual | lifetime
  planName: "Annual VIP",
  status: "active", // active | canceled | past_due | incomplete
  amount: 297,
  currency: "USD",
  interval: "year",
  nextBilling: "2025-01-15",
  currentPeriodStart: "2024-01-15",
  currentPeriodEnd: "2025-01-15",
  cancelAtPeriodEnd: false,
  trialEnd: null,
  billingHistory: [
    { 
      id: "inv_001",
      date: "2024-01-15", 
      amount: 297, 
      status: "paid",
      description: "Annual VIP - SSELFIE Studio Access",
      downloadUrl: "/invoices/inv_001.pdf"
    },
    { 
      id: "inv_002",
      date: "2023-01-15", 
      amount: 297, 
      status: "paid",
      description: "Annual VIP - SSELFIE Studio Access",
      downloadUrl: "/invoices/inv_002.pdf"
    }
  ],
  paymentMethod: {
    type: "card",
    brand: "visa",
    last4: "4242",
    expiryMonth: 12,
    expiryYear: 2026,
    country: "US"
  }
}

// Usage Tracking Mock Data
export const MOCK_USAGE = {
  currentMonth: "2024-06",
  aiGenerations: {
    used: 45,
    limit: 75, // Based on Annual VIP tier
    resetDate: "2024-07-01",
    percentage: 60,
    trending: "stable" // increasing | decreasing | stable
  },
  features: {
    poseCoach: { 
      used: 15, 
      unlimited: true,
      lastUsed: "2024-06-25T14:30:00Z"
    },
    glowCheck: { 
      used: 8, 
      unlimited: true,
      lastUsed: "2024-06-24T09:15:00Z"
    },
    communityAccess: true,
    monthlyTemplates: { 
      downloaded: 3, 
      available: 5,
      newThisMonth: 2
    }
  },
  monthlyTrend: [
    { month: "2024-01", used: 32 },
    { month: "2024-02", used: 28 },
    { month: "2024-03", used: 41 },
    { month: "2024-04", used: 38 },
    { month: "2024-05", used: 52 },
    { month: "2024-06", used: 45 }
  ]
}

// Training Progress Mock Data - Based on actual SSELFIE EDITING video lessons
export const MOCK_TRAINING = {
  totalModules: 6,
  completedModules: 2,
  progressPercentage: 33,
  currentModule: 3,
  nextLesson: "Smart Edits With Apps",
  timeInvested: "2.5 hours",
  estimatedCompletion: "4 hours remaining",
  modules: [
    { 
      id: 1, 
      title: "Start Here - Your Brand, Your Power", 
      subtitle: "Welcome, gorgeous. You're not here to play small anymore.",
      completed: true, 
      completedAt: "2024-06-15T16:45:00Z",
      duration: "8 min",
      lessons: 1,
      description: "The mindset shift that changes everything. This isn't just about selfies - it's about seeing yourself as the CEO you are."
    },
    { 
      id: 2, 
      title: "Selfie Editing - Edit Like a Pro", 
      subtitle: "Even on iPhone. Especially on iPhone.",
      completed: true, 
      completedAt: "2024-06-20T11:30:00Z",
      duration: "20 min",
      lessons: 2,
      description: "Learn my exact editing flow. The one that took me from bathroom selfies to 120K followers."
    },
    { 
      id: 3, 
      title: "Smart Edits With Apps", 
      subtitle: "Add mood without losing the real you",
      completed: false,
      progress: 40,
      duration: "25 min",
      lessons: 2,
      description: "Hypic for that editorial edge. CapCut for luxe video. I'll show you exactly how."
    },
    { 
      id: 4, 
      title: "Hands-Free Like a CEO", 
      subtitle: "Because you've got better things to do than hold your phone",
      completed: false,
      progress: 0,
      duration: "8 min",
      lessons: 1,
      description: "Voice control, gesture commands, and my secret timer tricks. Shoot solo, stay in flow."
    },
    { 
      id: 5, 
      title: "Brand Aesthetic Builder", 
      subtitle: "Design Like a CEO™",
      completed: false,
      progress: 0,
      duration: "15 min",
      lessons: 1,
      description: "Stop copying everyone else. Build YOUR signature look that makes people stop scrolling."
    },
    { 
      id: 6, 
      title: "Content Strategy Accelerator", 
      subtitle: "Because great content needs a plan",
      completed: false,
      progress: 0,
      duration: "12 min",
      lessons: 1,
      description: "My exact content calendar, batch shooting secrets, and how to never run out of ideas."
    }
  ],
  achievements: [
    {
      id: "first_generation",
      title: "First SSELFIE Created",
      description: "You did it. You showed up. That's the hardest part.",
      unlockedAt: "2024-06-16T12:00:00Z",
      icon: "sparkles"
    },
    {
      id: "week_streak",
      title: "7-Day Streak",
      description: "Consistency is your new superpower. Keep going.",
      unlockedAt: "2024-06-22T09:00:00Z",
      icon: "fire"
    }
  ]
}

// AI Generation History Mock Data
export const MOCK_GENERATIONS = {
  totalGenerated: 186,
  recentGenerations: [
    {
      id: "gen_001",
      createdAt: "2024-06-26T10:15:00Z",
      style: "Professional Headshot",
      prompt: "Confident business woman, natural lighting, warm smile",
      imageUrl: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop",
      rating: 5,
      inGallery: true
    },
    {
      id: "gen_002", 
      createdAt: "2024-06-25T16:30:00Z",
      style: "LinkedIn Portrait",
      prompt: "Executive presence, soft background blur, approachable",
      imageUrl: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&h=400&fit=crop",
      rating: 4,
      inGallery: true
    },
    {
      id: "gen_003",
      createdAt: "2024-06-24T11:45:00Z",
      style: "Brand Photoshoot",
      prompt: "Creative entrepreneur, bold colors, confident pose",
      imageUrl: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&h=400&fit=crop",
      rating: 5,
      inGallery: false
    }
  ],
  favoriteStyles: [
    "Professional Headshot",
    "LinkedIn Portrait", 
    "Brand Photoshoot"
  ],
  stylesUsed: {
    "Professional Headshot": 42,
    "LinkedIn Portrait": 38,
    "Brand Photoshoot": 35,
    "Lifestyle Portrait": 28,
    "Executive Portrait": 23,
    "Creative Headshot": 20
  }
}

// Community Mock Data
export const MOCK_COMMUNITY = {
  totalMembers: 847,
  onlineNow: 42,
  weeklyActive: 623,
  welcomeMessage: "Welcome to SSELFIE Studio, queen. You just joined 847 women who are done playing small.",
  memberHighlights: [
    {
      id: "highlight_001",
      member: {
        name: "Jessica Chen",
        avatar: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop&crop=face",
        tier: "Lifetime Legacy"
      },
      achievement: "Just booked 5 new clients from the content she created this week",
      celebration: "That glow up though. See what happens when you stop hiding?",
      timestamp: "2024-06-25T18:30:00Z",
      image: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=300&h=400&fit=crop"
    },
    {
      id: "highlight_002",
      member: {
        name: "Maria Rodriguez",
        avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face",
        tier: "Annual VIP"
      },
      achievement: "Landed her dream client after posting consistently for 30 days",
      celebration: "THIS is what I'm talking about. The world was waiting for this version of you.",
      timestamp: "2024-06-24T15:20:00Z",
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=300&h=400&fit=crop"
    }
  ]
}

// Pricing Tiers Mock Data - SSELFIE STUDIO official pricing
export const MOCK_PRICING_TIERS = [
  {
    id: "monthly",
    name: "Monthly",
    tagline: "For the girl who's testing the waters",
    price: 47,
    originalPrice: null,
    currency: "USD",
    interval: "month" as const,
    generationLimit: 50,
    popular: false,
    savings: null,
    features: [
      "AI SSELFIE Generator (50 generations/month)",
      "Pose Coach Tool - unlimited use", 
      "Glow Check Analysis - unlimited use",
      "SSELFIE Editing Training (6 video lessons)",
      "Custom Presets Collection",
      "Monthly Content Templates",
      "Private Community Access",
      "Email Support"
    ],
    cta: "Start here",
    subtext: "Literally the price of one dinner out"
  },
  {
    id: "annual",
    name: "Annual VIP",
    tagline: "For my girls who commit",
    price: 297,
    originalPrice: 564, // 47 * 12
    currency: "USD", 
    interval: "year" as const,
    generationLimit: 75,
    popular: true,
    savings: 267, // Save $267
    savingsPercentage: 47,
    features: [
      "Everything in Monthly PLUS:",
      "75 AI generations per month",
      "Priority Support (24hr response)",
      "Quarterly Group Coaching Calls",
      "Early Access to New Features",
      "Commercial Use License",
      "Advanced Editing Techniques",
      "Bonus: Social Media Templates Pack"
    ],
    cta: "Best value",
    subtext: "Save $267 - that's 2 months free"
  },
  {
    id: "lifetime",
    name: "Lifetime Legacy",
    tagline: "For the queens who know",
    price: 497,
    originalPrice: null,
    currency: "USD",
    interval: "lifetime" as const,
    generationLimit: 100,
    popular: false,
    savings: null,
    features: [
      "Everything in Annual VIP PLUS:",
      "100 AI generations per month - forever",
      "Never pay again (seriously, never)",
      "VIP Concierge Support",
      "Monthly Mastermind Access",
      "Beta Features Testing",
      "Annual Conference Ticket",
      "Personal Brand Audit (1x)",
      "Custom Preset Creation"
    ],
    cta: "Join us",
    subtext: "Limited spots - once they're gone, they're gone"
  }
]

// Social Proof Mock Data - Real testimonials from SSELFIE customers
export const MOCK_TESTIMONIALS = [
  {
    id: "testimonial_001",
    name: "Instagram User",
    role: "SSELFIE Customer",
    avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face",
    rating: 5,
    text: "Love it. You have literally changed my picture taking from boring selfies to professional pictures. Thank you.",
    result: "Professional selfies",
    imageUrl: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=300&h=400&fit=crop",
    featured: false
  },
  {
    id: "testimonial_002",
    name: "Flourish N Flow With Roxanne",
    role: "Content Creator",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face",
    rating: 5,
    text: "You're helping me so much to develop my 'just do it' attitude. Thank You.",
    result: "Confidence boost",
    imageUrl: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=300&h=400&fit=crop",
    featured: false
  },
  {
    id: "testimonial_003",
    name: "Judith Witzemann",
    role: "Business Owner",
    avatar: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop&crop=face",
    rating: 5,
    text: "Love it. So motivating. That's what I needed.",
    result: "Motivation found",
    imageUrl: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=300&h=400&fit=crop",
    featured: false
  },
  {
    id: "testimonial_004",
    name: "Olha Horbenko Namik",
    role: "Entrepreneur",
    avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=100&h=100&fit=crop&crop=face",
    rating: 5,
    text: "Thank you for sharing your knowledge and being so true. I feel so motivated to start taking pictures of myself. I heard the words that I've always wanted to say but never expressed before. Today, I posted three stories talking about my journey in a raw and authentic way. I'm pursuing my dream. Thank you so much.",
    result: "Authentic transformation",
    imageUrl: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=300&h=400&fit=crop",
    featured: true
  }
]

// Freebie Mock Data - The SSELFIE Guide lead magnet
export const MOCK_FREEBIE = {
  title: "The SSELFIE Guide",
  subtitle: "Your phone has a better camera than most photographers had 10 years ago. You just need to know how to use it.",
  tagline: "Pose till you glow",
  totalValue: 297,
  downloadCount: 12847,
  socialProof: "Join 12,847 women who stopped hiding from cameras",
  contents: [
    {
      chapter: "ONE",
      title: "Keep pushing boundaries & never stop evolving",
      description: "The mindset shift that changes everything"
    },
    {
      chapter: "TWO", 
      title: "The Art of Light",
      description: "Light can make or break your selfie. Master it, and you'll never take a bad photo again."
    },
    {
      chapter: "THREE",
      title: "Angles & Presence",
      description: "Your best angle is the one where you feel most confident. Let's find it together."
    },
    {
      chapter: "FOUR",
      title: "Editorial Editing", 
      description: "Enhance, don't hide. Your natural beauty deserves to shine through."
    },
    {
      chapter: "FIVE",
      title: "Confidence & Power",
      description: "The best accessory you can wear? Confidence. Let's build yours."
    },
    {
      chapter: "SIX",
      title: "Social Strategy",
      description: "Great selfies deserve to be seen. Let's make sure yours get noticed."
    }
  ],
  cta: {
    primary: "Get The Free Guide",
    secondary: "Ready for more? Join SSELFIE Studio",
    disclaimer: "This guide is just the beginning. When you're ready, I'll show you how to build your empire one selfie at a time inside SSELFIE Studio."
  }
}

// Onboarding Steps Mock Data
export const MOCK_ONBOARDING_STEPS = [
  {
    id: "welcome",
    title: "Welcome to SSELFIE Studio",
    description: "Let's get you set up real quick",
    completed: true,
    icon: "sparkles"
  },
  {
    id: "profile",
    title: "Tell me about you", 
    description: "Just the basics - your brand, your goals, where you're stuck",
    completed: true,
    icon: "user"
  },
  {
    id: "first_generation",
    title: "Create Your First SSELFIE",
    description: "Time to play. I'll walk you through it",
    completed: false,
    icon: "camera"
  },
  {
    id: "training",
    title: "Watch the 8-minute game changer",
    description: "Your Brand, Your Power - trust me, watch this first",
    completed: false,
    icon: "play"
  },
  {
    id: "community",
    title: "Meet your new best friends",
    description: "847 queens building empires together. Come say hi",
    completed: false,
    icon: "users"
  }
]

// Billing History Mock Data
export const MOCK_BILLING_HISTORY = [
  {
    id: "inv_2024_001",
    date: "2024-01-15",
    description: "Annual VIP - SSELFIE Studio",
    amount: 297,
    status: "paid",
    paymentMethod: "•••• 4242",
    downloadUrl: "/invoices/2024/inv_001.pdf"
  },
  {
    id: "inv_2023_012", 
    date: "2023-12-15",
    description: "Monthly - SSELFIE Studio",
    amount: 47,
    status: "paid",
    paymentMethod: "•••• 4242",
    downloadUrl: "/invoices/2023/inv_012.pdf"
  },
  {
    id: "inv_2023_011",
    date: "2023-11-15", 
    description: "Monthly - SSELFIE Studio",
    amount: 47,
    status: "paid",
    paymentMethod: "•••• 4242",
    downloadUrl: "/invoices/2023/inv_011.pdf"
  }
]

// Export all mock data
export const MOCK_DATA = {
  user: MOCK_USER,
  subscription: MOCK_SUBSCRIPTION,
  usage: MOCK_USAGE,
  training: MOCK_TRAINING,
  generations: MOCK_GENERATIONS,
  community: MOCK_COMMUNITY,
  pricingTiers: MOCK_PRICING_TIERS,
  testimonials: MOCK_TESTIMONIALS,
  freebie: MOCK_FREEBIE,
  onboarding: MOCK_ONBOARDING_STEPS,
  billing: MOCK_BILLING_HISTORY
}