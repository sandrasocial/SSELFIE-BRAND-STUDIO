'use client'

import React, { useState } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { cn } from '@/lib/utils'

export interface LoginFormProps {
  onSubmit?: (data: { email: string; password: string; rememberMe: boolean }) => Promise<void>
  onSocialLogin?: (provider: 'google' | 'facebook') => Promise<void>
  redirectUrl?: string
  className?: string
}

export const LoginForm: React.FC<LoginFormProps> = ({
  onSubmit,
  onSocialLogin,
  redirectUrl = '/studio',
  className
}) => {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    rememberMe: false
  })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setIsLoading(true)
    
    try {
      if (onSubmit) {
        await onSubmit(formData)
      } else {
        // Default behavior - simulate API call
        await new Promise(resolve => setTimeout(resolve, 2000))
      }
      
      // Redirect on success
      window.location.href = redirectUrl
      
    } catch (err: any) {
      setError(err.message || "That doesn't look right. Try again?")
    } finally {
      setIsLoading(false)
    }
  }
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }))
    setError('') // Clear error on input change
  }
  
  const handleSocialLogin = async (provider: 'google' | 'facebook') => {
    setError('')
    setIsLoading(true)
    
    try {
      if (onSocialLogin) {
        await onSocialLogin(provider)
      } else {
        // Default behavior - simulate OAuth
        await new Promise(resolve => setTimeout(resolve, 1500))
      }
      
      window.location.href = redirectUrl
      
    } catch (err: any) {
      setError(`Couldn't connect with ${provider}. Try again?`)
    } finally {
      setIsLoading(false)
    }
  }
  
  return (
    <div className={cn('grid lg:grid-cols-2 min-h-screen lg:min-h-[80vh]', className)}>
      {/* Visual Side */}
      <div className="relative bg-luxury-black overflow-hidden hidden lg:block">
        <Image
          src="https://i.postimg.cc/50bQ0Frk/out-0-20.webp"
          alt="SSELFIE Studio"
          fill
          className="object-cover opacity-40"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-br from-luxury-black/90 via-luxury-black/70 to-luxury-black/90" />
        <div className="absolute inset-0 flex flex-col justify-center p-20 text-pure-white">
          <h2 className="font-serif text-5xl lg:text-6xl font-light tracking-[-0.03em] leading-[1.1] mb-6">
            Welcome back<br />to your empire
          </h2>
          <p className="text-xl text-soft-white/80 leading-relaxed max-w-md">
            Ready to keep building? Your tools, training, and community are waiting.
          </p>
        </div>
      </div>
      
      {/* Form Side */}
      <div className="flex flex-col justify-center px-8 py-12 lg:px-20 lg:py-20 bg-pure-white">
        <div className="w-full max-w-md mx-auto">
          <div className="mb-12">
            <h1 className="font-serif text-4xl lg:text-5xl font-light tracking-[-0.02em] mb-4">
              Sign In
            </h1>
            <p className="text-lg text-luxury-black/80">
              Good to see you again
            </p>
          </div>
          
          {error && (
            <div className="bg-red-50 border-l-[3px] border-red-500 px-5 py-4 mb-6 text-sm text-red-800 animate-fadeIn">
              {error}
            </div>
          )}
          
          <form onSubmit={handleSubmit}>
            <div className="mb-8">
              <label className="block text-xs tracking-[0.2em] uppercase mb-3 opacity-70">
                Email Address
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                placeholder="you@example.com"
                required
                disabled={isLoading}
                className={cn(
                  'w-full px-0 py-4 bg-transparent border-0 border-b border-warm-gray',
                  'placeholder:text-warm-gray focus:outline-none focus:border-b-2 focus:border-luxury-black',
                  'transition-all duration-300 text-luxury-black',
                  isLoading && 'opacity-50'
                )}
              />
            </div>
            
            <div className="mb-8">
              <label className="block text-xs tracking-[0.2em] uppercase mb-3 opacity-70">
                Password
              </label>
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleInputChange}
                placeholder="••••••••"
                required
                disabled={isLoading}
                className={cn(
                  'w-full px-0 py-4 bg-transparent border-0 border-b border-warm-gray',
                  'placeholder:text-warm-gray focus:outline-none focus:border-b-2 focus:border-luxury-black',
                  'transition-all duration-300 text-luxury-black',
                  isLoading && 'opacity-50'
                )}
              />
            </div>
            
            <div className="flex items-center justify-between mb-10">
              <label className="flex items-center gap-3 cursor-pointer group">
                <div className="relative">
                  <input
                    type="checkbox"
                    name="rememberMe"
                    checked={formData.rememberMe}
                    onChange={handleInputChange}
                    className="sr-only"
                  />
                  <div className={cn(
                    'w-5 h-5 border border-luxury-black transition-all duration-300',
                    formData.rememberMe && 'bg-luxury-black'
                  )}>
                    {formData.rememberMe && (
                      <svg className="w-full h-full p-1" viewBox="0 0 12 12" fill="none">
                        <path
                          d="M2 6L5 9L10 3"
                          stroke="white"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                    )}
                  </div>
                </div>
                <span className="text-sm select-none">Remember me</span>
              </label>
              
              <Link
                href="/forgot-password"
                className="text-sm text-luxury-black/70 hover:text-luxury-black transition-colors"
              >
                Forgot password?
              </Link>
            </div>
            
            <button
              type="submit"
              disabled={isLoading}
              className={cn(
                'w-full py-5 px-10 bg-luxury-black text-pure-white',
                'text-xs tracking-[0.3em] uppercase',
                'relative overflow-hidden transition-all duration-500',
                'hover:transform hover:-translate-y-0.5',
                'disabled:opacity-70 disabled:cursor-not-allowed disabled:hover:transform-none',
                'before:absolute before:inset-0 before:bg-white/10',
                'before:translate-x-[-100%] hover:before:translate-x-[100%]',
                'before:transition-transform before:duration-700'
              )}
            >
              {isLoading ? (
                <span className="inline-flex items-center gap-2">
                  <span className="inline-block w-1 h-1 bg-current rounded-full animate-pulse" />
                  <span className="inline-block w-1 h-1 bg-current rounded-full animate-pulse delay-75" />
                  <span className="inline-block w-1 h-1 bg-current rounded-full animate-pulse delay-150" />
                </span>
              ) : (
                'Sign In to Studio'
              )}
            </button>
          </form>
          
          <div className="relative text-center my-10">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-warm-gray/50" />
            </div>
            <span className="relative bg-pure-white px-5 text-xs tracking-[0.1em] uppercase text-luxury-black/60">
              Or continue with
            </span>
          </div>
          
          <div className="space-y-4">
            <button
              onClick={() => handleSocialLogin('google')}
              disabled={isLoading}
              className={cn(
                'w-full px-6 py-4 bg-transparent border border-warm-gray',
                'text-sm text-luxury-black hover:bg-soft-white hover:border-luxury-black',
                'transition-all duration-300 flex items-center justify-center gap-3',
                'disabled:opacity-50 disabled:cursor-not-allowed'
              )}
            >
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path d="M19.8 10.227c0-.709-.064-1.39-.182-2.045H10.2v3.868h5.382a4.6 4.6 0 0 1-1.996 3.018v2.51h3.232c1.891-1.742 2.982-4.305 2.982-7.35Z" fill="#4285F4"/>
                <path d="M10.2 20c2.7 0 4.964-.895 6.618-2.423l-3.232-2.509c-.895.6-2.04.955-3.386.955-2.605 0-4.81-1.76-5.595-4.123H1.264v2.59A9.996 9.996 0 0 0 10.2 20Z" fill="#34A853"/>
                <path d="M4.605 11.9a6.007 6.007 0 0 1-.314-1.9c0-.66.114-1.3.314-1.9V5.51H1.264A9.996 9.996 0 0 0 .2 10c0 1.614.386 3.14 1.064 4.49l3.34-2.59Z" fill="#FBBC05"/>
                <path d="M10.2 3.977c1.468 0 2.786.505 3.823 1.496l2.868-2.868C15.159.959 12.896 0 10.2 0 6.618 0 3.495 2.24 1.264 5.51l3.34 2.59c.787-2.364 2.991-4.123 5.596-4.123Z" fill="#EA4335"/>
              </svg>
              Continue with Google
            </button>
            
            <button
              onClick={() => handleSocialLogin('facebook')}
              disabled={isLoading}
              className={cn(
                'w-full px-6 py-4 bg-transparent border border-warm-gray',
                'text-sm text-luxury-black hover:bg-soft-white hover:border-luxury-black',
                'transition-all duration-300 flex items-center justify-center gap-3',
                'disabled:opacity-50 disabled:cursor-not-allowed'
              )}
            >
              <svg width="20" height="20" viewBox="0 0 20 20" fill="#1877F2">
                <path d="M20 10.061C20 4.505 15.523 0 10 0S0 4.505 0 10.061c0 5.022 3.657 9.184 8.438 9.939v-7.03h-2.54v-2.91h2.54V7.845c0-2.522 1.492-3.915 3.777-3.915 1.094 0 2.238.196 2.238.196v2.476h-1.26c-1.243 0-1.63.775-1.63 1.57v1.888h2.773l-.443 2.908h-2.33V20C16.343 19.245 20 15.083 20 10.061Z"/>
              </svg>
              Continue with Facebook
            </button>
          </div>
          
          <p className="text-center mt-10 text-sm text-luxury-black/70">
            New to SSELFIE?{' '}
            <Link href="/signup" className="text-luxury-black font-medium hover:opacity-70 transition-opacity">
              Create an account
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}

// Standalone variant for modal/page use
export const LoginPage: React.FC<LoginFormProps> = (props) => (
  <div className="min-h-screen bg-soft-white flex items-center justify-center p-4">
    <div className="w-full max-w-[1400px] bg-pure-white shadow-xl overflow-hidden">
      <LoginForm {...props} />
    </div>
  </div>
)

// Compact variant for embedded use
export const LoginCompact: React.FC<Omit<LoginFormProps, 'className'>> = (props) => (
  <div className="max-w-md mx-auto p-8 bg-pure-white">
    <div className="mb-8">
      <h2 className="font-serif text-3xl font-light tracking-[-0.02em] mb-3">
        Sign In
      </h2>
      <p className="text-luxury-black/70">
        Good to see you again
      </p>
    </div>
    
    {/* Reuse form logic but in compact layout */}
    <LoginForm {...props} className="!grid-cols-1 !min-h-0" />
  </div>
)