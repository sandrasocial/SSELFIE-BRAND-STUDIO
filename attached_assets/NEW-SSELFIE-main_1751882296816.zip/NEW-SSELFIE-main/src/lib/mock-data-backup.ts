// CENTRALIZED MOCK DATA FOR SSELFIE COMPONENTS
// Use this data in all Claude Victoria design sessions

/**
 * MOCK DATA FOR DESIGN PHASE
 * 
 * This file contains realistic mock data for all components during the design phase.
 * All components should import from this file to ensure consistency.
 * 
 * Week 1: Design with mock data
 * Week 2: Replace with real API calls
 * Week 3: Full database integration
 */

// User Profile Mock Data
export const MOCK_USER = {
  id: "user_123",
  name: "Sarah Johnson",
  email: "sarah@sarahjohnsonbrand.com",
  avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400&h=400&fit=crop&crop=face",
  joined: "2024-01-15",
  timezone: "America/New_York",
  memberSince: "January 15, 2024",
  tier: "Annual VIP",
  bio: "Personal brand strategist helping female entrepreneurs build authentic online presence",
  industry: "Business Coaching",
  location: "Austin, TX",
  website: "sarahjohnsonbrand.com",
  instagram: "@sarahjohnsonbrand",
  isOnline: true,
  lastActive: "2024-06-26T10:30:00Z"
}

// Subscription Mock Data
export const MOCK_SUBSCRIPTION = {
  id: "sub_123",
  plan: "annual", // monthly | annual | lifetime
  planName: "Annual VIP",
  status: "active", // active | canceled | past_due | incomplete
  amount: 297,
  currency: "USD",
  interval: "year",
  nextBilling: "2025-01-15",
  currentPeriodStart: "2024-01-15",
  currentPeriodEnd: "2025-01-15",
  cancelAtPeriodEnd: false,
  trialEnd: null,
  billingHistory: [
    { 
      id: "inv_001",
      date: "2024-01-15", 
      amount: 297, 
      status: "paid",
      description: "Annual VIP Membership",
      downloadUrl: "/invoices/inv_001.pdf"
    },
    { 
      id: "inv_002",
      date: "2023-01-15", 
      amount: 297, 
      status: "paid",
      description: "Annual VIP Membership",
      downloadUrl: "/invoices/inv_002.pdf"
    }
  ],
  paymentMethod: {
    type: "card",
    brand: "visa",
    last4: "4242",
    expiryMonth: 12,
    expiryYear: 2026,
    country: "US"
  }
}

// Usage Tracking Mock Data
export const MOCK_USAGE = {
  currentMonth: "2024-06",
  aiGenerations: {
    used: 45,
    limit: 75, // Based on Annual VIP tier
    resetDate: "2024-07-01",
    percentage: 60,
    trending: "stable" // increasing | decreasing | stable
  },
  features: {
    poseCoach: { 
      used: 15, 
      unlimited: true,
      lastUsed: "2024-06-25T14:30:00Z"
    },
    glowCheck: { 
      used: 8, 
      unlimited: true,
      lastUsed: "2024-06-24T09:15:00Z"
    },
    communityAccess: true,
    monthlyTemplates: { 
      downloaded: 3, 
      available: 5,
      newThisMonth: 2
    }
  },
  monthlyTrend: [
    { month: "2024-01", used: 32 },
    { month: "2024-02", used: 28 },
    { month: "2024-03", used: 41 },
    { month: "2024-04", used: 38 },
    { month: "2024-05", used: 52 },
    { month: "2024-06", used: 45 }
  ]
}

// Training Progress Mock Data
export const MOCK_TRAINING = {
  totalModules: 6,
  completedModules: 2,
  progressPercentage: 33,
  currentModule: 3,
  nextLesson: "Advanced Posing Techniques",
  timeInvested: "2.5 hours",
  estimatedCompletion: "4 hours remaining",
  modules: [
    { 
      id: 1, 
      title: "Understanding Your Brand", 
      completed: true, 
      completedAt: "2024-06-15T16:45:00Z",
      duration: "45 min",
      lessons: 5
    },
    { 
      id: 2, 
      title: "Camera Basics & Settings", 
      completed: true, 
      completedAt: "2024-06-20T11:30:00Z",
      duration: "60 min",
      lessons: 7
    },
    { 
      id: 3, 
      title: "Advanced Posing Techniques", 
      completed: false,
      progress: 40,
      duration: "75 min",
      lessons: 8
    },
    { 
      id: 4, 
      title: "Lighting & Environment", 
      completed: false,
      progress: 0,
      duration: "50 min",
      lessons: 6
    },
    { 
      id: 5, 
      title: "Content Strategy", 
      completed: false,
      progress: 0,
      duration: "90 min",
      lessons: 10
    },
    { 
      id: 6, 
      title: "Building Your Empire", 
      completed: false,
      progress: 0,
      duration: "120 min",
      lessons: 12
    }
  ],
  achievements: [
    {
      id: "first_generation",
      title: "First Generation",
      description: "Created your first AI photo",
      unlockedAt: "2024-01-16T10:00:00Z",
      icon: "🎨"
    },
    {
      id: "style_explorer",
      title: "Style Explorer", 
      description: "Tried 5 different presets",
      unlockedAt: "2024-01-20T14:30:00Z",
      icon: "🎭"
    },
    {
      id: "community_helper",
      title: "Community Helper",
      description: "Helped 3 fellow members",
      unlockedAt: "2024-02-15T09:15:00Z",
      icon: "🤝"
    }
  ]
}

// Recent Generations Mock Data
export const MOCK_GENERATIONS = [
  {
    id: "gen_001",
    imageUrl: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400&h=600&fit=crop",
    prompt: "Professional headshot, golden hour lighting, confident pose",
    preset: "golden-hour",
    createdAt: "2024-06-25T16:30:00Z",
    isPrivate: false,
    likes: 12,
    downloads: 3,
    shares: 2
  },
  {
    id: "gen_002", 
    imageUrl: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=600&fit=crop",
    prompt: "Business casual, office environment, approachable smile",
    preset: "professional",
    createdAt: "2024-06-24T11:15:00Z",
    isPrivate: true,
    likes: 0,
    downloads: 1,
    shares: 0
  },
  {
    id: "gen_003",
    imageUrl: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=400&h=600&fit=crop",
    prompt: "Creative portrait, soft lighting, artistic composition",
    preset: "artistic-glow",
    createdAt: "2024-06-23T14:45:00Z",
    isPrivate: false,
    likes: 8,
    downloads: 2,
    shares: 1
  }
]

// Community Mock Data
export const MOCK_COMMUNITY = {
  totalMembers: 2847,
  activeToday: 127,
  weeklyGrowth: 8.5, // percentage
  recentHighlights: [
    {
      id: "highlight_001",
      member: {
        name: "Jessica Chen",
        avatar: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop&crop=face",
        tier: "Monthly"
      },
      achievement: "First viral post - 50K views!",
      timestamp: "2024-06-25T18:30:00Z",
      image: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=300&h=400&fit=crop"
    },
    {
      id: "highlight_002",
      member: {
        name: "Maria Rodriguez",
        avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face",
        tier: "Annual VIP"
      },
      achievement: "Landed dream client through SSELFIE content",
      timestamp: "2024-06-24T15:20:00Z",
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=300&h=400&fit=crop"
    }
  ]
}

// Pricing Tiers Mock Data
export const MOCK_PRICING_TIERS = [
  {
    id: "monthly",
    name: "Monthly Mastery",
    price: 47,
    originalPrice: null,
    currency: "USD",
    interval: "month",
    generationLimit: 50,
    popular: false,
    savings: null,
    features: [
      "AI Photo Generator",
      "Pose Coach Tool", 
      "Glow Check Analysis",
      "Basic Presets Collection",
      "Community Access",
      "Mobile App Access",
      "Email Support"
    ],
    limitations: [
      "50 AI generations per month",
      "Basic presets only",
      "Standard support"
    ]
  },
  {
    id: "annual",
    name: "Annual VIP",
    price: 297,
    originalPrice: 564, // 47 * 12
    currency: "USD", 
    interval: "year",
    generationLimit: 75,
    popular: true,
    savings: 267, // 564 - 297
    savingsPercentage: 47,
    features: [
      "Everything in Monthly",
      "75 AI generations per month",
      "Premium Presets Collection",
      "Priority Support",
      "Advanced Training Modules",
      "1-on-1 Monthly Group Calls",
      "Early Access to New Features",
      "Commercial License"
    ],
    limitations: [
      "75 AI generations per month"
    ]
  },
  {
    id: "lifetime",
    name: "Lifetime Legacy",
    price: 497,
    originalPrice: null,
    currency: "USD",
    interval: "lifetime",
    generationLimit: 100,
    popular: false,
    savings: null,
    features: [
      "Everything in Annual VIP",
      "100 AI generations per month",
      "Lifetime Access Guarantee",
      "Exclusive Masterclasses",
      "Direct Access to Sandra",
      "Beta Testing Program",
      "Lifetime Updates",
      "VIP Community Channel",
      "Annual In-Person Meetup"
    ],
    limitations: [
      "Limited spots available"
    ]
  }
]

// Social Proof Mock Data
export const MOCK_TESTIMONIALS = [
  {
    id: "testimonial_001",
    name: "Amanda Parker",
    role: "Marketing Consultant",
    avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face",
    rating: 5,
    text: "SSELFIE transformed my entire personal brand. I went from struggling with confidence to booking $10K clients consistently. The AI generator is incredible!",
    result: "Increased revenue by 340%",
    beforeAfter: {
      before: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=200&h=300&fit=crop",
      after: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=200&h=300&fit=crop"
    },
    featured: true
  },
  {
    id: "testimonial_002",
    name: "Sophie Chen",
    role: "Life Coach",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face",
    rating: 5,
    text: "I was skeptical about AI photos, but SSELFIE's quality is unmatched. My engagement rates doubled within a month of using these tools.",
    result: "2x engagement increase",
    beforeAfter: null,
    featured: false
  },
  {
    id: "testimonial_003",
    name: "Rachel Martinez",
    role: "E-commerce Founder",
    avatar: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop&crop=face",
    rating: 5,
    text: "The pose coach feature alone is worth the entire membership. I finally feel confident showing up online and my sales have tripled.",
    result: "300% sales increase",
    beforeAfter: null,
    featured: true
  }
]

// Freebie Mock Data
export const MOCK_FREEBIE = {
  title: "SSELFIE Starter Kit",
  subtitle: "Everything you need to start creating stunning content",
  totalValue: 297,
  downloadCount: 2847,
  items: [
    {
      name: "10 Professional Pose Templates",
      description: "Step-by-step photo guide",
      type: "PDF",
      value: 97
    },
    {
      name: "Lighting Setup Cheat Sheet", 
      description: "Perfect lighting every time",
      type: "PDF",
      value: 47
    },
    {
      name: "Camera Settings Quick Reference",
      description: "Phone & DSLR settings",
      type: "PDF", 
      value: 27
    },
    {
      name: "Before/After Transformation Examples",
      description: "Real member results",
      type: "PDF",
      value: 67
    },
    {
      name: "Mobile Photography Pro Tips",
      description: "Advanced techniques",
      type: "PDF",
      value: 37
    },
    {
      name: "3 Free AI Photo Generation Credits",
      description: "Try our AI generator",
      type: "Credits",
      value: 22
    }
  ]
}

// ============================================================================
// CRITICAL COMPONENTS MOCK DATA - Sandra: Replace with Brand Voice Content
// ============================================================================

// Import types for the 5 critical components
import type { PricingTier } from '@/components/business/PricingCard'
import type { Invoice } from '@/components/business/BillingHistory'
import type { Testimonial } from '@/components/marketing/SocialProof'
import type { OnboardingStep } from '@/components/marketing/OnboardingSteps'
import type { FreebieItem } from '@/components/marketing/FreebiePreview'

// PRICING CARD MOCK DATA - Replace with Sandra's actual pricing strategy
export const MOCK_PRICING_CARD_TIERS: PricingTier[] = [
  {
    id: 'starter',
    name: 'Selfie Starter',
    price: 29,
    currency: 'USD',
    interval: 'month',
    generationLimit: 50,
    features: [
      'AI selfie analysis and scoring',
      'Basic transformation suggestions', 
      'Monthly confidence report',
      'Email support for your journey'
    ],
    limitations: [
      'Limited to 50 AI generations monthly',
      'Standard templates only'
    ]
  },
  {
    id: 'professional',
    name: 'Power Professional',
    price: 79,
    originalPrice: 99,
    currency: 'USD', 
    interval: 'month',
    generationLimit: 200,
    popular: true,
    savings: 20,
    savingsPercentage: 20,
    features: [
      'Everything in Selfie Starter',
      'Advanced AI transformation engine',
      'Personal brand strategy session',
      'Custom style & color recommendations',
      'Priority support & guidance',
      'HD export & commercial usage rights'
    ]
  },
  {
    id: 'elite',
    name: 'Elite Transformation',
    price: 297,
    currency: 'USD',
    interval: 'year', 
    generationLimit: 1000,
    features: [
      'Everything in Power Professional',
      'Unlimited AI generations',
      '1-on-1 brand strategist consultation',
      'Custom transformation presets',
      'VIP onboarding experience', 
      '24/7 priority support access'
    ]
  }
]

// BILLING HISTORY MOCK DATA - Replace with actual invoice structure
export const MOCK_BILLING_INVOICES: Invoice[] = [
  {
    id: 'inv_current',
    date: '2024-12-15',
    amount: 79,
    currency: 'USD',
    status: 'paid',
    description: 'Power Professional - Monthly Subscription',
    downloadUrl: '/downloads/invoice-december-2024.pdf',
    paymentMethod: {
      type: 'card',
      brand: 'visa', 
      last4: '4242'
    }
  },
  {
    id: 'inv_previous', 
    date: '2024-11-15',
    amount: 79,
    currency: 'USD',
    status: 'paid',
    description: 'Power Professional - Monthly Subscription',
    downloadUrl: '/downloads/invoice-november-2024.pdf',
    paymentMethod: {
      type: 'card',
      brand: 'visa',
      last4: '4242' 
    }
  },
  {
    id: 'inv_first',
    date: '2024-10-15', 
    amount: 29,
    currency: 'USD',
    status: 'paid',
    description: 'Selfie Starter - Monthly Subscription (First Month)',
    downloadUrl: '/downloads/invoice-october-2024.pdf',
    paymentMethod: {
      type: 'card',
      brand: 'mastercard',
      last4: '8888'
    }
  }
]

// SOCIAL PROOF MOCK DATA - Replace with Sandra's authentic testimonials
export const MOCK_SOCIAL_TESTIMONIALS: Testimonial[] = [
  {
    id: 'testimonial_ceo',
    name: 'Alexandra Chen', 
    role: 'CEO, TechVenture Inc',
    avatar: '/images/testimonials/alexandra-chen.jpg',
    rating: 5,
    text: 'This platform completely revolutionized how I show up professionally. The AI insights were incredibly accurate and actionable.',
    result: '300% increase in LinkedIn engagement',
    featured: true
  },
  {
    id: 'testimonial_entrepreneur',
    name: 'Maria Rodriguez',
    role: 'Serial Entrepreneur', 
    avatar: '/images/testimonials/maria-rodriguez.jpg',
    rating: 5,
    text: 'I had no idea my selfie game was holding back my entire personal brand until I discovered this transformation system.',
    result: 'Landed 5 high-value clients in 8 weeks'
  },
  {
    id: 'testimonial_speaker',
    name: 'Amanda Foster',
    role: 'Keynote Speaker & Author',
    avatar: '/images/testimonials/amanda-foster.jpg', 
    rating: 5,
    text: 'The personal brand analysis opened my eyes to possibilities I never knew existed. This is the future of professional image.',
    result: 'Featured in Forbes 30 Under 30',
    beforeAfter: {
      before: '/images/before-after/amanda-before.jpg',
      after: '/images/before-after/amanda-after.jpg'
    }
  },
  {
    id: 'testimonial_marketing',
    name: 'Sarah Kim',
    role: 'VP Marketing',
    avatar: '/images/testimonials/sarah-kim.jpg',
    rating: 5, 
    text: 'This is exactly what I needed to level up my executive presence. The transformation was immediate and powerful.',
    beforeAfter: {
      before: '/images/before-after/sarah-before.jpg', 
      after: '/images/before-after/sarah-after.jpg'
    }
  }
]

// ONBOARDING STEPS MOCK DATA - Replace with Sandra's actual user journey
export const MOCK_ONBOARDING_JOURNEY: OnboardingStep[] = [
  {
    id: 'upload_selfie',
    number: 1,
    title: 'Upload Your Power Selfie',
    description: 'Start with your best current selfie - we\'ll help you discover its hidden potential.',
    status: 'completed',
    actionLabel: 'Upload & Analyze'
  },
  {
    id: 'set_vision',
    number: 2, 
    title: 'Define Your Vision',
    description: 'Tell us about your goals, industry, and the impression you want to make in the world.',
    status: 'current',
    actionLabel: 'Complete Vision Setting'
  },
  {
    id: 'ai_analysis',
    number: 3,
    title: 'AI Power Analysis', 
    description: 'Our advanced AI analyzes your features, energy, and brand potential to create your transformation roadmap.',
    status: 'upcoming'
  },
  {
    id: 'review_transformations',
    number: 4,
    title: 'Review Your Transformations',
    description: 'Explore your personalized results and choose the versions that make you feel most powerful and confident.',
    status: 'upcoming', 
    actionLabel: 'Explore Results'
  },
  {
    id: 'launch_brand',
    number: 5,
    title: 'Launch Your New Brand',
    description: 'Download your transformed images and start building the personal brand that opens doors and creates opportunities.',
    status: 'upcoming',
    actionLabel: 'Download & Launch'
  }
]

// FREEBIE PREVIEW MOCK DATA - Replace with Sandra's actual lead magnets  
export const MOCK_FREEBIE_RESOURCES: FreebieItem[] = [
  {
    name: 'The Ultimate Power Selfie Guide',
    description: 'Discover the 7 insider secrets to taking selfies that command attention and respect in any industry.',
    type: 'PDF Guide',
    value: 47
  },
  {
    name: 'Your Signature Brand Color System', 
    description: 'Unlock the colors that enhance your natural magnetism and elevate your professional presence.',
    type: 'Color Template',
    value: 67
  },
  {
    name: 'Confidence Transformation Blueprint',
    description: 'The step-by-step system for building unshakeable confidence that radiates through every photo.',
    type: 'Action Checklist', 
    value: 37
  },
  {
    name: 'Professional Lighting Mastery',
    description: 'Master the art of lighting for powerful, professional selfies that command respect.',
    type: 'Video Tutorial',
    value: 89
  },
  {
    name: 'Power Positioning Guide',
    description: 'Angle psychology and positioning secrets for maximum impact and authority.',
    type: 'Quick Reference',
    value: 29
  }
]

// Freebies and Resources
export const freebies = [
  {
    id: 'ultimate_power_selfie_guide',
    title: 'The Ultimate Power Selfie Guide',
    description: 'Discover the 7 insider secrets to taking selfies that command attention and respect in any industry.',
    type: 'pdf',
    thumbnail: '/images/freebies/power-selfie-guide-preview.jpg',
    value: 47,
    isLocked: false,
    downloadUrl: '/downloads/ultimate-power-selfie-guide.pdf',
    items: [
      'Professional lighting mastery techniques',
      'Angle psychology and power positioning', 
      'Background selection for brand authority',
      'Energy projection and confidence cultivation',
      'Brand consistency framework for all platforms'
    ]
  },
  {
    id: 'brand_color_system',
    title: 'Your Signature Brand Color System', 
    description: 'Unlock the colors that enhance your natural magnetism and elevate your professional presence.',
    type: 'template',
    thumbnail: '/images/freebies/brand-colors-preview.jpg',
    value: 67,
    isLocked: true,
    items: [
      'Personal color analysis framework',
      'Brand color psychology deep-dive',
      'Digital brand palette templates',
      'Professional styling guidelines',
      'Outfit coordination mastery guide'
    ]
  },
  {
    id: 'confidence_transformation',
    title: 'Confidence Transformation Blueprint',
    description: 'The step-by-step system for building unshakeable confidence that radiates through every photo and interaction.',
    type: 'checklist',
    thumbnail: '/images/freebies/confidence-blueprint-preview.jpg', 
    value: 37,
    isLocked: true,
    items: [
      'Pre-shoot confidence ritual system',
      'Mindset transformation exercises',
      'Power body language mastery',
      'Energy cultivation techniques',
      'Authentic presence framework'
    ]
  }
]

// ...existing mock data...

// Export all mock data
export const MOCK_DATA = {
  user: MOCK_USER,
  subscription: MOCK_SUBSCRIPTION,
  usage: MOCK_USAGE,
  training: MOCK_TRAINING,
  generations: MOCK_GENERATIONS,
  community: MOCK_COMMUNITY,
  pricingTiers: MOCK_PRICING_TIERS,
  testimonials: MOCK_TESTIMONIALS,
  freebie: MOCK_FREEBIE,
  // New critical components data
  pricingCards: MOCK_PRICING_CARD_TIERS,
  billingInvoices: MOCK_BILLING_INVOICES,
  socialTestimonials: MOCK_SOCIAL_TESTIMONIALS,
  onboardingJourney: MOCK_ONBOARDING_JOURNEY,
  freebieResources: MOCK_FREEBIE_RESOURCES
}
