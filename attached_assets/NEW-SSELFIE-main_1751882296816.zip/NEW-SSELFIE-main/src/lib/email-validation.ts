// Email validation utility with bounce prevention
export function validateEmail(email: string): { isValid: boolean; error?: string } {
  if (!email) {
    return { isValid: false, error: 'Email is required' };
  }

  const trimmedEmail = email.trim().toLowerCase();

  // Basic format validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(trimmedEmail)) {
    return { isValid: false, error: 'Please enter a valid email address' };
  }

  // Check for common typos and invalid domains
  const invalidDomains = [
    'gmail.co', 'gmial.com', 'yahooo.com', 'hotmial.com',
    'outlok.com', 'gmai.com', 'yahoo.co'
  ];

  const domain = trimmedEmail.split('@')[1];
  if (invalidDomains.includes(domain)) {
    return { isValid: false, error: 'Please check your email address for typos' };
  }

  // Check for disposable email domains
  const disposableDomains = [
    '10minutemail.com', 'tempmail.org', 'guerrillamail.com',
    'mailinator.com', 'throwaway.email'
  ];

  if (disposableDomains.includes(domain)) {
    return { isValid: false, error: 'Please use a permanent email address' };
  }

  // Advanced validation - check for multiple dots, consecutive dots, etc.
  if (domain.includes('..') || domain.startsWith('.') || domain.endsWith('.')) {
    return { isValid: false, error: 'Please enter a valid email address' };
  }

  return { isValid: true };
}

// Log validation attempts for analytics
export function logEmailValidation(email: string, isValid: boolean, error?: string) {
  if (typeof window !== 'undefined') {
    // Client-side logging
    console.log('Email validation:', { 
      email: email.split('@')[0] + '@***', // Privacy-safe logging
      isValid, 
      error 
    });
  }
}
