'use client'

import React from 'react'
import Link from 'next/link'
import Navigation from '@/components/global/Navigation'
import Footer from '@/components/global/Footer'
import OfferCardsGrid from '@/components/ui/OfferCardsGrid'
import { WelcomeEditorial, TimelineStats, EditorialTestimonials, PowerQuote, BeginningStory } from '@/components/sections'
import { PortfolioSection } from '@/components/sections/editorial/PortfolioSection'
import { HeroFullBleed } from '@/components/sections/hero/HeroFullBleed'
import { SandraImages } from '@/components/sandra-image-library'
import { ImageBreak } from '@/components/sections/about/ImageBreak'
import SignupGift from '@/components/SignupGift'

export default function HomePage() {
  return (
    <div className="min-h-screen bg-mid-gray">
      {/* Navigation */}
      <Navigation />

      {/* Hero Section - Full-bleed, drama, CTA */}
      <HeroFullBleed
        backgroundImage={SandraImages.hero.homepage}
        tagline="It starts with your selfie"
        title="SSELFIE"
        subtitle="STUDIO"
        ctaText="Show me how"
        ctaLink="/pricing"
      />

      {/* Editorial Welcome */}
      <WelcomeEditorial />

      {/* Dramatic Editorial Image Break */}
      <ImageBreak
        src={SandraImages.editorial.laptop1}
        alt="Sandra working, editorial style"
        height="54vh"
      />

      {/* Timeline Stats */}
      <TimelineStats />

      {/* Offer Grid ("Work With Me") */}
      <OfferCardsGrid />

      {/* Pull-quote break (power moment) */}
      <PowerQuote />

      {/* Portfolio - proof/social gallery */}
      <PortfolioSection />

      {/* Another Editorial Image Break (adds air/luxury) */}
      <ImageBreak
        src={SandraImages.editorial.mirror}
        alt="Sandra transformation, editorial"
        height="44vh"
      />

      {/* Testimonials */}
      <EditorialTestimonials />

      {/* “Sandra’s Story” */}
      <BeginningStory />

      {/* Gift/Signup: My Gift To You (email opt-in, not old newsletter) */}
      <SignupGift />

      {/* Final CTA */}
      <section className="section-padding bg-editorial-gray text-center">
        <div className="max-width-cta px-6">
          <h2 className="h2 mb-6">Ready to stop hiding?</h2>
          <p className="body-copy mb-8">Your empire starts with one selfie. Let&apos;s take it.</p>
          <Link href="/pricing" className="cta-link">Join SSELFIE Studio</Link>
        </div>
      </section>

      {/* Footer */}
      <Footer />
    </div>
  )
}