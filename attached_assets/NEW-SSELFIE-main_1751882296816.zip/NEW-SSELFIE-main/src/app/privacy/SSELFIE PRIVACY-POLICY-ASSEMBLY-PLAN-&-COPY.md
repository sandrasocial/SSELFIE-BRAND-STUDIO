# SSELFIE PRIVACY POLICY — ASSEMBLY PLAN & COPY

Alright Diana, this is the Privacy page—Sandra style. No legal jargon, no “we value your privacy” empty promises. Just real talk about what happens with your info, why it matters, and what you can expect. It’s privacy, but make it human.

---

## 1. HERO SECTION

- **Component:** `HeroFullBleed.tsx`
- **Image:** Editorial: Sandra, cozy, maybe reading or on her phone, somewhere she feels safe.
- **Title:**  
  PRIVACY
- **Tagline:**  
  YOUR STORY. YOUR DATA. YOUR RULES.
- **CTA:**  
  HAVE QUESTIONS? JUST ASK

---

## 2. REAL TALK: YOUR PRIVACY MATTERS

**Headline:**  
Let’s keep it simple.

**Copy:**  
Your story is yours.  
Your business is yours.  
Everything you share on SSELFIE—photos, emails, your signature shade of lipstick—is safe here.  
I built this platform for women who’ve had enough of being watched, tracked, or sold to. If it’s not helping you build your brand, we don’t need it.

---

## 3. WHAT WE COLLECT (AND WHY)

- **Selfies & Photos:**  
  So you can create your brand, your way. Only you (and the AI magic) see them unless you say otherwise.

- **Your info (name, email, colors, fonts):**  
  Used to set up your dashboard, build your mood board, and send you what you actually want (not spam).

- **Payment details:**  
  Only processed through secure, well-known payment providers. I never see your card.

- **Analytics:**  
  Tiny bits of data so I can see what’s working (and what’s not). No creepy tracking, ever.

---

## 4. WHAT WE NEVER DO

- **Never sell your info**  
- **Never share your photos without your permission**  
- **Never spam you with nonsense**  
- **Never show your stuff to random marketers**  

---

## 5. HOW YOU’RE IN CONTROL

- Download your photos, guides, and info any time.
- Delete your account (and all your data) with a click.
- Change your settings or unsubscribe, no angry emails required.

---

## 6. LEGAL BASICS (PLAIN ENGLISH)

- We follow all basic privacy laws for the EU and US.  
- If the law changes, so will this page (and I’ll let you know).
- If you’re ever worried, just ask. I’ll answer, not a robot.

---

## 7. CONTACT

**Headline:**  
Still not sure? Want all the details?

**Copy:**  
Message me on Instagram (@sandrasocial) or email me directly.  
No scripts, no runaround—just Sandra.

**CTA Button:**  
ASK SANDRA

---

## 8. STYLE & QA REMINDERS

- Editorial images only—no icons or stock shields.
- Layout: Air, clarity, and plenty of white space.
- Typography:  
  - Headlines = ‘Times New Roman’, serif  
  - Body/UI = system sans
- Button: All caps, minimal, inviting.
- Copy: Sandra’s voice—warm, honest, always plain English.
- Never say “empowerment,” “protection,” or “compliance” unless required.
- No m-dash. Never “lawyer speak.”

---

## FINAL CHECKLIST

- [ ] Hero: Title, tagline, CTA
- [ ] Real talk intro—sets the tone
- [ ] Clear breakdown of what’s collected (and what’s not)
- [ ] Control section—shows how easy it is to leave or update
- [ ] Legal basics—no jargon
- [ ] Contact/CTA—Sandra’s voice, not a bot

Let’s make this the only privacy page that actually makes you feel safer.