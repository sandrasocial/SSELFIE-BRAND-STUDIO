import { Metadata } from 'next'
import Navigation from '@/components/global/Navigation'
import { Footer } from '@/components/global/Footer'
import { HeroFullBleed } from '@/components/sections/hero/HeroFullBleed'
import { SandraImages } from '@/components/sandra-image-library'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'Privacy Policy | SSELFIE Studio',
  description: 'Your story. Your data. Your rules. Real talk about privacy at SSELFIE.',
}

export default function PrivacyPage() {
  return (
    <>
      <Navigation />
      
      <main className="bg-white">
        {/* Hero Section */}
        <HeroFullBleed
          backgroundImage={SandraImages.hero.about}
          tagline="YOUR STORY. YOUR DATA. YOUR RULES."
          title="PRIVACY"
          subtitle=""
          ctaText="HAVE QUESTIONS? JUST ASK"
          ctaLink="#contact"
        />

        {/* Real Talk Section */}
        <section className="py-20 px-4">
          <div className="max-w-4xl mx-auto">
            <h1 style={{ fontFamily: 'Times New Roman, serif' }} className="text-3xl md:text-4xl text-[#171719] mb-8">
              Let's keep it simple.
            </h1>
            
            <div className="space-y-6 text-lg leading-relaxed text-[#171719]">
              <p>Your story is yours.</p>
              <p>Your business is yours.</p>
              <p>Everything you share on SSELFIE—photos, emails, your signature shade of lipstick—is safe here.</p>
              <p>I built this platform for women who've had enough of being watched, tracked, or sold to. If it's not helping you build your brand, we don't need it.</p>
            </div>
          </div>
        </section>

        {/* What We Collect */}
        <section className="py-20 px-4 bg-[#F1F1F1]">
          <div className="max-w-4xl mx-auto">
            <h2 style={{ fontFamily: 'Times New Roman, serif' }} className="text-3xl text-[#171719] mb-12">
              What we collect (and why)
            </h2>
            
            <div className="grid gap-8 md:gap-12">
              <div>
                <h3 className="text-xl font-semibold text-[#171719] mb-4">Selfies & Photos</h3>
                <p className="text-[#171719] leading-relaxed">
                  So you can create your brand, your way. Only you (and the AI magic) see them unless you say otherwise.
                </p>
              </div>
              
              <div>
                <h3 className="text-xl font-semibold text-[#171719] mb-4">Your info (name, email, colors, fonts)</h3>
                <p className="text-[#171719] leading-relaxed">
                  Used to set up your dashboard, build your mood board, and send you what you actually want (not spam).
                </p>
              </div>
              
              <div>
                <h3 className="text-xl font-semibold text-[#171719] mb-4">Payment details</h3>
                <p className="text-[#171719] leading-relaxed">
                  Only processed through secure, well-known payment providers. I never see your card.
                </p>
              </div>
              
              <div>
                <h3 className="text-xl font-semibold text-[#171719] mb-4">Analytics</h3>
                <p className="text-[#171719] leading-relaxed">
                  Tiny bits of data so I can see what's working (and what's not). No creepy tracking, ever.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* What We Never Do */}
        <section className="py-20 px-4">
          <div className="max-w-4xl mx-auto">
            <h2 style={{ fontFamily: 'Times New Roman, serif' }} className="text-3xl text-[#171719] mb-12">
              What we never do
            </h2>
            
            <div className="grid gap-6 md:gap-8">
              <div className="flex items-start space-x-4">
                <div className="text-2xl">×</div>
                <p className="text-[#171719] text-lg">Never sell your info</p>
              </div>
              <div className="flex items-start space-x-4">
                <div className="text-2xl">×</div>
                <p className="text-[#171719] text-lg">Never share your photos without your permission</p>
              </div>
              <div className="flex items-start space-x-4">
                <div className="text-2xl">×</div>
                <p className="text-[#171719] text-lg">Never spam you with nonsense</p>
              </div>
              <div className="flex items-start space-x-4">
                <div className="text-2xl">×</div>
                <p className="text-[#171719] text-lg">Never show your stuff to random marketers</p>
              </div>
            </div>
          </div>
        </section>

        {/* Your Control */}
        <section className="py-20 px-4 bg-[#F1F1F1]">
          <div className="max-w-4xl mx-auto">
            <h2 style={{ fontFamily: 'Times New Roman, serif' }} className="text-3xl text-[#171719] mb-12">
              How you're in control
            </h2>
            
            <div className="space-y-6 text-lg text-[#171719]">
              <p>• Download your photos, guides, and info any time.</p>
              <p>• Delete your account (and all your data) with a click.</p>
              <p>• Change your settings or unsubscribe, no angry emails required.</p>
            </div>
          </div>
        </section>

        {/* Legal Basics */}
        <section className="py-20 px-4">
          <div className="max-w-4xl mx-auto">
            <h2 style={{ fontFamily: 'Times New Roman, serif' }} className="text-3xl text-[#171719] mb-12">
              Legal basics (plain English)
            </h2>
            
            <div className="space-y-6 text-lg text-[#171719]">
              <p>• We follow all basic privacy laws for the EU and US.</p>
              <p>• If the law changes, so will this page (and I'll let you know).</p>
              <p>• If you're ever worried, just ask. I'll answer, not a robot.</p>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-20 px-4 bg-[#F1F1F1]">
          <div className="max-w-4xl mx-auto text-center">
            <h2 style={{ fontFamily: 'Times New Roman, serif' }} className="text-3xl text-[#171719] mb-8">
              Still not sure? Want all the details?
            </h2>
            
            <p className="text-lg text-[#171719] mb-8 max-w-2xl mx-auto">
              Message me on Instagram (@sandrasocial) or email me directly.<br />
              No scripts, no runaround—just Sandra.
            </p>
            
            <Link 
              href="/contact"
              className="inline-block bg-[#171719] text-[#F1F1F1] px-8 py-4 font-medium tracking-wide hover:bg-[#2A2A2A] transition-colors duration-200"
            >
              ASK SANDRA
            </Link>
          </div>
        </section>
      </main>

      <Footer />
    </>
  )
}
