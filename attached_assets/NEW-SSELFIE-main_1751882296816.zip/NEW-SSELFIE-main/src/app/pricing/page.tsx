'use client'

import React from 'react'
import Navigation from '@/components/global/Navigation'
import { Footer } from '@/components/global/Footer'
import { HeroFullBleed } from '@/components/sections/hero/HeroFullBleed'
import { ImageBreak } from '@/components/sections/about/ImageBreak'
import EditorialTestimonials from '@/components/sections/editorial/EditorialTestimonials'
import { SandraImages } from '@/components/sandra-image-library'
import Image from 'next/image'
import Link from 'next/link'

export default function PricingPage() {
  return (
    <>
      <Navigation />
      
      <div className="min-h-screen">
        {/* 1. Hero Section */}
        <HeroFullBleed
          backgroundImage={SandraImages.hero.pricing}
          tagline="Ready to show the world who you are? Let's do it together."
          title="PRICING"
          ctaText="Show up as her"
          ctaLink="#pricing-options"
        />

        {/* 2. Editorial Spread - Sandra's Story */}
        <section className="py-20 md:py-32 bg-soft-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-7xl">
            <div className="flex flex-col lg:flex-row gap-12 lg:gap-20 items-center">
              {/* Left: Image */}
              <div className="relative h-96 lg:h-[600px] w-full lg:w-1/2 flex-shrink-0">
                <Image 
                  src={SandraImages.editorial.laptop1}
                  alt="Sandra working, not posed"
                  fill
                  className="object-cover"
                  sizes="(max-width: 1024px) 100vw, 50vw"
                  priority
                />
              </div>
              
              {/* Right: Content */}
              <div className="space-y-12 w-full lg:w-1/2">
                <h2 className="font-bodoni text-3xl md:text-4xl lg:text-5xl font-light text-luxury-black leading-tight">
                  Okay, here&apos;s what actually happened…
                </h2>
                
                <div className="space-y-8 font-inter text-lg md:text-xl text-luxury-black opacity-80 leading-loose">
                  <p>This didn&apos;t start as a business.<br />It started as survival.</p>
                  
                  <p>One year ago, I hit rock bottom. Divorced. Three kids. No backup plan. I was heartbroken, exhausted, and completely disconnected from the woman I used to be.</p>
                  
                  <p>And one day, in the middle of all that mess—I picked up my phone. Took a selfie. Posted something honest. Not perfect. Just true.</p>
                  
                  <p>That one moment sparked something. I didn&apos;t need a full plan. I needed one brave post. One real story. One step back to myself.</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 3. Image Break */}
        <ImageBreak 
          src={SandraImages.flatlays.workspace1}
          alt="Coffee, hands, workspace"
        />

        {/* 4. Pricing Options */}
        <section id="pricing-options" className="py-20 md:py-32 bg-pure-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-6xl">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 max-w-5xl mx-auto">

              {/* Card 1: Future Self */}
              <div className="bg-soft-white p-8 md:p-12 flex flex-col h-full justify-between relative overflow-hidden">
                {/* Background Editorial Image */}
                <div className="absolute top-0 right-0 w-32 h-32 opacity-10">
                  <Image 
                    src={SandraImages.editorial.phone1} 
                    alt=""
                    fill
                    className="object-cover"
                    sizes="128px"
                  />
                </div>
                <div className="relative z-10">
                  <div className="flex items-center justify-between mb-4">
                    <span className="font-inter text-xs tracking-[0.3em] uppercase text-luxury-black/50">
                      Just the selfies
                    </span>
                    <span className="bg-luxury-black text-soft-white px-3 py-1 text-xs tracking-wider uppercase">
                      Try it
                    </span>
                  </div>
                  <h3 className="font-bodoni text-3xl md:text-4xl font-light text-luxury-black mb-4">
                    FUTURE SELF
                  </h3>
                  <div className="flex items-baseline mb-6">
                    <span className="font-bodoni text-5xl font-light text-luxury-black">€47</span>
                    <span className="font-inter text-sm text-luxury-black/60 ml-2">one-time</span>
                  </div>
                  <p className="font-inter text-base text-luxury-black/80 leading-relaxed mb-6">
                    Upload. Wait. Wow. 30 images, zero stress.
                  </p>
                  <ul className="space-y-3 font-inter text-sm text-luxury-black/70">
                    <li>10–15 selfies in</li>
                    <li>30 AI images out</li>
                    <li>No studio, just you</li>
                    <li>Upgrade later, credit saved</li>
                  </ul>
                </div>
                <Link
                  href="/ai-images"
                  className="inline-block w-full text-center font-inter text-sm tracking-[0.2em] uppercase text-luxury-black hover:text-luxury-black/70 transition-colors duration-300 py-4 border border-luxury-black hover:bg-luxury-black hover:text-soft-white mt-10 relative z-10"
                >
                  Try it now
                </Link>
              </div>

              {/* Card 2: SSELFIE Studio */}
              <div className="bg-luxury-black text-soft-white p-8 md:p-12 flex flex-col h-full justify-between relative overflow-hidden">
                {/* Background Editorial Image */}
                <div className="absolute top-0 right-0 w-32 h-32 opacity-5">
                  <Image 
                    src={SandraImages.flatlays.workspace2} 
                    alt=""
                    fill
                    className="object-cover"
                    sizes="128px"
                  />
                </div>
                <div className="absolute top-4 right-4 z-20">
                  <span className="bg-soft-white text-luxury-black px-3 py-1 text-xs tracking-wider uppercase">
                    Most popular
                  </span>
                </div>
                <div className="relative z-10">
                  <span className="font-inter text-xs tracking-[0.3em] uppercase text-soft-white/60 mb-4 block">
                    The full experience
                  </span>
                  <h3 className="font-bodoni text-3xl md:text-4xl font-light text-soft-white mb-4">
                    SSELFIE STUDIO
                  </h3>
                  <div className="space-y-2 mb-6">
                    <div className="flex items-baseline">
                      <span className="font-bodoni text-5xl font-light text-soft-white">€97</span>
                      <span className="font-inter text-sm text-soft-white/60 ml-2">/month</span>
                    </div>
                    <p className="font-inter text-xs text-soft-white/60">
                      Founding Member (first 100) • Locks in price
                    </p>
                    <p className="font-inter text-xs text-soft-white/50">
                      Standard: €147/month
                    </p>
                  </div>
                  <p className="font-inter text-base text-soft-white/90 leading-relaxed mb-6">
                    Everything. Unlimited images. Your own page. Sandra in your pocket.
                  </p>
                  <ul className="space-y-3 font-inter text-sm text-soft-white/80">
                    <li>Unlimited SSELFIES</li>
                    <li>Luxury landing page</li>
                    <li>Bookings & payments</li>
                    <li>Sandra AI chat</li>
                    <li>Priority help</li>
                  </ul>
                </div>
                <Link
                  href="/studio"
                  className="inline-block w-full text-center font-inter text-sm tracking-[0.2em] uppercase text-soft-white hover:text-soft-white/70 transition-colors duration-300 py-4 border border-soft-white hover:bg-soft-white hover:text-luxury-black mt-10 relative z-10"
                >
                  Start today
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* 5. Editorial Gallery - Process/Proof */}
        <section className="py-16 md:py-24 bg-soft-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-7xl">
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
              <div className="aspect-square relative">
                <Image 
                  src={SandraImages.flatlays.workspace1}
                  alt="Behind the scenes"
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 50vw, (max-width: 1024px) 33vw, 25vw"
                />
              </div>
              <div className="aspect-square relative">
                <Image 
                  src={SandraImages.editorial.phone1}
                  alt="Creating content"
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 50vw, (max-width: 1024px) 33vw, 25vw"
                />
              </div>
              <div className="aspect-square relative">
                <Image 
                  src={SandraImages.flatlays.beauty}
                  alt="Process details"
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 50vw, (max-width: 1024px) 33vw, 25vw"
                />
              </div>
              <div className="aspect-square relative">
                <Image 
                  src={SandraImages.editorial.mirror}
                  alt="Transformation"
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 50vw, (max-width: 1024px) 33vw, 25vw"
                />
              </div>
              <div className="aspect-square relative">
                <Image 
                  src={SandraImages.flatlays.planning}
                  alt="Strategy"
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 50vw, (max-width: 1024px) 33vw, 25vw"
                />
              </div>
              <div className="aspect-square relative">
                <Image 
                  src={SandraImages.editorial.laughing}
                  alt="Joy in the process"
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 50vw, (max-width: 1024px) 33vw, 25vw"
                />
              </div>
              <div className="aspect-square relative">
                <Image 
                  src={SandraImages.flatlays.workspace2}
                  alt="Workspace setup"
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 50vw, (max-width: 1024px) 33vw, 25vw"
                />
              </div>
              <div className="aspect-square relative">
                <Image 
                  src={SandraImages.journey.building}
                  alt="Building phase"
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 50vw, (max-width: 1024px) 33vw, 25vw"
                />
              </div>
            </div>
          </div>
        </section>

        {/* 6. Why This Price */}
        <section className="py-20 md:py-32 bg-pure-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-4xl">
            <div className="text-center space-y-12">
              {/* Editorial Eyebrow */}
              <span className="font-inter text-xs tracking-[0.4em] uppercase text-luxury-black/50 block">
                THE REAL CONVERSATION
              </span>
              
              {/* Main Quote - Editorial Style */}
              <h2 className="font-bodoni text-3xl md:text-4xl lg:text-5xl font-light text-luxury-black leading-tight max-w-3xl mx-auto">
                You&apos;re not buying pixels.<br />
                You&apos;re claiming your story.
              </h2>
              
              {/* Supporting Copy */}
              <div className="space-y-8 max-w-2xl mx-auto">
                <p className="font-inter text-lg md:text-xl text-luxury-black/70 leading-relaxed">
                  Not ready for the full studio? Start with your SSELFIE images.
                </p>
                <p className="font-inter text-base md:text-lg text-luxury-black/60 leading-relaxed">
                  Try it, see the magic. Come back when you&apos;re ready for main character energy.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* 7. Testimonials Section */}
        <EditorialTestimonials />

        {/* 8. Final Image Break */}
        <ImageBreak 
          src={SandraImages.journey.success}
          alt="Sandra today - radiant, main character energy"
        />

        {/* 9. Final CTA */}
        <section className="py-20 md:py-32 bg-soft-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-4xl text-center">
            <span className="font-inter text-xs tracking-[0.3em] uppercase text-luxury-black/50 mb-6 block">
              READY TO TRANSFORM
            </span>
            <h2 className="font-bodoni text-4xl md:text-5xl lg:text-6xl font-light text-luxury-black mb-8">
              START NOW
            </h2>
            <p className="font-inter text-lg font-light text-luxury-black/70 leading-relaxed mb-12 max-w-2xl mx-auto">
              Face, story, twenty minutes. That&apos;s it.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 items-center justify-center">
              <Link
                href="/studio"
                className="inline-block font-inter text-sm tracking-[0.2em] uppercase text-luxury-black hover:text-luxury-black/70 transition-colors duration-300 px-8 py-4 border border-luxury-black hover:bg-luxury-black hover:text-soft-white"
              >
                Start your studio
              </Link>
              <Link
                href="/ai-images"
                className="inline-block font-inter text-sm tracking-[0.2em] uppercase text-luxury-black/60 hover:text-luxury-black transition-colors duration-300 px-8 py-4 border border-luxury-black/20 hover:border-luxury-black"
              >
                Just the images
              </Link>
            </div>
          </div>
        </section>
      </div>
      
      <Footer />
    </>
  )
}
