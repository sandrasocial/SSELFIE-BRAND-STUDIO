# SSELFIE Pricing Page Assembly Plan  
*For Diana – Editorial, Luxe, & Effortlessly Custom*

---

## 1. HERO SECTION (First Impression)

- **Component:** `/components/global/HeroFullBleed.tsx`
- **Image:** `SandraImages.hero.pricing` (full-bleed, editorial)
- **Tagline:**  
  `Ready to show the world who you are? Let’s do it together.`
- **Headline:**  
  `Pricing`
- **CTA Button:**  
  - Text: `Show up as her`
  - Link: `#pricing-options`
- **NO subheading. No overlays on the image.**
- **Styling:**  
  - Tons of air.  
  - Negative space.  
  - No busy overlays—let the image breathe.

---

## 2. EDITORIAL SPREAD (Sandra’s Story)

- **Component:** `/components/sections/editorial/EditorialSpread.tsx`
- **Left:**  
  - Image: `SandraImages.editorial.laptop1` (Sandra working, not posed)
- **Right:**  
  - Headline: `Okay, here’s what actually happened…`
  - Body: Sandra’s origin story (see below)
    ```
    This didn’t start as a business.  
    It started as survival.

    One year ago, I hit rock bottom. Divorced. Three kids. No backup plan.  
    I was heartbroken, exhausted, and completely disconnected from the woman I used to be.

    And one day, in the middle of all that mess—I picked up my phone.  
    Took a selfie. Posted something honest. Not perfect. Just true.

    That one moment sparked something.  
    I didn’t need a full plan. I needed one brave post. One real story. One step back to myself.
    ```
- **Styling:**  
  - Let the image take up at least 40% of the width.
  - Use Sandra’s serif headline style (see style guide).

---

## 3. IMAGE BREAK (Visual Breather)

- **Component:** `/components/sections/about/ImageBreak.tsx`
- **Image:** `SandraImages.editorial.contemplative` (Sandra looking away, candid, or flatlay: coffee, hands, workspace)
- **Purpose:**  
  - Visual pause.  
  - No text over image.  
  - Feels like flipping the page in Vogue.

---

## 4. PRICING OPTIONS (Editorial Cards Grid)

- **Component:** `/components/ui/OfferCardsGrid.tsx`
  - Or: Duplicate `/components/business/PricingCard.tsx` for 2-3 offers.
- **Each Card:**  
  - **Image:**  
    - “Future Self” → `SandraImages.editorial.phoneSelfie`
    - “SSELFIE Studio” → `SandraImages.editorial.studioDesk`
  - **Title/Label/Badge:**  
    - Card 1:  
      - Top Label: `Just the selfies`  
      - Badge: `Try it`
      - Title: `Future Self`
      - Price: `€47` (one-time)
      - Description: `Upload. Wait. Wow. 30 images, zero stress.`
      - List: `10–15 selfies in`, `30 AI images out`, `No studio, just you`, `Upgrade later, credit saved`
      - CTA: `Try it now` → `/ai-images`
    - Card 2:  
      - Top Label: `The full experience`  
      - Badge: `Most popular`
      - Title: `SSELFIE Studio`
      - Price: `€97/month`
      - Description: `Everything. Unlimited images. Your own page. Sandra in your pocket.`
      - List: `Unlimited SSELFIES`, `Luxury landing page`, `Bookings & payments`, `Sandra AI chat`, `Priority help`
      - Subtext: `Founding Member (first 100) • Locks in price`  
        `Standard: €147/month`
      - CTA: `Start today` → `/studio`
- **Styling:**  
  - Two cards side by side (desktop), stacked on mobile.
  - Each card has a unique, editorial image.
  - Use air between cards.

---

## 5. EDITORIAL GALLERY (Process/Proof)

- **Component:** `/components/sections/about/EditorialGallery.tsx`
- **Images:**  
  - 6-8 images: behind-the-scenes, hands, workspace, Sandra with phone, transformation process, flatlays.
  - All from `SandraImages.editorial` or `SandraImages.process`
- **Purpose:**  
  - Show real process, not just product.
- **Styling:**  
  - Grid or collage, lots of negative space.

---

## 6. WHY THIS PRICE (Minimal Editorial Quote)

- **Component:** Simple `<div>` or `/components/sections/editorial/PowerQuote.tsx`
- **Copy:**  
  ```
  You’re not buying pixels. You’re claiming your story.

  Not ready for the full studio? Start with your SSELFIE images. Try it, see the magic.
  Come back when you’re ready for main character energy.
  ```
- **Styling:**  
  - Centered, max 600px width.
  - Muted gray or white background.
  - No image—just air.

---

## 7. EDITORIAL MOODBOARD (Transformation)

- **Component:** `/components/sections/editorial/EditorialMoodboard.tsx`
- **Images:**  
  - 6-8 mixed: transformation before/after, candid details, luxury textures.
- **Purpose:**  
  - Visual proof of transformation.
- **Styling:**  
  - Grid, not crowded.

---

## 8. TESTIMONIALS (Optional)

- **Component:** `/components/sections/editorial/EditorialTestimonials.tsx`
- **Copy:**  
  - Use real client quotes (provided by Sandra—no stock).
- **Styling:**  
  - Editorial, minimal, no portraits unless available.

---

## 9. FINAL IMAGE BREAK

- **Component:** `/components/sections/about/ImageBreak.tsx`
- **Image:** `SandraImages.editorial.successPortrait` (Sandra today—radiant, main character energy)
- **Purpose:**  
  - Pre-CTA visual exhale.

---

## 10. FINAL CTA

- **Component:** `/components/sections/about/FinalCTA.tsx`  
  - Or build with `/components/ui/SectionHeadline.tsx` + `/components/ui/button.tsx`
- **Tagline:** `Ready to transform`
- **Headline:** `Start now`
- **Copy:**  
  `Face, story, twenty minutes. That’s it.`
- **Buttons:**  
  - `Start your studio` → `/studio`
  - `Just the images` → `/ai-images`
- **Styling:**  
  - Minimal, all caps CTA, max 700px wide, centered.

---

## GENERAL RULES (Diana, don’t skip these):

- **Each section = its own component/block for easy editing.**
- **Never repeat an image on the same page.**
- **Copy = always Sandra: honest, warm, never “salesy.”**
- **Editorial spacing = luxury (add more air if it feels crowded).**
- **All images from `/components/sandra-image-library.ts` (use the keys above).**
- **Every button styled per the Editorial Style Guide.**
- **If unsure, ask: “Would Sandra actually say this to a friend?”**

---

## 💡 Need a visual? Think:  
*Vogue meets Notion, but with Sandra’s warmth. Every scroll = a new breath of air, a new reason to trust her.*

---

*Victoria & Sandra’s rule: If you feel lost, add more space, swap the image, or rewrite the copy as if you were texting your best friend. That’s the fix, every time.*

ALL HEADLINES AND TAGLINES USES UPPERCASE