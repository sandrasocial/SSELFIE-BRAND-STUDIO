import { Metadata } from 'next'
import { GenericCard } from '@/components/ui/generic-card'
import { SectionHeadline } from '@/components/ui/SectionHeadline'
import Button from '@/components/ui/button'
import { CheckCircle, Upload, User, Calendar, Zap, ArrowRight } from 'lucide-react'

export const metadata: Metadata = {
  title: 'Get Started - SSELFIE Studio',
  description: 'Welcome to SSELFIE Studio! Follow these simple steps to set up your account and start your personal brand transformation.',
}

const steps = [
  {
    number: '01',
    title: 'Upload Your Selfies',
    description: 'Upload 5-10 current selfies from different angles and lighting. The more variety, the better your AI generations will be.',
    icon: Upload,
    action: 'Upload Now',
    time: '2 minutes'
  },
  {
    number: '02', 
    title: 'Complete Your Profile',
    description: 'Tell us about your industry, goals, and brand style preferences. This helps us create the perfect images for your needs.',
    icon: User,
    action: 'Complete Profile',
    time: '3 minutes'
  },
  {
    number: '03',
    title: 'Schedule Your Strategy Call',
    description: 'Book your first strategy session with Sandra\'s team to plan your brand transformation and set up your studio page.',
    icon: Calendar,
    action: 'Book Call',
    time: '1 minute'
  },
  {
    number: '04',
    title: 'Generate Your First Images',
    description: 'Start creating your professional AI images. Choose from multiple styles and see your future self come to life.',
    icon: Zap,
    action: 'Generate Images',
    time: '30 seconds'
  }
]

const quickTips = [
  {
    title: 'Best Selfie Tips',
    tips: [
      'Good lighting (natural light works best)',
      'Clear, front-facing shots',
      'Variety of expressions and angles',
      'High resolution (no blurry images)',
      'Minimal makeup and filters'
    ]
  },
  {
    title: 'Profile Setup Tips',
    tips: [
      'Be specific about your industry',
      'Think about your ideal client',
      'Consider where you\'ll use the images',
      'Choose styles that match your goals',
      'Don\'t hold back on your ambitions'
    ]
  }
]

export default function GetStartedPage() {
  return (
    <main className="min-h-screen bg-[#171719]">
      {/* Hero Section */}
      <section className="pt-32 pb-24 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="mb-8">
            <span className="text-[#B5B5B3] text-sm font-medium uppercase tracking-wider">
              Welcome To SSELFIE Studio
            </span>
          </div>
          
          <h1 className="font-['Bodoni_FLF'] text-5xl md:text-7xl text-[#F1F1F1] mb-8 leading-tight">
            Your Transformation
            <br />
            <span className="text-[#B5B5B3]">Starts Now</span>
          </h1>
          
          <p className="text-xl text-[#B5B5B3] mb-12 max-w-2xl mx-auto leading-relaxed">
            Follow these simple steps to set up your account and start creating stunning 
            professional images that elevate your personal brand.
          </p>
          
          <div className="bg-[#F1F1F1]/10 border border-[#F1F1F1]/20 rounded-lg p-6 max-w-xl mx-auto">
            <div className="flex items-center gap-3 mb-3">
              <CheckCircle className="w-6 h-6 text-[#F1F1F1]" />
              <span className="text-[#F1F1F1] font-semibold">Account Created Successfully</span>
            </div>
            <p className="text-[#B5B5B3] text-sm">
              Welcome aboard! Let's get you set up in just a few minutes.
            </p>
          </div>
        </div>
      </section>

      {/* Setup Steps */}
      <section className="py-24 px-4 border-t border-[#B5B5B3]/20">
        <div className="max-w-6xl mx-auto">
          <SectionHeadline 
            title="Quick Setup Guide"
            subtitle="4 simple steps to get started"
          />
          
          <div className="space-y-8 mt-16">
            {steps.map((step, index) => (
              <GenericCard key={index} className="p-8 bg-[#171719] border-[#B5B5B3]/20">
                <div className="flex flex-col md:flex-row gap-8 items-center">
                  <div className="flex-shrink-0">
                    <div className="w-20 h-20 bg-[#F1F1F1] rounded-full flex items-center justify-center">
                      <step.icon className="w-10 h-10 text-[#171719]" />
                    </div>
                  </div>
                  
                  <div className="flex-grow text-center md:text-left">
                    <div className="flex items-center gap-4 mb-4 justify-center md:justify-start">
                      <span className="font-['Bodoni_FLF'] text-3xl text-[#B5B5B3]">
                        {step.number}
                      </span>
                      <h3 className="font-['Bodoni_FLF'] text-2xl text-[#F1F1F1]">
                        {step.title}
                      </h3>
                    </div>
                    <p className="text-[#B5B5B3] text-lg leading-relaxed mb-4">
                      {step.description}
                    </p>
                    <div className="text-[#B5B5B3] text-sm">
                      Estimated time: {step.time}
                    </div>
                  </div>
                  
                  <div className="flex-shrink-0">
                    <Button 
                      size="lg"
                      className="bg-[#F1F1F1] text-[#171719] hover:bg-[#B5B5B3] px-8 py-3 font-semibold flex items-center gap-2"
                    >
                      {step.action}
                      <ArrowRight className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </GenericCard>
            ))}
          </div>
        </div>
      </section>

      {/* Quick Tips */}
      <section className="py-24 px-4 border-t border-[#B5B5B3]/20">
        <div className="max-w-6xl mx-auto">
          <SectionHeadline 
            title="Pro Tips For Best Results"
            subtitle="Get the most out of your SSELFIE Studio experience"
          />
          
          <div className="grid md:grid-cols-2 gap-12 mt-16">
            {quickTips.map((tipSection, index) => (
              <GenericCard key={index} className="p-8 bg-[#171719] border-[#B5B5B3]/20">
                <h3 className="font-['Bodoni_FLF'] text-2xl text-[#F1F1F1] mb-6">
                  {tipSection.title}
                </h3>
                <div className="space-y-4">
                  {tipSection.tips.map((tip, tipIndex) => (
                    <div key={tipIndex} className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-[#F1F1F1] mt-0.5 flex-shrink-0" />
                      <span className="text-[#B5B5B3]">{tip}</span>
                    </div>
                  ))}
                </div>
              </GenericCard>
            ))}
          </div>
        </div>
      </section>

      {/* Support Section */}
      <section className="py-24 px-4 border-t border-[#B5B5B3]/20">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="font-['Bodoni_FLF'] text-4xl md:text-5xl text-[#F1F1F1] mb-8">
            Need Help Getting
            <br />
            <span className="text-[#B5B5B3]">Started?</span>
          </h2>
          
          <p className="text-xl text-[#B5B5B3] mb-12 max-w-2xl mx-auto">
            Our team is here to support you every step of the way. 
            Don't hesitate to reach out if you have any questions.
          </p>
          
          <div className="grid md:grid-cols-3 gap-8">
            <GenericCard className="p-6 bg-[#171719] border-[#B5B5B3]/20 text-center">
              <h3 className="font-['Bodoni_FLF'] text-xl text-[#F1F1F1] mb-3">
                Live Chat
              </h3>
              <p className="text-[#B5B5B3] mb-4">
                Available 9AM-6PM EST
              </p>
              <Button 
                variant="outline"
                size="sm"
                className="border-[#F1F1F1] text-[#F1F1F1] hover:bg-[#F1F1F1] hover:text-[#171719]"
              >
                Start Chat
              </Button>
            </GenericCard>
            
            <GenericCard className="p-6 bg-[#171719] border-[#B5B5B3]/20 text-center">
              <h3 className="font-['Bodoni_FLF'] text-xl text-[#F1F1F1] mb-3">
                Email Support
              </h3>
              <p className="text-[#B5B5B3] mb-4">
                Response within 2 hours
              </p>
              <Button 
                variant="outline"
                size="sm"
                className="border-[#F1F1F1] text-[#F1F1F1] hover:bg-[#F1F1F1] hover:text-[#171719]"
              >
                Send Email
              </Button>
            </GenericCard>
            
            <GenericCard className="p-6 bg-[#171719] border-[#B5B5B3]/20 text-center">
              <h3 className="font-['Bodoni_FLF'] text-xl text-[#F1F1F1] mb-3">
                Video Tutorials
              </h3>
              <p className="text-[#B5B5B3] mb-4">
                Step-by-step guides
              </p>
              <Button 
                variant="outline"
                size="sm"
                className="border-[#F1F1F1] text-[#F1F1F1] hover:bg-[#F1F1F1] hover:text-[#171719]"
              >
                Watch Now
              </Button>
            </GenericCard>
          </div>
        </div>
      </section>

      {/* Next Steps CTA */}
      <section className="py-24 px-4 border-t border-[#B5B5B3]/20">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="font-['Bodoni_FLF'] text-4xl md:text-5xl text-[#F1F1F1] mb-8">
            Ready To Begin Your
            <br />
            <span className="text-[#B5B5B3]">Transformation?</span>
          </h2>
          
          <p className="text-xl text-[#B5B5B3] mb-12 max-w-2xl mx-auto">
            Your future self is waiting. Let's create the professional images 
            that will elevate your personal brand and transform how the world sees you.
          </p>
          
          <Button 
            size="lg" 
            className="bg-[#F1F1F1] text-[#171719] hover:bg-[#B5B5B3] px-12 py-4 text-lg font-semibold"
          >
            Start Step 1: Upload Selfies
          </Button>
          
          <div className="text-[#B5B5B3] text-sm mt-8">
            <p>Step 1 of 4 • Takes about 2 minutes</p>
          </div>
        </div>
      </section>
    </main>
  )
}
