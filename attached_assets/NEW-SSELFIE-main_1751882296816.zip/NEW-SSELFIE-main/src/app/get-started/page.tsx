import { Metadata } from 'next'
import Navigation from '@/components/global/Navigation'
import { Footer } from '@/components/global/Footer'
import { HeroFullBleed } from '@/components/sections/hero/HeroFullBleed'
import OnboardingSteps from '@/components/business/OnboardingSteps'
import OfferCardsGrid from '@/components/ui/OfferCardsGrid'
import { SandraImages } from '@/components/sandra-image-library'

export const metadata: Metadata = {
  title: 'Get Started | SSELFIE Studio',
  description: 'Start your personal brand transformation journey with SSELFIE Studio in just a few simple steps.',
}

const getStartedSteps = [
  {
    number: 1,
    title: "Choose Your Service",
    description: "Select from AI image generation, Studio membership, or personal brand strategy sessions."
  },
  {
    number: 2, 
    title: "Upload Your Photos",
    description: "Share 5-10 current selfies from different angles for the best AI generation results."
  },
  {
    number: 3,
    title: "Complete Your Profile", 
    description: "Tell us about your industry, goals, and brand style preferences to personalize your experience."
  },
  {
    number: 4,
    title: "Start Your Transformation",
    description: "Get your AI images, strategy session, or begin your Studio membership journey."
  }
]

export default function GetStartedPage() {
  return (
    <>
      {/* Navigation */}
      <Navigation />
      
      <main>
        {/* Hero Section */}
        <HeroFullBleed
          backgroundImage={SandraImages.hero.dashboard}
          tagline="Your transformation starts here"
          title="GET"
          subtitle="STARTED"
          ctaText="Begin Journey"
          ctaLink="#start-options"
        />

        {/* Quick Start Options */}
        <section className="py-16 px-4 bg-white">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="font-['Bodoni_FLF'] text-3xl md:text-4xl text-[#171719] mb-4">
                Choose Your Starting Point
              </h2>
              <p className="text-lg text-[#B5B5B3] max-w-2xl mx-auto">
                Select the service that best fits your current needs and goals
              </p>
            </div>
            <OfferCardsGrid />
          </div>
        </section>

        {/* Getting Started Process */}
        <section className="py-24 px-4 bg-[#F1F1F1]">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="font-['Bodoni_FLF'] text-4xl md:text-5xl text-[#171719] mb-6">
                How to Get Started
              </h2>
              <p className="text-xl text-[#B5B5B3] max-w-2xl mx-auto">
                Your transformation begins with these four simple steps
              </p>
            </div>
            <OnboardingSteps steps={getStartedSteps} />
          </div>
        </section>
      </main>

      {/* Footer */}
      <Footer />
    </>
  )
}
