import React from "react";
import Image from "next/image";
import Link from "next/link";
import { SandraImages } from "@/components/sandra-image-library";
import Button from "@/components/ui/button";

export default function FreebieGuide() {
  // Example images for grids (replace with real SandraImages paths)
  const lightGridImages = [
    SandraImages.editorial.laptop1,
    SandraImages.editorial.laptop2,
    SandraImages.editorial.phone1,
    SandraImages.editorial.mirror,
  ];

  const anglesGridImages = [
    SandraImages.editorial.phone2,
    SandraImages.editorial.laughing,
    SandraImages.editorial.thinking,
    SandraImages.editorial.firstAI,
  ];

  const editingGridImages = [
    SandraImages.editorial.aiInProgress,
    SandraImages.flatlays.beauty,
    SandraImages.flatlays.workspace1,
    SandraImages.flatlays.planning,
  ];

  const confidenceGridImages = [
    SandraImages.editorial.mirror,
    SandraImages.editorial.laptop1,
    SandraImages.editorial.laughing,
    SandraImages.editorial.thinking,
  ];

  const hashtagList = [
    "#SelfieQueen",
    "#GlowUp",
    "#SelfLoveClub",
    "#ContentCreator",
    "#ConfidenceBoost",
    "#PersonalBrand",
    "#AuthenticBeauty"
  ];

  return (
    <main className="bg-white">
      {/* Cover */}
      <section className="relative min-h-[60vh] bg-black flex items-center justify-center text-center px-6 pb-12">
        <Image
          src="https://i.postimg.cc/d0MV1PLq/IMG-8465-jpg.jpg"
          alt="Sandra confidently taking a selfie"
          fill
          className="object-cover opacity-30"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 to-black/80" />
        <div className="relative z-10 max-w-3xl mx-auto">
          <span className="text-xs uppercase tracking-[0.6em] text-white/80 block mb-6">
            SELFIE AI™
          </span>
          <h1 className="font-serif text-[3.5rem] md:text-[7rem] leading-[0.85] font-[300] text-white mb-2 tracking-[-0.04em]">
            SELFIE
          </h1>
          <p className="font-serif italic text-[2.5rem] md:text-[5rem] text-white mb-4">Queen</p>
          <p className="font-sans text-2xl text-white/80 mb-8 tracking-wide">
            Your guide to camera confidence
          </p>
          <div className="flex flex-wrap gap-4 justify-center items-baseline mt-12">
            <span className="uppercase text-xs tracking-[0.3em] font-sans text-white">
              pose till you glow
            </span>
            <span className="uppercase text-xs tracking-[0.4em] font-sans text-white/70">
              by Sandra
            </span>
          </div>
        </div>
      </section>

      {/* Intro */}
      <section className="bg-[#fafafa] py-24 px-6">
        <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="font-serif text-5xl md:text-6xl font-[300] leading-tight mb-8 -rotate-2">
              Hey,<br />I'm<br />Sandra
            </h2>
            <p className="font-serif italic text-xl text-soft-gray mb-8">
              Your one and only IG Selfie queen
            </p>
          </div>
          <div className="relative min-h-[320px] flex items-center">
            <Image
              src="https://i.postimg.cc/y8DtsRWp/1.png"
              alt="Sandra selfie"
              fill
              className="object-cover rounded-lg"
            />
            <div className="absolute inset-0 bg-white/80 md:bg-white/70" />
            <div className="relative z-10 p-6 md:p-12 font-sans text-lg text-black">
              <p className="mb-6">
                Struggling to take a selfie that actually looks good? I&apos;ve got you. In this guide, I&apos;ll share my best tips on lighting, angles, posing, and editing, so you can snap stunning, confident selfies every time.
              </p>
              <p className="mb-6">
                I create all my content using just my iPhone, a ring light, and editing apps like CapCut, Lightroom, and Hypic—and you can too. No fancy equipment needed.
              </p>
              <p className="mb-4">
                By the end, you&apos;ll have the skills to take scroll-stopping selfies effortlessly. Let&apos;s turn you into a Selfie Queen.
              </p>
              <p className="font-serif italic text-xl text-right">Sandra xoxo</p>
            </div>
          </div>
        </div>
      </section>

      {/* Table of Contents */}
      <section className="py-20 px-6 bg-white">
        <div className="max-w-4xl mx-auto">
          <span className="font-sans text-xs uppercase tracking-[0.4em] text-soft-gray block mb-4">
            Contents
          </span>
          <h2 className="font-serif text-3xl md:text-4xl font-[300] tracking-[-0.04em] mb-10">
            Table of Contents
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 border-t border-accent-line">
            {[
              ["01", "Camera Mastery", "Understanding your phone camera settings"],
              ["02", "The Art of Light", "Natural vs. artificial light mastery"],
              ["03", "Angles & Presence", "Find your best side"],
              ["04", "Editorial Editing", "Apps and techniques for pro results"],
              ["05", "Confidence & Power", "Embrace your unique beauty"],
              ["06", "Social Strategy", "Stand out and grow your brand"],
            ].map(([num, title, desc]) => (
              <div key={num} className="flex gap-6 py-8 border-b border-accent-line last:border-b-0">
                <span className="font-serif italic text-5xl text-soft-gray">{num}</span>
                <div>
                  <h3 className="font-serif text-xl mb-1">{title}</h3>
                  <p className="text-soft-gray text-sm">{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Welcome */}
      <section className="py-20 px-6 bg-[#fafafa]">
        <div className="max-w-3xl mx-auto">
          <h2 className="font-serif text-4xl md:text-5xl font-[300] mb-8">
            Welcome to My <br />Selfie World
          </h2>
          <p className="font-sans text-xl mb-8">
            Let&apos;s be real, selfies are everywhere. Whether you&apos;re snapping a quick pic to check your makeup, capturing a memory with friends, or posting on social media, selfies are part of how we show up in the world today.
          </p>
          <div className="grid md:grid-cols-2 gap-12 mb-8">
            <div>
              <p className="mb-6">
                And yet, somehow, no one ever really teaches us how to take a good one. We just kind of wing it, hoping for the best, deleting 50 shots before we get the one (we&apos;ve all been there).
              </p>
              <p>
                But what if I told you that taking a great selfie isn&apos;t about luck? It&apos;s about knowing a few simple tricks that can completely transform your photos, from meh to magazine-worthy.
              </p>
            </div>
            <div>
              <p className="mb-6">
                That&apos;s exactly what this guide is all about. I&apos;m here to show you how to master lighting, angles, posing, and editing so you can take selfies that make you feel confident, beautiful, and unapologetically you.
              </p>
              <p>
                Whether you want to level up your Instagram game, boost your personal brand, or just feel amazing in your own skin, I&apos;ve got you covered.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Camera Mastery */}
      <section className="py-24 px-6 bg-white">
        <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-16 items-center">
          <div>
            <span className="font-sans text-xs uppercase tracking-[0.4em] text-soft-gray block mb-4">
              Chapter 01
            </span>
            <h2 className="font-serif text-3xl md:text-5xl font-[300] mb-4">Camera Mastery</h2>
            <p className="font-serif italic text-lg text-black/70 mb-6">
              Small tweaks, major difference. Let&apos;s unlock your camera&apos;s full potential.
            </p>
            <ul className="mb-8 space-y-3">
              <li>• Go to Settings → Camera</li>
              <li>• Tap on Formats → High Efficiency</li>
              <li>• Enable ProRAW & Resolution Control</li>
              <li>• Turn on Preserve Settings</li>
              <li>• Enable Grid Lines for perfect composition</li>
              <li>• Activate Portrait Mode settings</li>
            </ul>
            <div className="bg-[#fafafa] border-l-4 border-black/10 p-6 mb-8">
              <h4 className="font-serif text-2xl mb-3">Pro Camera Tips</h4>
              <ul className="list-disc pl-5 space-y-1 text-soft-gray">
                <li>Clean your lens—sounds basic, but it makes your photos way sharper</li>
                <li>Use Portrait Mode sparingly—blurred background = pro look (but don&apos;t overdo it)</li>
                <li>Self-timer is your best friend for hands-free selfies on a tripod</li>
                <li>Test different camera modes to find what works for your style</li>
              </ul>
            </div>
            <p className="text-xs uppercase tracking-[0.3em] text-soft-gray mt-4">Settings Matter</p>
          </div>
          <div>
            <div className="grid grid-cols-2 gap-4">
              {lightGridImages.map((src, i) => (
                <div key={i} className="aspect-[3/4] relative rounded-lg overflow-hidden">
                  <Image
                    src={src}
                    alt="Lighting grid example"
                    fill
                    className="object-cover"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* The Art of Light */}
      <section className="py-24 px-6 bg-[#fafafa]">
        <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-16 items-center">
          <div>
            <div className="grid grid-cols-2 gap-4 mb-8">
              {lightGridImages.reverse().map((src, i) => (
                <div key={i} className="aspect-[3/4] relative rounded-lg overflow-hidden">
                  <Image
                    src={src}
                    alt="Sandra lighting example"
                    fill
                    className="object-cover"
                  />
                </div>
              ))}
            </div>
          </div>
          <div>
            <span className="font-sans text-xs uppercase tracking-[0.4em] text-soft-gray block mb-4">
              Chapter 02
            </span>
            <h2 className="font-serif text-3xl md:text-5xl font-[300] mb-4">The Art of Light</h2>
            <p className="font-serif italic text-lg text-black/70 mb-6">
              Light can make or break your selfie. Master it, and you&apos;ll never take a bad photo again.
            </p>
            <div className="mb-6">
              <h3 className="font-serif text-xl mb-2">Natural Light Magic</h3>
              <p className="mb-4">
                Soft, indirect sunlight is the best. Stand near a window or go outside for the most flattering glow. Golden hour? That&apos;s your best friend.
              </p>
              <h3 className="font-serif text-xl mb-2">My Lighting Setup</h3>
              <ul className="list-disc pl-5 space-y-1 mb-2">
                <li>Ring light positioned directly in front</li>
                <li>Two softboxes on both sides</li>
                <li>All overhead lighting turned OFF</li>
                <li>Mirror light behind for dimension</li>
              </ul>
            </div>
            <div className="bg-black text-white rounded-lg px-8 py-6 flex flex-col gap-3">
              <span className="uppercase tracking-[0.3em] text-xs mb-2">Pro Tip</span>
              <span className="text-lg font-serif italic">Golden hour gives everything a warm, forgiving glow that no filter can replicate.</span>
            </div>
          </div>
        </div>
      </section>

      {/* Pull Quote */}
      <section className="py-24 px-6 bg-black flex items-center justify-center text-center">
        <div className="max-w-3xl mx-auto">
          <p className="font-serif italic text-4xl md:text-6xl text-white mb-8 leading-tight">
            Keep pushing<br />boundaries<br />& never stop evolving
          </p>
          <span className="font-sans text-xs uppercase tracking-[0.4em] text-white/70">SELFIE AI™</span>
        </div>
      </section>

      {/* Angles & Presence */}
      <section className="py-24 px-6 bg-white">
        <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-16 items-center">
          <div>
            <span className="font-sans text-xs uppercase tracking-[0.4em] text-soft-gray block mb-4">
              Chapter 03
            </span>
            <h2 className="font-serif text-3xl md:text-5xl font-[300] mb-4">Angles & Presence</h2>
            <p className="font-serif italic text-lg text-black/70 mb-6">
              Your best angle is the one where you feel most confident. Let&apos;s find it together.
            </p>
            <div className="bg-[#fafafa] border-l-4 border-black/10 p-6 mb-8">
              <h4 className="font-serif text-2xl mb-3">Universal Angle Truths</h4>
              <ul className="list-disc pl-5 space-y-1 text-soft-gray">
                <li>Experiment—take selfies from different angles to see what flatters your face shape most</li>
                <li>Slight tilt—tilting your head slightly creates a more natural and dynamic look</li>
                <li>Hold your phone higher—a slightly elevated angle elongates your features</li>
                <li>Push your chin forward—feels weird, looks amazing (trust me)</li>
                <li>Angle your shoulders—turning slightly instead of facing straight on</li>
              </ul>
            </div>
            <div>
              <h3 className="font-serif text-xl mb-2">The Power of Expression</h3>
              <p>
                Your face tells the story. Play with emotions—a little smirk, a bold gaze, or a full smile can completely change the vibe. Not every selfie needs direct eye contact; looking away adds intrigue.
              </p>
            </div>
            <p className="text-xs uppercase tracking-[0.3em] text-soft-gray mt-4">Confidence is key</p>
          </div>
          <div>
            <div className="grid grid-cols-2 gap-4">
              {anglesGridImages.map((src, i) => (
                <div key={i} className="aspect-[3/4] relative rounded-lg overflow-hidden">
                  <Image
                    src={src}
                    alt="Sandra angles example"
                    fill
                    className="object-cover"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA - Try AI Images */}
      <section className="py-16 px-6 bg-[#fafafa] text-center">
        <div className="max-w-xl mx-auto">
          <h3 className="font-serif text-3xl mb-4">Want pro selfies in minutes?</h3>
          <p className="font-sans text-lg mb-8 text-soft-gray">
            Try SSELFIE AI Images—upload 10 selfies, get 30 luxury photos back. No studio, no stress, all you.
          </p>
          <Link href="/ai-images">
            <Button className="bg-black text-white px-10 py-3 text-xs uppercase tracking-[0.3em] rounded-none border-2 border-black hover:bg-white hover:text-black transition">
              Try AI Images
            </Button>
          </Link>
        </div>
      </section>

      {/* Editorial Editing */}
      <section className="py-24 px-6 bg-white">
        <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-16 items-center">
          <div>
            <div className="grid grid-cols-2 gap-4 mb-8">
              {editingGridImages.map((src, i) => (
                <div key={i} className="aspect-[3/4] relative rounded-lg overflow-hidden">
                  <Image
                    src={src}
                    alt="Sandra editing example"
                    fill
                    className="object-cover"
                  />
                </div>
              ))}
            </div>
          </div>
          <div>
            <span className="font-sans text-xs uppercase tracking-[0.4em] text-soft-gray block mb-4">
              Chapter 04
            </span>
            <h2 className="font-serif text-3xl md:text-5xl font-[300] mb-4">Editorial Editing</h2>
            <p className="font-serif italic text-lg text-black/70 mb-6">
              Enhance, don&apos;t hide. Your natural beauty deserves to shine through.
            </p>
            <div className="mb-6">
              <h3 className="font-serif text-xl mb-2">Lightroom</h3>
              <p>Add presets that match your vibe. I use Scandinavian collections for instant editorial looks—dark & moody, light & dreamy, or urban chic.</p>
              <h3 className="font-serif text-xl mb-2 mt-4">Hypic</h3>
              <p>
                Subtle skin smoothing, detail enhancement, and nothing overdone. If it looks edited, you&apos;ve gone too far.
              </p>
              <h3 className="font-serif text-xl mb-2 mt-4">CapCut</h3>
              <p>
                Turn selfies into dynamic content. Perfect for video montages and adding motion.
              </p>
              <h3 className="font-serif text-xl mb-2 mt-4">The Perfect Formula</h3>
              <ul className="list-disc pl-5 space-y-1 mb-2">
                <li>Brighten slightly (never blow out highlights)</li>
                <li>Add warmth for healthy glow</li>
                <li>Increase contrast just a touch</li>
                <li>Sharpen details without overdoing it</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* CTA - Presets */}
      <section className="py-16 px-6 bg-black text-center">
        <div className="max-w-xl mx-auto">
          <h3 className="font-serif text-3xl text-white mb-4">Want my Lightroom presets?</h3>
          <p className="font-sans text-lg mb-8 text-white/80">
            Shop my Scandinavian preset collections—dark & moody, light & dreamy, and more. You&apos;ll look expensive, promise.
          </p>
          <Link href="/presets">
            <Button className="bg-white text-black px-10 py-3 text-xs uppercase tracking-[0.3em] rounded-none border-2 border-white hover:bg-black hover:text-white transition">
              Get Presets
            </Button>
          </Link>
        </div>
      </section>

      {/* Confidence & Power */}
      <section className="py-24 px-6 bg-[#fafafa]">
        <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-16 items-center">
          <div>
            <span className="font-sans text-xs uppercase tracking-[0.4em] text-soft-gray block mb-4">
              Chapter 05
            </span>
            <h2 className="font-serif text-3xl md:text-5xl font-[300] mb-4">Confidence & Power</h2>
            <p className="font-serif italic text-lg text-black/70 mb-6">
              The best accessory you can wear? Confidence. Let&apos;s build yours.
            </p>
            <div className="bg-white border-l-4 border-black/10 p-6 mb-8">
              <h4 className="font-serif text-2xl mb-3">Confidence Rituals</h4>
              <ul className="list-disc pl-5 space-y-1 text-soft-gray">
                <li>Play music that makes you feel like a queen</li>
                <li>Wear your power outfit—the one that makes you stand taller</li>
                <li>Take deep breaths between shots to release tension</li>
                <li>Remember: perfection is boring, personality is everything</li>
                <li>Stop comparing yourself to others—your beauty is uniquely yours</li>
              </ul>
            </div>
            <div>
              <h3 className="font-serif text-xl mb-2">Getting Comfortable</h3>
              <p>
                Feel awkward in front of the camera? You&apos;re not alone. Here&apos;s my secret: I take 100 photos to get one I love. And that&apos;s totally okay. The more you practice, the more natural it gets.
              </p>
              <p>
                Put on music, wear something you love, and remember—these are your memories. Not for anyone else. Just you.
              </p>
            </div>
          </div>
          <div>
            <div className="grid grid-cols-2 gap-4">
              {confidenceGridImages.map((src, i) => (
                <div key={i} className="aspect-[3/4] relative rounded-lg overflow-hidden">
                  <Image
                    src={src}
                    alt="Sandra confidence example"
                    fill
                    className="object-cover"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Social Strategy */}
      <section className="py-24 px-6 bg-white">
        <div className="max-w-6xl mx-auto">
          <span className="font-sans text-xs uppercase tracking-[0.4em] text-soft-gray block mb-4">
            Chapter 06
          </span>
          <h2 className="font-serif text-3xl md:text-5xl font-[300] mb-4">Social Strategy</h2>
          <p className="font-serif italic text-lg text-black/70 mb-6">
            Great selfies deserve to be seen. Let&apos;s make sure yours get noticed.
          </p>
          <div className="grid md:grid-cols-2 gap-12 mb-8">
            <div>
              <h3 className="font-serif text-xl mb-2">Instagram</h3>
              <p>High-quality, aesthetic selfies work best. Post in-feed for permanence, Stories for behind-the-scenes, Reels for reach.</p>
              <h3 className="font-serif text-xl mb-2 mt-6">TikTok</h3>
              <p>Raw, real, relatable. Show the process, not just the result. Transformations and tutorials perform incredibly well.</p>
            </div>
            <div>
              <h3 className="font-serif text-xl mb-2">LinkedIn</h3>
              <p>Professional polish is key. Your selfie is your personal brand—make it count with confident, approachable energy.</p>
              <h3 className="font-serif text-xl mb-2 mt-6">Captions That Convert</h3>
              <ul className="list-disc pl-5 space-y-1 mb-2">
                <li>&quot;Which look? 1 or 2?&quot;</li>
                <li>&quot;Owning my glow&quot;</li>
                <li>&quot;100 takes for this one&quot;</li>
              </ul>
            </div>
          </div>
          <div className="mb-8">
            <h3 className="font-serif text-xl mb-2">Strategic Hashtags</h3>
            <div className="flex flex-wrap gap-3">
              {hashtagList.map((tag, i) => (
                <span key={i} className="bg-[#fafafa] px-4 py-2 rounded-full font-sans text-sm text-soft-gray">
                  {tag}
                </span>
              ))}
            </div>
          </div>
          <div className="bg-[#fafafa] p-8 rounded-lg text-center">
            <p className="font-serif italic text-lg text-black/70 mb-2">
              Tag <span className="font-sans uppercase tracking-[0.3em]">@sandra.social</span> to share your journey.
            </p>
            <p className="text-xs text-soft-gray">Let the world see your transformation.</p>
          </div>
        </div>
      </section>

      {/* 7-Day Selfie Challenge */}
      <section className="py-24 px-6 bg-[#fafafa]">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="font-serif text-4xl md:text-5xl font-[300] mb-6">
            The 7-Day Selfie Challenge
          </h2>
          <p className="font-sans text-lg mb-10 text-soft-gray">
            Ready to put everything into action? Let&apos;s do this.
          </p>
          <div className="grid grid-cols-2 md:grid-cols-7 gap-2 bg-accent-line p-2 rounded-lg mb-6">
            {[
              ["1", "Natural Light Magic"],
              ["2", "Find Your Best Angle"],
              ["3", "Pose Like a Pro"],
              ["4", "Express Yourself"],
              ["5", "Editing Glow-Up"],
              ["6", "Social Media Ready"],
              ["7", "Before & After"],
            ].map(([num, task]) => (
              <div key={num} className="bg-white p-6 min-h-[160px] flex flex-col items-center justify-center rounded-none">
                <span className="text-xs uppercase tracking-[0.3em] text-soft-gray mb-2">Day</span>
                <span className="font-serif text-4xl text-black mb-2">{num}</span>
                <span className="font-sans text-sm text-soft-gray text-center">{task}</span>
              </div>
            ))}
          </div>
          <p className="font-sans text-xs uppercase tracking-[0.3em] text-soft-gray mt-6">
            Tag @sandra.social to share your journey
          </p>
        </div>
      </section>

      {/* Final Quote */}
      <section className="py-24 px-6 bg-black flex items-center justify-center text-center">
        <div className="max-w-3xl mx-auto">
          <p className="font-serif italic text-4xl md:text-6xl text-white mb-8 leading-tight">
            A selfie isn&apos;t just a picture<br />
            <span className="font-sans font-light not-italic text-2xl block mt-2">
              it&apos;s a celebration of who you are
            </span>
          </p>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 px-6 bg-[#fafafa] text-center">
        <div className="max-w-2xl mx-auto">
          <h2 className="font-serif text-4xl md:text-5xl font-[300] mb-6">
            Ready for more?
          </h2>
          <p className="font-sans text-lg mb-8 text-soft-gray">
            This guide is just the beginning. Join me inside SSELFIE AI™ where we dive deeper into personal branding, content strategy, and building your empire one selfie at a time.
          </p>
          <div className="flex flex-wrap justify-center gap-6">
            <Link href="/pricing">
              <Button className="bg-black text-white px-10 py-3 text-xs uppercase tracking-[0.3em] rounded-none border-2 border-black hover:bg-white hover:text-black transition">
                See Offers
              </Button>
            </Link>
            <Link href="/ai-images">
              <Button className="bg-white text-black px-10 py-3 text-xs uppercase tracking-[0.3em] rounded-none border-2 border-black hover:bg-black hover:text-white transition">
                Try AI Images
              </Button>
            </Link>
            <Link href="/presets">
              <Button className="bg-white text-black px-10 py-3 text-xs uppercase tracking-[0.3em] rounded-none border-2 border-black hover:bg-black hover:text-white transition">
                Get Presets
              </Button>
            </Link>
          </div>
          <p className="mt-10 font-serif italic text-xl">Sandra xoxo</p>
        </div>
      </section>
    </main>
  );
}