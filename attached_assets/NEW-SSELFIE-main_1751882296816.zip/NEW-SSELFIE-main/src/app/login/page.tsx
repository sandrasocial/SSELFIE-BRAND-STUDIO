'use client'

import React from 'react'
import Image from 'next/image'
import { HeroFullBleed } from '@/components/sections/hero/HeroFullBleed'
import { AuthForm } from '@/components/auth/AuthForm'
import { SandraImages } from '@/components/sandra-image-library'

export default function Login() {
  return (
    <div className="min-h-screen bg-luxury-black">
      <div className="min-h-screen grid md:grid-cols-2">
        {/* Left side - Image and Headline */}
        <div className="relative hidden md:flex flex-col justify-center p-12 lg:p-20">
          <div className="relative z-10 max-w-lg">
            <h1 className="font-serif text-5xl md:text-6xl font-light tracking-[-0.03em] text-soft-white mb-4">
              Welcome back.
            </h1>
            <p className="text-xl text-soft-white/80 mb-10">
              Let's pick up where you left off.
            </p>
            <p className="text-soft-white/60 italic">
              "You don't need to remember everything. Just your email, your story, and maybe your favorite coffee order."
            </p>
          </div>

          {/* Background image with overlay */}
          <div className="absolute inset-0">
            <Image
              src={SandraImages.editorial.thinking}
              alt="Sandra, relaxed"
              fill
              className="object-cover opacity-60"
              priority
            />
            <div className="absolute inset-0 bg-gradient-to-br from-luxury-black/90 to-luxury-black/70" />
          </div>
        </div>

        {/* Right side - Form */}
        <div className="flex items-center justify-center px-6 py-16 md:py-0 md:px-12 lg:px-20 bg-luxury-black">
          <div className="w-full max-w-md">
            {/* Mobile only headline */}
            <div className="mb-12 md:hidden">
              <h1 className="font-serif text-4xl font-light tracking-[-0.02em] text-soft-white mb-3">
                Welcome back.
              </h1>
              <p className="text-lg text-soft-white/80">
                Let's pick up where you left off.
              </p>
            </div>
            
            <AuthForm type="login" />
          </div>
        </div>
      </div>
    </div>
  )
}
