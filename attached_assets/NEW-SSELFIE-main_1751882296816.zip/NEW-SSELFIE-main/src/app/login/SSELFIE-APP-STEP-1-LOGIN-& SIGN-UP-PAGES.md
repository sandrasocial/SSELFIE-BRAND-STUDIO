# SSELFIE APP — STEP 1: LOGIN & SIGN UP PAGES

Alright, let’s keep it real. This is where your users first step inside—not just “create an account,” but step into a whole new chapter. If it feels cold or confusing, they’ll bounce. If it feels like Sandra just opened the door and said “hey, come in,” they’ll stay.

---

## 1. LOGIN PAGE

### Editorial Vibe

- **Image:** Sandra, relaxed, maybe a “come on in” half-smile, somewhere that feels like home.
- **Headline:**  
  Welcome back.
- **Subtext:**  
  Let’s pick up where you left off.
- **Form:**  
  - Email  
  - Password  
  - Forgot your password?
  - Button: SIGN IN (all caps, tracked)
- **Footer:**  
  Don’t have an account? [Start here]

### Copy Example

> “You don’t need to remember everything. Just your email, your story, and maybe your favorite coffee order.”

---

## 2. SIGN UP PAGE

### Editorial Vibe

- **Image:** Sandra in action—phone in hand, “let’s do this” energy.
- **Headline:**  
  Ready to start?
- **Subtext:**  
  This is the first step to showing up as her.
- **Form:**  
  - Name  
  - Email  
  - Password  
  - Button: BEGIN (all caps, tracked)
- **Footer:**  
  Already have an account? [Sign in]

### Copy Example

> “It doesn’t have to be perfect. You just have to begin.”

---

## 3. COMPONENTS TO REUSE

- **HeroFullBleed.tsx** (for that editorial, full-bleed hero image and headline)
- **AuthForm.tsx** (if you have a reusable login/signup form component)
- **Button** (all caps, minimal, editorial style)
- **Typography** (headline = Times New Roman, body = system sans)

---

## 4. COMPONENTS TO BUILD (IF NEEDED)

- **AuthForm.tsx**
  - Handles both login and signup (switches by prop)
  - Editorial error messages (“Wrong email? Don’t worry, we’ve all done it.”)
  - Social login (optional)
- **ForgotPassword.tsx**
  - Simple, inviting (“We’ll send you a reset link. No drama.”)

---

## 5. UX & STYLE NOTES

- White space everywhere—luxury is air.
- No icons, no “create account” robots. Editorial photo, always.
- Button: All caps, underlined or bordered on hover.
- Copy: Feels like Sandra’s texting you—warm, direct, never salesy.
- Errors: Always human. (“Let’s try that again.”)
- Layout: Centered, not crowded. Max width 400-500px for forms.

---

## 6. NEXT STEP PREVIEW

Once login/signup are done, you’ll route users to the Dashboard (Step 2)—their “welcome home” moment.

---

# LET'S DO THIS

- [ ] Design Login page (use HeroFullBleed, AuthForm)
- [ ] Design Sign Up page (same)
- [ ] Copy check—does every word feel like Sandra?
- [ ] Test with a real woman (bonus: someone overwhelmed by tech!)

Ping me when you’re ready for Step 2: The Dashboard.