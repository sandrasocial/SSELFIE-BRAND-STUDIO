'use client'

import React from 'react'
import Image from 'next/image'
import Navigation from '@/components/global/Navigation'
import { HeroFullBleed } from '@/components/sections/hero/HeroFullBleed'
import { EditorialTestimonials, PowerQuote } from '@/components/sections'
import { SandraImages } from '@/components/sandra-image-library'

export default function StoriesPage() {
  return (
    <>
      <div className="min-h-screen">
        {/* Navigation */}
        <Navigation />
        
        {/* Hero Section */}
        <HeroFullBleed
          backgroundImage={SandraImages.hero.course}
          tagline="Real women, real transformations"
          title="STORIES"
          subtitle=""
          ctaText="Start your story"
          ctaLink="/pricing"
        />

        {/* Introduction */}
        <section className="py-32 md:py-40 bg-soft-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-4xl text-center">
            <p className="font-inter text-xs tracking-[0.3em] uppercase text-luxury-black/50 mb-8">
              The proof is in the transformation
            </p>
            
            <h2 className="font-bodoni text-4xl md:text-5xl lg:text-6xl font-light leading-tight text-luxury-black mb-12">
              &ldquo;I can&rsquo;t believe<br />
              that&rsquo;s actually me.&rdquo;
            </h2>
            
            <div className="space-y-6 max-w-2xl mx-auto">
              <p className="font-inter text-lg font-light text-luxury-black/80 leading-relaxed">
                This is what happens when women stop waiting for permission to be seen.
              </p>
              
              <p className="font-inter text-base font-light text-luxury-black/70 leading-relaxed">
                These aren&rsquo;t stock photos or staged testimonials. These are real DMs from real women who decided to show up as themselves&mdash;and watched everything change.
              </p>
            </div>
          </div>
        </section>

        {/* Main Testimonials Section */}
        <EditorialTestimonials />

        {/* Transformation Stats */}
        <section className="py-32 md:py-40 bg-pure-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-6xl">
            <div className="text-center mb-20">
              <p className="font-inter text-xs tracking-[0.3em] uppercase text-luxury-black/50 mb-8">
                The numbers don&rsquo;t lie
              </p>
              
              <h2 className="font-bodoni text-4xl md:text-5xl lg:text-6xl font-light leading-tight text-luxury-black mb-8">
                What happens when<br />
                you stop hiding.
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12 max-w-4xl mx-auto">
              <div className="text-center">
                <div className="font-bodoni text-5xl md:text-6xl font-light text-luxury-black mb-4">
                  73%
                </div>
                <p className="font-inter text-sm text-luxury-black/70 leading-relaxed">
                  Book their first client within 30 days of going live
                </p>
              </div>
              
              <div className="text-center">
                <div className="font-bodoni text-5xl md:text-6xl font-light text-luxury-black mb-4">
                  2.3x
                </div>
                <p className="font-inter text-sm text-luxury-black/70 leading-relaxed">
                  Increase in Instagram engagement after their first SSELFIE post
                </p>
              </div>
              
              <div className="text-center">
                <div className="font-bodoni text-5xl md:text-6xl font-light text-luxury-black mb-4">
                  €47K
                </div>
                <p className="font-inter text-sm text-luxury-black/70 leading-relaxed">
                  Average revenue increase in the first 6 months
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Power Quote */}
        <PowerQuote />

        {/* Detailed Transformation Stories */}
        <section className="py-32 md:py-40 bg-soft-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-6xl">
            <div className="text-center mb-20">
              <p className="font-inter text-xs tracking-[0.3em] uppercase text-luxury-black/50 mb-8">
                The full story
              </p>
              
              <h2 className="font-bodoni text-4xl md:text-5xl font-light leading-tight text-luxury-black mb-8">
                From self-doubt<br />
                to fully booked.
              </h2>
            </div>

            <div className="space-y-20">
              {/* Story 1 */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <div className="order-2 lg:order-1">
                  <div className="bg-luxury-black/5 p-8 md:p-12">
                    <div className="mb-6">
                      <div className="font-inter text-xs tracking-[0.3em] uppercase text-luxury-black/50 mb-2">
                        Marketing Consultant
                      </div>
                      <h3 className="font-bodoni text-2xl md:text-3xl font-light text-luxury-black">
                        Sarah, London
                      </h3>
                    </div>
                    
                    <blockquote className="font-inter text-base font-light text-luxury-black/80 leading-relaxed mb-6 italic">
                      &ldquo;I spent two years avoiding video calls because I didn&rsquo;t feel &lsquo;professional&rsquo; enough. Then I got my SSELFIE images back and... I actually looked like the expert I am. Posted my first LinkedIn headshot, got three inquiries that week.&rdquo;
                    </blockquote>
                    
                    <div className="space-y-2">
                      <p className="font-inter text-sm text-luxury-black/60">
                        <span className="font-medium">Before:</span> Hiding behind generic stock photos
                      </p>
                      <p className="font-inter text-sm text-luxury-black/60">
                        <span className="font-medium">After:</span> €15K month within 90 days
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="order-1 lg:order-2">
                  <div className="aspect-[4/5] bg-luxury-black/10 rounded-none overflow-hidden">
                    <Image 
                      src="/images/transformation-sarah.jpg" 
                      alt="Sarah&rsquo;s transformation"
                      width={400}
                      height={500}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
              </div>

              {/* Story 2 */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <div className="order-2">
                  <div className="bg-luxury-black/5 p-8 md:p-12">
                    <div className="mb-6">
                      <div className="font-inter text-xs tracking-[0.3em] uppercase text-luxury-black/50 mb-2">
                        Life Coach
                      </div>
                      <h3 className="font-bodoni text-2xl md:text-3xl font-light text-luxury-black">
                        Maya, Amsterdam
                      </h3>
                    </div>
                    
                    <blockquote className="font-inter text-base font-light text-luxury-black/80 leading-relaxed mb-6 italic">
                      &ldquo;I&rsquo;d been putting off launching my coaching practice for months because I &lsquo;needed better photos.&rsquo; Sandra&rsquo;s AI gave me exactly what I needed in 20 minutes. I launched the next day and had my first paying client within a week.&rdquo;
                    </blockquote>
                    
                    <div className="space-y-2">
                      <p className="font-inter text-sm text-luxury-black/60">
                        <span className="font-medium">Before:</span> Procrastinating on launch for 8 months
                      </p>
                      <p className="font-inter text-sm text-luxury-black/60">
                        <span className="font-medium">After:</span> Fully booked coaching practice
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="order-1">
                  <div className="aspect-[4/5] bg-luxury-black/10 rounded-none overflow-hidden">
                    <Image 
                      src="/images/transformation-maya.jpg" 
                      alt="Maya&rsquo;s transformation"
                      width={400}
                      height={500}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
              </div>

              {/* Story 3 */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <div className="order-2 lg:order-1">
                  <div className="bg-luxury-black/5 p-8 md:p-12">
                    <div className="mb-6">
                      <div className="font-inter text-xs tracking-[0.3em] uppercase text-luxury-black/50 mb-2">
                        Creative Director
                      </div>
                      <h3 className="font-bodoni text-2xl md:text-3xl font-light text-luxury-black">
                        Elena, Berlin
                      </h3>
                    </div>
                    
                    <blockquote className="font-inter text-base font-light text-luxury-black/80 leading-relaxed mb-6 italic">
                      &ldquo;I used to dread networking events because I never felt like I looked &lsquo;creative&rsquo; enough. My SSELFIE images captured exactly who I am&mdash;confident, artistic, unapologetically me. Now I show up differently everywhere.&rdquo;
                    </blockquote>
                    
                    <div className="space-y-2">
                      <p className="font-inter text-sm text-luxury-black/60">
                        <span className="font-medium">Before:</span> Imposter syndrome in creative spaces
                      </p>
                      <p className="font-inter text-sm text-luxury-black/60">
                        <span className="font-medium">After:</span> Leading creative teams with confidence
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="order-1 lg:order-2">
                  <div className="aspect-[4/5] bg-luxury-black/10 rounded-none overflow-hidden">
                    <Image 
                      src="/images/transformation-elena.jpg" 
                      alt="Elena&rsquo;s transformation"
                      width={400}
                      height={500}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Final CTA */}
        <section className="py-32 md:py-40 bg-luxury-black text-soft-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-4xl text-center">
            <h2 className="font-bodoni text-4xl md:text-5xl lg:text-6xl font-light leading-tight mb-8">
              Your story<br />
              starts with a selfie.
            </h2>
            
            <p className="font-inter text-lg font-light text-soft-white/70 leading-relaxed mb-12 max-w-2xl mx-auto">
              Stop waiting for the perfect moment. Stop waiting for permission. 
              Your transformation begins the moment you decide you&rsquo;re ready to be seen.
            </p>
            
            <div className="space-y-4">
              <a 
                href="/pricing"
                className="inline-block font-inter text-sm tracking-[0.2em] uppercase text-soft-white hover:text-soft-white/70 transition-colors duration-300 px-8 py-4 border border-soft-white hover:bg-soft-white hover:text-luxury-black mr-4"
              >
                Start your transformation
              </a>
              <a 
                href="/about"
                className="inline-block font-inter text-sm tracking-[0.2em] uppercase text-soft-white/60 hover:text-soft-white transition-colors duration-300 px-8 py-4 border border-soft-white/20 hover:border-soft-white"
              >
                Learn my story
              </a>
            </div>
          </div>
        </section>
      </div>
    </>
  )
}
