import { Metadata } from 'next'
import Navigation from '@/components/global/Navigation'
import { Footer } from '@/components/global/Footer'
import { HeroFullBleed } from '@/components/sections/hero/HeroFullBleed'
import { SandraImages } from '@/components/sandra-image-library'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'The Journal | SSELFIE Studio',
  description: 'Real stories, real strategy. Sandra\'s honest take on branding, business, and building something real.',
}

// Mock blog posts data - in a real app, this would come from a CMS or API
const featuredPosts = [
  {
    id: 1,
    title: "How I built a personal brand with only my phone and a little courage",
    excerpt: "The real story of starting SSELFIE with nothing but selfies and a stubborn belief that women deserve better than cookie-cutter advice.",
    category: "SSELFIE Stories",
    readTime: "8 min read",
    image: SandraImages.editorial.phone2
  },
  {
    id: 2,
    title: "Branding when you feel like a hot mess",
    excerpt: "Some days you feel unstoppable. Other days you feel like a fraud. Here's how to build a brand that works through both.",
    category: "Mindset & Real Life",
    readTime: "6 min read",
    image: SandraImages.editorial.thinking
  },
  {
    id: 3,
    title: "Why your first offer doesn't have to be perfect (or even close)",
    excerpt: "I launched my first service before I knew what I was doing. Best decision ever. Here's why messy action beats perfect planning.",
    category: "Branding & Offers",
    readTime: "10 min read",
    image: SandraImages.editorial.laptop1
  },
  {
    id: 4,
    title: "Selfies, strategy, and surviving heartbreak: My real method",
    excerpt: "The Method wasn't born in a boardroom. It was born from necessity, heartbreak, and a desperate need to rebuild everything.",
    category: "SSELFIE Stories",
    readTime: "12 min read",
    image: SandraImages.journey.rockBottom
  },
  {
    id: 5,
    title: "The no-agency guide to landing your first client",
    excerpt: "No connections, no experience, no problem. Here's exactly how I went from zero to paying clients without a single networking event.",
    category: "Tutorials & How-Tos",
    readTime: "15 min read",
    image: SandraImages.editorial.laptop2
  },
  {
    id: 6,
    title: "Single mom wisdom: Building a business around real life",
    excerpt: "Forget the 4am morning routines and hustle culture. Here's how to build something sustainable when life is beautifully chaotic.",
    category: "Single Mom Wisdom",
    readTime: "9 min read",
    image: SandraImages.editorial.laughing
  }
]

const categories = [
  "SSELFIE Stories",
  "Tutorials & How-Tos",
  "Mindset & Real Life",
  "Branding & Offers",
  "Single Mom Wisdom"
]

export default function BlogPage() {
  return (
    <>
      <Navigation />
      
      <main className="bg-white">
        {/* Hero Section */}
        <HeroFullBleed
          backgroundImage={SandraImages.hero.about}
          tagline="REAL STORIES, REAL STRATEGY"
          title="THE JOURNAL"
          subtitle=""
          ctaText="GOT A TOPIC REQUEST? TELL SANDRA"
          ctaLink="#request-topic"
        />

        {/* Intro Section */}
        <section className="py-20 px-4">
          <div className="max-w-4xl mx-auto">
            <h1 style={{ fontFamily: 'Times New Roman, serif' }} className="text-3xl md:text-4xl text-[#171719] mb-8">
              Okay, here's what actually happened…
            </h1>
            
            <div className="space-y-6 text-lg leading-relaxed text-[#171719]">
              <p>This isn't your average "blog."</p>
              <p>It's not recycled Pinterest advice or listicles you'll forget in five minutes.</p>
              <p>Every post here is something I wish I'd known when I started—real talk, real strategy, and a little bit of "you got this" energy.</p>
              <p>Some days it's business. Some days it's mindset. Every day, it's honest.</p>
            </div>
          </div>
        </section>

        {/* Categories */}
        <section className="py-12 px-4 bg-[#F1F1F1]">
          <div className="max-w-6xl mx-auto">
            <div className="flex flex-wrap justify-center gap-4 md:gap-6">
              {categories.map((category, index) => (
                <button
                  key={index}
                  className="px-6 py-3 text-[#171719] border border-[#171719] hover:bg-[#171719] hover:text-[#F1F1F1] transition-colors duration-200"
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Featured Posts Grid */}
        <section className="py-20 px-4">
          <div className="max-w-6xl mx-auto">
            <h2 style={{ fontFamily: 'Times New Roman, serif' }} className="text-3xl text-[#171719] mb-12 text-center">
              Featured Stories
            </h2>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredPosts.map((post) => (
                <article key={post.id} className="group cursor-pointer">
                  <div className="aspect-[4/3] overflow-hidden mb-4">
                    <div
                      className="w-full h-full bg-cover bg-center group-hover:scale-105 transition-transform duration-500"
                      style={{
                        backgroundImage: `url(${post.image})`,
                        position: 'relative'
                      }}
                    >
                      <div 
                        className="absolute inset-0 bg-cover bg-center"
                        style={{
                          backgroundImage: `url(${post.image})`,
                          objectFit: 'cover'
                        }}
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm text-[#B5B5B3]">
                      <span>{post.category}</span>
                      <span>{post.readTime}</span>
                    </div>
                    
                    <h3 className="text-xl font-medium text-[#171719] group-hover:text-[#B5B5B3] transition-colors duration-200 leading-tight">
                      {post.title}
                    </h3>
                    
                    <p className="text-[#171719] leading-relaxed">
                      {post.excerpt}
                    </p>
                    
                    <div className="pt-2">
                      <span className="text-[#171719] font-medium text-sm tracking-wide hover:text-[#B5B5B3] transition-colors duration-200">
                        READ MORE →
                      </span>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* Request Topic Section */}
        <section id="request-topic" className="py-20 px-4 bg-[#F1F1F1]">
          <div className="max-w-4xl mx-auto text-center">
            <h2 style={{ fontFamily: 'Times New Roman, serif' }} className="text-3xl text-[#171719] mb-8">
              Want to see something covered?
            </h2>
            
            <p className="text-lg text-[#171719] mb-8 max-w-2xl mx-auto">
              DM me on Instagram (@sandrasocial) or drop your idea on the contact page.<br />
              This is your space, too. Let's build something real together.
            </p>
            
            <Link 
              href="/contact"
              className="inline-block bg-[#171719] text-[#F1F1F1] px-8 py-4 font-medium tracking-wide hover:bg-[#2A2A2A] transition-colors duration-200"
            >
              REQUEST A TOPIC
            </Link>
          </div>
        </section>
      </main>

      <Footer />
    </>
  )
}
