# SSELFIE BLOG / RESOURCES — ASSEMBLY PLAN & COPY

Alright Diana, here’s the BLOG page—Sandra style. No “content mill,” no SEO-for-the-sake-of-SEO. Just real stories, honest tutorials, and the stuff you wish someone had told you sooner. If it doesn’t help, inspire, or make you laugh, it doesn’t make the cut.

---

## 1. HERO SECTION

- **Component:** `HeroFullBleed.tsx`
- **Image:** Editorial: Sandra at her kitchen table, laptop open, mug in hand; real life in the background.
- **Title:**  
  THE JOURNAL
- **Tagline:**  
  REAL STORIES, REAL STRATEGY
- **CTA:**  
  GOT A TOPIC REQUEST? TELL SANDRA

---

## 2. INTRO / WHAT THIS BLOG IS (AND ISN’T)

**Headline:**  
Okay, here’s what actually happened…

**Copy:**  
This isn’t your average “blog.”  
It’s not recycled Pinterest advice or listicles you’ll forget in five minutes.  
Every post here is something I wish I’d known when I started—real talk, real strategy, and a little bit of “you got this” energy.  
Some days it’s business. Some days it’s mindset. Every day, it’s honest.

---

## 3. FEATURED STORIES / LATEST POSTS

- **Component:** `EditorialGallery.tsx` or `BlogCard.tsx` grid  
- **Copy Example (teasers):**  
  - “How I built a personal brand with only my phone and a little courage”
  - “Branding when you feel like a hot mess”
  - “Why your first offer doesn’t have to be perfect (or even close)”
  - “Selfies, strategy, and surviving heartbreak: My real method”
  - “The no-agency guide to landing your first client”

---

## 4. CATEGORIES (OPTIONAL)

**Copy:**  
- SSELFIE Stories  
- Tutorials & How-Tos  
- Mindset & Real Life  
- Branding & Offers  
- Single Mom Wisdom

---

## 5. CALL TO ACTION (CONTRIBUTION / REQUEST)

**Headline:**  
Want to see something covered?

**Copy:**  
DM me on Instagram (@sandrasocial) or drop your idea on the contact page.  
This is your space, too. Let’s build something real together.

**CTA Button:**  
REQUEST A TOPIC

---

## 6. STYLE & QA REMINDERS

- Editorial images only—never “stock photo blog” vibes.
- Layout: Minimal, lots of air, clean grids.
- Typography:  
  - Headlines = ‘Times New Roman’, serif  
  - Body/UI = system sans
- Button: All caps, minimal, inviting.
- Copy: Sandra’s voice—warm, honest, always practical.
- No m-dash. Never fake urgency. No “10 Secrets to…” clickbait.

---

## FINAL CHECKLIST

- [ ] Hero: Title, tagline, CTA
- [ ] Clear intro—sets the honest tone
- [ ] Featured stories grid—real stories, real strategy
- [ ] Categories for easy navigation
- [ ] Final CTA—feels like Sandra, always inviting

Let’s make this the only blog that actually makes you want to come back.