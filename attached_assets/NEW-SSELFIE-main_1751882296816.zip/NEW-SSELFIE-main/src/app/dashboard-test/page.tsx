import EditorialCTA from "@/components/sections/editorial/EditorialCTA";
import EditorialMoodboard from "@/components/sections/editorial/EditorialMoodboard";
import EditorialSpread from "@/components/sections/editorial/EditorialSpread";

export default function DashboardTestPage() {
  return (
    <main>
      <EditorialCTA />
      <EditorialMoodboard />
      <EditorialSpread />
    </main>
  );
}
