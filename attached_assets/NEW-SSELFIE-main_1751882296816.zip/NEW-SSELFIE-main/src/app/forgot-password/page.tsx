'use client'

import React from 'react'
import Image from 'next/image'
import { ForgotPassword } from '@/components/auth/ForgotPassword'
import { SandraImages } from '@/components/sandra-image-library'

export default function ForgotPasswordPage() {
  return (
    <div className="min-h-screen bg-luxury-black">
      <div className="min-h-screen grid md:grid-cols-2">
        {/* Left side - Image and Headline */}
        <div className="relative hidden md:flex flex-col justify-center p-12 lg:p-20">
          <div className="relative z-10 max-w-lg">
            <h1 className="font-serif text-5xl md:text-6xl font-light tracking-[-0.03em] text-soft-white mb-4">
              No worries.
            </h1>
            <p className="text-xl text-soft-white/80 mb-10">
              We all forget sometimes.
            </p>
          </div>

          {/* Background image with overlay */}
          <div className="absolute inset-0">
            <Image
              src={SandraImages.editorial.laptop1}
              alt="Sandra workspace"
              fill
              className="object-cover opacity-60"
              priority
            />
            <div className="absolute inset-0 bg-gradient-to-br from-luxury-black/90 to-luxury-black/70" />
          </div>
        </div>

        {/* Right side - Form */}
        <div className="flex items-center justify-center px-6 py-16 md:py-0 md:px-12 lg:px-20 bg-luxury-black">
          <div className="w-full max-w-md">
            {/* Mobile only headline */}
            <div className="mb-12 md:hidden">
              <h1 className="font-serif text-4xl font-light tracking-[-0.02em] text-soft-white mb-3">
                No worries.
              </h1>
              <p className="text-lg text-soft-white/80">
                We all forget sometimes.
              </p>
            </div>
            
            <ForgotPassword />
          </div>
        </div>
      </div>
    </div>
  )
}
