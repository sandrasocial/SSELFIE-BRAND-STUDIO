import { HeroFullBleed } from "@/components/sections/hero/HeroFullBleed";

export default function CoursesPage() {
  return (
    <HeroFullBleed
      backgroundImage="/images/sandra-hero-course.jpg"
      tagline="90 days to your first 100K"
      title="SSELFIE"
      subtitle="METHOD"
      ctaText="Teach me your ways"
      ctaLink="/pricing"
    />
  );
}
