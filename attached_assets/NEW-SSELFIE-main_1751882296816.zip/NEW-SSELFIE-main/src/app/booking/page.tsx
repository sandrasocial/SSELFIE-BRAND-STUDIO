import { Metadata } from 'next'
import Navigation from '@/components/global/Navigation'
import { Footer } from '@/components/global/Footer'
import { HeroFullBleed } from '@/components/sections/hero/HeroFullBleed'
import OnboardingSteps from '@/components/business/OnboardingSteps'
import { SandraImages } from '@/components/sandra-image-library'

export const metadata: Metadata = {
  title: 'Book Strategy Session | SSELFIE Studio',
  description: 'Book a personal brand strategy session with Sandra to plan your transformation journey.',
}

const sessionSteps = [
  {
    number: 1,
    title: "Choose Your Session",
    description: "Select the strategy session that best fits your needs and timeline."
  },
  {
    number: 2, 
    title: "Complete Pre-Session Form",
    description: "Fill out our detailed questionnaire to maximize our time together."
  },
  {
    number: 3,
    title: "Join Your Call", 
    description: "Meet with Sandra for your personalized brand strategy session."
  },
  {
    number: 4,
    title: "Receive Your Action Plan",
    description: "Get your custom transformation roadmap with next steps and resources."
  }
]

export default function BookingPage() {
  return (
    <>
      {/* Navigation */}
      <Navigation />
      
      <main>
        {/* Hero Section */}
        <HeroFullBleed
          backgroundImage={SandraImages.hero.course}
          tagline="Strategy session with Sandra"
          title="BOOK YOUR"
          subtitle="TRANSFORMATION"
          ctaText="Book Session"
          ctaLink="#session-options"
        />

      {/* Session Options */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-4xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8">
            {/* Quick Strategy */}
            <div className="bg-[#F1F1F1] p-8 border border-[#B5B5B3]/20">
              <h3 className="font-['Bodoni_FLF'] text-2xl text-[#171719] mb-4">
                Quick Strategy Session
              </h3>
              <p className="text-3xl font-bold text-[#171719] mb-4">€97</p>
              <p className="text-[#B5B5B3] mb-6">
                30-minute focused session to identify your biggest brand opportunity and create an action plan.
              </p>
              <ul className="space-y-2 text-[#171719] mb-8">
                <li>✓ Brand positioning audit</li>
                <li>✓ Immediate action items</li>
                <li>✓ Resource recommendations</li>
                <li>✓ Follow-up email summary</li>
              </ul>
              <a 
                href="https://calendly.com/sandra-sselfie/quick-strategy"
                className="block w-full bg-[#171719] text-[#F1F1F1] px-6 py-3 text-center font-medium hover:bg-[#B5B5B3] hover:text-[#171719] transition-colors duration-300"
              >
                Book Quick Session
              </a>
            </div>

            {/* Deep Dive Strategy */}
            <div className="bg-[#171719] p-8 border border-[#B5B5B3]/20">
              <h3 className="font-['Bodoni_FLF'] text-2xl text-[#F1F1F1] mb-4">
                Deep Dive Strategy
              </h3>
              <p className="text-3xl font-bold text-[#F1F1F1] mb-4">€197</p>
              <p className="text-[#B5B5B3] mb-6">
                60-minute comprehensive session with complete brand strategy and implementation roadmap.
              </p>
              <ul className="space-y-2 text-[#F1F1F1] mb-8">
                <li>✓ Complete brand audit</li>
                <li>✓ Custom strategy roadmap</li>
                <li>✓ Content planning framework</li>
                <li>✓ AI image style guidance</li>
                <li>✓ 30-day action plan</li>
                <li>✓ Email & text follow-up</li>
              </ul>
              <a 
                href="https://calendly.com/sandra-sselfie/deep-dive-strategy"
                className="block w-full bg-[#F1F1F1] text-[#171719] px-6 py-3 text-center font-medium hover:bg-[#B5B5B3] transition-colors duration-300"
              >
                Book Deep Dive
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Process Steps */}
      <section className="py-24 px-4 bg-[#F1F1F1]">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="font-['Bodoni_FLF'] text-4xl md:text-5xl text-[#171719] mb-6">
              Your Strategy Session Process
            </h2>
            <p className="text-xl text-[#B5B5B3] max-w-2xl mx-auto">
              What to expect from your personalized brand strategy session
            </p>
          </div>
          <OnboardingSteps steps={sessionSteps} />
        </div>
      </section>
    </main>

    {/* Footer */}
    <Footer />
  </>
  )
}
