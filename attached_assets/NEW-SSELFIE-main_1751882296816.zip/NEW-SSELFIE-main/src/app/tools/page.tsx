'use client';

import React from 'react';
import { HeroFullBleed } from '@/components/sections/hero/HeroFullBleed';
import { ToolsIntroduction } from '@/components/tools/ToolsIntroduction';
import { FeaturedToolShowcase } from '@/components/tools/FeaturedToolShowcase';
import { ToolCollection } from '@/components/tools/ToolCollection';
import { ToolsMethodExplanation } from '@/components/tools/ToolsMethodExplanation';
import { ToolsTestimonialSlider } from '@/components/tools/ToolsTestimonialSlider';
import { ToolsNextStepsCTA } from '@/components/tools/ToolsNextStepsCTA';
import { SandraImages } from '@/components/sandra-image-library';

export default function ToolsPage() {
  // Mock data for the current user
  const firstName = "Sandra";

  // Tool data following EXACTLY the examples from the design guide
  const tools = [
    {
      id: 'selfie-generator',
      title: "Show up as her",
      description: "Transform everyday selfies into editorial moments.",
      imageSrc: SandraImages.editorial.phone2,
      ctaText: "START",
      ctaLink: '/tools/selfie-generator',
      status: 'new' as const
    },
    {
      id: 'content-calendar',
      title: "Content Calendar",
      description: "Plan content with templates that feel like you.",
      imageSrc: SandraImages.flatlays.planning,
      ctaText: "CREATE",
      ctaLink: '/tools/content-calendar'
    },
    {
      id: 'brand-voice',
      title: "Brand Voice",
      description: "Save your unique voice for every post.",
      imageSrc: SandraImages.editorial.laptop2,
      ctaText: "SETUP",
      ctaLink: '/tools/brand-voice'
    },
    {
      id: 'selfie-generator-ai',
      title: "Selfie Generator",
      description: "Make AI-powered, editorial selfies in seconds.",
      imageSrc: SandraImages.editorial.phone1,
      ctaText: "GENERATE",
      ctaLink: '/tools/selfie-ai'
    }
  ];

  return (
    <main className="min-h-screen space-y-[120px] md:space-y-[140px] lg:space-y-[160px]">
      {/* 1. Hero Section */}
      <HeroFullBleed 
        backgroundImage={SandraImages.editorial.mirror}
        title="TOOLS"
        tagline="Your magic toolbox, one click away."
        subtitle="Hey Sandra, let's get started."
        alignment="left"
        fullHeight={false}
      />
      
      {/* 2. Tool Introduction */}
      <ToolsIntroduction 
        quote="Tools don't build brands. Stories do."
        description="Each tool in this collection is designed to help you transform your everyday moments into a cohesive brand story that resonates with your audience. No complicated tech, just strategic simplicity."
      />
      
      {/* 3. Featured Tool Showcase */}
      <FeaturedToolShowcase 
        title="Show up as her"
        description="Transform your everyday selfies into editorial brand moments that capture your essence. Our AI-powered Selfie Generator helps you create consistent, on-brand imagery without the need for professional photoshoots or complicated editing software."
        imageSrc={SandraImages.editorial.phone2}
        ctaText="START"
        ctaLink="/tools/selfie-generator"
        status="new"
      />
      
      {/* 4. Tool Collection */}
      <ToolCollection />
      
      {/* 5. Method Explanation */}
      <ToolsMethodExplanation 
        title="The Phoenix Method"
        description="Behind every tool is Sandra's proven Phoenix Method — a strategic approach to brand building that transforms your personal story into your most powerful business asset. These tools work together to help you rise from the ashes of what was, into who you're meant to be."
        quote="Your tools should work as hard as you do."
        imageSrc={SandraImages.hero.method}
        ctaText="EXPLORE THE METHOD"
        ctaLink="/method"
      />
      
      {/* 6. Testimonial Section */}
      <ToolsTestimonialSlider />
      
      {/* 7. Next Steps CTA */}
      <ToolsNextStepsCTA 
        title="Ready to transform your story?"
        description="Start with one tool, or use them all. Your brand transformation begins with a single brave step."
        quote="You don't need a plan. You need one brave post."
        ctaText="GET STARTED"
        ctaLink="/tools/selfie-generator"
      />
    </main>
  );
}
