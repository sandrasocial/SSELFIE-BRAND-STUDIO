# SSELFIE TOOLS PAGE — COMPONENT & DESIGN GUIDE FOR DIANA  

## EDITORIAL VISION

This isn't just a tools page—it's an editorial spread that introduces each transformation tool as a chapter in the user's brand story. Each tool should feel like a carefully curated magazine spread that invites exploration, not like a utilitarian dashboard.

## PAGE STRUCTURE & COMPONENT LAYOUT

## 1. HERO SECTION (REQUIRED, CONSISTENT)

- **Use Global Hero Component:**  
  Always use `<HeroGlobal />` at the top of every tools and dashboard page.
- **Props Example:**  
  - Title: TOOLS (or DASHBOARD, YOUR VIBE, etc.)
  - Tagline: “Your magic toolbox, one click away.” *(or whatever fits the tool’s promise—see below)*
  - Username: “Hey [FirstName], let’s get started.” *(Always personal, always warm)*"
- Clean, minimal design with ample negative space

### 2. TOOL INTRODUCTION (ToolsIntroduction)
- Editorial paragraph introducing the collection of tools
- Quote: "Tools don't build brands. Stories do."
- Short description about how these tools work together to create a cohesive brand story
- Minimal, clean typography with generous spacing

### 3. FEATURED TOOL SHOWCASE (FeaturedToolShowcase)
- Highlight "Selfie Generator" as the featured/newest tool
- Large editorial image (phone or mirror shot)
- Extended description and prominent CTA
- "NEW" label in uppercase with tracking
- Subtle animation on hover/interaction

### 4. TOOL COLLECTION (ToolCollection)
- Grid layout of all tools (3 columns on desktop, 2 on tablet, 1 on mobile)
- Each tool card includes:
  - Editorial image
  - Tool name (Bodoni)
  - Short description
  - START button (uppercase, tracked)
  - Status label if applicable (NEW, UPDATED, COMING SOON)
- Generous spacing between cards
- Subtle hover effects
- Tool categories:
  1. Selfie Generator
  2. Future Self
  3. Content Calendar
  4. Landing Page Builder
  5. Brand Voice Creator
  6. Social Blueprint

### 5. METHOD EXPLANATION (ToolsMethodExplanation)
- Split layout (text + image)
- Explain Sandra's method behind the tools
- "The Phoenix Method" - brief description
- Quote: "Your tools should work as hard as you do."
- Link to methodology page

### 6. TESTIMONIAL SECTION (ToolsTestimonialSlider)
- Editorial quote slider/carousel
- Success stories specifically about tool usage
- Before/after context
- User images that feel editorial, not stock
- Manual navigation (no auto-scroll)

### 7. NEXT STEPS CTA (ToolsNextStepsCTA)
- Clean, editorial CTA section
- "Ready to transform your story?"
- Link to get started or explore more
- Sandra's signature quote about taking action

## EDITORIAL STYLING NOTES

### Typography
- Headline: Bodoni, 64px+, generous line height
- Body: Clean sans-serif, 18-21px
- CTAs: Uppercase, tracked (0.3em)
- Quotes: Bodoni italic, 32px+

### Spacing
- Generous whitespace throughout
- 120-160px vertical padding between sections
- Allow typography to breathe
- Grid gaps: 40-60px minimum

### Imagery
- Editorial, high-contrast photography
- Transformation focused (before/after storytelling)
- Phone/mirror shots for selfie tools
- Laptop/planning shots for strategy tools
- AI gallery for future self

### Microinteractions
- Subtle scale on hover for tool cards
- Smooth underline animations for CTAs
- No bouncing or playful animations
- Everything should feel luxurious and intentional

## COLOR & LAYOUT DIRECTION

- Black/white primary palette
- Editorial gray for backgrounds
- No color accents except in imagery
- Clean grid structures with intentional breaks
- Magazine-inspired layout
- Mobile first, but create desktop editorial moments

## CODE STRUCTURE

- Create reusable components for tool cards
- Implement responsive grid
- Ensure all images are optimized
- Implement subtle animations using CSS transitions
- Keep accessibility in mind (proper contrast, alt text, etc.)

## SANDRA'S NOTES

This tools page should feel like walking into a high-end studio where everything has purpose and nothing is superfluous. I want users to feel like each tool is a chapter in their story, not just a utility.

Let's build a tools page that feels like a magazine spread, not a checklist.

*—Sandra*

## 2. LAYOUT & SPACING

- **Grid, not list:**  
  2-3 columns, responsive to 1 on mobile. Air, always.
- **Section Padding:**  
  - Desktop: 80-120px top/bottom  
  - Mobile: 40px top/bottom
- **Page Max Width:**  
  1200px, always centered. Never full-bleed.  
  Air on both sides—luxury = negative space.

---

## 3. TOOLCARD COMPONENT

- **Editorial image:**  
  - 64x64px, left-aligned on desktop, stacked on mobile  
  - Slightly desaturated, editorial feel (never icons, never stock photos)
- **Headline:**  
  - Times New Roman, 2.2–2.6rem, tight and luxe  
  - Black, never gray. Short. Editorial.  
- **Subcopy:**  
  - System sans, #666, max 2 lines—make it feel like Sandra’s advice, not instructions.
- **CTA:**  
  - All caps, 13px, letter-spacing: 0.3em
  - Underline animates in on hover  
  - Editorial: “START”, “CREATE”, “GO”, etc.—always action, never pressure
- **Card Style:**  
  - White bg, 1.5px #e5e5e5 border, 8px radius  
  - Padding: 48–56px desktop, 24–32px mobile  
  - Hover: scale 1.025, subtle shadow #e5e5e580  
  - Transition: 0.22s cubic-bezier(0.4,0,0.2,1)

```css
.tool-card {
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  background: #fff;
  border: 1.5px solid #e5e5e5;
  border-radius: 8px;
  padding: 56px;
  transition: box-shadow 0.22s cubic-bezier(0.4,0,0.2,1), transform 0.22s cubic-bezier(0.4,0,0.2,1);
}
.tool-card:hover {
  box-shadow: 0 8px 32px 0 #e5e5e580;
  transform: scale(1.025);
}
.tool-card .cta {
  text-transform: uppercase;
  font-size: 13px;
  letter-spacing: 0.3em;
  border-bottom: 1.5px solid transparent;
  transition: border-color 0.22s, color 0.22s;
}
.tool-card .cta:hover {
  border-bottom: 1.5px solid #0a0a0a;
}
@media (max-width: 900px) {
  .tool-card {
    flex-direction: column;
    padding: 28px;
  }
}
```

---

## 4. SECTION HEADLINES

- **Always editorial, always consistent:**  
  - Times New Roman, 3.2rem for main page title  
  - Example: “Your Magic Toolbox”  
  - Subheadline: Soft gray, “Pick a tool to get started. You can always come back.” (system sans, max 2 lines)

---

## 5. MICROINTERACTIONS & ACCESSIBILITY

- **Card hover:**  
  - Subtle scale and shadow (never bouncy, never bright)
  - CTA underline animates left-to-right
- **Accessible:**  
  - Whole card is keyboard clickable  
  - Clear hover and focus states

---

## 6. MOBILE UX

- Stack images above text
- Padding reduced to 24–32px
- Cards full-width, 12px gap
- Big tap targets, air still matters