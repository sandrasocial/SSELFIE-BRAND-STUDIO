'use client'

import React from 'react'
import Navigation from '@/components/global/Navigation'
import { Footer } from '@/components/global/Footer'
import { 
  AboutHero,
  BeginningStory,
  ImageBreak,
  MomentQuote,
  TimelineStats,
  EvolutionStory,
  PhilosophySection,
  EditorialGallery,
  FinalCTA
} from '@/components/sections'
import { SandraImages } from '@/components/sandra-image-library'

export default function AboutPage() {
  return (
    <>
      {/* Navigation */}
      <Navigation />
      
      <main className="bg-white">
        {/* Hero Section */}
        <AboutHero />

        {/* Magazine Spread 1 - The Beginning */}
        <BeginningStory />

        {/* Full Width Image Break */}
        <ImageBreak 
          src={SandraImages.editorial.mirror}
          alt="Mirror Moment / Transformation"
        />

        {/* Magazine Spread 2 - The Moment */}
        <MomentQuote />

        {/* The Numbers - Editorial Style */}
        <TimelineStats />

        {/* Magazine Spread 3 - The Evolution */}
        <EvolutionStory />

        {/* The Philosophy - Clean Typography */}
        <PhilosophySection />

        {/* Image Gallery - Editorial Grid */}
        <EditorialGallery />

        {/* Final CTA - Magazine Style */}
        <FinalCTA />
      </main>
      
      {/* Global Footer */}
      <Footer />
    </>
  )
}