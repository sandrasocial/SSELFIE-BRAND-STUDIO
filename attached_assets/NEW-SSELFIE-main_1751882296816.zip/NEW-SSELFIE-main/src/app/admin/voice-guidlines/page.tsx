'use client'

import React from 'react'

/**
 * VOICE GUIDELINES - Admin Resource Page
 * 
 * Purpose: Brand voice, tone, and copywriting guidelines
 * Access: Admin-only reference for content consistency
 * Content: Sandra's voice guidelines (HTML imported)
 * 
 * Business Context:
 * - Master reference for all copywriting decisions
 * - Brand voice and tone standards
 * - Messaging consistency across platform
 * - Content creation guidelines
 */

export default function VoiceGuidelinesPage() {
  const toggleChecked = (e: React.MouseEvent<HTMLLIElement>) => {
    e.currentTarget.classList.toggle('checked')
  }

  return (
    <>
      <style jsx>{`
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        :root {
            /* Core Colors */
            --luxury-black: #171719;
            --soft-white: #F1F1F1;
            --warm-gray: #B5B5B3;
            --pure-white: #FFFFFF;
            --deep-graphite: #4C4B4B;
            
            /* Spacing */
            --space-xs: 8px;
            --space-sm: 16px;
            --space-md: 24px;
            --space-lg: 40px;
            --space-xl: 60px;
            --space-xxl: 80px;
            --space-hero: 100px;
            
            /* Typography */
            --font-serif: 'Bodoni Moda', Georgia, serif;
            --font-sans: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            --font-accent: 'Playfair Display', Georgia, serif;
            
            /* Transitions */
            --ease-default: cubic-bezier(0.4, 0, 0.2, 1);
            --ease-editorial: cubic-bezier(0.16, 1, 0.3, 1);
        }
        
        ::selection {
            background: var(--luxury-black);
            color: var(--pure-white);
        }
        
        :global(body) {
            font-family: var(--font-sans);
            font-weight: 300;
            color: var(--luxury-black);
            background: var(--pure-white);
            line-height: 1.8;
            letter-spacing: -0.01em;
        }
        
        /* Typography */
        h1, h2, h3 {
            font-family: var(--font-serif);
            font-weight: 300;
            letter-spacing: -0.04em;
            line-height: 1.1;
        }
        
        h1 {
            font-size: clamp(48px, 8vw, 96px);
            margin-bottom: var(--space-md);
        }
        
        h2 {
            font-size: clamp(36px, 6vw, 72px);
            margin-bottom: var(--space-lg);
        }
        
        h3 {
            font-size: clamp(28px, 4vw, 48px);
            margin-bottom: var(--space-md);
        }
        
        h4 {
            font-family: var(--font-sans);
            font-size: 12px;
            font-weight: 400;
            letter-spacing: 0.2em;
            text-transform: uppercase;
            margin-bottom: var(--space-sm);
        }
        
        p {
            font-size: 18px;
            line-height: 1.8;
            font-weight: 300;
            max-width: 720px;
        }
        
        /* Navigation */
        .nav-fixed {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-bottom: 0.5px solid var(--warm-gray);
            transition: all 0.3s var(--ease-default);
        }
        
        nav {
            max-width: 1600px;
            margin: 0 auto;
            padding: 24px 60px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            font-family: var(--font-serif);
            font-size: 24px;
            letter-spacing: -0.02em;
        }
        
        .nav-menu {
            display: flex;
            gap: 48px;
            list-style: none;
        }
        
        .nav-menu a {
            color: var(--luxury-black);
            text-decoration: none;
            font-size: 12px;
            font-weight: 400;
            letter-spacing: 0.1em;
            text-transform: uppercase;
            transition: opacity 0.3s var(--ease-default);
            position: relative;
        }
        
        .nav-menu a::after {
            content: '';
            position: absolute;
            bottom: -4px;
            left: 0;
            right: 0;
            height: 1px;
            background: var(--luxury-black);
            transform: scaleX(0);
            transition: transform 0.3s var(--ease-editorial);
        }
        
        .nav-menu a:hover::after {
            transform: scaleX(1);
        }
        
        /* Sections */
        section {
            padding: var(--space-hero) 0;
            position: relative;
        }
        
        .container {
            max-width: 1600px;
            margin: 0 auto;
            padding: 0 60px;
        }
        
        /* Hero */
        .hero {
            min-height: 60vh;
            display: flex;
            align-items: center;
            background: var(--luxury-black);
            color: var(--pure-white);
            position: relative;
            overflow: hidden;
            margin-top: 73px;
        }
        
        .hero-bg {
            position: absolute;
            inset: 0;
            opacity: 0.3;
        }
        
        .hero-bg img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .hero-content {
            position: relative;
            z-index: 1;
        }
        
        /* Editorial Number */
        .editorial-number {
            font-family: var(--font-serif);
            font-size: clamp(120px, 15vw, 200px);
            position: absolute;
            top: -40px;
            right: 60px;
            opacity: 0.03;
            line-height: 1;
            pointer-events: none;
        }
        
        /* Voice Cards */
        .voice-card {
            background: var(--soft-white);
            padding: var(--space-xl);
            margin-bottom: var(--space-md);
            position: relative;
            overflow: hidden;
        }
        
        .voice-card.dark {
            background: var(--luxury-black);
            color: var(--pure-white);
        }
        
        .voice-card h3 {
            margin-bottom: var(--space-md);
        }
        
        /* Examples Grid */
        .example-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: var(--space-lg);
            margin: var(--space-lg) 0;
        }
        
        .example-box {
            padding: var(--space-lg);
            background: var(--pure-white);
            border: 0.5px solid var(--warm-gray);
        }
        
        .example-box.good {
            border-left: 3px solid var(--luxury-black);
        }
        
        .example-box.bad {
            border-left: 3px solid var(--warm-gray);
            opacity: 0.7;
        }
        
        .example-label {
            font-size: 12px;
            letter-spacing: 0.2em;
            text-transform: uppercase;
            margin-bottom: var(--space-sm);
            color: var(--luxury-black);
        }
        
        .example-box.bad .example-label {
            text-decoration: line-through;
        }
        
        /* Word Lists */
        .word-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: var(--space-md);
            margin: var(--space-lg) 0;
        }
        
        .word-list {
            list-style: none;
        }
        
        .word-list li {
            padding: var(--space-xs) 0;
            border-bottom: 0.5px solid var(--warm-gray);
            font-size: 16px;
        }
        
        /* Quote Blocks */
        .quote-block {
            padding: var(--space-xxl) 0;
            text-align: center;
            background: var(--luxury-black);
            color: var(--pure-white);
        }
        
        .quote-text {
            font-family: var(--font-accent);
            font-size: clamp(28px, 3vw, 40px);
            font-style: italic;
            letter-spacing: -0.02em;
            line-height: 1.4;
            max-width: 1000px;
            margin: 0 auto;
        }
        
        /* Checklist */
        .checklist {
            list-style: none;
            margin: var(--space-lg) 0;
        }
        
        .checklist li {
            padding: var(--space-sm) 0;
            border-bottom: 0.5px solid var(--warm-gray);
            display: flex;
            align-items: center;
            gap: var(--space-sm);
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .checklist li:hover {
            padding-left: var(--space-sm);
        }
        
        .checkbox {
            width: 24px;
            height: 24px;
            border: 2px solid var(--luxury-black);
            position: relative;
            flex-shrink: 0;
        }
        
        .checklist li:global(.checked) .checkbox::after {
            content: '';
            position: absolute;
            left: 6px;
            top: 2px;
            width: 8px;
            height: 14px;
            border: solid var(--luxury-black);
            border-width: 0 2px 2px 0;
            transform: rotate(45deg);
        }
        
        /* Responsive */
        @media (max-width: 1200px) {
            .container { padding: 0 40px; }
            .example-grid { grid-template-columns: 1fr; }
        }
        
        @media (max-width: 768px) {
            section { padding: var(--space-xxl) 0; }
            .container { padding: 0 24px; }
            nav { padding: 20px 24px; }
            .nav-menu { display: none; }
            h1 { font-size: 48px; }
            h2 { font-size: 36px; }
            h3 { font-size: 28px; }
            .editorial-number { font-size: 100px; }
            .voice-card { padding: var(--space-lg); }
        }
      `}</style>
      
      <div>
        {/* Navigation */}
        <div className="nav-fixed">
            <nav>
                <div className="logo">SSELFIE</div>
                <ul className="nav-menu">
                    <li><a href="#essence">Essence</a></li>
                    <li><a href="#principles">Principles</a></li>
                    <li><a href="#examples">Examples</a></li>
                    <li><a href="#vocabulary">Vocabulary</a></li>
                    <li><a href="#templates">Templates</a></li>
                    <li><a href="#checklist">Checklist</a></li>
                </ul>
            </nav>
        </div>
        
        {/* Hero */}
        <section className="hero">
            <div className="hero-bg">
                <img src="https://i.postimg.cc/YqG0t39C/out-1-24.webp" alt="Voice hero" />
            </div>
            <div className="container">
                <div className="hero-content">
                    <h4>SSELFIE STUDIO</h4>
                    <h1>Voice Guidelines</h1>
                    <p style={{fontSize: '24px', marginTop: '32px', opacity: 0.9}}>
                        How to sound like Sandra's best friend who happens<br />
                        to know everything about looking expensive.
                    </p>
                </div>
            </div>
        </section>
        
        {/* Brand Essence */}
        <section id="essence">
            <div className="container">
                <span className="editorial-number">01</span>
                <h2>Brand Voice<br />Essence</h2>
                
                <div className="voice-card">
                    <h3>Who You Are</h3>
                    <p style={{fontSize: '24px', marginBottom: '32px'}}>
                        Sandra - The friend who gets it. Former hairdresser, single mom of 3, 
                        built 120K followers in 90 days.
                    </p>
                    <p style={{fontFamily: 'var(--font-accent)', fontStyle: 'italic', fontSize: '32px'}}>
                        "Like Rachel from FRIENDS meets luxury fashion editor.<br />
                        Simple words, warm heart, impeccable taste."
                    </p>
                </div>
                
                <div className="voice-card dark">
                    <h3>The Mission</h3>
                    <p style={{fontSize: '20px'}}>
                        We're not just teaching selfies. We're building an army of confident women 
                        who know their worth and aren't afraid to show it. Every word should feel 
                        like Sandra - the friend who made it and is reaching back to pull you up too.
                    </p>
                </div>
            </div>
        </section>
        
        {/* Core Principles */}
        <section id="principles" style={{background: 'var(--soft-white)'}}>
            <div className="container">
                <span className="editorial-number">02</span>
                <h2>Core Voice<br />Principles</h2>
                
                <div className="voice-card" style={{background: 'var(--pure-white)'}}>
                    <h3>1. Speak Like Rachel, Design Like Vogue</h3>
                    <ul style={{listStyle: 'none', marginTop: '24px'}}>
                        <li style={{padding: '12px 0'}}>• Use everyday language that your sister would understand</li>
                        <li style={{padding: '12px 0'}}>• No fancy business jargon or "empowerment speak"</li>
                        <li style={{padding: '12px 0'}}>• Think coffee chat, not corporate meeting</li>
                        <li style={{padding: '12px 0'}}>• Luxury doesn't mean complicated</li>
                    </ul>
                </div>
                
                <div className="voice-card" style={{background: 'var(--pure-white)'}}>
                    <h3>2. The "Best Friend Who Made It" Tone</h3>
                    <p style={{marginBottom: '24px'}}>
                        You're not talking down to anyone. You're the friend who figured it out 
                        and is pulling everyone else up with you.
                    </p>
                    <div style={{background: 'var(--soft-white)', padding: '32px', marginTop: '24px'}}>
                        <p style={{fontStyle: 'italic'}}>
                            "Listen, I get it. I was there too - divorced, starting over, taking 
                            bathroom selfies at 2am trying to figure out Instagram."
                        </p>
                    </div>
                </div>
                
                <div className="voice-card" style={{background: 'var(--pure-white)'}}>
                    <h3>3. No Exclamation Marks Rule</h3>
                    <p style={{fontSize: '20px', marginBottom: '24px'}}>
                        Confidence doesn't need to shout. Your words are powerful enough.
                    </p>
                    <div className="example-grid">
                        <div className="example-box bad">
                            <p className="example-label">Instead of</p>
                            <p>"This is amazing! You'll love it! Transform your life!"</p>
                        </div>
                        <div className="example-box good">
                            <p className="example-label">Write</p>
                            <p>"This changes everything. You're going to love what happens next."</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        {/* Quote Break */}
        <div className="quote-block">
            <div className="container">
                <p className="quote-text">
                    "Your selfie literally IS your business card now.<br />
                    Let's make sure it's working for you."
                </p>
            </div>
        </div>
        
        {/* Copy Examples */}
        <section id="examples">
            <div className="container">
                <span className="editorial-number">03</span>
                <h2>Copy Examples<br />By Context</h2>
                
                {/* Headlines */}
                <div className="voice-card">
                    <h3>Headlines</h3>
                    <div className="example-grid">
                        <div className="example-box good">
                            <p className="example-label">Good</p>
                            <p style={{fontSize: '24px', fontFamily: 'var(--font-serif)'}}>Your story starts here.<br />Let's make it unforgettable.</p>
                        </div>
                        <div className="example-box bad">
                            <p className="example-label">Bad</p>
                            <p style={{fontSize: '24px'}}>Transform your brand and scale your impact today!</p>
                        </div>
                    </div>
                </div>
                
                {/* Body Copy */}
                <div className="voice-card">
                    <h3>Body Copy</h3>
                    <div className="example-grid">
                        <div className="example-box good">
                            <p className="example-label">Good</p>
                            <p>"Here's the thing - everyone's out here spending hundreds on photoshoots that give them maybe 20 photos they actually like. Meanwhile, you need fresh content every single day."</p>
                        </div>
                        <div className="example-box bad">
                            <p className="example-label">Bad</p>
                            <p>"Our revolutionary AI-powered platform leverages cutting-edge technology to optimize your personal brand presence across all digital touchpoints."</p>
                        </div>
                    </div>
                </div>
                
                {/* CTAs */}
                <div className="voice-card">
                    <h3>Call to Actions</h3>
                    <div className="example-grid">
                        <div className="example-box good">
                            <p className="example-label">Good</p>
                            <ul style={{listStyle: 'none'}}>
                                <li style={{padding: '8px 0'}}>Start Here</li>
                                <li style={{padding: '8px 0'}}>Let's Do This</li>
                                <li style={{padding: '8px 0'}}>Get The Guide</li>
                                <li style={{padding: '8px 0'}}>Join Us</li>
                            </ul>
                        </div>
                        <div className="example-box bad">
                            <p className="example-label">Bad</p>
                            <ul style={{listStyle: 'none'}}>
                                <li style={{padding: '8px 0'}}>Click Here Now!</li>
                                <li style={{padding: '8px 0'}}>Transform Today!</li>
                                <li style={{padding: '8px 0'}}>Unlock Your Potential!</li>
                                <li style={{padding: '8px 0'}}>Start Your Journey!</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                {/* Email Subject Lines */}
                <div className="voice-card">
                    <h3>Email Subject Lines</h3>
                    <div className="example-grid">
                        <div className="example-box good">
                            <p className="example-label">Good</p>
                            <ul style={{listStyle: 'none'}}>
                                <li style={{padding: '8px 0'}}>the selfie secret nobody talks about</li>
                                <li style={{padding: '8px 0'}}>why your selfies look weird (and how to fix it)</li>
                                <li style={{padding: '8px 0'}}>I took 100 selfies yesterday. Here's why</li>
                                <li style={{padding: '8px 0'}}>the $47 tool that replaced my photographer</li>
                            </ul>
                        </div>
                        <div className="example-box bad">
                            <p className="example-label">Bad</p>
                            <ul style={{listStyle: 'none'}}>
                                <li style={{padding: '8px 0'}}>🔥 TRANSFORM Your Selfie Game NOW! 🔥</li>
                                <li style={{padding: '8px 0'}}>You Won't BELIEVE This Selfie Hack!!!</li>
                                <li style={{padding: '8px 0'}}>⚡ Limited Time Offer Inside! ⚡</li>
                                <li style={{padding: '8px 0'}}>Unlock Your Selfie Goddess Energy ✨</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        {/* Vocabulary */}
        <section id="vocabulary" style={{background: 'var(--soft-white)'}}>
            <div className="container">
                <span className="editorial-number">04</span>
                <h2>Words We Use<br />vs Words We Don't</h2>
                
                <div className="voice-card" style={{background: 'var(--pure-white)'}}>
                    <div className="word-grid">
                        <div>
                            <h3 style={{color: 'var(--luxury-black)', fontSize: '24px'}}>YES Words</h3>
                            <ul className="word-list">
                                <li>Queen (but sparingly)</li>
                                <li>Fire (for great content)</li>
                                <li>Real talk</li>
                                <li>Here's the thing</li>
                                <li>Listen</li>
                                <li>Okay, so</li>
                                <li>Let's be honest</li>
                                <li>Game-changer</li>
                                <li>Next level</li>
                            </ul>
                        </div>
                        <div>
                            <h3 style={{color: 'var(--warm-gray)', fontSize: '24px'}}>NO Words</h3>
                            <ul className="word-list" style={{opacity: 0.7}}>
                                <li>Goddess</li>
                                <li>Unleash</li>
                                <li>Transform (unless specific)</li>
                                <li>Journey</li>
                                <li>Authentic self</li>
                                <li>Empowerment</li>
                                <li>Manifest</li>
                                <li>Align</li>
                                <li>Sacred feminine</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        {/* Response Templates */}
        <section id="templates">
            <div className="container">
                <span className="editorial-number">05</span>
                <h2>Response<br />Templates</h2>
                
                <div className="voice-card">
                    <h3>When someone says "I'm not photogenic"</h3>
                    <div style={{background: 'var(--soft-white)', padding: '32px', marginTop: '24px'}}>
                        <p style={{fontStyle: 'italic'}}>
                            "Okay stop. There's no such thing as 'not photogenic.' There's only not 
                            knowing your angles yet. Let me show you."
                        </p>
                    </div>
                </div>
                
                <div className="voice-card">
                    <h3>When someone asks about price</h3>
                    <div style={{background: 'var(--soft-white)', padding: '32px', marginTop: '24px'}}>
                        <p style={{fontStyle: 'italic'}}>
                            "Listen, you spend more on coffee in a month. This is an investment in 
                            your business, your brand, and honestly? Your confidence. Which one matters more?"
                        </p>
                    </div>
                </div>
                
                <div className="voice-card">
                    <h3>When someone shares a win</h3>
                    <div style={{background: 'var(--soft-white)', padding: '32px', marginTop: '24px'}}>
                        <p style={{fontStyle: 'italic'}}>
                            "THIS is what I'm talking about. You see what happens when you stop hiding? 
                            The world was waiting for this version of you."
                        </p>
                    </div>
                </div>
            </div>
        </section>
        
        {/* Voice Checklist */}
        <section id="checklist" style={{background: 'var(--soft-white)'}}>
            <div className="container">
                <span className="editorial-number">06</span>
                <h2>Voice Checklist</h2>
                <p style={{fontSize: '24px', marginBottom: '60px'}}>
                    Before publishing anything, run through this list. Every box should be checked.
                </p>
                
                <div className="voice-card" style={{background: 'var(--pure-white)'}}>
                    <h3>For All Content</h3>
                    <ul className="checklist">
                        <li onClick={toggleChecked}>
                            <div className="checkbox"></div>
                            <span>Would Rachel from FRIENDS say this?</span>
                        </li>
                        <li onClick={toggleChecked}>
                            <div className="checkbox"></div>
                            <span>Is it simple enough for my mom to understand?</span>
                        </li>
                        <li onClick={toggleChecked}>
                            <div className="checkbox"></div>
                            <span>Does it sound like advice from a successful friend?</span>
                        </li>
                        <li onClick={toggleChecked}>
                            <div className="checkbox"></div>
                            <span>Are there any exclamation marks to remove?</span>
                        </li>
                        <li onClick={toggleChecked}>
                            <div className="checkbox"></div>
                            <span>Does it feel expensive but approachable?</span>
                        </li>
                        <li onClick={toggleChecked}>
                            <div className="checkbox"></div>
                            <span>Would I text this to my best friend?</span>
                        </li>
                    </ul>
                </div>
            </div>
        </section>
        
        {/* Final Quote */}
        <div className="quote-block" style={{padding: '120px 0'}}>
            <div className="container">
                <h4 style={{color: 'white', marginBottom: '32px'}}>FINAL VOICE RULE</h4>
                <p className="quote-text">
                    "When in doubt, write like you're texting your<br />
                    best friend who needs a pep talk. Keep it real,<br />
                    keep it warm, keep it moving forward."
                </p>
            </div>
        </div>
      </div>
    </>
  )
}