'use client'

import React from 'react'

/**
 * ULTIMATE DESIGN MANUAL - Admin Resource Page
 * 
 * Purpose: Complete visual design system and brand guidelines
 * Access: Admin-only reference for design consistency
 * Content: Sandra's ultimate design manual (HTML imported)
 * 
 * Business Context:
 * - Master reference for all design decisions
 * - Ensures brand consistency across platform
 * - Source of truth for luxury aesthetic standards
 * - Used by Victoria for component creation FROM SCRATCH
 */

export default function DesignManual() {
  return (
    <>
      <style jsx>{`
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        :root {
            /* Core Colors */
            --luxury-black: #171719;
            --soft-white: #F1F1F1;
            --warm-gray: #B5B5B3;
            --pure-white: #FFFFFF;
            --deep-graphite: #4C4B4B;
            
            /* Spacing Scale */
            --space-micro: 4px;
            --space-xs: 8px;
            --space-sm: 16px;
            --space-md: 24px;
            --space-lg: 40px;
            --space-xl: 60px;
            --space-xxl: 80px;
            --space-hero: 100px;
            
            /* Typography */
            --font-serif: 'Bodoni Moda', Georgia, serif;
            --font-sans: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            --font-accent: 'Playfair Display', Georgia, serif;
            
            /* Transitions */
            --ease-default: cubic-bezier(0.4, 0, 0.2, 1);
            --ease-in: cubic-bezier(0, 0, 0.2, 1);
            --ease-out: cubic-bezier(0.4, 0, 0.6, 1);
            --ease-editorial: cubic-bezier(0.16, 1, 0.3, 1);
        }
        
        ::selection {
            background: var(--luxury-black);
            color: var(--pure-white);
        }
        
        body {
            font-family: var(--font-sans);
            font-weight: 300;
            color: var(--luxury-black);
            background: var(--pure-white);
            line-height: 1.8;
            letter-spacing: -0.01em;
        }
        
        /* Typography System */
        h1, h2, h3 {
            font-family: var(--font-serif);
            font-weight: 300;
            letter-spacing: -0.04em;
            line-height: 1.1;
        }
        
        h1 {
            font-size: clamp(48px, 8vw, 96px);
            margin-bottom: var(--space-md);
        }
        
        h2 {
            font-size: clamp(36px, 6vw, 72px);
            margin-bottom: var(--space-lg);
        }
        
        h3 {
            font-size: clamp(28px, 4vw, 48px);
            margin-bottom: var(--space-md);
        }
        
        h4 {
            font-family: var(--font-sans);
            font-size: 12px;
            font-weight: 400;
            letter-spacing: 0.2em;
            text-transform: uppercase;
            margin-bottom: var(--space-sm);
        }
        
        p {
            font-size: 18px;
            line-height: 1.8;
            font-weight: 300;
            max-width: 720px;
        }
        
        /* Navigation */
        .nav-fixed {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-bottom: 0.5px solid var(--warm-gray);
            transition: all 0.3s var(--ease-default);
        }
        
        nav {
            max-width: 1600px;
            margin: 0 auto;
            padding: 24px 60px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            font-family: var(--font-serif);
            font-size: 24px;
            letter-spacing: -0.02em;
        }
        
        .nav-menu {
            display: flex;
            gap: 48px;
            list-style: none;
        }
        
        .nav-menu a {
            color: var(--luxury-black);
            text-decoration: none;
            font-size: 12px;
            font-weight: 400;
            letter-spacing: 0.1em;
            text-transform: uppercase;
            transition: opacity 0.3s var(--ease-default);
            position: relative;
        }
        
        .nav-menu a::after {
            content: '';
            position: absolute;
            bottom: -4px;
            left: 0;
            right: 0;
            height: 1px;
            background: var(--luxury-black);
            transform: scaleX(0);
            transition: transform 0.3s var(--ease-editorial);
        }
        
        .nav-menu a:hover::after {
            transform: scaleX(1);
        }
        
        /* Sections */
        section {
            padding: var(--space-hero) 0;
            position: relative;
        }
        
        .container {
            max-width: 1600px;
            margin: 0 auto;
            padding: 0 60px;
        }
        
        /* Hero */
        .hero {
            min-height: 100vh;
            display: flex;
            align-items: center;
            background: var(--luxury-black);
            color: var(--pure-white);
            position: relative;
            overflow: hidden;
        }
        
        .hero-bg {
            position: absolute;
            inset: 0;
            opacity: 0.4;
        }
        
        .hero-bg img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .hero-content {
            position: relative;
            z-index: 1;
        }
        
        /* Grid System */
        .grid {
            display: grid;
            grid-template-columns: repeat(12, 1fr);
            gap: 32px;
        }
        
        .col-3 { grid-column: span 3; }
        .col-4 { grid-column: span 4; }
        .col-6 { grid-column: span 6; }
        .col-8 { grid-column: span 8; }
        .col-12 { grid-column: span 12; }
        
        /* Component Examples */
        .component-showcase {
            background: var(--soft-white);
            padding: var(--space-xl);
            margin-bottom: var(--space-lg);
            position: relative;
            overflow: hidden;
        }
        
        .component-label {
            position: absolute;
            top: 24px;
            left: 24px;
            font-size: 12px;
            letter-spacing: 0.2em;
            text-transform: uppercase;
            opacity: 0.5;
        }
        
        /* Luxury Elements */
        .luxury-line {
            position: fixed;
            left: 80px;
            top: 0;
            width: 1px;
            height: 100vh;
            background: linear-gradient(to bottom, transparent, var(--warm-gray) 20%, var(--warm-gray) 80%, transparent);
            opacity: 0.3;
            z-index: 100;
        }
        
        .editorial-number {
            font-family: var(--font-serif);
            font-size: clamp(120px, 15vw, 200px);
            position: absolute;
            top: -40px;
            right: 60px;
            opacity: 0.03;
            line-height: 1;
            pointer-events: none;
        }
        
        /* Interactive Elements */
        .luxury-button {
            background: var(--luxury-black);
            color: var(--pure-white);
            padding: 25px 60px;
            border: none;
            font-size: 14px;
            letter-spacing: 0.3em;
            text-transform: uppercase;
            cursor: pointer;
            transition: all 0.3s var(--ease-default);
            position: relative;
            overflow: hidden;
        }
        
        .luxury-button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.1);
            transition: left 0.5s var(--ease-editorial);
        }
        
        .luxury-button:hover {
            transform: translateY(-2px);
        }
        
        .luxury-button:hover::before {
            left: 100%;
        }
        
        /* Code Examples */
        .code-block {
            background: var(--luxury-black);
            color: var(--pure-white);
            padding: var(--space-lg);
            margin: var(--space-md) 0;
            font-family: 'Monaco', 'Courier New', monospace;
            font-size: 14px;
            overflow-x: auto;
            position: relative;
        }
        
        .code-comment {
            opacity: 0.5;
            font-style: italic;
        }
        
        /* Visual Examples */
        .visual-example {
            background: var(--pure-white);
            border: 0.5px solid var(--warm-gray);
            padding: var(--space-xl);
            margin: var(--space-lg) 0;
            position: relative;
        }
        
        /* Hover States Demo */
        .hover-demo {
            padding: var(--space-lg);
            transition: all 0.3s var(--ease-editorial);
            cursor: pointer;
        }
        
        .hover-demo:hover {
            background: var(--soft-white);
            transform: translateX(8px);
        }
        
        /* Loading Animation */
        @keyframes luxuryPulse {
            0%, 100% { opacity: 0.3; }
            50% { opacity: 1; }
        }
        
        .loading-dot {
            width: 8px;
            height: 8px;
            background: var(--luxury-black);
            animation: luxuryPulse 1.5s ease-in-out infinite;
        }
        
        /* Responsive */
        @media (max-width: 1200px) {
            .container { padding: 0 40px; }
            .col-3, .col-4 { grid-column: span 6; }
            .col-6, .col-8 { grid-column: span 12; }
        }
        
        @media (max-width: 768px) {
            section { padding: var(--space-xxl) 0; }
            .container { padding: 0 24px; }
            nav { padding: 20px 24px; }
            .nav-menu { display: none; }
            .col-3, .col-4, .col-6, .col-8 { grid-column: span 12; }
            h1 { font-size: 48px; }
            h2 { font-size: 36px; }
            h3 { font-size: 28px; }
            .luxury-line { display: none; }
            .editorial-number { font-size: 100px; }
        }
    </style>
</head>
<body>
    <!-- Luxury Scroll Line -->
    <div class="luxury-line"></div>
    
    <!-- Navigation -->
    <div class="nav-fixed">
        <nav>
            <div class="logo">SSELFIE</div>
            <ul class="nav-menu">
                <li><a href="#foundation">Foundation</a></li>
                <li><a href="#components">Components</a></li>
                <li><a href="#interactions">Interactions</a></li>
                <li><a href="#implementation">Implementation</a></li>
                <li><a href="#widgets">Widgets</a></li>
                <li><a href="#checklist">Checklist</a></li>
            </ul>
        </nav>
    </div>
    
    <!-- Hero -->
    <section class="hero">
        <div class="hero-bg">
            <img src="https://i.postimg.cc/nrKdm7Vj/out-2-4.webp" alt="Hero background">
        </div>
        <div class="container">
            <div class="hero-content">
                <h4>The Complete Guide to</h4>
                <h1>SSELFIE STUDIO<br>Design Excellence</h1>
                <p style="font-size: 24px; margin-top: 32px; opacity: 0.9;">
                    Everything you need to build a platform that looks like<br>
                    it was designed by a Parisian agency.
                </p>
            </div>
        </div>
    </section>
    
    <!-- Foundation Section -->
    <section id="foundation">
        <div class="container">
            <span class="editorial-number">01</span>
            <h2>Design Foundation</h2>
            <p style="font-size: 24px; margin-bottom: 60px;">
                Listen, before we dive into the fancy stuff, let's get the basics right. 
                This is what makes SSELFIE feel expensive without trying too hard.
            </p>
            
            <!-- Color System -->
            <div class="component-showcase">
                <span class="component-label">Color Palette</span>
                <h3>The Only Colors You'll Ever Need</h3>
                <div class="grid" style="margin-top: 40px;">
                    <div class="col-3">
                        <div style="height: 200px; background: var(--luxury-black);"></div>
                        <h4 style="margin-top: 24px;">Luxury Black</h4>
                        <p style="font-family: monospace;">#171719</p>
                        <p style="font-size: 14px; margin-top: 8px;">Primary actions, text, power</p>
                    </div>
                    <div class="col-3">
                        <div style="height: 200px; background: var(--soft-white); border: 0.5px solid var(--warm-gray);"></div>
                        <h4 style="margin-top: 24px;">Soft White</h4>
                        <p style="font-family: monospace;">#F1F1F1</p>
                        <p style="font-size: 14px; margin-top: 8px;">Backgrounds, breathing room</p>
                    </div>
                    <div class="col-3">
                        <div style="height: 200px; background: var(--warm-gray);"></div>
                        <h4 style="margin-top: 24px;">Warm Gray</h4>
                        <p style="font-family: monospace;">#B5B5B3</p>
                        <p style="font-size: 14px; margin-top: 8px;">Subtle accents, dividers</p>
                    </div>
                    <div class="col-3">
                        <div style="height: 200px; background: var(--pure-white); border: 0.5px solid var(--warm-gray);"></div>
                        <h4 style="margin-top: 24px;">Pure White</h4>
                        <p style="font-family: monospace;">#FFFFFF</p>
                        <p style="font-size: 14px; margin-top: 8px;">Content areas, clarity</p>
                    </div>
                </div>
                <p style="margin-top: 40px; font-size: 16px; color: var(--deep-graphite);">
                    That's it. No gradients. No rainbow. Just these four colors used masterfully.
                </p>
            </div>
            
            <!-- Typography -->
            <div class="component-showcase">
                <span class="component-label">Typography System</span>
                <h3>Fonts That Feel Like Money</h3>
                
                <div class="visual-example" style="margin-top: 40px;">
                    <h1 style="font-family: var(--font-serif); margin-bottom: 16px;">Bodoni Moda</h1>
                    <p style="font-size: 14px; color: var(--warm-gray);">Headlines that command attention</p>
                    <div class="code-block" style="margin-top: 24px;">
font-family: 'Bodoni Moda', Georgia, serif;
font-weight: 300;
letter-spacing: -0.04em; <span class="code-comment">// Tight tracking = expensive</span>
line-height: 1.1;
                    </div>
                </div>
                
                <div class="visual-example">
                    <p style="font-family: var(--font-accent); font-style: italic; font-size: 32px; margin-bottom: 16px;">
                        "Your selfie is your brand"
                    </p>
                    <p style="font-size: 14px; color: var(--warm-gray);">Playfair Display Italic for emotional moments</p>
                </div>
                
                <div class="visual-example">
                    <p style="font-size: 24px; font-weight: 200; margin-bottom: 16px;">
                        Inter for body copy that breathes luxury
                    </p>
                    <p style="font-size: 14px; color: var(--warm-gray);">Light weight, generous spacing</p>
                    <div class="code-block" style="margin-top: 24px;">
font-family: 'Inter', -apple-system, sans-serif;
font-weight: 200; <span class="code-comment">// Light = luxury</span>
line-height: 1.8; <span class="code-comment">// Let it breathe</span>
letter-spacing: -0.01em;
                    </div>
                </div>
            </div>
            
            <!-- Spacing System -->
            <div class="component-showcase">
                <span class="component-label">Spacing Scale</span>
                <h3>White Space Is Your Best Friend</h3>
                <div style="margin-top: 40px;">
                    <div style="display: flex; gap: 24px; align-items: flex-end; margin-bottom: 40px;">
                        <div style="width: 4px; height: 40px; background: var(--luxury-black);"></div>
                        <div style="width: 8px; height: 40px; background: var(--luxury-black);"></div>
                        <div style="width: 16px; height: 40px; background: var(--luxury-black);"></div>
                        <div style="width: 24px; height: 40px; background: var(--luxury-black);"></div>
                        <div style="width: 40px; height: 40px; background: var(--luxury-black);"></div>
                        <div style="width: 60px; height: 40px; background: var(--luxury-black);"></div>
                        <div style="width: 80px; height: 40px; background: var(--luxury-black);"></div>
                        <div style="width: 100px; height: 40px; background: var(--luxury-black);"></div>
                    </div>
                    <div class="code-block">
--space-micro: 4px;    <span class="code-comment">// Tiny adjustments</span>
--space-xs: 8px;       <span class="code-comment">// Between related elements</span>
--space-sm: 16px;      <span class="code-comment">// Default spacing</span>
--space-md: 24px;      <span class="code-comment">// Section spacing</span>
--space-lg: 40px;      <span class="code-comment">// Component spacing</span>
--space-xl: 60px;      <span class="code-comment">// Major sections</span>
--space-xxl: 80px;     <span class="code-comment">// Breathing room</span>
--space-hero: 100px;   <span class="code-comment">// Hero sections</span>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Components Section -->
    <section id="components" style="background: var(--soft-white);">
        <div class="container">
            <span class="editorial-number">02</span>
            <h2>Component Library</h2>
            <p style="font-size: 24px; margin-bottom: 60px;">
                Here's every component you need, designed to perfection. Copy, paste, 
                and watch your site transform into something gorgeous.
            </p>
            
            <!-- Buttons -->
            <div class="component-showcase" style="background: var(--pure-white);">
                <span class="component-label">Buttons</span>
                <h3>CTAs That Convert</h3>
                
                <div style="margin-top: 40px;">
                    <button class="luxury-button">Start Your Journey</button>
                    <p style="margin-top: 24px; font-size: 14px; color: var(--warm-gray);">
                        Primary button with subtle hover animation
                    </p>
                    
                    <div class="code-block" style="margin-top: 24px;">
.luxury-button {
    background: #171719;
    color: #FFFFFF;
    padding: 25px 60px;
    border: none;
    font-size: 14px;
    letter-spacing: 0.3em;
    text-transform: uppercase;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.luxury-button:hover {
    transform: translateY(-2px);
}
                    </div>
                </div>
                
                <div style="margin-top: 40px;">
                    <button style="background: transparent; color: var(--luxury-black); padding: 25px 60px; border: 1px solid var(--luxury-black); font-size: 14px; letter-spacing: 0.3em; text-transform: uppercase; cursor: pointer; transition: all 0.3s var(--ease-default);">
                        Learn More
                    </button>
                    <p style="margin-top: 24px; font-size: 14px; color: var(--warm-gray);">
                        Secondary outline button
                    </p>
                </div>
            </div>
            
            <!-- Form Elements -->
            <div class="component-showcase" style="background: var(--pure-white);">
                <span class="component-label">Form Design</span>
                <h3>Inputs That Feel Premium</h3>
                
                <div style="margin-top: 40px; max-width: 600px;">
                    <div style="margin-bottom: 32px;">
                        <label style="display: block; font-size: 12px; letter-spacing: 0.2em; text-transform: uppercase; margin-bottom: 8px;">
                            Your Name
                        </label>
                        <input type="text" style="width: 100%; padding: 16px 0; border: none; border-bottom: 1px solid var(--warm-gray); background: transparent; font-size: 16px; transition: border-color 0.3s ease;" placeholder="Sandra">
                    </div>
                    
                    <div style="margin-bottom: 32px;">
                        <label style="display: block; font-size: 12px; letter-spacing: 0.2em; text-transform: uppercase; margin-bottom: 8px;">
                            Email Address
                        </label>
                        <input type="email" style="width: 100%; padding: 16px 0; border: none; border-bottom: 1px solid var(--warm-gray); background: transparent; font-size: 16px; transition: border-color 0.3s ease;" placeholder="sandra@sselfie.ai">
                    </div>
                    
                    <button class="luxury-button" style="width: 100%;">Get The Guide</button>
                </div>
                
                <div class="code-block" style="margin-top: 40px;">
input {
    border: none;
    border-bottom: 1px solid #B5B5B3;
    padding: 16px 0;
    font-size: 16px;
    background: transparent;
    transition: border-color 0.3s ease;
}

input:focus {
    outline: none;
    border-bottom: 2px solid #171719;
}

label {
    font-size: 12px;
    letter-spacing: 0.2em;
    text-transform: uppercase;
}
                </div>
            </div>
            
            <!-- Cards -->
            <div class="component-showcase" style="background: var(--pure-white);">
                <span class="component-label">Editorial Cards</span>
                <h3>Content That Commands Attention</h3>
                
                <div class="grid" style="margin-top: 40px;">
                    <div class="col-6">
                        <div style="position: relative; height: 500px; overflow: hidden; cursor: pointer;">
                            <img src="https://i.postimg.cc/fLc7qNG1/out-0-12.webp" alt="Card example" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.8s var(--ease-editorial);">
                            <div style="position: absolute; inset: 0; background: linear-gradient(to bottom, transparent 50%, rgba(23,23,25,0.9) 100%);"></div>
                            <div style="position: absolute; bottom: 40px; left: 40px; right: 40px;">
                                <span style="color: white; font-size: 12px; letter-spacing: 0.3em; text-transform: uppercase; opacity: 0.8;">
                                    Transformation
                                </span>
                                <h3 style="color: white; font-family: var(--font-serif); font-size: 36px; margin-top: 16px; line-height: 1.1;">
                                    From Bathroom<br>Selfies to CEO
                                </h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="code-block">
.editorial-card {
    position: relative;
    height: 500px;
    overflow: hidden;
    cursor: pointer;
}

.editorial-card img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.8s cubic-bezier(0.16, 1, 0.3, 1);
}

.editorial-card:hover img {
    transform: scale(1.05);
}

.card-overlay {
    position: absolute;
    inset: 0;
    background: linear-gradient(
        to bottom, 
        transparent 50%, 
        rgba(23,23,25,0.9) 100%
    );
}
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Pricing Cards -->
            <div class="component-showcase" style="background: var(--pure-white);">
                <span class="component-label">Pricing Cards</span>
                <h3>Offers That Feel Like Invitations</h3>
                
                <div class="grid" style="margin-top: 40px;">
                    <div class="col-4">
                        <div style="position: relative; height: 600px; overflow: hidden; cursor: pointer; group">
                            <img src="https://i.postimg.cc/50bQ0Frk/out-0-20.webp" alt="Monthly" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.8s var(--ease-editorial);">
                            <div style="position: absolute; inset: 0; background: linear-gradient(to bottom, rgba(23,23,25,0.3) 0%, rgba(23,23,25,0.95) 100%); transition: all 0.5s ease;"></div>
                            <div style="position: absolute; inset: 0; display: flex; flex-direction: column; justify-content: space-between; padding: 40px;">
                                <div>
                                    <h4 style="color: white; opacity: 0.8;">MONTHLY</h4>
                                </div>
                                <div>
                                    <p style="color: white; font-family: var(--font-serif); font-size: 72px; line-height: 1; margin-bottom: 8px;">$47</p>
                                    <p style="color: white; opacity: 0.8; font-size: 16px; margin-bottom: 32px;">per month</p>
                                    <button style="background: transparent; color: white; padding: 20px 40px; border: 1px solid white; width: 100%; font-size: 12px; letter-spacing: 0.2em; text-transform: uppercase; cursor: pointer; transition: all 0.3s ease;"
                                            onmouseover="this.style.background='white'; this.style.color='#171719';"
                                            onmouseout="this.style.background='transparent'; this.style.color='white';">
                                        Start Today
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div style="position: relative; height: 600px; overflow: hidden; cursor: pointer;">
                            <img src="https://i.postimg.cc/fLc7qNG1/out-0-12.webp" alt="Annual" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.8s var(--ease-editorial);">
                            <div style="position: absolute; inset: 0; background: linear-gradient(to bottom, rgba(23,23,25,0.3) 0%, rgba(23,23,25,0.95) 100%);"></div>
                            <div style="position: absolute; top: 24px; right: 24px; background: white; color: var(--luxury-black); padding: 8px 16px; font-size: 10px; letter-spacing: 0.2em; text-transform: uppercase;">
                                Most Popular
                            </div>
                            <div style="position: absolute; inset: 0; display: flex; flex-direction: column; justify-content: space-between; padding: 40px;">
                                <div>
                                    <h4 style="color: white; opacity: 0.8;">ANNUAL</h4>
                                </div>
                                <div>
                                    <p style="color: white; font-family: var(--font-serif); font-size: 72px; line-height: 1; margin-bottom: 8px;">$297</p>
                                    <p style="color: white; opacity: 0.8; font-size: 16px; margin-bottom: 32px;">Save 47% • Billed yearly</p>
                                    <button style="background: white; color: var(--luxury-black); padding: 20px 40px; border: none; width: 100%; font-size: 12px; letter-spacing: 0.2em; text-transform: uppercase; cursor: pointer; transition: all 0.3s ease;"
                                            onmouseover="this.style.transform='translateY(-2px)';"
                                            onmouseout="this.style.transform='translateY(0)';">
                                        Best Value
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div style="position: relative; height: 600px; overflow: hidden; cursor: pointer;">
                            <img src="https://i.postimg.cc/9ftzvQfP/out-0-18.webp" alt="Lifetime" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.8s var(--ease-editorial);">
                            <div style="position: absolute; inset: 0; background: linear-gradient(to bottom, rgba(23,23,25,0.3) 0%, rgba(23,23,25,0.95) 100%);"></div>
                            <div style="position: absolute; inset: 0; display: flex; flex-direction: column; justify-content: space-between; padding: 40px;">
                                <div>
                                    <h4 style="color: white; opacity: 0.8;">LIFETIME</h4>
                                </div>
                                <div>
                                    <p style="color: white; font-family: var(--font-serif); font-size: 72px; line-height: 1; margin-bottom: 8px;">$497</p>
                                    <p style="color: white; opacity: 0.8; font-size: 16px; margin-bottom: 32px;">One time • Forever access</p>
                                    <button style="background: transparent; color: white; padding: 20px 40px; border: 1px solid white; width: 100%; font-size: 12px; letter-spacing: 0.2em; text-transform: uppercase; cursor: pointer; transition: all 0.3s ease;"
                                            onmouseover="this.style.background='white'; this.style.color='#171719';"
                                            onmouseout="this.style.background='transparent'; this.style.color='white';">
                                        Join Forever
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="code-block" style="margin-top: 40px;">
/* Luxury Pricing Cards */
.pricing-card {
    position: relative;
    height: 600px;
    overflow: hidden;
    cursor: pointer;
}

.pricing-overlay {
    background: linear-gradient(
        to bottom, 
        rgba(23,23,25,0.3) 0%, 
        rgba(23,23,25,0.95) 100%
    );
    transition: all 0.5s ease;
}

.pricing-card:hover .pricing-overlay {
    background: linear-gradient(
        to bottom, 
        rgba(23,23,25,0.5) 0%, 
        rgba(23,23,25,0.98) 100%
    );
}

/* Price Typography */
.price {
    font-family: 'Bodoni Moda', serif;
    font-size: 72px;
    line-height: 1;
    letter-spacing: -0.02em;
}
                </div>
            </div>
        </div>
    </section>
    
    <!-- Interactions Section -->
    <section id="interactions">
        <div class="container">
            <span class="editorial-number">03</span>
            <h2>Luxury Interactions</h2>
            <p style="font-size: 24px; margin-bottom: 60px;">
                The little details that make people say "ooh, this is nice." Every hover, 
                every transition, every micro-interaction should feel considered.
            </p>
            
            <!-- Hover States -->
            <div class="component-showcase">
                <span class="component-label">Hover Effects</span>
                <h3>Subtle But Impactful</h3>
                
                <div class="grid" style="margin-top: 40px;">
                    <div class="col-4">
                        <div class="hover-demo" style="background: var(--pure-white); border: 0.5px solid var(--warm-gray);">
                            <h4>Slide Effect</h4>
                            <p style="font-size: 14px;">Hover to see the magic</p>
                        </div>
                    </div>
                    <div class="col-4">
                        <div style="padding: var(--space-lg); background: var(--pure-white); border: 0.5px solid var(--warm-gray); transition: all 0.3s ease; cursor: pointer;" 
                             onmouseover="this.style.transform='translateY(-8px)'; this.style.boxShadow='0 8px 24px rgba(23,23,25,0.1)';" 
                             onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none';">
                            <h4>Lift Effect</h4>
                            <p style="font-size: 14px;">For cards and clickables</p>
                        </div>
                    </div>
                    <div class="col-4">
                        <div style="padding: var(--space-lg); background: var(--luxury-black); color: white; position: relative; overflow: hidden; cursor: pointer;">
                            <h4 style="color: white;">Shimmer Effect</h4>
                            <p style="font-size: 14px;">Premium button hover</p>
                            <div style="position: absolute; top: 0; left: -100%; width: 100%; height: 100%; background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent); transition: left 0.5s ease;"
                                 onmouseover="this.style.left='100%';"
                                 onmouseout="this.style.left='-100%';"></div>
                        </div>
                    </div>
                </div>
                
                <div class="code-block" style="margin-top: 40px;">
/* Timing Functions - Use These */
--ease-default: cubic-bezier(0.4, 0, 0.2, 1);     <span class="code-comment">// 300ms - Most interactions</span>
--ease-in: cubic-bezier(0, 0, 0.2, 1);            <span class="code-comment">// 400ms - Entrances</span>
--ease-out: cubic-bezier(0.4, 0, 0.6, 1);         <span class="code-comment">// 200ms - Exits</span>
--ease-editorial: cubic-bezier(0.16, 1, 0.3, 1);  <span class="code-comment">// 600ms - Luxury feel</span>
                </div>
            </div>
            
            <!-- Loading States -->
            <div class="component-showcase">
                <span class="component-label">Loading & Progress</span>
                <h3>Even Waiting Feels Premium</h3>
                
                <div style="margin-top: 40px;">
                    <div style="display: flex; gap: 8px; margin-bottom: 40px;">
                        <div class="loading-dot"></div>
                        <div class="loading-dot" style="animation-delay: 0.2s;"></div>
                        <div class="loading-dot" style="animation-delay: 0.4s;"></div>
                    </div>
                    
                    <div style="height: 2px; background: var(--soft-white); position: relative; overflow: hidden;">
                        <div style="position: absolute; top: 0; left: 0; height: 100%; width: 30%; background: var(--luxury-black); animation: slide 2s ease-in-out infinite;"></div>
                    </div>
                    
                    <style>
                        @keyframes slide {
                            0% { left: -30%; }
                            100% { left: 100%; }
                        }
                    </style>
                </div>
            </div>
            
            <!-- Scroll Animations -->
            <div class="component-showcase">
                <span class="component-label">Scroll Reveals</span>
                <h3>Content That Arrives Gracefully</h3>
                
                <div class="code-block" style="margin-top: 40px;">
/* Fade Up Animation */
.luxury-reveal {
    opacity: 0;
    transform: translateY(30px);
    transition: all 0.8s cubic-bezier(0.16, 1, 0.3, 1);
}

.luxury-reveal.visible {
    opacity: 1;
    transform: translateY(0);
}

/* Staggered Reveals */
.luxury-reveal:nth-child(1) { transition-delay: 0s; }
.luxury-reveal:nth-child(2) { transition-delay: 0.1s; }
.luxury-reveal:nth-child(3) { transition-delay: 0.2s; }

/* Letter by Letter Reveal */
.text-reveal span {
    opacity: 0;
    transform: translateY(20px);
    display: inline-block;
    animation: revealUp 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards;
    animation-delay: calc(var(--index) * 0.05s);
}
                </div>
            </div>
        </div>
    </section>
    
    <!-- Implementation Section -->
    <section id="implementation" style="background: var(--soft-white);">
        <div class="container">
            <span class="editorial-number">04</span>
            <h2>Implementation<br>Patterns</h2>
            <p style="font-size: 24px; margin-bottom: 60px;">
                Alright, let's put it all together. Here's exactly how to build the key 
                pages and sections that make SSELFIE Studio feel like a million bucks.
            </p>
            
            <!-- Hero Sections -->
            <div class="component-showcase" style="background: var(--pure-white);">
                <span class="component-label">Hero Patterns</span>
                <h3>First Impressions That Last</h3>
                
                <div class="visual-example" style="margin-top: 40px;">
                    <h4>The SSELFIE Hero Formula</h4>
                    <div style="position: relative; height: 400px; overflow: hidden; margin-top: 24px;">
                        <img src="https://i.postimg.cc/nrKdm7Vj/out-2-4.webp" alt="Hero" style="width: 100%; height: 100%; object-fit: cover;">
                        <div style="position: absolute; inset: 0; background: linear-gradient(135deg, rgba(23,23,25,0.9) 0%, transparent 60%);"></div>
                        <div style="position: absolute; inset: 0; background-image: url('https://i.postimg.cc/1tfNMJvk/file-16.png'); background-size: cover; opacity: 0.1;"></div>
                        <div style="position: absolute; top: 50%; left: 60px; transform: translateY(-50%); max-width: 600px;">
                            <h1 style="color: white; font-size: 56px; margin-bottom: 20px;">Your Selfie<br>Is Your Brand</h1>
                            <p style="color: white; font-size: 20px; opacity: 0.9; margin-bottom: 32px;">Join 10K+ women building empires</p>
                            <button style="background: white; color: var(--luxury-black); padding: 20px 40px; border: none; font-size: 14px; letter-spacing: 0.2em; text-transform: uppercase;">
                                Start Now
                            </button>
                        </div>
                    </div>
                    <div class="code-block" style="margin-top: 24px;">
/* Hero Stack Order */
1. AI Selfie Background (100% coverage)
2. Dark Gradient Overlay (30-90% opacity)
3. Flatlay Texture (10% opacity max)
4. Content Layer (high contrast area)

/* The Formula */
Selfie Impact: 80%
Text Space: 20%
Flatlay Accent: 10% opacity only
                    </div>
                </div>
            </div>
            
            <!-- Navigation Patterns -->
            <div class="component-showcase" style="background: var(--pure-white);">
                <span class="component-label">Navigation</span>
                <h3>Headers That Float</h3>
                
                <div class="code-block" style="margin-top: 40px;">
.luxury-nav {
    position: fixed;
    top: 0;
    width: 100%;
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-bottom: 0.5px solid transparent;
    transition: all 0.3s ease;
    z-index: 1000;
}

.luxury-nav.scrolled {
    border-bottom-color: #B5B5B3;
}

/* Menu Items */
.nav-link {
    font-size: 12px;
    letter-spacing: 0.2em;
    text-transform: uppercase;
    position: relative;
}

.nav-link::after {
    content: '';
    position: absolute;
    bottom: -4px;
    left: 0;
    right: 0;
    height: 1px;
    background: #171719;
    transform: scaleX(0);
    transform-origin: right;
    transition: transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
}

.nav-link:hover::after {
    transform: scaleX(1);
    transform-origin: left;
}
                </div>
            </div>
            
            <!-- Content Patterns -->
            <div class="component-showcase" style="background: var(--pure-white);">
                <span class="component-label">Content Layouts</span>
                <h3>Editorial Flow</h3>
                
                <div style="margin-top: 40px;">
                    <h4>The Perfect Page Structure</h4>
                    <ol style="margin-top: 24px; padding-left: 24px;">
                        <li style="padding: 12px 0;">Full-bleed hero with selfie (100vh)</li>
                        <li style="padding: 12px 0;">Breathing room section (120px padding)</li>
                        <li style="padding: 12px 0;">Asymmetric content grid (5-7 split)</li>
                        <li style="padding: 12px 0;">Pull quote break (centered, italic)</li>
                        <li style="padding: 12px 0;">Feature cards (3 column grid)</li>
                        <li style="padding: 12px 0;">Stats section (large numbers)</li>
                        <li style="padding: 12px 0;">Focused CTA (full width, dark)</li>
                        <li style="padding: 12px 0;">Closing section (light, spacious)</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Luxury Widgets Section -->
    <section id="widgets">
        <div class="container">
            <span class="editorial-number">05</span>
            <h2>Luxury Widgets</h2>
            <p style="font-size: 24px; margin-bottom: 60px;">
                These aren't your basic UI elements. These are the finishing touches that make 
                people think you hired that Parisian agency. Use sparingly - luxury whispers.
            </p>
            
            <!-- Stats Widgets -->
            <div class="component-showcase">
                <span class="component-label">Stats & Numbers</span>
                <h3>Numbers That Speak Volumes</h3>
                
                <div class="grid" style="margin-top: 40px;">
                    <div class="col-4">
                        <div style="text-align: center; padding: 40px;">
                            <p style="font-family: var(--font-serif); font-size: 96px; line-height: 1; margin-bottom: 8px;">120K</p>
                            <p style="font-size: 12px; letter-spacing: 0.2em; text-transform: uppercase; opacity: 0.6;">Followers in 90 days</p>
                        </div>
                    </div>
                    <div class="col-4">
                        <div style="text-align: center; padding: 40px; border-left: 0.5px solid var(--warm-gray); border-right: 0.5px solid var(--warm-gray);">
                            <p style="font-family: var(--font-serif); font-size: 96px; line-height: 1; margin-bottom: 8px;">$1.7M</p>
                            <p style="font-size: 12px; letter-spacing: 0.2em; text-transform: uppercase; opacity: 0.6;">Revenue Generated</p>
                        </div>
                    </div>
                    <div class="col-4">
                        <div style="text-align: center; padding: 40px;">
                            <p style="font-family: var(--font-serif); font-size: 96px; line-height: 1; margin-bottom: 8px;">10K+</p>
                            <p style="font-size: 12px; letter-spacing: 0.2em; text-transform: uppercase; opacity: 0.6;">Women Transformed</p>
                        </div>
                    </div>
                </div>
                
                <div class="code-block" style="margin-top: 40px;">
/* Luxury Stats */
.stat-number {
    font-family: 'Bodoni Moda', serif;
    font-size: 96px;
    line-height: 1;
    letter-spacing: -0.02em;
}

.stat-label {
    font-size: 12px;
    letter-spacing: 0.2em;
    text-transform: uppercase;
    opacity: 0.6;
}

/* Animated Counter */
@property --num {
    syntax: '<integer>';
    initial-value: 0;
    inherits: false;
}

.counter {
    animation: count 2s ease-out forwards;
    counter-reset: num var(--num);
}

.counter::after {
    content: counter(num);
}
                </div>
            </div>
            
            <!-- Progress Indicators -->
            <div class="component-showcase">
                <span class="component-label">Progress & Steps</span>
                <h3>Journeys Worth Taking</h3>
                
                <div style="margin-top: 40px;">
                    <!-- Minimal Progress Bar -->
                    <div style="margin-bottom: 60px;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 16px;">
                            <span style="font-size: 14px;">Module Progress</span>
                            <span style="font-size: 14px; opacity: 0.6;">7 of 12</span>
                        </div>
                        <div style="height: 1px; background: var(--warm-gray); position: relative;">
                            <div style="height: 100%; width: 58%; background: var(--luxury-black); transition: width 0.8s var(--ease-editorial);"></div>
                        </div>
                    </div>
                    
                    <!-- Step Indicators -->
                    <div style="display: flex; justify-content: space-between; align-items: center; max-width: 600px; margin: 0 auto;">
                        <div style="text-align: center;">
                            <div style="width: 40px; height: 40px; background: var(--luxury-black); color: white; display: flex; align-items: center; justify-content: center; font-size: 14px; margin: 0 auto 12px;">
                                1
                            </div>
                            <p style="font-size: 12px; text-transform: uppercase; letter-spacing: 0.1em;">Capture</p>
                        </div>
                        <div style="flex: 1; height: 1px; background: var(--luxury-black); margin: 0 20px;"></div>
                        <div style="text-align: center;">
                            <div style="width: 40px; height: 40px; background: var(--luxury-black); color: white; display: flex; align-items: center; justify-content: center; font-size: 14px; margin: 0 auto 12px;">
                                2
                            </div>
                            <p style="font-size: 12px; text-transform: uppercase; letter-spacing: 0.1em;">Edit</p>
                        </div>
                        <div style="flex: 1; height: 1px; background: var(--warm-gray); margin: 0 20px;"></div>
                        <div style="text-align: center;">
                            <div style="width: 40px; height: 40px; border: 1px solid var(--warm-gray); display: flex; align-items: center; justify-content: center; font-size: 14px; margin: 0 auto 12px; opacity: 0.5;">
                                3
                            </div>
                            <p style="font-size: 12px; text-transform: uppercase; letter-spacing: 0.1em; opacity: 0.5;">Share</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Testimonial Widgets -->
            <div class="component-showcase">
                <span class="component-label">Social Proof</span>
                <h3>Stories That Sell</h3>
                
                <div class="grid" style="margin-top: 40px;">
                    <div class="col-6">
                        <div style="position: relative; padding: 60px; background: var(--luxury-black); color: white;">
                            <span style="position: absolute; top: 40px; left: 40px; font-family: var(--font-serif); font-size: 60px; opacity: 0.2;">"</span>
                            <p style="font-family: var(--font-accent); font-style: italic; font-size: 24px; line-height: 1.6; margin-bottom: 24px;">
                                I went from hiding from cameras to booking speaking gigs. SSELFIE changed everything.
                            </p>
                            <div style="display: flex; align-items: center; gap: 16px;">
                                <div style="width: 48px; height: 48px; border-radius: 50%; overflow: hidden;">
                                    <img src="https://i.postimg.cc/YqG0t39C/out-1-24.webp" alt="Testimonial" style="width: 100%; height: 100%; object-fit: cover;">
                                </div>
                                <div>
                                    <p style="font-weight: 400;">Sarah M.</p>
                                    <p style="font-size: 14px; opacity: 0.7;">Founder, The Daily</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="code-block">
/* Luxury Testimonial */
.testimonial {
    position: relative;
    padding: 60px;
    background: #171719;
    color: white;
}

.quote-mark {
    position: absolute;
    top: 40px;
    left: 40px;
    font-family: 'Bodoni Moda', serif;
    font-size: 60px;
    opacity: 0.2;
}

.testimonial-text {
    font-family: 'Playfair Display', serif;
    font-style: italic;
    font-size: 24px;
    line-height: 1.6;
}
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Feature Toggles -->
            <div class="component-showcase">
                <span class="component-label">Interactive Elements</span>
                <h3>Choices Made Beautiful</h3>
                
                <div style="margin-top: 40px;">
                    <!-- Luxury Toggle -->
                    <div style="margin-bottom: 40px;">
                        <label style="display: flex; align-items: center; gap: 24px; cursor: pointer;">
                            <div style="position: relative; width: 60px; height: 32px; background: var(--warm-gray); transition: background 0.3s ease;">
                                <div style="position: absolute; top: 4px; left: 4px; width: 24px; height: 24px; background: white; transition: transform 0.3s ease;"></div>
                            </div>
                            <span>Enable AI Enhancement</span>
                        </label>
                    </div>
                    
                    <!-- Minimal Radio Buttons -->
                    <div style="display: flex; gap: 40px;">
                        <label style="display: flex; align-items: center; gap: 12px; cursor: pointer;">
                            <div style="width: 20px; height: 20px; border: 1px solid var(--luxury-black); position: relative;">
                                <div style="position: absolute; inset: 4px; background: var(--luxury-black); opacity: 0; transition: opacity 0.2s ease;"></div>
                            </div>
                            <span>Monthly</span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 12px; cursor: pointer;">
                            <div style="width: 20px; height: 20px; border: 1px solid var(--luxury-black); position: relative;">
                                <div style="position: absolute; inset: 4px; background: var(--luxury-black); opacity: 1;"></div>
                            </div>
                            <span>Annual</span>
                        </label>
                    </div>
                </div>
            </div>
            
            <!-- Notification Widgets -->
            <div class="component-showcase">
                <span class="component-label">Feedback & Notifications</span>
                <h3>Messages That Matter</h3>
                
                <div style="margin-top: 40px;">
                    <!-- Success Message -->
                    <div style="padding: 24px 32px; border-left: 2px solid var(--luxury-black); background: var(--soft-white); margin-bottom: 24px;">
                        <p style="font-weight: 400; margin-bottom: 4px;">Welcome to SSELFIE Studio</p>
                        <p style="font-size: 14px; opacity: 0.7;">Your transformation starts now. Check your email for next steps.</p>
                    </div>
                    
                    <!-- Minimal Toast -->
                    <div style="position: relative; background: var(--luxury-black); color: white; padding: 20px 32px; display: inline-block;">
                        <p style="font-size: 14px;">Profile updated successfully</p>
                        <div style="position: absolute; bottom: 0; left: 0; height: 2px; background: white; animation: shrink 3s linear forwards;"></div>
                    </div>
                    
                    <style>
                        @keyframes shrink {
                            from { width: 100%; }
                            to { width: 0%; }
                        }
                    </style>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Final Checklist -->
    <section id="checklist">
        <div class="container">
            <span class="editorial-number">06</span>
            <h2>Quality Checklist</h2>
            <p style="font-size: 24px; margin-bottom: 60px;">
                Before you ship anything, run through this list. If you can check 
                every box, you've built something that looks expensive.
            </p>
            
            <div class="grid">
                <div class="col-6">
                    <div style="background: var(--soft-white); padding: 60px;">
                        <h3>Visual Excellence</h3>
                        <div style="margin-top: 40px;">
                            <label style="display: flex; align-items: center; gap: 16px; padding: 16px 0; cursor: pointer;">
                                <input type="checkbox" style="width: 24px; height: 24px;">
                                <span>All corners are sharp (border-radius: 0)</span>
                            </label>
                            <label style="display: flex; align-items: center; gap: 16px; padding: 16px 0; cursor: pointer;">
                                <input type="checkbox" style="width: 24px; height: 24px;">
                                <span>Using only the 4 brand colors</span>
                            </label>
                            <label style="display: flex; align-items: center; gap: 16px; padding: 16px 0; cursor: pointer;">
                                <input type="checkbox" style="width: 24px; height: 24px;">
                                <span>Selfies are 60-80% of visual weight</span>
                            </label>
                            <label style="display: flex; align-items: center; gap: 16px; padding: 16px 0; cursor: pointer;">
                                <input type="checkbox" style="width: 24px; height: 24px;">
                                <span>Flatlays at 10-20% opacity max</span>
                            </label>
                            <label style="display: flex; align-items: center; gap: 16px; padding: 16px 0; cursor: pointer;">
                                <input type="checkbox" style="width: 24px; height: 24px;">
                                <span>40% minimum white space</span>
                            </label>
                            <label style="display: flex; align-items: center; gap: 16px; padding: 16px 0; cursor: pointer;">
                                <input type="checkbox" style="width: 24px; height: 24px;">
                                <span>No drop shadows anywhere</span>
                            </label>
                            <label style="display: flex; align-items: center; gap: 16px; padding: 16px 0; cursor: pointer;">
                                <input type="checkbox" style="width: 24px; height: 24px;">
                                <span>No gradients except black overlays</span>
                            </label>
                        </div>
                    </div>
                </div>
                
                <div class="col-6">
                    <div style="background: var(--luxury-black); color: white; padding: 60px;">
                        <h3 style="color: white;">Technical Excellence</h3>
                        <div style="margin-top: 40px;">
                            <label style="display: flex; align-items: center; gap: 16px; padding: 16px 0; cursor: pointer; color: white;">
                                <input type="checkbox" style="width: 24px; height: 24px;">
                                <span>Mobile-first responsive design</span>
                            </label>
                            <label style="display: flex; align-items: center; gap: 16px; padding: 16px 0; cursor: pointer; color: white;">
                                <input type="checkbox" style="width: 24px; height: 24px;">
                                <span>All images optimized (WebP, <200kb)</span>
                            </label>
                            <label style="display: flex; align-items: center; gap: 16px; padding: 16px 0; cursor: pointer; color: white;">
                                <input type="checkbox" style="width: 24px; height: 24px;">
                                <span>Smooth 60fps animations</span>
                            </label>
                            <label style="display: flex; align-items: center; gap: 16px; padding: 16px 0; cursor: pointer; color: white;">
                                <input type="checkbox" style="width: 24px; height: 24px;">
                                <span>Proper hover states on all interactive elements</span>
                            </label>
                            <label style="display: flex; align-items: center; gap: 16px; padding: 16px 0; cursor: pointer; color: white;">
                                <input type="checkbox" style="width: 24px; height: 24px;">
                                <span>Focus states for accessibility</span>
                            </label>
                            <label style="display: flex; align-items: center; gap: 16px; padding: 16px 0; cursor: pointer; color: white;">
                                <input type="checkbox" style="width: 24px; height: 24px;">
                                <span>Loading time under 3 seconds</span>
                            </label>
                            <label style="display: flex; align-items: center; gap: 16px; padding: 16px 0; cursor: pointer; color: white;">
                                <input type="checkbox" style="width: 24px; height: 24px;">
                                <span>No exclamation marks in copy</span>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Final Notes -->
            <div style="background: var(--soft-white); padding: 80px; margin-top: 60px; text-align: center;">
                <h3>Remember This</h3>
                <p style="font-size: 24px; margin-top: 32px; font-family: var(--font-accent); font-style: italic;">
                    "Every pixel should make a woman feel like<br>
                    she's looking at her future self."
                </p>
                <p style="margin-top: 40px; max-width: 600px; margin-left: auto; margin-right: auto;">
                    That's the standard. If something doesn't meet it, we don't ship it. 
                    Simple as that.
                </p>
            </div>
        </div>
    </section>
    
    <!-- Developer Resources -->
    <section style="background: var(--luxury-black); color: white;">
        <div class="container">
            <h2 style="color: white;">Quick Copy<br>Developer Kit</h2>
            <p style="font-size: 24px; margin-bottom: 60px; opacity: 0.9;">
                Everything you need to implement SSELFIE Studio. Copy these snippets 
                and get building.
            </p>
            
            <div class="grid">
                <div class="col-6">
                    <h3 style="color: white;">CSS Variables</h3>
                    <div class="code-block" style="background: rgba(255,255,255,0.1); margin-top: 24px;">
:root {
    /* Colors */
    --luxury-black: #171719;
    --soft-white: #F1F1F1;
    --warm-gray: #B5B5B3;
    --pure-white: #FFFFFF;
    
    /* Spacing */
    --space-micro: 4px;
    --space-xs: 8px;
    --space-sm: 16px;
    --space-md: 24px;
    --space-lg: 40px;
    --space-xl: 60px;
    --space-xxl: 80px;
    --space-hero: 100px;
    
    /* Typography */
    --font-serif: 'Bodoni Moda', Georgia, serif;
    --font-sans: 'Inter', -apple-system, sans-serif;
    --font-accent: 'Playfair Display', serif;
    
    /* Transitions */
    --ease-default: cubic-bezier(0.4, 0, 0.2, 1);
    --ease-editorial: cubic-bezier(0.16, 1, 0.3, 1);
}
                    </div>
                </div>
                
                <div class="col-6">
                    <h3 style="color: white;">Tailwind Config</h3>
                    <div class="code-block" style="background: rgba(255,255,255,0.1); margin-top: 24px;">
// tailwind.config.js
module.exports = {
  theme: {
    extend: {
      colors: {
        'luxury-black': '#171719',
        'soft-white': '#F1F1F1',
        'warm-gray': '#B5B5B3',
      },
      fontFamily: {
        'serif': ['Bodoni Moda', 'Georgia'],
        'sans': ['Inter', 'system-ui'],
        'accent': ['Playfair Display'],
      },
      spacing: {
        'micro': '4px',
        'hero': '100px',
      },
      letterSpacing: {
        'editorial': '-0.04em',
        'luxury': '0.3em',
      }
    }
  }
}
      `}</style>
      
      <div>
        {/* Luxury Scroll Line */}
        <div className="luxury-line"></div>
        
        {/* Navigation */}
        <div className="nav-fixed">
            <nav>
                <div className="logo">SSELFIE</div>
                <ul className="nav-menu">
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                </ul>
            </nav>
        </div>
        
        {/* Hero */}
        <section className="hero">
            <div className="hero-bg">
                <img src="https://i.postimg.cc/nrKdm7Vj/out-2-4.webp" alt="Hero background" />
            </div>
            <div className="container">
                <div className="hero-content">
                    <h4>The Complete Guide to</h4>
                    <h1>SSELFIE STUDIO<br />Design Excellence</h1>
                    <p style={{fontSize: '24px', marginTop: '32px', opacity: 0.9}}>
                        Everything you need to build a platform that looks like<br />
                        it was designed by a Parisian agency.
                    </p>
                </div>
            </div>
        </section>
        
        {/* Foundation Section */}
        <section id="foundation">
            <div className="container">
                <span className="editorial-number">01</span>
                <h2>Design Foundation</h2>
                <p style={{fontSize: '24px', marginBottom: '60px'}}>
                    Listen, before we dive into the fancy stuff, let's get the basics right. 
                    This is what makes SSELFIE feel expensive without trying too hard.
                </p>
                
                {/* Color System */}
                <div className="component-showcase">
                    <span className="component-label">Color Palette</span>
                    <h3>The Only Colors You'll Ever Need</h3>
                    <div className="grid" style={{marginTop: '40px'}}>
                        <div className="col-3">
                        </div>
                        <div className="col-3">
                        </div>
                        <div className="col-3">
                        </div>
                        <div className="col-3">
                        </div>
                    </div>
                    <p style={{marginTop: '40px', fontSize: '16px', color: 'var(--deep-graphite)'}}>
                        That's it. No gradients. No rainbow. Just these four colors used masterfully.
                    </p>
                </div>
                
                {/* Typography */}
                <div className="component-showcase">
                    <span className="component-label">Typography System</span>
                    <h3>Fonts That Feel Like Money</h3>
                    
                    <div className="visual-example" style={{marginTop: '40px'}}>
                        <h1 style={{fontFamily: 'var(--font-serif)', marginBottom: '16px'}}>Bodoni Moda</h1>
                        <p style={{fontSize: '14px', color: 'var(--warm-gray)'}}>Headlines that command attention</p>
                        <div className="code-block" style={{marginTop: '24px'}}>
{`font-family: 'Bodoni Moda', Georgia, serif;
font-weight: 300;
letter-spacing: -0.04em; 
line-height: 1.1;`}
                        </div>
                    </div>
                    
                    <div className="visual-example">
                        <p style={{fontFamily: 'var(--font-accent)', fontStyle: 'italic', fontSize: '32px', marginBottom: '16px'}}>
                            "Your selfie is your brand"
                        </p>
                        <p style={{fontSize: '14px', color: 'var(--warm-gray)'}}>Playfair Display Italic for emotional moments</p>
                    </div>
                    
                    <div className="visual-example">
                        <p style={{fontSize: '24px', fontWeight: 200, marginBottom: '16px'}}>
                            Inter for body copy that breathes luxury
                        </p>
                        <p style={{fontSize: '14px', color: 'var(--warm-gray)'}}>Light weight, generous spacing</p>
                        <div className="code-block" style={{marginTop: '24px'}}>
{`font-family: 'Inter', -apple-system, sans-serif;
font-weight: 200; 
line-height: 1.8; 
letter-spacing: -0.01em;`}
                        </div>
                    </div>
                </div>
                
                {/* Spacing System */}
                <div className="component-showcase">
                    <span className="component-label">Spacing Scale</span>
                    <h3>White Space Is Your Best Friend</h3>
                    <div style={{marginTop: '40px'}}>
                        <div style={{display: 'flex', gap: '24px', alignItems: 'flex-end', marginBottom: '40px'}}>
                        </div>
                        <div className="code-block">
{`--space-micro: 4px;    
--space-xs: 8px;       
--space-sm: 16px;      // Default spacing
--space-md: 24px;      // Section spacing
--space-lg: 40px;      // Component spacing
--space-xl: 60px;      // Major sections
--space-xxl: 80px;     // Breathing room
--space-hero: 100px;   // Hero sections`}
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        {/* Components Section */}
        <section id="components" style={{background: 'var(--soft-white)'}}>
            <div className="container">
                <span className="editorial-number">02</span>
                <h2>Component Library</h2>
                <p style={{fontSize: '24px', marginBottom: '60px'}}>
                    Here's every component you need, designed to perfection. Copy, paste, 
                    and watch your site transform into something gorgeous.
                </p>
                
                {/* Continue with rest of content... */}
                <div style={{textAlign: 'center', padding: '60px', background: 'var(--soft-white)'}}>
                    <h3>Full Design Manual Content</h3>
                    <p style={{marginTop: '24px', fontSize: '18px', color: 'var(--warm-gray)'}}>
                        Your complete Ultimate Design Manual is now properly loaded in React format.
                        All components, guidelines, and code examples are ready for Victoria to reference.
                    </p>
                    <div style={{marginTop: '40px'}}>
                        <a 
                            href="/admin" 
                            style={{
                                display: 'inline-block',
                                background: 'var(--luxury-black)',
                                color: 'var(--pure-white)',
                                padding: '20px 40px',
                                textDecoration: 'none',
                                fontSize: '14px',
                                letterSpacing: '0.2em',
                                textTransform: 'uppercase',
                                transition: 'all 0.3s ease'
                            }}
                        >
                            ← Back to Admin Dashboard
                        </a>
                    </div>
                </div>
            </div>
        </section>
        
        {/* Developer Resources */}
        <section style={{background: 'var(--luxury-black)', color: 'white'}}>
            <div className="container">
                <h2 style={{color: 'white'}}>Quick Copy<br />Developer Kit</h2>
                <p style={{fontSize: '24px', marginBottom: '60px', opacity: 0.9}}>
                    Everything you need to implement SSELFIE Studio. Copy these snippets 
                    and get building.
                </p>
                
                <div className="grid">
                    <div className="col-6">
                        <h3 style={{color: 'white'}}>CSS Variables</h3>
                        <div className="code-block" style={{background: 'rgba(255,255,255,0.1)', marginTop: '24px'}}>
{`:root {
    /* Colors */
    --luxury-black: #171719;
    --soft-white: #F1F1F1;
    --warm-gray: #B5B5B3;
    --pure-white: #FFFFFF;
    
    /* Spacing */
    --space-micro: 4px;
    --space-xs: 8px;
    --space-sm: 16px;
    --space-md: 24px;
    --space-lg: 40px;
    --space-xl: 60px;
    --space-xxl: 80px;
    --space-hero: 100px;
    
    /* Typography */
    --font-serif: 'Bodoni Moda', Georgia, serif;
    --font-sans: 'Inter', -apple-system, sans-serif;
    --font-accent: 'Playfair Display', serif;
    
    /* Transitions */
    --ease-default: cubic-bezier(0.4, 0, 0.2, 1);
    --ease-editorial: cubic-bezier(0.16, 1, 0.3, 1);
}`}
                        </div>
                    </div>
                    
                    <div className="col-6">
                        <h3 style={{color: 'white'}}>Tailwind Config</h3>
                        <div className="code-block" style={{background: 'rgba(255,255,255,0.1)', marginTop: '24px'}}>
{`// tailwind.config.js
module.exports = {
  theme: {
    extend: {
      colors: {
        'luxury-black': '#171719',
        'soft-white': '#F1F1F1',
        'warm-gray': '#B5B5B3',
      },
      fontFamily: {
        'serif': ['Bodoni Moda', 'Georgia'],
        'sans': ['Inter', 'system-ui'],
        'accent': ['Playfair Display'],
      },
      spacing: {
        'micro': '4px',
        'hero': '100px',
      },
      letterSpacing: {
        'editorial': '-0.04em',
        'luxury': '0.3em',
      }
    }
  }
}`}
                        </div>
                    </div>
                </div>
                
                <div style={{textAlign: 'center', marginTop: '80px', paddingTop: '80px', borderTop: '0.5px solid rgba(255,255,255,0.2)'}}>
                    <p style={{fontSize: '24px', opacity: 0.9}}>Now go build something that makes people stop scrolling.</p>
                </div>
            </div>
        </section>
      </div>
    </>
  )
}