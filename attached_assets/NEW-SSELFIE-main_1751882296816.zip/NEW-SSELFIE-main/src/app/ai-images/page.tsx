import { Metadata } from 'next'
import Navigation from '@/components/global/Navigation'
import { Footer } from '@/components/global/Footer'
import { HeroFullBleed } from '@/components/sections/hero/HeroFullBleed'
import OfferCardsGrid from '@/components/ui/OfferCardsGrid'
import OnboardingSteps from '@/components/business/OnboardingSteps'
import { SandraImages } from '@/components/sandra-image-library'

export const metadata: Metadata = {
  title: 'AI Images | SSELFIE Studio',
  description: 'Generate stunning AI-powered images with SSELFIE Studio\'s advanced AI technology.',
}

const onboardingSteps = [
  {
    number: 1,
    title: "Upload Your Photos",
    description: "Share 3-5 of your best selfies for AI analysis and processing."
  },
  {
    number: 2, 
    title: "Choose Your Style",
    description: "Select from professional, artistic, or future-forward AI generation styles."
  },
  {
    number: 3,
    title: "AI Processing", 
    description: "Our advanced AI creates multiple high-quality variations of your images."
  },
  {
    number: 4,
    title: "Download & Use",
    description: "Get your AI-generated images in multiple formats, ready for any platform."
  }
]

export default function AIImagesPage() {
  return (
    <>
      {/* Navigation */}
      <Navigation />
      
      <main>
        {/* Hero Section */}
        <HeroFullBleed
          backgroundImage={SandraImages.hero.pricing}
          tagline="Just want the selfies?"
          title="AI-Powered"
          subtitle="IMAGE GENERATION"
          ctaText="Get AI Images"
          ctaLink="#offers"
        />

        {/* Offers Grid */}
        <section className="py-16 px-4 bg-white">
          <div className="max-w-6xl mx-auto">
            <OfferCardsGrid />
          </div>
        </section>

        {/* How It Works */}
        <section className="py-24 px-4 bg-[#F1F1F1]">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="font-['Bodoni_FLF'] text-4xl md:text-5xl text-[#171719] mb-6">
                How AI Image Generation Works
              </h2>
              <p className="text-xl text-[#B5B5B3] max-w-2xl mx-auto">
                Your transformation journey in four simple steps
              </p>
            </div>
            <OnboardingSteps steps={onboardingSteps} />
          </div>
        </section>
      </main>

      {/* Footer */}
      <Footer />
    </>
  )
}
