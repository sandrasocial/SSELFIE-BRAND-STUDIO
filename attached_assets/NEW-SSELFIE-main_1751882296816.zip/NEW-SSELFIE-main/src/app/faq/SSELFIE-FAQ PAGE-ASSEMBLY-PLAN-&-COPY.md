# SSELFIE FAQ PAGE — ASSEMBLY PLAN & COPY

Alright Diana, here’s the FAQ page—Sandra style. No tech jargon, no “please see our help center.” Just the real questions women ask (in the DMs and the comments) and the answers you’d actually give your best friend.

---

## 1. HERO SECTION

- **Component:** `HeroFullBleed.tsx`
- **Image:** Editorial: Sandra looking relaxed, mid-laugh or mid-conversation, coffee in hand.
- **Title:**  
  FAQ
- **Tagline:**  
  REAL QUESTIONS, REAL ANSWERS
- **CTA:**  
  STILL CURIOUS? JUST ASK

---

## 2. TOP QUESTIONS (THE ONES THEY’RE REALLY ASKING)

**Q: “Do I need to be good at tech to use SSELFIE?”**  
Nope. If you can upload a photo and tap a button, you’re more than qualified. I built this for women who’d rather spend time living than learning new software.

---

**Q: “What if I don’t look like an influencer?”**  
Perfect. Me neither. SSELFIE is about real women, real stories, and real brands. No filters, no fake perfection, just you, showing up as her.

---

**Q: “Do I need professional photos?”**  
Absolutely not. All you need is your phone and a little window light. I’ll show you exactly how to take the selfies that work (even on a messy Monday).

---

**Q: “Is this just for coaches?”**  
Nope. It’s for anyone who wants to build a personal brand—coaches, service providers, product makers, or “I’m not sure what I do yet” types. If you want to be seen, you’re in the right place.

---

**Q: “How much time does this take?”**  
You can go from first selfie to live landing page in under an hour. Most women do it between school drop-off and their third cup of coffee.

---

**Q: “What do I get—like, actually?”**  
- Your own brand mood board (colors, fonts, vibe)  
- Magazine-worthy on-brand selfies (AI-powered, but still you)  
- A done-for-you landing page (with email capture & booking)  
- Your custom SSELFIE link  
- Optional: Downloadable guides and digital products, ready to sell or send

---

**Q: “What if I want to change something later?”**  
It’s your brand—change anything, anytime. Upload new selfies, switch up your colors, or update your offer whenever you want. No extra fees, no tech headaches.

---

**Q: “Can I use my own domain?”**  
For now, you get a custom sselfie.ai/yourname link. If you’re craving a .com, DM me—we’re working on it.

---

**Q: “Is this monthly or one-time?”**  
Membership is monthly, so you can update and keep everything fresh. Cancel anytime, no guilt, no drama.

---

**Q: “What if I get stuck?”**  
You won’t. But if you do, I’m here. DM me on Instagram or use the contact page

---

## 3. CTA SECTION

**Headline:**  
Still have questions?

**Copy:**  
I get it—sometimes you just want to talk to a real person.  
Message me on Instagram (@sandrasocial) or send a note through the contact page.  


**CTA Button:**  
ASK SANDRA

---

## 4. STYLE & QA REMINDERS

- Editorial images only—no icons, no question marks.
- Layout: Lots of air, clear dividers, never overwhelming.
- Typography:  
  - Headlines = ‘Times New Roman’, serif  
  - Body/UI = system sans
- Button: All caps, minimal, inviting.
- Copy: Sandra’s voice—warm, honest, practical, zero jargon.
- No m-dash. Never “support ticket” vibes.

---

## FINAL CHECKLIST

- [ ] Hero: Title, tagline, CTA
- [ ] Real FAQ: Only the questions women actually ask
- [ ] Warm, direct answers—like advice from your smartest friend
- [ ] Final CTA: Feels like Sandra, not a support agent

Let’s make this the page that makes someone say, “Wait, this is actually for me.”