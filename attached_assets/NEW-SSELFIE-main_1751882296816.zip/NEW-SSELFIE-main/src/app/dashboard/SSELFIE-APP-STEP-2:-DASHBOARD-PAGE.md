# SSELFIE APP — STEP 2: DASHBOARD PAGE (UPDATED w/ COMPONENTS)

Alright, Diana—here’s the Dashboard, now with every custom component laid out so you (and only you) get to set the vibe. No SaaS clutter, no “where do I even start?” moments. This is Sandra’s signature “welcome home” screen, built from the ground up with heart and real intention.

---

## 1. DashboardHero.tsx

- **Purpose:** Sets the tone. Feels like Sandra’s opening the door, coffee in hand.
- **Image:** Editorial, never posed. Sandra in her element.
- **Headline:**  
   Use Hero Full Bleed component. - User name as headline - Welcome above styled as the tagline 


---

## 2. MoodboardSnapshot.tsx

- **Purpose:** Your vibe, at a glance.
- **Layout:**  
  - Brand color swatches (up to 4)
  - Font preview (“aa” in your headline font)
  - Recent selfie (editorial, soft crop)
- **Text:**  
  “This is your vibe. Update it anytime.”

---

## 3. QuickStatsPanel.tsx

- **Purpose:** Encouragement, not overwhelm.
- **Stats:**  
  - Latest landing page views  
  - New email signups  
  - Last selfie upload date  
  - Gentle copy: “Don’t worry about the numbers. Just keep showing up.”

---

## 4. ToolCardGrid.tsx

- **Purpose:** All the magic, one glance.
- **Each Card:**  
  - Editorial headline  
  - One-sentence real-world benefit  
  - CTA: START or EDIT  
  - Editorial image (never an icon)
- **Tools Included:**  
  - Selfie Generator  
  - Landing Page Builder  
  - Guide/PDF Creator  
  - Booking/Offer Manager  
  - Moodboard Editor  
  - (Room to add more)

---

## 5. WhatsNextPanel.tsx

- **Purpose:** Gentle, editorial nudge—never a push.
- **Copy:**  
  - “Want to try something new? Use the Selfie Generator.”
  - “Ready to update your landing page? Click here.”
  - “Not sure where to start? Just ask Sandra.”
- **CTA:** NEED HELP? (all caps)

- Full-width, background #fafafa
- Headline: ‘Times New Roman’, 2.5rem, centered
- Steps: slightly larger, more readable, more air
- CTA: Button, all caps, underline on hover
---

## 6. SidebarNav.tsx

- **Purpose:** Quiet, calm, always on-brand.
- **Links:**  
  - Dashboard  
  - My Tools  
  - Billing  
  - Profile  
  - Support
- **Style:**  
  - Editorial gray  
  - Tracked uppercase, minimal, no icons  
  - Black underline for active link

  - Collapsible by default on mobile, always visible on desktop (but minimal width).
- Menu: vertical, uppercase, spaced by 32px.
- Active link: black underline, smooth transition.
- Hamburger appears under 900px width.

```css
.sidebar-nav {
  background: #f5f5f5;
  min-width: 88px;
  max-width: 240px;
  transition: max-width 0.3s cubic-bezier(0.4,0,0.2,1);
}
.sidebar-nav.collapsed {
  max-width: 0;
  overflow: hidden;
}
.sidebar-link {
  font-size: 13px;
  letter-spacing: 0.3em;
  text-transform: uppercase;
  color: #0a0a0a;
  padding: 16px 32px;
  display: block;
  border-left: 2px solid transparent;
  transition: border-color 0.2s;
}
.sidebar-link.active {
  border-left: 2px solid #0a0a0a;
}
```


---

## 7. EncouragementPanel.tsx (Optional)

- **Purpose:** Little hug, mid-scroll.
- **Copy:**  
  “Your mess is your message. Keep building.”
- **Style:**  
  - Serif, centered, black on white or light gray

---

## 8. EditorialEmptyState.tsx

- **Purpose:** When there’s no data, it still feels like Sandra.
- **Copy:**  
  “Looks like you haven’t uploaded any selfies yet. Want a little help?”
- **CTA:** UPLOAD YOUR FIRST SELFIE

---

## DASHBOARD LAYOUT STRUCTURE

1. **SidebarNav.tsx** (left, always visible)
2. **Main Content:**
    - DashboardHero.tsx
    - MoodboardSnapshot.tsx + QuickStatsPanel.tsx (side-by-side on desktop, stacked on mobile)
    - ToolCardGrid.tsx (main grid)
    - WhatsNextPanel.tsx (call to action)
    - EncouragementPanel.tsx (optional, scattered between sections)
    - EditorialEmptyState.tsx (when needed)

---

## STYLE & UX REMINDERS

- Editorial images everywhere, never icons
- White and editorial gray backgrounds only
- Air, air, and more air (never crowded)
- Typography: Headlines = Times New Roman, body = system sans
- Buttons: All caps, underlined/bordered on hover
- Copy: Sandra’s voice—warm, real, no SaaS robot speak

- Section padding: min 80px top/bottom
- Editorial images: always, even if subtle
- Never icons or system emojis
- Every interaction: smooth, not jumpy

---

## FINAL CHECKLIST

- [ ] Every component is editorial, luxe, and feels like Sandra’s living room
- [ ] Tools are obvious and inviting—not overwhelming
- [ ] User always knows “what’s next”
- [ ] Sidebar is simple, never distracting
- [ ] QA every word and interaction for Sandra’s voice

---

# NEXT STEP

Once this dashboard structure is live, we’ll move into the first “tool” page:  
**Photo/Brand Onboarding** (the “let’s build your vibe” flow).

Let’s keep it real, keep it warm, and keep it moving.