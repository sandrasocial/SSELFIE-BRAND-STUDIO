# DASHBOARD: ELEVATE & EDITORIALIZE — MAGIC TOUCH GUIDE

---

## 1. Use Hero Full Bleed component. - User name as headline - Welcome above styled as the tagline

## 2. What Needs “Sandra Magic”

**A. Visual Richness**
- Add full-bleed or collage editorial images (even as subtle backgrounds or “corner crops”).
- “START” CTAs need to feel like invitations, not system links—underline on hover, elegant micro-animation.
- Card hover: gentle shadow+scale (not bouncy, just “lifts” a little).
- Each ToolCard gets a unique editorial image—never an icon.

**B. Typography/Hierarchy**
- “Your Magic Toolbox” should feel like a magazine cover—huge, tight, luxurious.
- Subheads in soft gray, smaller, for contrast.
- Body copy: a smidge bigger, more readable, more air.

**C. Layout/Spacing**
- Grid gap: increase (try 40px+).
- ToolCards: more padding (48-56px), softer border radius (8px), subtle border (#e5e5e5).
- “What’s next?” panel: Full-width, different soft background (#fafafa), section padding 80-120px.
- “NEED HELP?” CTA: Make it a button, not just text.

**D. Sidebar/Menu**
- Collapsible sidebar that auto-hides on mobile, floats in on hover/focus (desktop).
- Hamburger icon (simple, minimal) for mobile.
- Sidebar: vertical, soft gray (#f5f5f5), with black active underline.
- Menu items: uppercase, tracked, more air between.

**E. Microinteractions**
- Card hover: scale 1.025, shadow #e5e5e5, smooth 0.22s cubic-bezier.
- Button hover: underline animates in from left.
- Menu active: underline slides in, not just appears.

---

## 3. NEW COMPONENT/STYLE GUIDE FOR DIANA

### ToolCard.tsx

- Editorial image (top or left, 56x56px, slightly desaturated)
- Headline: ‘Times New Roman’, 2.5rem+, tight
- Subcopy: system sans, soft gray
- Button:  
  - All caps, 13px, underline on hover  
  - Animation: underline slides in, not fades
- Card:  
  - White bg, border #e5e5e5, 8px radius  
  - Padding: 48-56px  
  - Shadow on hover, scale 1.025  
  - Transition: 0.22s cubic-bezier(0.4,0,0.2,1)

```css
.tool-card {
  background: #fff;
  border: 1px solid #e5e5e5;
  border-radius: 8px;
  padding: 56px;
  transition: box-shadow 0.22s cubic-bezier(0.4,0,0.2,1), transform 0.22s cubic-bezier(0.4,0,0.2,1);
}
.tool-card:hover {
  box-shadow: 0 8px 32px 0 #e5e5e555;
  transform: scale(1.025);
}
.tool-card .cta {
  text-transform: uppercase;
  font-size: 13px;
  letter-spacing: 0.3em;
  border-bottom: 1.5px solid transparent;
  transition: border-color 0.22s, color 0.22s;
}
.tool-card .cta:hover {
  border-bottom: 1.5px solid #0a0a0a;
}
```

---

### SidebarNav.tsx

- Collapsible by default on mobile, always visible on desktop (but minimal width).
- Menu: vertical, uppercase, spaced by 32px.
- Active link: black underline, smooth transition.
- Hamburger appears under 900px width.

```css
.sidebar-nav {
  background: #f5f5f5;
  min-width: 88px;
  max-width: 240px;
  transition: max-width 0.3s cubic-bezier(0.4,0,0.2,1);
}
.sidebar-nav.collapsed {
  max-width: 0;
  overflow: hidden;
}
.sidebar-link {
  font-size: 13px;
  letter-spacing: 0.3em;
  text-transform: uppercase;
  color: #0a0a0a;
  padding: 16px 32px;
  display: block;
  border-left: 2px solid transparent;
  transition: border-color 0.2s;
}
.sidebar-link.active {
  border-left: 2px solid #0a0a0a;
}
```

---

### WhatsNextPanel.tsx

- Full-width, background #fafafa
- Headline: ‘Times New Roman’, 2.5rem, centered
- Steps: slightly larger, more readable, more air
- CTA: Button, all caps, underline on hover

---

### General

- Section padding: min 80px top/bottom
- Editorial images: always, even if subtle
- Never icons or system emojis
- Every interaction: smooth, not jumpy

---

## 4. “Diana, Update Checklist”

- [ ] Add unique editorial image to each ToolCard
- [ ] Increase grid gaps, card padding, and section spacing
- [ ] Apply hover/active microinteractions (see above)
- [ ] SidebarNav: Make collapsible, add hamburger for mobile
- [ ] Make “NEED HELP?” a real CTA button with animation
- [ ] Review all copy for editorial warmth and clarity (no placeholders)
- [ ] Test on mobile—should feel just as luxe and clear

---

# Let’s turn this dashboard into a space where every woman feels like she’s in her favorite magazine, not just another app.