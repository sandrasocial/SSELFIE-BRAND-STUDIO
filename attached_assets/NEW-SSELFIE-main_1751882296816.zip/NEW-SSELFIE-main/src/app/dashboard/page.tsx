'use client'

import React from 'react'
import { DashboardLayout } from '@/components/dashboard/DashboardLayout'
import { DashboardHero } from '@/components/dashboard/DashboardHero'
import { MoodboardSnapshot } from '@/components/dashboard/MoodboardSnapshot'
import { QuickStatsPanel } from '@/components/dashboard/QuickStatsPanel'
import { ToolCardGrid } from '@/components/dashboard/ToolCardGrid'
import { WhatsNextPanel } from '@/components/dashboard/WhatsNextPanel'
import { EncouragementPanel } from '@/components/dashboard/EncouragementPanel'
import { EditorialEmptyState } from '@/components/dashboard/EditorialEmptyState'
import { SandraImages } from '@/components/sandra-image-library'

export default function Dashboard() {
  // Mock data - in a real app, this would come from the user's profile/API
  const userName = "Stephanie";
  const userStats = [
    { label: 'Landing Page Views', value: '124', change: 'up' as const },
    { label: 'Email Signups', value: '7', change: 'up' as const },
    { label: 'Last Selfie Upload', value: 'July 1, 2025', change: 'neutral' as const },
  ];
  
  const brandColors = [
    { color: '#171719', name: 'Luxury' },
    { color: '#F1F1F1', name: 'Soft' },
    { color: '#B5B5B3', name: 'Warm' },
  ];
  
  return (
    <DashboardLayout>
      <main className="min-h-screen">
        {/* 1. Hero Section */}
        <DashboardHero 
          userName={userName}
          subtext="Here's what's next for your brand (and your story)."
          quote="You don't need a plan. You need one brave post."
        />
        
        {/* 2 & 3. Mood Board & Stats Section - Side by side on desktop, stacked on mobile */}
        <div className="container mx-auto px-6 py-16 lg:py-28">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24">
            <div className="bg-white p-12 lg:p-16 shadow-sm border-[1.5px] border-[#e5e5e5]">
              {/* 2. Mood Board Snapshot */}
              <MoodboardSnapshot 
                colors={brandColors}
                fontFamily="Times New Roman"
                selfieUrl={SandraImages.aiGallery[0]}
              />
            </div>
            
            <div className="bg-white p-12 lg:p-16 shadow-sm border-[1.5px] border-[#e5e5e5]">
              {/* 3. Stats Panel */}
            <QuickStatsPanel 
              stats={userStats}
            />
          </div>
        </div>
      </div>
      
      {/* 4. Tool Cards */}
      <ToolCardGrid />
      
      {/* 5. What's Next */}
      <WhatsNextPanel />
      
      {/* 7. Encouragement */}
      <EncouragementPanel />
      
      {/* 8. Editorial Empty State - Shown conditionally when there's no data */}
      <div className="container mx-auto px-6 py-16 lg:py-28">
        <EditorialEmptyState />
      </div>
    </main>
    </DashboardLayout>
  )
}
