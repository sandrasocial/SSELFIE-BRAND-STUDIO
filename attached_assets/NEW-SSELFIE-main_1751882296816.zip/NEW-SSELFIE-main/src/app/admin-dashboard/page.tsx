import { HeroFullBleed } from "@/components/sections/hero/HeroFullBleed";

export default function AdminDashboardPage() {
  return (
    <HeroFullBleed
      backgroundImage="/images/sandra-hero-admin.jpg"
      tagline="admin dashboard"
      title="ADMIN"
      subtitle="SANDRA"
      ctaText="Time to run the show"
      ctaLink="/admin"
    />
  );
}
