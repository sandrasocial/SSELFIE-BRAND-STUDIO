'use client'

import React from 'react'
import Navigation from '@/components/global/Navigation'
import { Footer } from '@/components/global/Footer'
import { HeroFullBleed } from '@/components/sections/hero/HeroFullBleed'
import { PowerQuote } from '@/components/sections'
import { SandraImages } from '@/components/sandra-image-library'
import Image from 'next/image'
import Link from 'next/link'

export default function StudioPage() {
  return (
    <>
      <Navigation />
      
      <div className="min-h-screen">
        {/* Hero Section */}
        <HeroFullBleed
          backgroundImage={SandraImages.hero.about}
          tagline="WHERE YOUR BRAND STARTS WITH A SELFIE"
          title="STUDIO"
          ctaText="ENTER THE STUDIO"
          ctaLink="#onboarding"
        />

        {/* The Problem Section */}
        <section className="py-20 md:py-32 bg-pure-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-4xl text-center">
            <h2 className="font-bodoni text-4xl md:text-5xl lg:text-6xl font-light text-luxury-black leading-tight mb-8">
              Overwhelmed by tech? Tired of feeling invisible online?
            </h2>
            
            <div className="space-y-6 text-lg md:text-xl text-luxury-black/80 leading-loose max-w-3xl mx-auto">
              <p>
                You want to coach, teach, or sell what you know—but you keep running into Canva tutorials, endless "branding" checklists, and cold, confusing AI tools.
              </p>
              <p>
                You don&rsquo;t want to look like everyone else.
              </p>
              <p>
                You just want a brand that feels like you—without spending a year (or a fortune) figuring it out.
              </p>
            </div>
          </div>
        </section>

        {/* The Solution Section */}
        <section className="py-20 md:py-32 bg-soft-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-6xl">
            <div className="text-center mb-16">
              <h2 className="font-bodoni text-4xl md:text-5xl lg:text-6xl font-light text-luxury-black leading-tight mb-8">
                Branding made simple. Finally.
              </h2>
            </div>

            <div className="flex flex-col lg:flex-row gap-12 lg:gap-20 items-center">
              <div className="space-y-8 w-full lg:w-1/2">
                <p className="font-inter text-lg md:text-xl text-luxury-black/80 leading-loose">
                  Imagine this:
                </p>
                <div className="space-y-4 text-lg md:text-xl text-luxury-black/80 leading-loose">
                  <p>You sign up.</p>
                  <p>You upload 10-15 real, everyday selfies (yep, the ones already on your phone).</p>
                  <p>You answer a few fun questions about your style, colors, and what actually feels like you.</p>
                </div>
                <p className="font-inter text-lg md:text-xl text-luxury-black leading-loose font-medium">
                  That&rsquo;s it.
                </p>
                <p className="font-inter text-lg md:text-xl text-luxury-black/80 leading-loose">
                  No design degree. No "tech stack." No overwhelm.
                </p>
              </div>
              
              <div className="relative h-96 lg:h-[600px] w-full lg:w-1/2 flex-shrink-0" style={{position: 'relative'}}>
                <Image 
                  src={SandraImages.journey.rockBottom}
                  alt="Simple branding process"
                  fill
                  className="object-cover"
                  sizes="(max-width: 1024px) 100vw, 50vw"
                  style={{objectFit: 'cover'}}
                />
              </div>
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section id="onboarding" className="py-20 md:py-32 bg-pure-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-6xl">
            <div className="text-center mb-20">
              <h2 className="font-bodoni text-4xl md:text-5xl lg:text-6xl font-light text-luxury-black leading-tight">
                How it works
              </h2>
            </div>

            <div className="space-y-20">
              {/* Step 1: Instant Onboarding */}
              <div className="flex flex-col lg:flex-row gap-12 lg:gap-20 items-center">
                <div className="relative h-96 lg:h-[600px] w-full lg:w-1/2 flex-shrink-0" style={{position: 'relative'}}>
                  <Image 
                    src={SandraImages.editorial.phone2}
                    alt="Upload your selfies"
                    fill
                    className="object-cover"
                    sizes="(max-width: 1024px) 100vw, 50vw"
                    priority
                    style={{objectFit: 'cover'}}
                  />
                </div>
                
                <div className="space-y-8 w-full lg:w-1/2">
                  <div>
                    <span className="font-inter text-xs tracking-[0.3em] uppercase text-luxury-black/50 mb-4 block">
                      STEP 1
                    </span>
                    <h3 className="font-bodoni text-3xl md:text-4xl lg:text-5xl font-light text-luxury-black leading-tight mb-6">
                      Instant Onboarding
                    </h3>
                  </div>
                  
                  <p className="font-inter text-lg md:text-xl text-luxury-black/80 leading-loose">
                    Upload your selfies. Tell us your vibe. Choose your colors and fonts (don&rsquo;t worry, we make it easy).
                  </p>
                </div>
              </div>

              {/* Step 2: Your Dashboard */}
              <div className="flex flex-col lg:flex-row gap-12 lg:gap-20 items-center">
                <div className="space-y-8 w-full lg:w-1/2 order-2 lg:order-1">
                  <div>
                    <span className="font-inter text-xs tracking-[0.3em] uppercase text-luxury-black/50 mb-4 block">
                      STEP 2
                    </span>
                    <h3 className="font-bodoni text-3xl md:text-4xl lg:text-5xl font-light text-luxury-black leading-tight mb-6">
                      Your Dashboard
                    </h3>
                  </div>
                  
                  <div className="space-y-4 font-inter text-lg md:text-xl text-luxury-black/80 leading-loose">
                    <p>The moment you finish onboarding, your dashboard is ready—no waiting.</p>
                    <ul className="space-y-2 ml-4">
                      <li>• See your brand mood board: colors, fonts, and magazine-worthy images (all generated for you).</li>
                      <li>• Your best selfies, now perfectly on-brand.</li>
                    </ul>
                  </div>
                </div>
                
                <div className="relative h-96 lg:h-[600px] w-full lg:w-1/2 flex-shrink-0 order-1 lg:order-2" style={{position: 'relative'}}>
                  <Image 
                    src={SandraImages.editorial.laptop1}
                    alt="Your brand dashboard"
                    fill
                    className="object-cover"
                    sizes="(max-width: 1024px) 100vw, 50vw"
                    style={{objectFit: 'cover'}}
                  />
                </div>
              </div>

              {/* Step 3: Generate Branded Selfies */}
              <div className="flex flex-col lg:flex-row gap-12 lg:gap-20 items-center">
                <div className="relative h-96 lg:h-[600px] w-full lg:w-1/2 flex-shrink-0" style={{position: 'relative'}}>
                  <Image 
                    src={SandraImages.journey.success}
                    alt="Generate branded selfies"
                    fill
                    className="object-cover"
                    sizes="(max-width: 1024px) 100vw, 50vw"
                    style={{objectFit: 'cover'}}
                  />
                </div>
                
                <div className="space-y-8 w-full lg:w-1/2">
                  <div>
                    <span className="font-inter text-xs tracking-[0.3em] uppercase text-luxury-black/50 mb-4 block">
                      STEP 3
                    </span>
                    <h3 className="font-bodoni text-3xl md:text-4xl lg:text-5xl font-light text-luxury-black leading-tight mb-6">
                      Generate Branded Selfies
                    </h3>
                  </div>
                  
                  <div className="space-y-4 font-inter text-lg md:text-xl text-luxury-black/80 leading-loose">
                    <p>Click a button. Get images that actually match your brand.</p>
                    <p>No weird filters. No learning Photoshop. No "is this even me?" moments.</p>
                  </div>
                </div>
              </div>

              {/* Step 4: Create Your Landing Page */}
              <div className="flex flex-col lg:flex-row gap-12 lg:gap-20 items-center">
                <div className="space-y-8 w-full lg:w-1/2 order-2 lg:order-1">
                  <div>
                    <span className="font-inter text-xs tracking-[0.3em] uppercase text-luxury-black/50 mb-4 block">
                      STEP 4
                    </span>
                    <h3 className="font-bodoni text-3xl md:text-4xl lg:text-5xl font-light text-luxury-black leading-tight mb-6">
                      Create Your Landing Page
                    </h3>
                  </div>
                  
                  <div className="space-y-4 font-inter text-lg md:text-xl text-luxury-black/80 leading-loose">
                    <p>One click.</p>
                    <ul className="space-y-2 ml-4">
                      <li>• Your landing page is ready—complete with your photos, brand colors, email capture, and booking system.</li>
                      <li>• Host it right here (no domain drama) or grab your custom link.</li>
                    </ul>
                  </div>
                </div>
                
                <div className="relative h-96 lg:h-[600px] w-full lg:w-1/2 flex-shrink-0 order-1 lg:order-2" style={{position: 'relative'}}>
                  <Image 
                    src={SandraImages.editorial.phone1}
                    alt="Your landing page ready"
                    fill
                    className="object-cover"
                    sizes="(max-width: 1024px) 100vw, 50vw"
                    style={{objectFit: 'cover'}}
                  />
                </div>
              </div>

              {/* Step 5: Sell, Book, Launch */}
              <div className="flex flex-col lg:flex-row gap-12 lg:gap-20 items-center">
                <div className="relative h-96 lg:h-[600px] w-full lg:w-1/2 flex-shrink-0" style={{position: 'relative'}}>
                  <Image 
                    src={SandraImages.journey.building}
                    alt="Launch your business"
                    fill
                    className="object-cover"
                    sizes="(max-width: 1024px) 100vw, 50vw"
                    style={{objectFit: 'cover'}}
                  />
                </div>
                
                <div className="space-y-8 w-full lg:w-1/2">
                  <div>
                    <span className="font-inter text-xs tracking-[0.3em] uppercase text-luxury-black/50 mb-4 block">
                      STEP 5
                    </span>
                    <h3 className="font-bodoni text-3xl md:text-4xl lg:text-5xl font-light text-luxury-black leading-tight mb-6">
                      Sell, Book, Launch
                    </h3>
                  </div>
                  
                  <div className="space-y-4 font-inter text-lg md:text-xl text-luxury-black/80 leading-loose">
                    <ul className="space-y-2">
                      <li>• Add your offer, digital product, or calendar.</li>
                      <li>• Download your PDF guide with your branding (perfect for lead magnets or first product).</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Step 6: Update Anytime */}
              <div className="flex flex-col lg:flex-row gap-12 lg:gap-20 items-center">
                <div className="space-y-8 w-full lg:w-1/2 order-2 lg:order-1">
                  <div>
                    <span className="font-inter text-xs tracking-[0.3em] uppercase text-luxury-black/50 mb-4 block">
                      STEP 6
                    </span>
                    <h3 className="font-bodoni text-3xl md:text-4xl lg:text-5xl font-light text-luxury-black leading-tight mb-6">
                      Update Anytime
                    </h3>
                  </div>
                  
                  <p className="font-inter text-lg md:text-xl text-luxury-black/80 leading-loose">
                    Change your photos, tweak your colors, add new services—your brand grows with you.
                  </p>
                </div>
                
                <div className="relative h-96 lg:h-[600px] w-full lg:w-1/2 flex-shrink-0 order-1 lg:order-2" style={{position: 'relative'}}>
                  <Image 
                    src={SandraImages.editorial.mirror}
                    alt="Your brand evolves with you"
                    fill
                    className="object-cover"
                    sizes="(max-width: 1024px) 100vw, 50vw"
                    style={{objectFit: 'cover'}}
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Who It's For Section */}
        <section className="py-20 md:py-32 bg-soft-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-4xl text-center">
            <h2 className="font-bodoni text-4xl md:text-5xl lg:text-6xl font-light text-luxury-black leading-tight mb-12">
              Who it&rsquo;s for
            </h2>
            
            <div className="space-y-6 text-lg md:text-xl text-luxury-black/80 leading-loose max-w-3xl mx-auto">
              <p>
                If you&rsquo;re a woman 35+ who&rsquo;s ready to coach, teach, or sell—but you&rsquo;re lost on where to start?
              </p>
              <p className="font-medium text-luxury-black">
                This is for you.
              </p>
              <p>
                No more tool overwhelm. No more "I&rsquo;ll do it when I have time."
              </p>
              <p>
                Just a clear path, beautiful branding, and your face as the main character.
              </p>
            </div>
          </div>
        </section>

        {/* In-App Experience Section */}
        <section className="py-20 md:py-32 bg-pure-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-6xl">
            <div className="text-center mb-16">
              <h2 className="font-bodoni text-4xl md:text-5xl lg:text-6xl font-light text-luxury-black leading-tight mb-8">
                What you see is what you get
              </h2>
              <p className="font-inter text-lg md:text-xl text-luxury-black/80 leading-loose max-w-3xl mx-auto">
                Scroll through your own mood board, swap out images, and launch your page in minutes. Want to update something? It&rsquo;s just a click. This is your space. It should feel like you.
              </p>
            </div>

            <div className="relative h-96 md:h-[500px] lg:h-[600px] w-full" style={{position: 'relative'}}>
              <Image 
                src={SandraImages.editorial.laughing}
                alt="Your studio experience"
                fill
                className="object-cover"
                sizes="100vw"
                style={{objectFit: 'cover'}}
              />
            </div>
          </div>
        </section>

        {/* Power Quote */}
        <PowerQuote />

        {/* Final CTA */}
        <section className="py-20 md:py-32 bg-luxury-black text-soft-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-4xl text-center">
            <blockquote className="font-bodoni text-3xl md:text-4xl lg:text-5xl font-light leading-tight mb-12">
              "Your brand doesn&rsquo;t start with a logo.<br />
              It starts with your story—and your face.<br />
              Let&rsquo;s make it official."
            </blockquote>
            
            <div className="pt-8">
              <Link 
                href="/pricing"
                className="inline-block font-inter text-sm tracking-[0.2em] uppercase text-soft-white hover:text-soft-white/70 transition-colors duration-300 px-12 py-4 border border-soft-white hover:bg-soft-white hover:text-luxury-black"
              >
                ENTER THE STUDIO
              </Link>
            </div>
          </div>
        </section>
      </div>
      
      <Footer />
    </>
  )
}
