import type { Metadata, Viewport } from 'next'
import { Inter } from 'next/font/google'
import { Bodoni_Moda, Playfair_Display, Cormorant_Garamond } from 'next/font/google'
import Script from 'next/script'
import '../styles/globals-clean.css'
import { Toaster } from 'sonner'
import { Analytics } from '@vercel/analytics/react'
import { SpeedInsights } from '@vercel/speed-insights/next'

// Font Configurations - The Typography Symphony
const inter = Inter({ 
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-inter',
  preload: true,
  fallback: ['system-ui', '-apple-system', 'sans-serif'],
})

const bodoniModa = Bodoni_Moda({ 
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-bodoni',
  weight: ['400', '500', '600', '700', '800', '900'],
  style: ['normal', 'italic'],
  preload: true,
  fallback: ['Georgia', 'serif'],
})

const playfairDisplay = Playfair_Display({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-playfair',
  weight: ['400', '500', '600', '700', '800', '900'],
  style: ['normal', 'italic'],
  preload: true,
  fallback: ['Georgia', 'serif'],
})

const cormorantGaramond = Cormorant_Garamond({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-cormorant',
  weight: ['300', '400', '500', '600', '700'],
  style: ['normal', 'italic'],
  preload: true,
  fallback: ['Georgia', 'serif'],
})

// Metadata - SEO & Open Graph
export const metadata: Metadata = {
  metadataBase: new URL('https://sselfie.ai'),
  title: {
    default: 'SSELFIE - Your Personal Brand Starts Here',
    template: '%s | SSELFIE'
  },
  description: 'Transform your personal brand with AI-powered tools. From zero to 120K followers in 90 days. Your phone is all you need.',
  keywords: [
    'personal branding',
    'selfie confidence',
    'content creation',
    'AI tools',
    'social media growth',
    'personal brand photography',
    'content strategy',
    'Sandra Sigurjonsdottir'
  ],
  authors: [{ name: 'Sandra Sigurjonsdottir', url: 'https://sselfie.ai' }],
  creator: 'Sandra Sigurjonsdottir',
  publisher: 'SSELFIE',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://sselfie.ai',
    siteName: 'SSELFIE',
    title: 'SSELFIE - Your Personal Brand Starts Here',
    description: 'Transform your personal brand with AI-powered tools. Your phone is all you need.',
    images: [
      {
        url: 'https://sselfie.ai/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'SSELFIE - Build Your Personal Brand',
      }
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'SSELFIE - Your Personal Brand Starts Here',
    description: 'Transform your personal brand with AI-powered tools.',
    creator: '@sandrasocial',
    images: ['https://sselfie.ai/twitter-image.jpg'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  icons: {
    icon: [
      { url: '/favicon.ico' },
      { url: '/favicon-16x16.png', sizes: '16x16', type: 'image/png' },
      { url: '/favicon-32x32.png', sizes: '32x32', type: 'image/png' },
    ],
    apple: [
      { url: '/apple-touch-icon.png' },
    ],
    other: [
      {
        rel: 'mask-icon',
        url: '/safari-pinned-tab.svg',
        color: '#171719',
      },
    ],
  },
  manifest: '/site.webmanifest',
}

// Viewport Configuration
export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  userScalable: true,
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#FFFFFF' },
    { media: '(prefers-color-scheme: dark)', color: '#171719' },
  ],
}

// JSON-LD Structured Data
const jsonLd = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  name: 'SSELFIE',
  url: 'https://sselfie.ai',
  logo: 'https://i.postimg.cc/L88db1fc/White-transperent-logo.png',
  description: 'Personal brand platform helping women show up confidently online through AI-powered tools and strategic content guidance.',
  founder: {
    '@type': 'Person',
    name: 'Sandra Sigurjonsdottir',
    jobTitle: 'Founder & CEO',
    description: 'Former hairdresser from Iceland who built 120K followers in 90 days and now teaches women to transform their personal brands.',
  },
  foundingDate: '2025',
  sameAs: [
    'https://www.instagram.com/sandra.social',
    'https://www.tiktok.com/@sandra.social',
    'https://www.linkedin.com/in/sandrasigurjonsdottir'
  ],
  contactPoint: {
    '@type': 'ContactPoint',
    contactType: 'customer support',
    email: 'hello@sselfie.ai',
    availableLanguage: ['en']
  }
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html 
      lang="en" 
      className={`${inter.variable} ${bodoniModa.variable} ${playfairDisplay.variable} ${cormorantGaramond.variable}`}
      suppressHydrationWarning
    >
      <head>
        {/* Preconnect to external domains for performance */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link rel="preconnect" href="https://i.postimg.cc" />
        <link rel="preconnect" href="https://cdn.jsdelivr.net" />
        
        {/* DNS Prefetch for additional performance */}
        <link rel="dns-prefetch" href="https://www.googletagmanager.com" />
        <link rel="dns-prefetch" href="https://vercel.live" />
        
        {/* Critical CSS for above-the-fold content */}
        <style dangerouslySetInnerHTML={{ __html: `
          /* Critical CSS - Prevent FOUC */
          body { 
            margin: 0; 
            background: #FFFFFF;
            opacity: 1 !important;
            transition: opacity 0.3s ease-in-out;
          }
          body.preload { 
            opacity: 1 !important; 
          }
          body.loaded { 
            opacity: 1 !important; 
          }
          
          /* Next.js Image optimization fixes */
          img[data-nimg="fill"] {
            position: absolute !important;
            inset: 0 !important;
            width: 100% !important;
            height: 100% !important;
            max-width: none !important;
            object-fit: cover !important;
            z-index: 1 !important;
          }
          
          /* Ensure image containers have proper positioning */
          [style*="position:relative"] img[data-nimg="fill"],
          .relative img[data-nimg="fill"] {
            position: absolute !important;
          }
          
          /* Fix for image containers */
          .group.relative .absolute.inset-0 {
            z-index: 0;
          }
          
          /* Ensure gradients don't block images */
          .bg-gradient-to-t {
            z-index: 2;
          }
          
          /* Prevent layout shift from fonts */
          .font-bodoni { 
            font-family: 'Bodoni Moda', Georgia, serif; 
          }
          .font-inter { 
            font-family: 'Inter', system-ui, sans-serif; 
          }
          
          /* Hide elements until fonts load */
          .font-loading-hide {
            visibility: hidden;
          }
          .fonts-loaded .font-loading-hide {
            visibility: visible;
          }
          
          /* Smooth scroll behavior */
          html {
            scroll-behavior: smooth;
          }
          
          /* Disable transitions on page load */
          .preload * {
            -webkit-transition: none !important;
            -moz-transition: none !important;
            -ms-transition: none !important;
            -o-transition: none !important;
            transition: none !important;
          }
        `}} />
        
        {/* Schema.org structured data */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        
        {/* Google Tag Manager */}
        <Script id="gtm-script" strategy="afterInteractive">
          {`
            (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
            new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
            j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
            'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
            })(window,document,'script','dataLayer','${process.env.NEXT_PUBLIC_GTM_ID || 'GTM-XXXXXX'}');
          `}
        </Script>
      </head>
      
      <body className={`${inter.className} antialiased preload`}>
        {/* Google Tag Manager (noscript) */}
        <noscript>
          <iframe 
            src={`https://www.googletagmanager.com/ns.html?id=${process.env.NEXT_PUBLIC_GTM_ID || 'GTM-XXXXXX'}`}
            height="0" 
            width="0" 
            style={{ display: 'none', visibility: 'hidden' }}
          />
        </noscript>
        
        {/* Skip to main content for accessibility */}
        <a 
          href="#main-content" 
          className="skip-to-content"
          style={{
            position: 'absolute',
            left: '-9999px',
            top: '0',
            zIndex: 999,
            padding: '1rem',
            background: '#171719',
            color: '#FFFFFF',
            textDecoration: 'none',
          }}
        >
          Skip to main content
        </a>
        
        {/* Main app wrapper */}
        <div id="app-wrapper" className="min-h-screen flex flex-col">
          {children}
        </div>
        
        {/* Toaster for notifications - styled to match luxury aesthetic */}
        <Toaster 
          position="bottom-right"
          toastOptions={{
            duration: 5000,
            style: {
              background: '#171719',
              color: '#FFFFFF',
              borderRadius: '0',
              padding: '16px 24px',
              fontSize: '14px',
              fontFamily: 'var(--font-sans)',
              letterSpacing: '0.025em',
            },
            className: 'luxury-toast',
          }}
        />
        
        {/* Analytics */}
        <Analytics />
        <SpeedInsights />
        
        {/* Font loading optimization */}
        <Script id="font-loading" strategy="beforeInteractive">
          {`
            // Immediately remove preload class to show content
            document.body.classList.remove('preload');
            document.body.classList.add('loaded');
            
            // Check if fonts are loaded
            if ('fonts' in document) {
              Promise.all([
                document.fonts.load('400 1em Inter'),
                document.fonts.load('400 1em Bodoni Moda'),
              ]).then(() => {
                document.documentElement.classList.add('fonts-loaded');
              });
            }
            
            // Smooth scroll polyfill for Safari
            if (!('scrollBehavior' in document.documentElement.style)) {
              import('smoothscroll-polyfill').then(module => {
                module.polyfill();
              });
            }
          `}
        </Script>
        
        {/* Performance monitoring */}
        <Script id="performance-monitor" strategy="afterInteractive">
          {`
            // Log Core Web Vitals
            if ('web-vital' in window) {
              window.addEventListener('load', () => {
                import('web-vitals').then(({ getCLS, getFID, getFCP, getLCP, getTTFB }) => {
                  getCLS(console.log);
                  getFID(console.log);
                  getFCP(console.log);
                  getLCP(console.log);
                  getTTFB(console.log);
                });
              });
            }
          `}
        </Script>
      </body>
    </html>
  );
}
