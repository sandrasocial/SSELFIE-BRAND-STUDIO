'use client'

import React from 'react'
import Navigation from '@/components/global/Navigation'
import { Footer } from '@/components/global/Footer'
import { HeroFullBleed } from '@/components/sections/hero/HeroFullBleed'
import { ImageBreak } from '@/components/sections/about/ImageBreak'
import { EditorialTestimonials } from '@/components/sections'
import { SandraImages } from '@/components/sandra-image-library'
import Image from 'next/image'
import Link from 'next/link'

export default function SSelfieAIPage() {
  return (
    <>
      <Navigation />
      
      <div className="min-h-screen">
        {/* 1. Hero Section */}
        <HeroFullBleed
          backgroundImage={SandraImages.hero.ai}
          tagline="Meet the woman you're becoming"
          title="SSELFIE AI"
          ctaText="Create your future self"
          ctaLink="#future-self-generator"
        />

        {/* 2. Editorial Spread - The First AI Selfie Story */}
        <section className="py-20 md:py-32 bg-soft-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-7xl">
            <div className="flex flex-col lg:flex-row gap-12 lg:gap-20 items-center">
              {/* Left: Image */}
              <div className="relative h-96 lg:h-[600px] w-full lg:w-1/2 flex-shrink-0">
                <Image 
                  src={SandraImages.editorial.firstAI}
                  alt="Sandra with her first AI selfie"
                  fill
                  className="object-cover"
                  sizes="(max-width: 1024px) 100vw, 50vw"
                  priority
                />
              </div>
              
              {/* Right: Content */}
              <div className="space-y-12 w-full lg:w-1/2">
                <h2 className="font-bodoni text-3xl md:text-4xl lg:text-5xl font-light text-luxury-black leading-tight">
                  The first time I saw my Future Self, I cried.
                </h2>
                
                <div className="space-y-8 font-inter text-lg md:text-xl text-luxury-black opacity-80 leading-loose">
                  <p>Not because she was perfect.<br />Because she was <em>possible</em>.</p>
                  
                  <p>This wasn't some fantasy version filtered beyond recognition. This was me—but confident. Radiant. Like I'd finally stopped hiding and started showing up.</p>
                  
                  <p>That's when I knew: we don't need more photo editing. We need permission to see who we're becoming.</p>
                  
                  <p>Your SSELFIE AI isn't about looking different. It's about seeing yourself clearly—for maybe the first time.</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 3. Image Break */}
        <ImageBreak 
          src={SandraImages.flatlays.workspace1}
          alt="Creating magic behind the scenes"
        />

        {/* 4. How It Works - OnboardingSteps Component */}
        <section className="py-20 md:py-32 bg-pure-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-6xl">
            <div className="text-center mb-16">
              <span className="font-inter text-xs tracking-[0.4em] uppercase text-luxury-black/50 mb-6 block">
                THREE STEPS TO TRANSFORMATION
              </span>
              <h2 className="font-bodoni text-4xl md:text-5xl lg:text-6xl font-light text-luxury-black leading-tight">
                From selfie to<br />
                future self.
              </h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12 max-w-5xl mx-auto">
              <div className="text-center">
                <div className="bg-luxury-black/5 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="font-bodoni text-2xl font-light text-luxury-black">1</span>
                </div>
                <h3 className="font-bodoni text-xl font-light text-luxury-black mb-4">
                  Upload Your Selfies
                </h3>
                <p className="font-inter text-sm text-luxury-black/70 leading-relaxed">
                  10–15 photos. Face the window, wear what makes you feel powerful. No ring light needed.
                </p>
              </div>
              
              <div className="text-center">
                <div className="bg-luxury-black/5 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="font-bodoni text-2xl font-light text-luxury-black">2</span>
                </div>
                <h3 className="font-bodoni text-xl font-light text-luxury-black mb-4">
                  Choose Your Future
                </h3>
                <p className="font-inter text-sm text-luxury-black/70 leading-relaxed">
                  Pick your vibe: CEO, Creative, Coach, Entrepreneur. The AI learns your aesthetic.
                </p>
              </div>
              
              <div className="text-center">
                <div className="bg-luxury-black/5 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="font-bodoni text-2xl font-light text-luxury-black">3</span>
                </div>
                <h3 className="font-bodoni text-xl font-light text-luxury-black mb-4">
                  Become Her
                </h3>
                <p className="font-inter text-sm text-luxury-black/70 leading-relaxed">
                  30 editorial-quality images of your Future Self. Use them everywhere. Watch your life change.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* 5. AI Gallery Showcase */}
        <section className="py-20 md:py-32 bg-soft-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-7xl">
            <div className="text-center mb-16">
              <span className="font-inter text-xs tracking-[0.4em] uppercase text-luxury-black/50 mb-6 block">
                YOUR FUTURE SELF GALLERY
              </span>
              <h2 className="font-bodoni text-4xl md:text-5xl font-light text-luxury-black leading-tight mb-8">
                30 images of the woman<br />
                you're becoming.
              </h2>
              <p className="font-inter text-lg text-luxury-black/70 leading-relaxed max-w-2xl mx-auto">
                Each image shows a different facet of your Future Self. Use them everywhere. Watch your life change.
              </p>
            </div>

            {/* AI Gallery Grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6 mb-16">
              {SandraImages.aiGallery.slice(0, 8).map((image, index) => (
                <div key={index} className="aspect-square relative">
                  <Image 
                    src={image}
                    alt={`AI Future Self ${index + 1}`}
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 50vw, (max-width: 1024px) 33vw, 25vw"
                  />
                </div>
              ))}
            </div>

            <div className="text-center">
              <p className="font-inter text-base text-luxury-black/60 leading-relaxed">
                This is just a preview. Your gallery will be uniquely yours—created from your selfies, your vibe, your future.
              </p>
            </div>
          </div>
        </section>

        {/* 6. Editorial Spread - The Science & Magic */}
        <section className="py-20 md:py-32 bg-pure-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-7xl">
            <div className="flex flex-col lg:flex-row gap-12 lg:gap-20 items-center">
              {/* Left: Content */}
              <div className="space-y-12 w-full lg:w-1/2 order-2 lg:order-1">
                <h2 className="font-bodoni text-3xl md:text-4xl lg:text-5xl font-light text-luxury-black leading-tight">
                  The science is real.<br />
                  The magic is you.
                </h2>
                
                <div className="space-y-8 font-inter text-lg md:text-xl text-luxury-black opacity-80 leading-loose">
                  <p>Our AI doesn't just smooth skin or fix lighting. It learns your face, your style, your energy—then shows you what confidence looks like on <em>you</em>.</p>
                  
                  <p>No generic beauty standards. No one-size-fits-all filters. Just you, elevated. You, radiant. You, ready to show up as the main character of your own life.</p>
                  
                  <p>Because when you can see who you're becoming, you stop hiding who you are.</p>
                </div>
              </div>
              
              {/* Right: Image */}
              <div className="relative h-96 lg:h-[600px] w-full lg:w-1/2 flex-shrink-0 order-1 lg:order-2">
                <Image 
                  src={SandraImages.editorial.aiInProgress}
                  alt="AI magic in progress"
                  fill
                  className="object-cover"
                  sizes="(max-width: 1024px) 100vw, 50vw"
                />
              </div>
            </div>
          </div>
        </section>

        {/* 7. Pricing Options */}
        <section className="py-20 md:py-32 bg-soft-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-6xl">
            <div className="text-center mb-16">
              <span className="font-inter text-xs tracking-[0.4em] uppercase text-luxury-black/50 mb-6 block">
                READY TO MEET HER?
              </span>
              <h2 className="font-bodoni text-4xl md:text-5xl lg:text-6xl font-light text-luxury-black leading-tight">
                Two ways to create<br />
                your Future Self.
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 max-w-5xl mx-auto">
              {/* Option 1: Just the Images */}
              <div className="bg-pure-white p-8 md:p-12 flex flex-col h-full justify-between relative overflow-hidden border border-luxury-black/10">
                <div className="relative z-10">
                  <div className="flex items-center justify-between mb-4">
                    <span className="font-inter text-xs tracking-[0.3em] uppercase text-luxury-black/50">
                      Just the images
                    </span>
                    <span className="bg-luxury-black text-soft-white px-3 py-1 text-xs tracking-wider uppercase">
                      Popular
                    </span>
                  </div>
                  <h3 className="font-bodoni text-3xl md:text-4xl font-light text-luxury-black mb-4">
                    FUTURE SELF
                  </h3>
                  <div className="flex items-baseline mb-6">
                    <span className="font-bodoni text-5xl font-light text-luxury-black">€47</span>
                    <span className="font-inter text-sm text-luxury-black/60 ml-2">one-time</span>
                  </div>
                  <p className="font-inter text-base text-luxury-black/80 leading-relaxed mb-6">
                    30 luxury AI images of your Future Self. Perfect if you just want to see who you're becoming.
                  </p>
                  <ul className="space-y-3 font-inter text-sm text-luxury-black/70">
                    <li>10–15 selfies in</li>
                    <li>30 AI images out</li>
                    <li>Multiple styles & vibes</li>
                    <li>Instant download</li>
                    <li>Upgrade to Studio anytime</li>
                  </ul>
                </div>
                <Link
                  href="/ai-images"
                  className="inline-block w-full text-center font-inter text-sm tracking-[0.2em] uppercase text-luxury-black hover:text-luxury-black/70 transition-colors duration-300 py-4 border border-luxury-black hover:bg-luxury-black hover:text-soft-white mt-10 relative z-10"
                >
                  Create your future self
                </Link>
              </div>

              {/* Option 2: Full Studio */}
              <div className="bg-luxury-black text-soft-white p-8 md:p-12 flex flex-col h-full justify-between relative overflow-hidden">
                <div className="absolute top-4 right-4 z-20">
                  <span className="bg-soft-white text-luxury-black px-3 py-1 text-xs tracking-wider uppercase">
                    Complete transformation
                  </span>
                </div>
                <div className="relative z-10">
                  <span className="font-inter text-xs tracking-[0.3em] uppercase text-soft-white/60 mb-4 block">
                    The full experience
                  </span>
                  <h3 className="font-bodoni text-3xl md:text-4xl font-light text-soft-white mb-4">
                    SSELFIE STUDIO
                  </h3>
                  <div className="space-y-2 mb-6">
                    <div className="flex items-baseline">
                      <span className="font-bodoni text-5xl font-light text-soft-white">€97</span>
                      <span className="font-inter text-sm text-soft-white/60 ml-2">/month</span>
                    </div>
                    <p className="font-inter text-xs text-soft-white/60">
                      Founding Member (first 100) • Locks in price
                    </p>
                  </div>
                  <p className="font-inter text-base text-soft-white/90 leading-relaxed mb-6">
                    Unlimited Future Self generations plus your complete luxury studio. Build your brand around who you're becoming.
                  </p>
                  <ul className="space-y-3 font-inter text-sm text-soft-white/80">
                    <li>Unlimited SSELFIE AI</li>
                    <li>Luxury landing page</li>
                    <li>Sandra AI chat</li>
                    <li>Content calendar</li>
                    <li>Priority support</li>
                  </ul>
                </div>
                <Link
                  href="/studio"
                  className="inline-block w-full text-center font-inter text-sm tracking-[0.2em] uppercase text-soft-white hover:text-soft-white/70 transition-colors duration-300 py-4 border border-soft-white hover:bg-soft-white hover:text-luxury-black mt-10 relative z-10"
                >
                  Start your transformation
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* 8. Testimonials */}
        <EditorialTestimonials />

        {/* 9. Final Editorial Spread - Permission to Transform */}
        <section className="py-20 md:py-32 bg-pure-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-7xl">
            <div className="flex flex-col lg:flex-row gap-12 lg:gap-20 items-center">
              {/* Left: Image */}
              <div className="relative h-96 lg:h-[600px] w-full lg:w-1/2 flex-shrink-0">
                <Image 
                  src={SandraImages.editorial.aiSuccess}
                  alt="Sandra radiating main character energy"
                  fill
                  className="object-cover"
                  sizes="(max-width: 1024px) 100vw, 50vw"
                />
              </div>
              
              {/* Right: Content */}
              <div className="space-y-12 w-full lg:w-1/2">
                <h2 className="font-bodoni text-3xl md:text-4xl lg:text-5xl font-light text-luxury-black leading-tight">
                  Your Future Self isn't waiting for permission.<br />
                  She's waiting for <em>you</em>.
                </h2>
                
                <div className="space-y-8 font-inter text-lg md:text-xl text-luxury-black opacity-80 leading-loose">
                  <p>Stop hiding behind "I'm not photogenic" or "I don't know how to pose."</p>
                  
                  <p>Your Future Self doesn't need perfect lighting or professional makeup. She just needs you to stop waiting and start showing up.</p>
                  
                  <p>Upload your selfies. See who you're becoming. Then become her.</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 10. Final CTA */}
        <section id="future-self-generator" className="py-20 md:py-32 bg-luxury-black text-soft-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-4xl text-center">
            <span className="font-inter text-xs tracking-[0.3em] uppercase text-soft-white/50 mb-6 block">
              READY TO TRANSFORM
            </span>
            <h2 className="font-bodoni text-4xl md:text-5xl lg:text-6xl font-light text-soft-white leading-tight mb-8">
              She's been waiting<br />
              for you to find her.
            </h2>
            <p className="font-inter text-lg font-light text-soft-white/70 leading-relaxed mb-12 max-w-2xl mx-auto">
              Upload 10 selfies. Choose your vibe. Meet the woman you're becoming.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 items-center justify-center">
              <Link
                href="/ai-images"
                className="inline-block font-inter text-sm tracking-[0.2em] uppercase text-soft-white hover:text-soft-white/70 transition-colors duration-300 px-8 py-4 border border-soft-white hover:bg-soft-white hover:text-luxury-black"
              >
                Create your future self
              </Link>
              <Link
                href="/pricing"
                className="inline-block font-inter text-sm tracking-[0.2em] uppercase text-soft-white/60 hover:text-soft-white transition-colors duration-300 px-8 py-4 border border-soft-white/20 hover:border-soft-white"
              >
                See all options
              </Link>
            </div>
          </div>
        </section>
      </div>
      
      <Footer />
    </>
  )
}