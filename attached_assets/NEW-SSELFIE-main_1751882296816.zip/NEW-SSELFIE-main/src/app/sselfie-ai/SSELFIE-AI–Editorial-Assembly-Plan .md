# SSELFIE AI – Editorial Assembly Plan  
*For Diana – Luxe, Editorial, and Actually Fun to Read*

---

## 1. HERO SECTION

- **Component:** `/components/global/HeroFullBleed.tsx`
- **Image:** `SandraImages.hero.ai` (editorial, Sandra with phone or looking at screen)
- **Tagline:**  
  `AI images. Zero stress. All you.`
- **Headline:**  
  `SSELFIE AI`
- **CTA Button:**  
  - Text: `Try it for yourself`
  - Link: `#how-it-works`
- **NO subheading.**
- **Styling:**  
  - Full-bleed.  
  - Airy, no overlays.  
  - Negative space = luxury.

---

## 2. EDITORIAL SPREAD (Sandra’s “First AI Selfie” Story)

- **Component:** `/components/sections/editorial/EditorialSpread.tsx`
- **Left:**  
  - Image: `SandraImages.editorial.firstAI` (Sandra’s first AI image or fun, imperfect selfie) Add placeholder for sandra to update the image url later inside sandras image library.
- **Right:**  
  - Headline: `Okay, here’s what happened…`
  - Body:
    ```
    I’ll be honest: the first time I tried this, I was terrified.

    I thought, “Who am I to show up like this?”  
    But I did it anyway.  
    10 selfies, zero makeup, three minutes in my car with the world’s worst lighting.

    And then the images came back…  
    And for the first time in ages, I saw myself. Not the tired mom, not the “should be farther by now,” just me.

    That’s why I built SSELFIE AI—so you can see her, too.
    ```
- **Styling:**  
  - Editorial split, 40/60 or 50/50.
  - Use serif for headline.

---

## 3. IMAGE BREAK (Breather)

- **Component:** `/components/sections/about/ImageBreak.tsx`
- **Image:** `SandraImages.editorial.aiInProgress` (AI images in process, screen, or candid work shot)
- **Purpose:**  
  - Visual pause.  
  - No overlay.  
  - Feels like a magazine spread.

---

## 4. HOW IT WORKS (Onboarding Steps Visual)

- **Component:** `/components/business/OnboardingSteps.tsx`
- **Images:**  
  - Use Sandra's real phone screenshots, candid step-by-step, or SSELFIE interface shots (`SandraImages.process.*`) use placeholders. Sandra will update later
- **Copy:**  
  - Step 1: Upload 10–15 selfies (bad lighting? Still fine.)
  - Step 2: Let SSELFIE AI work its magic (grab coffee, this takes a sec)
  - Step 3: Get 30+ editorial images, ready to use anywhere
- **Styling:**  
  - Each step gets its own image.
  - Editorial air between steps.
  - No icons—only real images or screenshots.

---

## 5. BEFORE / AFTER MOODBOARD

- **Component:** `/components/sections/editorial/EditorialMoodboard.tsx`
- **Images:**  
  - 6: Before (raw selfie), after (AI glam), detail shots, process images. (use placeholders for Before images. Sandra will upload later. Update the sandras image libarery where sandra needs to paste the before image url later)
- **Purpose:**  
  - “Real transformations, not just pretty filters.”
- **Styling:**  
  - Grid, negative space.

---

## 6. POWER QUOTE (Typographic Breather)

- **Component:** `/components/sections/editorial/PowerQuote.tsx`
- **Copy:**  
  ```
  You don’t need new clothes, a new face, or a new life.  
  You just need to see yourself like this.
  ```
- **Styling:**  
  - No image.
  - Centered, editorial.

---

## 7. TESTIMONIAL GALLERY (Optional)

- **Component:** `/components/sections/editorial/EditorialTestimonials.tsx`
- **Quotes:**  
  - “I literally cried when I saw my images.”  
  - “Didn’t know I could look this confident.”  
  - “This is what showing up as her means.”
- **Styling:**  
  - Minimal, editorial, magazine-style.

---

## 8. EDITORIAL GALLERY (Show the Range)

- **Component:** `/components/sections/about/EditorialGallery.tsx` you can also use the portfolio component for this
- **Images:**  
  - 8–10 AI images: different moods, outfits, backgrounds (real SSELFIE results, not stock)
- **Purpose:**  
  - Show versatility, not perfection.
- **Styling:**  
  - Grid/collage, keep it luxe.

---

## 9. FINAL IMAGE BREAK

- **Component:** `/components/sections/about/ImageBreak.tsx`
- **Image:** `SandraImages.editorial.aiSuccess` (Sandra or client, “main character” energy)
- **Purpose:**  
  - Exhale before final CTA.

---

## 10. FINAL CTA

- **Component:** `/components/sections/about/FinalCTA.tsx`
  - Or build with `/components/ui/SectionHeadline.tsx` + `/components/ui/button.tsx`
- **Tagline:** `Ready for your editorial era?`
- **Headline:** `Try SSELFIE AI today`
- **Copy:**  
  `10 selfies. 30 images. One big shift.`
- **Button:**  
  - `Get started` → `/ai-images`
- **Styling:**  
  - Minimal, wide, centered, lots of air.

---

## GENERAL RULES (Diana, you know the drill):

- **Each section = its own component/block for easy editing.**
- **Never repeat an image on the same page.**
- **Copy is always Sandra: honest, warm, and real.**
- **Editorial spacing = luxury (add more air if it feels crowded).**
- **All images from `/components/sandra-image-library.ts` (use the keys above).**
- **Every button styled per the Editorial Style Guide.**
- **If unsure, ask: “Would Sandra actually say this to a friend?”**

---

*If you ever feel lost: add more space, swap the image, or rewrite the copy like you’re texting your best friend. That’s it. That’s the magic.*
