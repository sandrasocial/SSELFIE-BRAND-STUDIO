# CONTACT PAGE ASSEMBLY PLAN & COPY

Alright Diana, here’s how to make the Contact page look and feel like Sandra. Keep it minimal, warm, and editorial. No fluff, no “inspirational” extras.

---

## 1. SECTION & COMPONENT LAYOUT

### HERO SECTION
- **Component:** `HeroFullBleed.tsx` (WORKING VERSION)
- **Image:** Editorial Sandra—relaxed, open, modern.
- **Title:**  
  CONTACT
- **Tagline:**  
  YOUR STORY, YOUR IMAGE, YOUR WAY  
- **CTA:**  
  START YOUR STORY

---

### CONTACT FORM SECTION
- **Component:** `/business/ContactSection.tsx` (or main form)
- **Fields:**  
  - Name  
  - Email  
  - Message (placeholder: “What’s on your mind?”)
- **Button:**  
  SEND

---

### SOCIAL LINKS (optional, below form)
- Editorial text only (no icons unless on-brand)
- Instagram: @sandrasocial  
- Email: hello@sselfie.com  
- Line: Prefer DMs? Message me on Instagram.

---

## 2. PAGE COPY

---

### HERO SECTION

**Title:**  
CONTACT

**Tagline:**  
YOUR STORY, YOUR IMAGE, YOUR WAY

**CTA:**  
START YOUR STORY

---

### CONTACT FORM

**Headline (if needed):**  
Tell me what’s going on

**Message Placeholder:**  
What’s on your mind?

**Button:**  
SEND

**After Submit:**  
Thank you for reaching out. I’ll reply as soon as I can, usually with coffee in hand and a few tabs open.

---

### SOCIAL LINKS (if included)

Prefer DMs? Message me on Instagram @sandrasocial  
Or email: hello@sselfie.com

---

## 3. STYLE & QA

- Editorial image only. No icons unless they’re on-brand.
- Everything breathes. No crowding, no extra stories.
- All copy sounds like Sandra. Warm, direct, never corporate.
- Button is all caps, minimal, and luxury.
- Font: ‘Times New Roman’ for headlines. System sans for the rest.
- Colors: Black, white, editorial gray (#f5f5f5), mid gray (#fafafa), soft gray (#666666).
- No m-dash. Ever.

---

## FINAL CHECKLIST

- [ ] HeroFullBleed: Title, tagline (uppercase), CTA button.
- [ ] ContactSection: Name, email, message, send button.
- [ ] Minimal editorial social links, if included.
- [ ] No extra fluff or long stories.

Let’s keep it real, keep it modern, and make it easy for people to reach out.