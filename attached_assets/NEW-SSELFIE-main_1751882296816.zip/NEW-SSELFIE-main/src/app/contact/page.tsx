'use client'

import Navigation from '@/components/global/Navigation'
import { Footer } from '@/components/global/Footer'
import { HeroFullBleed } from '@/components/sections/hero/HeroFullBleed'
import { SandraImages } from '@/components/sandra-image-library'
import React, { useState } from 'react'

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  })
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    
    // Simulate form submission
    setTimeout(() => {
      setIsSubmitted(true)
      setIsSubmitting(false)
    }, 1000)
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }

  return (
    <>
      <Navigation />
      
      <main>
        {/* Hero Section */}
        <HeroFullBleed
          backgroundImage={SandraImages.hero.contact}
          tagline="YOUR STORY, YOUR IMAGE, YOUR WAY"
          title="CONTACT"
          ctaText="START YOUR STORY"
          ctaLink="#contact-form"
        />

        {/* Contact Form Section */}
        <section id="contact-form" className="py-20 md:py-32 bg-pure-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-4xl">
            <div className="text-center mb-16">
              <h2 className="font-bodoni text-4xl md:text-5xl font-light text-luxury-black leading-tight mb-8">
                Tell me what&rsquo;s going on
              </h2>
            </div>

            {!isSubmitted ? (
              <form onSubmit={handleSubmit} className="max-w-2xl mx-auto space-y-8">
                <div>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Name"
                    required
                    className="w-full p-4 border-b border-luxury-black/20 bg-transparent font-inter text-lg text-luxury-black placeholder-luxury-black/50 focus:outline-none focus:border-luxury-black transition-colors duration-300"
                  />
                </div>
                
                <div>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="Email"
                    required
                    className="w-full p-4 border-b border-luxury-black/20 bg-transparent font-inter text-lg text-luxury-black placeholder-luxury-black/50 focus:outline-none focus:border-luxury-black transition-colors duration-300"
                  />
                </div>
                
                <div>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="What's on your mind?"
                    required
                    rows={6}
                    className="w-full p-4 border-b border-luxury-black/20 bg-transparent font-inter text-lg text-luxury-black placeholder-luxury-black/50 focus:outline-none focus:border-luxury-black transition-colors duration-300 resize-none"
                  />
                </div>
                
                <div className="text-center pt-8">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="inline-block font-inter text-sm tracking-[0.2em] uppercase text-luxury-black hover:text-luxury-black/70 transition-colors duration-300 px-12 py-4 border border-luxury-black hover:bg-luxury-black hover:text-soft-white disabled:opacity-50"
                  >
                    {isSubmitting ? 'SENDING...' : 'SEND'}
                  </button>
                </div>
              </form>
            ) : (
              <div className="max-w-2xl mx-auto text-center">
                <h3 className="font-bodoni text-3xl font-light text-luxury-black mb-6">
                  Thank you for reaching out.
                </h3>
                <p className="font-inter text-lg text-luxury-black/70 leading-relaxed">
                  I&rsquo;ll reply as soon as I can, usually with coffee in hand and a few tabs open.
                </p>
              </div>
            )}
          </div>
        </section>

        {/* Social Links Section */}
        <section className="py-16 md:py-20 bg-soft-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-4xl text-center">
            <div className="space-y-4 font-inter text-base text-luxury-black/70">
              <p>Prefer DMs? Message me on Instagram <a href="https://instagram.com/sandrasocial" target="_blank" rel="noopener noreferrer" className="text-luxury-black hover:text-luxury-black/70 transition-colors duration-300">@sandrasocial</a></p>
              <p>Or email: <a href="mailto:hello@sselfie.com" className="text-luxury-black hover:text-luxury-black/70 transition-colors duration-300">hello@sselfie.com</a></p>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  )
}
