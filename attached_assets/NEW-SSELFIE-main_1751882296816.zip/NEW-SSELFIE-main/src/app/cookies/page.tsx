import { Metadata } from 'next'
import Navigation from '@/components/global/Navigation'
import { Footer } from '@/components/global/Footer'
import { HeroFullBleed } from '@/components/sections/hero/HeroFullBleed'
import { SandraImages } from '@/components/sandra-image-library'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'Cookie Policy | SSELFIE Studio',
  description: 'The only cookies here are digital. Real talk about cookies at SSELFIE.',
}

export default function CookiesPage() {
  return (
    <>
      <Navigation />
      
      <main className="bg-white">
        {/* Hero Section */}
        <HeroFullBleed
          backgroundImage={SandraImages.hero.about}
          tagline="THE ONLY COOKIES HERE ARE DIGITAL"
          title="COOKIES"
          subtitle=""
          ctaText="GOT QUESTIONS? JUST ASK"
          ctaLink="#contact"
        />

        {/* Real Talk Section */}
        <section className="py-20 px-4">
          <div className="max-w-4xl mx-auto">
            <h1 style={{ fontFamily: 'Times New Roman, serif' }} className="text-3xl md:text-4xl text-[#171719] mb-8">
              Cookies, explained (the real way).
            </h1>
            
            <div className="space-y-6 text-lg leading-relaxed text-[#171719]">
              <p>Basically, cookies are tiny files your browser saves so a website remembers who you are, what you like, and how you move around.</p>
              <p>They don't spy on you, steal your snacks, or send Sandra your DMs.</p>
            </div>
          </div>
        </section>

        {/* What SSELFIE Uses */}
        <section className="py-20 px-4 bg-[#F1F1F1]">
          <div className="max-w-4xl mx-auto">
            <h2 style={{ fontFamily: 'Times New Roman, serif' }} className="text-3xl text-[#171719] mb-12">
              What cookies does SSELFIE use?
            </h2>
            
            <div className="grid gap-8 md:gap-12">
              <div>
                <h3 className="text-xl font-semibold text-[#171719] mb-4">Strictly necessary cookies</h3>
                <p className="text-[#171719] leading-relaxed">
                  These make the site actually work—like keeping you logged in or saving your preferences.
                </p>
              </div>
              
              <div>
                <h3 className="text-xl font-semibold text-[#171719] mb-4">Performance cookies</h3>
                <p className="text-[#171719] leading-relaxed">
                  These help me see what's working (are women getting stuck on onboarding? Is the gallery loading?)—all anonymous, all to make your experience smoother.
                </p>
              </div>
              
              <div>
                <h3 className="text-xl font-semibold text-[#171719] mb-4">No creepy stuff</h3>
                <p className="text-[#171719] leading-relaxed">
                  We don't sell your info, track your every move, or let advertisers follow you around the internet. No third-party ads, ever.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Your Choices */}
        <section className="py-20 px-4">
          <div className="max-w-4xl mx-auto">
            <h2 style={{ fontFamily: 'Times New Roman, serif' }} className="text-3xl text-[#171719] mb-12">
              Your choices
            </h2>
            
            <div className="space-y-6 text-lg text-[#171719]">
              <p>• You can turn off cookies in your browser settings anytime—just know, some features might not work as well.</p>
              <p>• No cookie pop-up walls here. You decide what you're comfortable with.</p>
            </div>
          </div>
        </section>

        {/* Legal Basics */}
        <section className="py-20 px-4 bg-[#F1F1F1]">
          <div className="max-w-4xl mx-auto">
            <h2 style={{ fontFamily: 'Times New Roman, serif' }} className="text-3xl text-[#171719] mb-12">
              Legal basics (plain English)
            </h2>
            
            <div className="space-y-6 text-lg text-[#171719]">
              <p>• We follow the cookie rules for the EU, US, and everywhere SSELFIE is used.</p>
              <p>• If anything changes, this page gets updated first.</p>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-20 px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 style={{ fontFamily: 'Times New Roman, serif' }} className="text-3xl text-[#171719] mb-8">
              Still got questions about cookies? (The digital kind.)
            </h2>
            
            <p className="text-lg text-[#171719] mb-8 max-w-2xl mx-auto">
              Send me a note through the contact page or DM me on Instagram (@sandrasocial).<br />
              No bots, no wait times, just Sandra.
            </p>
            
            <Link 
              href="/contact"
              className="inline-block bg-[#171719] text-[#F1F1F1] px-8 py-4 font-medium tracking-wide hover:bg-[#2A2A2A] transition-colors duration-200"
            >
              ASK SANDRA
            </Link>
          </div>
        </section>
      </main>

      <Footer />
    </>
  )
}
