# SSELFIE COOKIES POLICY — ASSEMBLY PLAN & COPY

Alright Diana, this is the Cookies page—Sandra style. No pop-ups that make you want to throw your laptop, no endless legal mumbo-jumbo. Just the truth about what cookies are, what we use, and why it’s all about making your SSELFIE experience better (not creepier).

---

## 1. HERO SECTION

- **Component:** `HeroFullBleed.tsx`
- **Image:** Editorial: Sandra with coffee and her laptop, maybe a little side-eye at the “cookie” pop-up.
- **Title:**  
  COOKIES
- **Tagline:**  
  THE ONLY COOKIES HERE ARE DIGITAL
- **CTA:**  
  GOT QUESTIONS? JUST ASK

---

## 2. REAL TALK: WHAT EVEN ARE COOKIES?

**Headline:**  
Cookies, explained (the real way).

**Copy:**  
Basically, cookies are tiny files your browser saves so a website remembers who you are, what you like, and how you move around.  
They don’t spy on you, steal your snacks, or send Sandra your DMs.

---

## 3. WHAT COOKIES DOES SSELFIE USE?

- **Strictly necessary cookies:**  
  These make the site actually work—like keeping you logged in or saving your preferences.

- **Performance cookies:**  
  These help me see what’s working (are women getting stuck on onboarding? Is the gallery loading?)—all anonymous, all to make your experience smoother.

- **No creepy stuff:**  
  We don’t sell your info, track your every move, or let advertisers follow you around the internet.  
  No third-party ads, ever.

---

## 4. YOUR CHOICES

- You can turn off cookies in your browser settings anytime—just know, some features might not work as well.
- No cookie pop-up walls here. You decide what you’re comfortable with.

---

## 5. LEGAL BASICS (PLAIN ENGLISH)

- We follow the cookie rules for the EU, US, and everywhere SSELFIE is used.
- If anything changes, this page gets updated first.

---

## 6. CONTACT

**Headline:**  
Still got questions about cookies? (The digital kind.)

**Copy:**  
Send me a note through the contact page or DM me on Instagram (@sandrasocial).  
No bots, no wait times, just Sandra.

**CTA Button:**  
ASK SANDRA

---

## 7. STYLE & QA REMINDERS

- Editorial images only—never stock “cookie” icons or cartoon crumbs.
- Layout: Clean, open, with plenty of air.
- Typography:  
  - Headlines = ‘Times New Roman’, serif  
  - Body/UI = system sans
- Button: All caps, minimal, inviting.
- Copy: Sandra’s voice—warm, honest, always conversational.
- No m-dash. Never legal robot copy.

---

## FINAL CHECKLIST

- [ ] Hero: Title, tagline, CTA
- [ ] What cookies are, in plain English
- [ ] What SSELFIE uses (and doesn’t)
- [ ] Choices, not demands
- [ ] Legal basics—short, clear
- [ ] Contact/CTA—Sandra’s voice, not a bot

Let’s make this the only cookies page that actually makes sense.