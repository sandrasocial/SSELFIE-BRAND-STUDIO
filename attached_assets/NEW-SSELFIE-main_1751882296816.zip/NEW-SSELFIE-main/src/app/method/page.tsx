'use client'

import React from 'react'
import Navigation from '@/components/global/Navigation'
import { Footer } from '@/components/global/Footer'
import { HeroFullBleed } from '@/components/sections/hero/HeroFullBleed'
import { PowerQuote } from '@/components/sections'
import { SandraImages } from '@/components/sandra-image-library'
import Image from 'next/image'
import Link from 'next/link'

export default function MethodPage() {
  return (
    <>
      <Navigation />
      
      <div className="min-h-screen">
        {/* Hero Section */}
        <HeroFullBleed
          backgroundImage={SandraImages.hero.method}
          tagline="YOUR STORY, YOUR SELFIE, YOUR WAY"
          title="METHOD"
          ctaText="START YOUR TRANSFORMATION"
          ctaLink="#method-overview"
        />

        {/* Method Overview - The 4 Steps */}
        <section id="method-overview" className="py-20 md:py-32 bg-pure-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-6xl">
            <div className="text-center mb-16">
              <span className="font-inter text-xs md:text-sm tracking-[0.2em] uppercase text-luxury-black/60 mb-6 block">
                WHEN YOU'RE NOT IN THE MOOD TO OVERTHINK IT
              </span>
              <h2 className="font-bodoni text-4xl md:text-5xl lg:text-6xl font-light text-luxury-black leading-tight">
                How it works
              </h2>
            </div>

            <div className="space-y-20">
              {/* Step 1: SHOW UP */}
              <div className="flex flex-col lg:flex-row gap-12 lg:gap-20 items-center">
                <div className="relative h-96 lg:h-[600px] w-full lg:w-1/2 flex-shrink-0" style={{position: 'relative'}}>
                  <Image 
                    src={SandraImages.editorial.phone2}
                    alt="Just show up and take the photo"
                    fill
                    className="object-cover"
                    sizes="(max-width: 1024px) 100vw, 50vw"
                    priority
                    style={{objectFit: 'cover'}}
                  />
                </div>
                
                <div className="space-y-8 w-full lg:w-1/2">
                  <div>
                    <span className="font-inter text-xs tracking-[0.3em] uppercase text-luxury-black/50 mb-4 block">
                      STEP 1
                    </span>
                    <h3 className="font-bodoni text-3xl md:text-4xl lg:text-5xl font-light text-luxury-black leading-tight mb-6">
                      SHOW UP
                    </h3>
                  </div>
                  
                  <p className="font-inter text-lg md:text-xl text-luxury-black/80 leading-loose">
                    Let&rsquo;s be honest—this is the hardest part. Just take the photo. Messy bun, tired eyes, whatever. You&rsquo;re the main character, even on your worst day.
                  </p>
                </div>
              </div>

              {/* Step 2: STYLE IT */}
              <div className="flex flex-col lg:flex-row gap-12 lg:gap-20 items-center">
                <div className="space-y-8 w-full lg:w-1/2 order-2 lg:order-1">
                  <div>
                    <span className="font-inter text-xs tracking-[0.3em] uppercase text-luxury-black/50 mb-4 block">
                      STEP 2
                    </span>
                    <h3 className="font-bodoni text-3xl md:text-4xl lg:text-5xl font-light text-luxury-black leading-tight mb-6">
                      STYLE IT
                    </h3>
                  </div>
                  
                  <p className="font-inter text-lg md:text-xl text-luxury-black/80 leading-loose">
                    Now for the magic. SSELFIE&rsquo;s AI takes your photo and gives it that &ldquo;wait, is that really me?&rdquo; feeling. No weird filters. You&rsquo;re still you—just the version you actually want to post.
                  </p>
                </div>
                
                <div className="relative h-96 lg:h-[600px] w-full lg:w-1/2 flex-shrink-0 order-1 lg:order-2" style={{position: 'relative'}}>
                  <Image 
                    src={SandraImages.editorial.laptop1}
                    alt="AI styling your photos"
                    fill
                    className="object-cover"
                    sizes="(max-width: 1024px) 100vw, 50vw"
                    style={{objectFit: 'cover'}}
                  />
                </div>
              </div>

              {/* Step 3: SHARE IT */}
              <div className="flex flex-col lg:flex-row gap-12 lg:gap-20 items-center">
                <div className="relative h-96 lg:h-[600px] w-full lg:w-1/2 flex-shrink-0" style={{position: 'relative'}}>
                  <Image 
                    src={SandraImages.editorial.phone1}
                    alt="Sharing your styled photo"
                    fill
                    className="object-cover"
                    sizes="(max-width: 1024px) 100vw, 50vw"
                    style={{objectFit: 'cover'}}
                  />
                </div>
                
                <div className="space-y-8 w-full lg:w-1/2">
                  <div>
                    <span className="font-inter text-xs tracking-[0.3em] uppercase text-luxury-black/50 mb-4 block">
                      STEP 3
                    </span>
                    <h3 className="font-bodoni text-3xl md:text-4xl lg:text-5xl font-light text-luxury-black leading-tight mb-6">
                      SHARE IT
                    </h3>
                  </div>
                  
                  <p className="font-inter text-lg md:text-xl text-luxury-black/80 leading-loose">
                    This is where the nerves kick in. Hit post. Don&rsquo;t overthink it. The people who matter will notice. The rest? Who cares.
                  </p>
                </div>
              </div>

              {/* Step 4: STEP IN */}
              <div className="flex flex-col lg:flex-row gap-12 lg:gap-20 items-center">
                <div className="space-y-8 w-full lg:w-1/2 order-2 lg:order-1">
                  <div>
                    <span className="font-inter text-xs tracking-[0.3em] uppercase text-luxury-black/50 mb-4 block">
                      STEP 4
                    </span>
                    <h3 className="font-bodoni text-3xl md:text-4xl lg:text-5xl font-light text-luxury-black leading-tight mb-6">
                      STEP IN
                    </h3>
                  </div>
                  
                  <p className="font-inter text-lg md:text-xl text-luxury-black/80 leading-loose">
                    Here&rsquo;s where it gets good. You&rsquo;re not just posting—you&rsquo;re practicing being seen. The more you do it, the easier it gets. Promise.
                  </p>
                </div>
                
                <div className="relative h-96 lg:h-[600px] w-full lg:w-1/2 flex-shrink-0 order-1 lg:order-2" style={{position: 'relative'}}>
                  <Image 
                    src={SandraImages.editorial.mirror}
                    alt="Stepping into your power"
                    fill
                    className="object-cover"
                    sizes="(max-width: 1024px) 100vw, 50vw"
                    style={{objectFit: 'cover'}}
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Transformation Showcase */}
        <section className="py-20 md:py-32 bg-soft-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-6xl">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12 text-center">
              <div>
                <div className="relative aspect-[4/5] mb-6" style={{position: 'relative'}}>
                  <Image 
                    src={SandraImages.journey.rockBottom}
                    alt="Before transformation"
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 100vw, 33vw"
                    style={{objectFit: 'cover'}}
                  />
                </div>
                <p className="font-bodoni text-xl font-light text-luxury-black">
                  Before
                </p>
              </div>
              
              <div>
                <div className="relative aspect-[4/5] mb-6" style={{position: 'relative'}}>
                  <Image 
                    src={SandraImages.journey.success}
                    alt="After transformation"
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 100vw, 33vw"
                    style={{objectFit: 'cover'}}
                  />
                </div>
                <p className="font-bodoni text-xl font-light text-luxury-black">
                  After
                </p>
              </div>
              
              <div>
                <div className="relative aspect-[4/5] mb-6" style={{position: 'relative'}}>
                  <Image 
                    src={SandraImages.journey.building}
                    alt="This could be you"
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 100vw, 33vw"
                    style={{objectFit: 'cover'}}
                  />
                </div>
                <p className="font-bodoni text-xl font-light text-luxury-black">
                  This could be you
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Power Quote */}
        <PowerQuote />

        {/* Final CTA */}
        <section className="py-20 md:py-32 bg-luxury-black text-soft-white">
          <div className="container mx-auto px-6 md:px-12 lg:px-20 max-w-4xl text-center">
            <h2 className="font-bodoni text-4xl md:text-5xl lg:text-6xl font-light leading-tight mb-8">
              You don&rsquo;t need a plan.<br />
              Just one brave post.
            </h2>
            
            <div className="pt-8">
              <Link 
                href="/pricing"
                className="inline-block font-inter text-sm tracking-[0.2em] uppercase text-soft-white hover:text-soft-white/70 transition-colors duration-300 px-12 py-4 border border-soft-white hover:bg-soft-white hover:text-luxury-black"
              >
                GET STARTED
              </Link>
            </div>
          </div>
        </section>
      </div>
      
      <Footer />
    </>
  )
}
