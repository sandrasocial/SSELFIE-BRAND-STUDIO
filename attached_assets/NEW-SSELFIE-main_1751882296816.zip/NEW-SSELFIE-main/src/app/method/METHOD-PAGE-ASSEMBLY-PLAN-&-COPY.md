# METHOD PAGE ASSEMBLY PLAN & COPY

Alright Diana, here’s how we’re doing the Method page—Sandra style. Editorial, image-first, transformation at the center. No tech manual vibes, no “let’s build something real” (save that for the big moments). This is for the woman who wants to know “but how does it actually work?” and needs a nudge, not a lecture.

---

## 1. SECTION & COMPONENT LAYOUT

### 1. HERO SECTION
- **Component:** `HeroFullBleed.tsx` (WORKING VERSION)
- **Image:** Sandra, in motion, somewhere between “figuring it out” and “absolutely unstoppable.”
- **Title:**  
  METHOD
- **Tagline:**  
  YOUR STORY, YOUR SELFIE, YOUR WAY
- **CTA:**  
  START YOUR TRANSFORMATION

---

### 2. METHOD OVERVIEW (THE 4 STEPS)
- **Component:** `/sections/method/MethodOverview.tsx`
- **Images:** One per step if possible (editorial, process, or “real life” shots).
- **Copy:**  
  Step titles: Short, direct, zero fluff.  
  Descriptions: Conversational, a little cheeky, sounds like Sandra telling you how she’d do it if she only had two minutes and her phone was at 5%.

**Example Steps:**  
1. **SHOW UP**  
   Let’s be honest—this is the hardest part. Just take the photo. Messy bun, tired eyes, whatever. You’re the main character, even on your worst day.

2. **STYLE IT**  
   Now for the magic. SSELFIE’s AI takes your photo and gives it that “wait, is that really me?” feeling. No weird filters. You’re still you—just the version you actually want to post.

3. **SHARE IT**  
   This is where the nerves kick in. Hit post. Don’t overthink it. The people who matter will notice. The rest? Who cares.

4. **STEP IN**  
   Here’s where it gets good. You’re not just posting—you’re practicing being seen. The more you do it, the easier it gets. Promise.

---

### 3. MOODBOARD / TRANSFORMATION SHOWCASE
- **Component:** `EditorialMoodboard.tsx` or `TransformationPreview.tsx`
- **Images:** Before and afters, progress, real stories, behind-the-scenes.
- **Copy:**  
  No long explanations. Just:  
  - “Before”  
  - “After”  
  - “This could be you.”

---

### 4. POWER QUOTE / FINAL CTA
- **Component:** `PowerQuote.tsx` or `FinalCTA.tsx`
- **Copy:**  
  “You don’t need a plan. Just one brave post.”  
- **CTA Button:**  
  GET STARTED

---

## 2. PAGE COPY (FOR DIANA—EDIT AS NEEDED)

---

### HERO SECTION

**Title:**  
METHOD

**Tagline:**  
YOUR STORY, YOUR SELFIE, YOUR WAY

**CTA:**  
START YOUR TRANSFORMATION

---

### METHOD OVERVIEW

**Section Headline:**  
How it works (when you’re not in the mood to overthink it)

**Step 1: SHOW UP**  
Let’s be honest—this is the hardest part. Just take the photo. Messy bun, tired eyes, whatever. You’re the main character, even on your worst day.

**Step 2: STYLE IT**  
Now for the magic. SSELFIE’s AI takes your photo and gives it that “wait, is that really me?” feeling. No weird filters. You’re still you—just the version you actually want to post.

**Step 3: SHARE IT**  
This is where the nerves kick in. Hit post. Don’t overthink it. The people who matter will notice. The rest? Who cares.

**Step 4: STEP IN**  
Here’s where it gets good. You’re not just posting—you’re practicing being seen. The more you do it, the easier it gets. Promise.

---

### MOODBOARD / SHOWCASE

Before  
After  
This could be you.

---

### POWER QUOTE / FINAL CTA

“You don’t need a plan. Just one brave post.”

**CTA Button:**  
GET STARTED

---

## 3. STYLE & QA REMINDERS

- Editorial images only. No icons, no stock.
- Give every section breathing room.
- Headlines: ‘Times New Roman’, serif. Steps/body: system sans.
- Button = all caps, minimal.
- Color palette: Only from the Editorial Style Guide.
- Copy feels like Sandra texting a friend at midnight—warm, direct, no m-dash.

---

## FINAL CHECKLIST

- [ ] HeroFullBleed: METHOD title, tagline, CTA.
- [ ] MethodOverview: 4 steps, image per step, feels like Sandra.
- [ ] Moodboard/Transformation: Editorial, minimal copy.
- [ ] PowerQuote/FinalCTA: Just enough to nudge, not push.
- [ ] All text sounds like Sandra, but doesn’t repeat herself from other pages.

Let’s make this the page that makes someone say, “That’s actually doable. I could start today.”