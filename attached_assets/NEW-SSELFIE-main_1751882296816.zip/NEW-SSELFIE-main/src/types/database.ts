export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          user_id: string
          email: string
          full_name: string | null
          avatar_url: string | null
          bio: string | null
          website: string | null
          instagram_handle: string | null
          tiktok_handle: string | null
          youtube_handle: string | null
          linkedin_handle: string | null
          goals: string[] | null
          interests: string[] | null
          is_verified: boolean
          subscription_tier: 'free' | 'premium' | 'enterprise'
          onboarding_completed: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          email: string
          full_name?: string | null
          avatar_url?: string | null
          bio?: string | null
          website?: string | null
          instagram_handle?: string | null
          tiktok_handle?: string | null
          youtube_handle?: string | null
          linkedin_handle?: string | null
          goals?: string[] | null
          interests?: string[] | null
          is_verified?: boolean
          subscription_tier?: 'free' | 'premium' | 'enterprise'
          onboarding_completed?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          email?: string
          full_name?: string | null
          avatar_url?: string | null
          bio?: string | null
          website?: string | null
          instagram_handle?: string | null
          tiktok_handle?: string | null
          youtube_handle?: string | null
          linkedin_handle?: string | null
          goals?: string[] | null
          interests?: string[] | null
          is_verified?: boolean
          subscription_tier?: 'free' | 'premium' | 'enterprise'
          onboarding_completed?: boolean
          created_at?: string
          updated_at?: string
        }
        Relationships: []
      }
      glow_checks: {
        Row: {
          id: string
          user_id: string
          date: string
          energy_level: number
          mood_rating: number
          skin_quality: number
          sleep_hours: number
          water_intake: number
          exercise_minutes: number
          notes: string | null
          photo_url: string | null
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          date: string
          energy_level: number
          mood_rating: number
          skin_quality: number
          sleep_hours: number
          water_intake: number
          exercise_minutes: number
          notes?: string | null
          photo_url?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          date?: string
          energy_level?: number
          mood_rating?: number
          skin_quality?: number
          sleep_hours?: number
          water_intake?: number
          exercise_minutes?: number
          notes?: string | null
          photo_url?: string | null
          created_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "glow_checks_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["user_id"]
          }
        ]
      }
      content_calendar: {
        Row: {
          id: string
          user_id: string
          title: string
          content_type: 'post' | 'story' | 'reel' | 'video' | 'blog'
          platform: 'instagram' | 'tiktok' | 'youtube' | 'linkedin' | 'blog'
          scheduled_date: string
          status: 'draft' | 'scheduled' | 'published' | 'archived'
          content: string | null
          media_urls: string[] | null
          hashtags: string[] | null
          ai_generated: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          title: string
          content_type: 'post' | 'story' | 'reel' | 'video' | 'blog'
          platform: 'instagram' | 'tiktok' | 'youtube' | 'linkedin' | 'blog'
          scheduled_date: string
          status?: 'draft' | 'scheduled' | 'published' | 'archived'
          content?: string | null
          media_urls?: string[] | null
          hashtags?: string[] | null
          ai_generated?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          title?: string
          content_type?: 'post' | 'story' | 'reel' | 'video' | 'blog'
          platform?: 'instagram' | 'tiktok' | 'youtube' | 'linkedin' | 'blog'
          scheduled_date?: string
          status?: 'draft' | 'scheduled' | 'published' | 'archived'
          content?: string | null
          media_urls?: string[] | null
          hashtags?: string[] | null
          ai_generated?: boolean
          created_at?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "content_calendar_user_id_fkey"
            columns: ["user_id"]
            referencedRelation: "profiles"
            referencedColumns: ["user_id"]
          }
        ]
      }
      wellness_tracking: {
        Row: {
          id: string
          user_id: string
          date: string
          weight: number | null
          body_fat_percentage: number | null
          muscle_mass: number | null
          steps: number | null
          calories_burned: number | null
          meditation_minutes: number | null
          journal_entry: string | null
          gratitude_notes: string[] | null
          goals_completed: string[] | null
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          date: string
          weight?: number | null
          body_fat_percentage?: number | null
          muscle_mass?: number | null
          steps?: number | null
          calories_burned?: number | null
          meditation_minutes?: number | null
          journal_entry?: string | null
          gratitude_notes?: string[] | null
          goals_completed?: string[] | null
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          date?: string
          weight?: number | null
          body_fat_percentage?: number | null
          muscle_mass?: number | null
          steps?: number | null
          calories_burned?: number | null
          meditation_minutes?: number | null
          journal_entry?: string | null
          gratitude_notes?: string[] | null
          goals_completed?: string[] | null
          created_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "wellness_tracking_user_id_fkey"
            columns: ["user_id"]
            referencedRelation: "profiles"
            referencedColumns: ["user_id"]
          }
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      subscription_tier: 'free' | 'premium' | 'enterprise'
      content_status: 'draft' | 'scheduled' | 'published' | 'archived'
      content_type: 'post' | 'story' | 'reel' | 'video' | 'blog'
      platform: 'instagram' | 'tiktok' | 'youtube' | 'linkedin' | 'blog'
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}
