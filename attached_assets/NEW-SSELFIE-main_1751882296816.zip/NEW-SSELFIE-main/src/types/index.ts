// User and Profile Types
export interface User {
  id: string
  email: string
  created_at: string
  updated_at: string
}

export interface UserProfile {
  id: string
  user_id: string
  email: string
  full_name: string | null
  avatar_url: string | null
  bio: string | null
  website: string | null
  instagram_handle: string | null
  tiktok_handle: string | null
  youtube_handle: string | null
  linkedin_handle: string | null
  goals: string[] | null
  interests: string[] | null
  is_verified: boolean
  subscription_tier: 'free' | 'premium' | 'enterprise'
  onboarding_completed: boolean
  created_at: string
  updated_at: string
}

// Export Profile as alias for UserProfile for compatibility
export type Profile = UserProfile

// Glow Check Types
export interface GlowCheckResult {
  id: string
  user_id: string
  image_url: string
  score: number
  feedback: {
    lighting: number
    angle: number
    expression: number
    overall: string
  }
  created_at: string
}

// Future Self Types
export interface FutureSelfImage {
  id: string
  user_id: string
  prompt: string
  image_url: string
  scenario: string
  created_at: string
}

// Sandra AI Types
export interface SandraAIMessage {
  id: string
  user_id: string
  message: string
  response: string
  message_type: 'motivation' | 'tip' | 'celebration' | 'reminder'
  created_at: string
}

// Content Calendar Types
export interface ContentPlan {
  id: string
  user_id: string
  title: string
  content: string
  platform: 'instagram' | 'linkedin' | 'tiktok' | 'twitter'
  scheduled_date: string
  status: 'draft' | 'scheduled' | 'published'
  created_at: string
}

// Subscription Types
export interface Subscription {
  id: string
  user_id: string
  tier: 'free' | 'premium' | 'enterprise'
  status: 'active' | 'canceled' | 'past_due'
  current_period_start: string
  current_period_end: string
  stripe_subscription_id: string | null
}

// API Response Types
export interface ApiResponse<T> {
  data: T | null
  error: string | null
  success: boolean
}

// UI Component Types
export interface ButtonProps {
  variant?: 'default' | 'outline' | 'ghost' | 'link'
  size?: 'default' | 'sm' | 'lg' | 'icon'
  className?: string
  children: React.ReactNode
  onClick?: () => void
  disabled?: boolean
  type?: 'button' | 'submit' | 'reset'
}
