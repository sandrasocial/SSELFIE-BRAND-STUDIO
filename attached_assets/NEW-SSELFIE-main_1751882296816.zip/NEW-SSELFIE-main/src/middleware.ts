import { NextResponse, type NextRequest } from 'next/server'

export async function middleware(request: NextRequest) {
  // TEMPORARY: Middleware disabled during design phase
  // Will re-enable when Supabase is set up in Week 2
  const response = NextResponse.next()
  return response
  
  // DISABLED FOR NOW - RE-ENABLE IN WEEK 2:
  /*
  const supabase = createMiddlewareClient(request, response)

  // Get session
  const { data: { session } } = await supabase.auth.getSession()

  // Protected routes that require authentication
  const protectedRoutes = ['/dashboard', '/profile', '/glow-check', '/content-calendar']
  const isProtectedRoute = protectedRoutes.some(route => 
    request.nextUrl.pathname.startsWith(route)
  )

  // Auth routes that should redirect if already logged in
  const authRoutes = ['/login', '/signup']
  const isAuthRoute = authRoutes.includes(request.nextUrl.pathname)
  */

  // DISABLED FOR NOW - RE-ENABLE IN WEEK 2:
  /*
  // Redirect unauthenticated users from protected routes
  if (isProtectedRoute && !session) {
    const redirectUrl = new URL('/login', request.url)
    redirectUrl.searchParams.set('redirectTo', request.nextUrl.pathname)
    return NextResponse.redirect(redirectUrl)
  }

  // Redirect authenticated users from auth routes
  if (isAuthRoute && session) {
    return NextResponse.redirect(new URL('/dashboard', request.url))
  }
  */

  return response
}

// DISABLED DURING DESIGN PHASE - RE-ENABLE IN WEEK 2:
/*
export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
}
*/
