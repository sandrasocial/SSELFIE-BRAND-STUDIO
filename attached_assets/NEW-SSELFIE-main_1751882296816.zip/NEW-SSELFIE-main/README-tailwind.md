# SSELFIE Editorial Tailwind Config — DO NOT OVERRIDE

- Only use the color, font, spacing, and animation tokens in this file.
- Never add default Tailwind color classes (gray-700, blue-500, etc).
- Do not use border-radius utilities except for `rounded-none`.
- Do not import DaisyUI, TailwindUI, or shadcn themes.
- Do not “fix” spacing by adding Tailwind’s default padding/margin classes.
- All hover, focus, and animation states must be subtle, minimal, and editorial (see config).
- If you need a new utility, add it to this config or the global CSS, not with Tailwind’s defaults.
- If you’re unsure, check the Editorial Style Guide or ask Sandra/Victoria before changing.

Let’s keep this brand real, expensive, and editorial—never “just another Tailwind site.”