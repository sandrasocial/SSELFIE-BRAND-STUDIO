# SANDRA'S IMAGE RULES - MANDATORY READING

## HOW TO USE IMAGES:
1. ALWAYS import from sandra-image-library.ts
2. NEVER use generic stock photos
3. NEVER use placeholder.com except during dev
4. Follow the 80/20 rule (80% Sandra, 20% flatlays)

## IMAGE SELECTION LOGIC:
- Homepage? Use SandraImages.hero.homepage
- About section? Use SandraImages.journey.[appropriate stage]
- Working section? Use SandraImages.editorial.laptop1 or laptop2
- Break needed? Use ONE flatlay from SandraImages.flatlays

## FORBIDDEN:
- Using the same image twice on one page
- Using journey images out of story context
- Using more than 2 flatlays per page
- Making up image URLs

## IF UNSURE:
Use SandraImages.placeholder.[size] and flag for Sandra

Tell each component which images to use:

// In your design system
export const HeroFullBleed = ({ page }) => {
  const image = SandraImages.hero[page] || SandraImages.hero.homepage
  // Component automatically picks the right image!
}

export const EditorialSpread = ({ mood }) => {
  // mood: "working" | "confident" | "vulnerable" | "celebration"
  const imageMap = {
    working: SandraImages.editorial.laptop1,
    confident: SandraImages.editorial.today,
    vulnerable: SandraImages.journey.rockBottom,
    celebration: SandraImages.editorial.laughing,
  }
  // No guessing needed!
}

export const PageImageRules = {
  totalImages: 10, // per page average
  sandraShots: 8, // 80%
  flatlays: 2, // 20%
  
  example: {
    hero: "1 Sandra hero shot",
    content: "6-7 Sandra editorial/journey shots",
    breaks: "2 flatlay/lifestyle shots",
    social: "Optional: testimonials/results"
  }
}

