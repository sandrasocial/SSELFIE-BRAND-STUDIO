# SSELFIE STUDIO

**"It Starts With Your Selfie"**

Sandra's luxury AI platform that transforms selfies into personal brands in 20 minutes. Built for women 30+ who want to get seen, booked, and paid.

## 🎯 New Vision (2025)

**SSELFIE Studio** is THE shortcut for coaches, creators, and founders to build their personal brand using only their phone, their story, and about 20 minutes.

### The Process
1. **Upload 10-15 selfies** (simple tutorial included)
2. **Pick your vibe** (niche, look, dream client mood)  
3. **AI magic** (FLUX model creates editorial images)
4. **One-click studio** (luxury templates + your story)
5. **Everything connects** (booking, payments, your link)

## 💎 Pricing
- **AI Images**: €47 one-time (30 luxury images)
- **Studio Founding**: €97/month (first 100 members)
- **Studio Standard**: €147/month (full platform)

## 🚀 Features

### Core Tools
- **FLUX AI Model** - Custom-trained for women's selfies
- **SSELFIE Studio** - One-click brand builder
- **Editorial Templates** - Luxury layouts, not generic
- **Instant Setup** - Stripe, Calendly, everything connected

### User Experience
- **Luxury Design System** - Sharp, editorial aesthetic with generous whitespace
- **Mobile-First** - Responsive design optimized for all devices
- **Performance** - <2s load times with optimized code splitting

## 🛠 Tech Stack

- **Framework**: Next.js 14 with App Router
- **Language**: TypeScript (strict mode)
- **Styling**: Tailwind CSS with custom luxury design system
- **Database**: Supabase PostgreSQL
- **Authentication**: Supabase Auth with magic links
- **Payments**: Stripe for subscription management
- **AI**: OpenAI API for Sandra AI personality
- **Deployment**: Vercel

## 🎨 Design System

### Colors (ONLY THESE ALLOWED)
- `#171719` - Luxury Black (primary)
- `#F1F1F1` - Soft White (background)
- `#B5B5B3` - Warm Gray (accents)

### Typography
- **Headers**: Bodoni FLF (serif)
- **Body**: Inter (sans-serif)

### Principles
- ❌ No border radius, gradients, or bright colors
- ✅ Sharp corners, clean lines, generous whitespace
- ✅ Editorial layouts with luxury feel

## 🚀 Getting Started

### Development
```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Run linting
npm run lint
```

### Project Structure
```
src/
├── app/                 # Next.js app router pages
│   ├── dashboard/       # User dashboard
│   ├── globals.css      # Global styles with design system
│   └── page.tsx         # Homepage
├── components/
│   └── ui/              # Reusable UI components
├── lib/                 # Utility functions
└── types/               # TypeScript type definitions
```

## 📋 Development Status

### Day 1 - Complete ✅
- [x] Clean Next.js 14 project setup
- [x] Luxury design system implementation
- [x] Homepage with editorial design
- [x] Dashboard structure and navigation
- [x] TypeScript configuration and types
- [x] Component library foundation

### Day 2 - Planned
- [ ] Supabase authentication setup
- [ ] Database schema implementation
- [ ] API routes structure
- [ ] Email system integration

### Day 3 - Planned
- [ ] User profile system
- [ ] Basic dashboard functionality
- [ ] Cross-device testing
- [ ] Performance optimization

## 🎯 Phoenix Strategy Progress

This repository represents the **clean implementation** of Sandra's SSELFIE vision:

- **Migrated**: Luxury design system, component patterns, Sandra's voice
- **Rebuilt**: Clean architecture, modern TypeScript, optimized performance
- **New**: Future Self Gallery, enhanced Content Calendar, streamlined UX

## 📖 Documentation

- [Phoenix Strategy Master Plan](docs/PHOENIX-STRATEGY-MASTER-PLAN.md)
- [Component Library Guide](docs/components.md)
- [Design System Reference](docs/design-system.md)

## 🤝 Contributing

This project follows the Phoenix Strategy with clean code standards:

1. TypeScript strict mode - all code must be properly typed
2. Design system compliance - use only approved colors and styles
3. Mobile-first approach - all components must be responsive
4. Performance standards - maintain <2s load times

---

**Status**: 🔥 Phoenix Strategy Day 1 - Foundation Complete  
**Next**: Day 2 - Core Infrastructure (Authentication, Database)  
**Timeline**: 14 days to beta launch  
**Confidence**: 95% on track

# SSELFIE AI Platform

All real components live in `src/components/`.
Page-specific or legacy components are archived in `src/legacy/`.

See STYLEGUIDE.md for details on what to keep.
