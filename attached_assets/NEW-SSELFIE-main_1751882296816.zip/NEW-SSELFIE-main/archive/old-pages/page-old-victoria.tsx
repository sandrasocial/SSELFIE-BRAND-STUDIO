'use client'

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { inter, playfair } from './fonts';

// Lazy loaded image component with error handling
function LazyImage({ src, alt, className = '', priority = false, width, height, fill = false }: {
  src: string;
  alt: string;
  className?: string;
  priority?: boolean;
  width?: number;
  height?: number;
  fill?: boolean;
}) {
  const [error, setError] = useState(false);
  
  if (error) {
    return (
      <div className={`${className} bg-gray-200 flex items-center justify-center`}>
        <span className="text-gray-400 text-sm">Image unavailable</span>
      </div>
    );
  }

  if (fill) {
    return (
      <Image
        src={src}
        alt={alt}
        fill
        className={className}
        onError={() => setError(true)}
        priority={priority}
        sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
      />
    );
  }

  return (
    <Image
      src={src}
      alt={alt}
      width={width}
      height={height}
      className={className}
      onError={() => setError(true)}
      priority={priority}
    />
  );
}

// Add a type-safe gtag function (unused but keeping for future use)
// function gtag(
//   event: 'event',
//   action: string,
//   params: Record<string, unknown>
// ): void {
//   if (typeof window !== 'undefined' && typeof (window as unknown).gtag === 'function') {
//     (window as unknown).gtag(event, action, params);
//   }
// }

// ErrorBoundary component  
class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { hasError: boolean }> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError() {
    return { hasError: true };
  }
  componentDidCatch(_error: unknown, _info: unknown) {
    // Log error if needed
    // console.error(error, info);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-[#F1F1F1] text-[#171719] p-8">
          <h1 className="text-3xl font-bodoni mb-4">Something went wrong</h1>
          <p className="text-lg mb-8">Sorry, an unexpected error occurred. Please refresh the page or try again later.</p>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function HomeWithBoundary() {
  return <ErrorBoundary><Home /></ErrorBoundary>;
}

function Home() {
  const [isLoading, setIsLoading] = useState(false); // Start with false to bypass loading screen
  const [cursorPos, setCursorPos] = useState({ x: 0, y: 0 });
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Handle scroll for nav backdrop
  useEffect(() => {
    const handleScroll = () => {
      // Scroll functionality removed for simplicity
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Cursor follower effect (desktop only)
  useEffect(() => {
    if (window.innerWidth < 768) return;
    
    let lastUpdate = 0;
    const handleMouseMove = (e: MouseEvent) => {
      const now = Date.now();
      if (now - lastUpdate > 16) { // ~60fps
        setCursorPos({ x: e.clientX, y: e.clientY });
        lastUpdate = now;
      }
    };
    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  // Loading sequence with cleanup
  useEffect(() => {
    setIsLoading(false);
    return () => {};
  }, []);

  // Intersection Observer for animations
  useEffect(() => {
    if (isLoading) return;
    
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -100px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in-view');
        }
      });
    }, observerOptions);

    const elementsToObserve = document.querySelectorAll('.observe-me');
    elementsToObserve.forEach(el => observer.observe(el));

    return () => {
      elementsToObserve.forEach(el => observer.unobserve(el));
      observer.disconnect();
    };
  }, [isLoading]);

  // Lock body scroll when mobile menu is open
  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileMenuOpen]);

  // Loading Screen
  if (isLoading) {
    return (
      <div className="fixed inset-0 bg-[#F1F1F1] z-50 flex items-center justify-center">
        <div className="relative">
          <div className="font-playfair italic text-[120px] text-[#171719] opacity-0 animate-fadeIn">
            S
          </div>
          <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 w-32 h-[1px] bg-[#171719]/20">
            <div className="h-full bg-[#171719] animate-loadingLine"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen bg-white w-full ${inter.variable} ${playfair.variable}`}>
      <style jsx>{`
        /* Use CSS variables for fonts */
        .font-playfair { font-family: var(--font-playfair), Georgia, serif; }
        .font-inter { font-family: var(--font-inter), -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; }
        .font-bodoni { font-family: var(--font-playfair), Georgia, serif; }
        .font-neue { font-family: var(--font-inter), -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; }
        
        .story-opener {
          font-family: var(--font-playfair);
          font-style: italic;
          font-size: 1.25rem;
          color: #4C4B4B;
          margin-bottom: 2rem;
          line-height: 1.6;
        }
        
        .story-body {
          font-family: var(--font-inter);
          font-size: 1.125rem;
          color: #171719;
          line-height: 1.7;
          font-weight: 400;
        }
        
        .story-highlight {
          font-family: var(--font-playfair);
          font-style: italic;
          font-size: 1.5rem;
          color: #171719;
          margin: 2rem 0;
          padding-left: 1.5rem;
          border-left: 2px solid #171719;
          line-height: 1.5;
        }
        
        .story-cta {
          font-family: var(--font-inter);
          font-size: 0.875rem;
          color: #4C4B4B;
          text-transform: uppercase;
          letter-spacing: 0.15em;
          font-weight: 500;
        }
        
        .section-label {
          font-family: var(--font-inter);
          font-size: 0.6875rem;
          color: #B5B5B3;
          text-transform: uppercase;
          letter-spacing: 0.3em;
          font-weight: 400;
        }
        
        .editorial-number {
          position: absolute;
          font-family: 'Lingerie', serif;
          font-size: 18rem;
          color: rgba(23, 23, 25, 0.03);
          line-height: 0.8;
          pointer-events: none;
          user-select: none;
          z-index: 0;
        }
        
        .stats-container {
          position: relative;
          z-index: 10;
        }
        
        .stats-content {
          position: relative;
          z-index: 20;
        }
        
        .stats-numbers {
          margin-bottom: 3rem;
        }
        
        .stat-item {
          text-align: left;
        }
        
        .stat-label {
          font-family: var(--font-inter);
          font-size: 0.6875rem;
          color: #B5B5B3;
          text-transform: uppercase;
          letter-spacing: 0.2em;
        }
        
        .stats-quote {
          margin-bottom: 2rem;
        }
        
        .stats-cta {
          display: inline-block;
          margin-top: 2rem;
        }
        
        .stats-image {
          position: relative;
          z-index: 10;
        }
        
        .image-wrapper {
          position: relative;
        }
        
        .portrait-image {
          object-fit: cover;
          object-position: top;
        }
        
        .image-overlay {
          position: absolute;
          bottom: 1.5rem;
          right: 1.5rem;
          background: white;
          padding: 2rem;
          max-width: 18rem;
          box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        }
        
        .overlay-date {
          font-family: var(--font-inter);
          font-size: 0.625rem;
          color: #B5B5B3;
          text-transform: uppercase;
          letter-spacing: 0.2em;
          margin-bottom: 0.5rem;
        }
        
        .overlay-title {
          font-family: var(--font-playfair);
          font-style: italic;
          font-size: 1.25rem;
          color: #171719;
          line-height: 1.3;
        }
        
        .fade-in-up {
          opacity: 0;
          transform: translateY(2rem);
          transition: all 0.8s cubic-bezier(0.16, 1, 0.3, 1);
        }
        
        .fade-in-up.in-view {
          opacity: 1;
          transform: translateY(0);
        }
        
        .luxury-hover {
          overflow: hidden;
        }
        
        .luxury-hover:hover img {
          transform: scale(1.05);
        }
        
        .luxury-hover img {
          transition: transform 0.7s cubic-bezier(0.16, 1, 0.3, 1);
        }
        
        @keyframes fadeIn {
          from { opacity: 0; transform: scale(0.9); }
          to { opacity: 1; transform: scale(1); }
        }
        
        @keyframes loadingLine {
          from { width: 0; }
          to { width: 100%; }
        }
        
        .animate-fadeIn {
          animation: fadeIn 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
        
        .animate-loadingLine {
          animation: loadingLine 1.5s cubic-bezier(0.4, 0, 0.2, 1) forwards;
        }
        
        @keyframes revealUp {
          from { 
            opacity: 0; 
            transform: translateY(30px);
          }
          to { 
            opacity: 1; 
            transform: translateY(0);
          }
        }
        
        .letter-reveal span {
          display: inline-block;
          opacity: 0;
          animation: revealUp 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards;
          animation-delay: calc(var(--index) * 50ms);
        }
        
        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(400%); }
        }

        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        
        @keyframes float {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }

        .animate-shimmer {
          animation: shimmer 3s infinite;
        }

        .animate-spin-slow {
          animation: spin-slow 20s linear infinite;
        }
        
        .animate-float {
          animation: float 6s ease-in-out infinite;
        }

        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }

        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }

        * {
          border-radius: 0 !important;
        }
        
        .film-grain::after {
          content: '';
          position: absolute;
          inset: 0;
          background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)' opacity='0.05'/%3E%3C/svg%3E");
          pointer-events: none;
          mix-blend-mode: overlay;
        }
        
        .blur-load {
          filter: blur(20px);
          transition: filter 0.8s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .blur-load.loaded {
          filter: blur(0);
        }
        
        .observe-me {
          opacity: 0;
          transform: translateY(40px);
          transition: all 0.8s cubic-bezier(0.16, 1, 0.3, 1);
        }
        
        .observe-me.in-view {
          opacity: 1;
          transform: translateY(0);
        }
        
        *:focus {
          outline: none;
        }
        
        *:focus-visible {
          outline: 2px solid currentColor;
          outline-offset: 4px;
        }
        
        @media (max-width: 768px) {
          .editorial-number {
            font-size: 12rem;
            opacity: 0.02;
          }
          
          .story-opener {
            font-size: 1.125rem;
          }
          
          .story-body {
            font-size: 1rem;
          }
          
          .story-highlight {
            font-size: 1.25rem;
            padding-left: 1rem;
          }
          
          .image-overlay {
            bottom: 1rem;
            right: 1rem;
            padding: 1.5rem;
            max-width: 16rem;
          }
          
          .overlay-title {
            font-size: 1.125rem;
          }
        }
      `}</style>

      {/* Skip Navigation */}
      <a href="#main-content" className="absolute top-[-40px] left-0 bg-[#171719] text-white p-2 z-[100] focus:top-0">Skip to main content</a>

      {/* Subtle Cursor Follower (Desktop Only) */}
      {typeof window !== 'undefined' && window.innerWidth >= 768 && (
        <div 
          className="fixed w-96 h-96 pointer-events-none z-50 opacity-5 hidden md:block"
          style={{
            background: `radial-gradient(circle at center, #171719 0%, transparent 70%)`,
            transform: `translate(${cursorPos.x - 192}px, ${cursorPos.y - 192}px)`,
            transition: 'transform 0.2s ease-out'
          }}
          aria-hidden="true"
        />
      )}

      {/* HERO SECTION */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-[#171719]">
        {/* Background Image */}
        <div className="absolute inset-0 z-0">
          <LazyImage
            src="https://i.postimg.cc/BbhKRQM7/out-1-15.webp"
            alt="Sandra - SELFIE Founder"
            fill
            className="object-cover"
            priority
          />
          {/* Add a subtle dark overlay for better text readability */}
          <div className="absolute inset-0 bg-[#171719]/50" />
        </div>

        {/* Navigation - absolute positioned */}
        <nav className="absolute top-0 left-0 right-0 z-50 px-6 md:px-16 lg:px-24 py-8">
          <div className="flex items-center justify-between">
            <div className="text-white">
              <LazyImage 
                src="https://i.postimg.cc/L88db1fc/White-transperent-logo.png" 
                alt="SELFIE Logo" 
                width={120}
                height={32}
                className="h-8" 
              />
            </div>
            <div className="hidden md:flex items-center gap-12">
              <a href="/about" className="font-neue text-[11px] uppercase tracking-[0.3em] text-white/80 hover:text-white transition-colors">About</a>
              <a href="/tools" className="font-neue text-[11px] uppercase tracking-[0.3em] text-white/80 hover:text-white transition-colors">Tools</a>
              <a href="/stories" className="font-neue text-[11px] uppercase tracking-[0.3em] text-white/80 hover:text-white transition-colors">Stories</a>
            </div>
            <a href="/start-here" className="hidden md:inline-block bg-white text-[#171719] px-8 py-3 font-neue text-[11px] uppercase tracking-[0.3em] hover:bg-[#F1F1F1] transition-colors" aria-label="Navigate to start page">
              Let's Begin
            </a>
            {/* Hamburger for mobile */}
            <button
              className="md:hidden flex items-center justify-center w-10 h-10 text-white focus:outline-none"
              aria-label="Open menu"
              onClick={() => setMobileMenuOpen(true)}
            >
              <svg width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="feather feather-menu"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
            </button>
          </div>
          {/* Mobile Menu Drawer */}
          {mobileMenuOpen && (
            <div className="fixed inset-0 z-[100] bg-[#171719]/95 flex flex-col">
              <button
                className="absolute top-6 right-6 text-white text-3xl focus:outline-none"
                aria-label="Close menu"
                onClick={() => setMobileMenuOpen(false)}
              >
                &times;
              </button>
              <nav className="flex flex-col items-center justify-center flex-1 gap-10">
                <a href="/about" className="font-inter text-xl uppercase tracking-[0.3em] text-white/80 hover:text-white transition-colors" onClick={() => setMobileMenuOpen(false)}>About</a>
                <a href="/tools" className="font-inter text-xl uppercase tracking-[0.3em] text-white/80 hover:text-white transition-colors" onClick={() => setMobileMenuOpen(false)}>Tools</a>
                <a href="/stories" className="font-inter text-xl uppercase tracking-[0.3em] text-white/80 hover:text-white transition-colors" onClick={() => setMobileMenuOpen(false)}>Stories</a>
                <a href="/start-here" className="bg-white text-[#171719] px-8 py-3 font-inter text-[13px] uppercase tracking-[0.3em] hover:bg-[#F1F1F1] transition-colors" onClick={() => setMobileMenuOpen(false)} aria-label="Navigate to start page">
                  Let's Begin
                </a>
              </nav>
            </div>
          )}
        </nav>

        {/* Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 sm:py-32">
          <div className="max-w-3xl">
            {/* Small accent text - responsive sizing */}
            <p 
              className="text-xs sm:text-sm uppercase tracking-[0.3em] sm:tracking-[0.4em] text-white/80 mb-6 sm:mb-8 font-inter font-light"
              style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}
            >
              Stop hiding. Start posting. Watch it grow.
            </p>
            
            {/* Main headline - mobile-first responsive */}
            <h1 
              className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bodoni font-light leading-[1.1] mb-6 sm:mb-8 text-white"
              style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}
            >
              Build your entire personal brand<br/>from your phone
            </h1>
            
            {/* Subheadline - responsive sizing */}
            <p 
              className="text-lg sm:text-xl lg:text-2xl font-inter font-light italic text-white/90 mb-8 sm:mb-12 leading-relaxed"
              style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}
            >
              The same system that took me from zero to 120K.<br/>
              Now with AI tools that make it even easier.
            </p>

            {/* CTA Buttons - Mobile-first: stacked → inline */}
            <div className="flex flex-col sm:flex-row gap-4 sm:gap-6">
              {/* Primary Button */}
              <Link
                href="/free-guide"
                className="w-full sm:w-auto inline-block bg-white text-[#171719] px-8 py-5 sm:px-12 sm:py-4 font-inter text-sm uppercase tracking-wider hover:bg-white/90 transition-colors font-medium text-center min-h-[44px] flex items-center justify-center"
              >
                Get The Free Guide
              </Link>
              
              {/* Secondary Button */}
              <Link
                href="/tools"
                className="w-full sm:w-auto inline-block bg-transparent text-white px-8 py-5 sm:px-12 sm:py-4 font-inter text-sm uppercase tracking-wider border border-white hover:bg-white hover:text-[#171719] transition-all duration-300 font-medium text-center min-h-[44px] flex items-center justify-center"
              >
                Show Me Everything
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* About Section - Editorial Story */}
      <section className="py-24 lg:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="grid lg:grid-cols-2 gap-16 lg:gap-24 items-start">
            {/* Content */}
            <div className="observe-me">
              <div className="section-label mb-8">About</div>
              
              <div className="story-opener">
                Five years ago, I was invisible online. Now, I've built a personal brand that generates six figures annually.
              </div>
              
              <div className="story-body mb-8">
                I'm Sandra, and I used to think personal branding was for influencers and CEOs. I was wrong. When I finally committed to showing up authentically online, everything changed. My business grew, my network expanded, and opportunities started finding me instead of the other way around.
              </div>
              
              <div className="story-highlight">
                "The difference between being seen and being invisible online is having a system that works consistently."
              </div>
              
              <div className="story-body mb-8">
                That's why I created SSELFIE—the same transformation system I used, now enhanced with AI tools that make personal branding feel effortless. No more guessing what to post. No more writer's block. Just a clear pathway to becoming the person everyone remembers.
              </div>
              
              <Link 
                href="/story" 
                className="story-cta inline-block hover:text-black transition-colors"
              >
                Read My Full Story →
              </Link>
            </div>
            
            {/* Image */}
            <div className="observe-me luxury-hover">
              <div className="image-wrapper">
                <LazyImage
                  src="https://i.postimg.cc/BbhKRQM7/out-1-15.webp"
                  alt="Sandra - Founder of SSELFIE"
                  width={600}
                  height={800}
                  className="w-full h-[500px] lg:h-[600px] object-cover portrait-image"
                />
                
                <div className="image-overlay">
                  <div className="overlay-date">Est. 2019</div>
                  <div className="overlay-title">From invisible to influential in 18 months</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-24 lg:py-32 bg-[#F8F8F6] relative overflow-hidden">
        <div className="editorial-number top-20 right-20">02</div>
        
        <div className="max-w-7xl mx-auto px-6 lg:px-12 stats-container">
          <div className="grid lg:grid-cols-2 gap-16 lg:gap-24 items-center stats-content">
            {/* Stats Content */}
            <div className="observe-me">
              <div className="section-label mb-8">By The Numbers</div>
              
              <div className="stats-numbers">
                <div className="grid grid-cols-2 gap-8 mb-16">
                  <div className="stat-item">
                    <div className="text-5xl lg:text-6xl font-playfair font-light text-[#171719] mb-2">5K+</div>
                    <div className="stat-label">Women Transformed</div>
                  </div>
                  <div className="stat-item">
                    <div className="text-5xl lg:text-6xl font-playfair font-light text-[#171719] mb-2">$2.4M</div>
                    <div className="stat-label">Revenue Generated</div>
                  </div>
                  <div className="stat-item">
                    <div className="text-5xl lg:text-6xl font-playfair font-light text-[#171719] mb-2">89%</div>
                    <div className="stat-label">Increase in Confidence</div>
                  </div>
                  <div className="stat-item">
                    <div className="text-5xl lg:text-6xl font-playfair font-light text-[#171719] mb-2">156%</div>
                    <div className="stat-label">Business Growth Avg</div>
                  </div>
                </div>
              </div>
              
              <div className="stats-quote">
                <div className="story-highlight">
                  "SSELFIE didn't just help me build a personal brand—it helped me find my voice and step into my power."
                </div>
                <div className="text-sm font-inter text-[#4C4B4B] mt-4">— Maria K., Marketing Director</div>
              </div>
              
              <Link 
                href="/results" 
                className="stats-cta story-cta hover:text-black transition-colors"
              >
                See All Success Stories →
              </Link>
            </div>
            
            {/* Stats Image */}
            <div className="observe-me luxury-hover stats-image">
              <LazyImage
                src="https://i.postimg.cc/BbhKRQM7/out-1-15.webp"
                alt="SSELFIE Community Success"
                width={600}
                height={700}
                className="w-full h-[500px] lg:h-[700px] object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Who It's For Section */}
      <section className="py-24 lg:py-32 bg-white">
        <div className="max-w-4xl mx-auto px-6 lg:px-12 text-center">
          <div className="observe-me">
            <div className="section-label mb-8">Who This Is For</div>
            
            <h2 className="text-4xl lg:text-5xl font-playfair italic text-[#171719] mb-16 leading-tight">
              For the woman who knows she's meant for more
            </h2>
            
            <div className="grid md:grid-cols-3 gap-8 lg:gap-12 mb-16">
              <div className="text-center">
                <div className="text-6xl lg:text-7xl font-playfair italic text-[#171719] mb-4">01</div>
                <h3 className="text-xl font-playfair italic text-[#171719] mb-4">The Ambitious Professional</h3>
                <p className="story-body text-base">Ready to step into thought leadership and be recognized for your expertise</p>
              </div>
              
              <div className="text-center">
                <div className="text-6xl lg:text-7xl font-playfair italic text-[#171719] mb-4">02</div>
                <h3 className="text-xl font-playfair italic text-[#171719] mb-4">The Entrepreneur</h3>
                <p className="story-body text-base">Building a business and need a personal brand that attracts your ideal clients</p>
              </div>
              
              <div className="text-center">
                <div className="text-6xl lg:text-7xl font-playfair italic text-[#171719] mb-4">03</div>
                <h3 className="text-xl font-playfair italic text-[#171719] mb-4">The Creative</h3>
                <p className="story-body text-base">Have talents to share but struggle with consistent content and self-promotion</p>
              </div>
            </div>
            
            <div className="story-highlight text-center max-w-3xl mx-auto">
              "If you've been waiting for permission to shine, this is it."
            </div>
          </div>
        </div>
      </section>

      {/* Tools Preview Section */}
      <section className="py-24 lg:py-32 bg-[#F8F8F6] relative overflow-hidden">
        <div className="editorial-number top-20 left-20">03</div>
        
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="observe-me text-center mb-16">
            <div className="section-label mb-8">AI-Powered Tools</div>
            <h2 className="text-4xl lg:text-5xl font-playfair italic text-[#171719] mb-8">
              Everything you need to build your brand
            </h2>
            <p className="text-xl font-inter text-[#4C4B4B] max-w-3xl mx-auto">
              From content creation to visual branding, our AI tools make personal branding feel effortless
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-12">
            <div className="observe-me bg-white p-8 lg:p-12">
              <div className="text-3xl font-playfair italic text-[#171719] mb-4">Glow Check Studio</div>
              <p className="story-body text-base mb-6">AI-powered selfie analysis that reveals your most confident angles and optimal lighting</p>
              <Link href="/glow-check" className="story-cta hover:text-black transition-colors">Try Now →</Link>
            </div>
            
            <div className="observe-me bg-white p-8 lg:p-12">
              <div className="text-3xl font-playfair italic text-[#171719] mb-4">Content Generator</div>
              <p className="story-body text-base mb-6">Never run out of post ideas with AI that understands your unique voice and audience</p>
              <Link href="/content-tools" className="story-cta hover:text-black transition-colors">Explore →</Link>
            </div>
            
            <div className="observe-me bg-white p-8 lg:p-12">
              <div className="text-3xl font-playfair italic text-[#171719] mb-4">Brand Voice AI</div>
              <p className="story-body text-base mb-6">Develop a consistent, authentic voice that resonates with your ideal audience</p>
              <Link href="/voice-tools" className="story-cta hover:text-black transition-colors">Discover →</Link>
            </div>
          </div>
        </div>
      </section>

      {/* Value Ladder Section */}
      <section className="py-24 lg:py-32 bg-white">
        <div className="max-w-6xl mx-auto px-6 lg:px-12">
          <div className="observe-me text-center mb-16">
            <div className="section-label mb-8">Investment Options</div>
            <h2 className="text-4xl lg:text-5xl font-playfair italic text-[#171719] mb-8">
              Choose your transformation journey
            </h2>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 lg:gap-12">
            {/* Free Tier */}
            <div className="observe-me border border-[#E5E5E5] p-8 lg:p-12">
              <div className="text-sm font-inter text-[#B5B5B3] uppercase tracking-wider mb-4">Start Here</div>
              <div className="text-3xl font-playfair italic text-[#171719] mb-4">Free Guide</div>
              <div className="text-5xl font-playfair text-[#171719] mb-6">$0</div>
              <ul className="space-y-3 mb-8">
                <li className="story-body text-base">• Personal Brand Audit</li>
                <li className="story-body text-base">• Content Calendar Template</li>
                <li className="story-body text-base">• Confidence Building Exercises</li>
              </ul>
              <Link 
                href="/free-guide" 
                className="w-full inline-block bg-[#171719] text-white text-center px-8 py-4 font-inter text-sm uppercase tracking-wider hover:bg-[#2a2a2a] transition-colors"
              >
                Get Started
              </Link>
            </div>
            
            {/* Paid Tier */}
            <div className="observe-me border-2 border-[#171719] p-8 lg:p-12 relative">
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-[#171719] text-white px-6 py-2 text-xs font-inter uppercase tracking-wider">
                Most Popular
              </div>
              <div className="text-sm font-inter text-[#B5B5B3] uppercase tracking-wider mb-4">Complete System</div>
              <div className="text-3xl font-playfair italic text-[#171719] mb-4">SSELFIE Platform</div>
              <div className="text-5xl font-playfair text-[#171719] mb-6">$97<span className="text-xl text-[#4C4B4B]">/mo</span></div>
              <ul className="space-y-3 mb-8">
                <li className="story-body text-base">• All AI-powered tools</li>
                <li className="story-body text-base">• Personal brand blueprint</li>
                <li className="story-body text-base">• Community access</li>
                <li className="story-body text-base">• Monthly group coaching</li>
              </ul>
              <Link 
                href="/join" 
                className="w-full inline-block bg-[#171719] text-white text-center px-8 py-4 font-inter text-sm uppercase tracking-wider hover:bg-[#2a2a2a] transition-colors"
              >
                Join Now
              </Link>
            </div>
            
            {/* Premium Tier */}
            <div className="observe-me border border-[#E5E5E5] p-8 lg:p-12">
              <div className="text-sm font-inter text-[#B5B5B3] uppercase tracking-wider mb-4">VIP Experience</div>
              <div className="text-3xl font-playfair italic text-[#171719] mb-4">1:1 Intensive</div>
              <div className="text-5xl font-playfair text-[#171719] mb-6">$2,997</div>
              <ul className="space-y-3 mb-8">
                <li className="story-body text-base">• Personal brand strategy session</li>
                <li className="story-body text-base">• Custom content templates</li>
                <li className="story-body text-base">• 90-day implementation plan</li>
                <li className="story-body text-base">• Direct access to Sandra</li>
              </ul>
              <Link 
                href="/vip" 
                className="w-full inline-block border border-[#171719] text-[#171719] text-center px-8 py-4 font-inter text-sm uppercase tracking-wider hover:bg-[#171719] hover:text-white transition-colors"
              >
                Apply Now
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-24 lg:py-32 bg-[#171719] text-white relative overflow-hidden">
        <div className="max-w-4xl mx-auto px-6 lg:px-12 text-center">
          <div className="observe-me">
            <h2 className="text-4xl lg:text-6xl font-playfair italic text-white mb-8 leading-tight">
              Your future self is waiting
            </h2>
            
            <p className="text-xl lg:text-2xl font-inter text-white/90 mb-12 leading-relaxed">
              The woman you're meant to become is just one decision away.<br/>
              Start building the personal brand that transforms everything.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-6 justify-center">
              <Link
                href="/free-guide"
                className="bg-white text-[#171719] px-12 py-4 font-inter text-sm uppercase tracking-wider hover:bg-white/90 transition-colors font-medium"
              >
                Get The Free Guide
              </Link>
              
              <Link
                href="/join"
                className="bg-transparent text-white px-12 py-4 font-inter text-sm uppercase tracking-wider border border-white hover:bg-white hover:text-[#171719] transition-all duration-300 font-medium"
              >
                Join SSELFIE Now
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
