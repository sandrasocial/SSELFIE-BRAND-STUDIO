#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// Get all TypeScript and TSX files
function getAllFiles(dir, fileExtensions = ['.tsx', '.ts']) {
  let results = [];
  const list = fs.readdirSync(dir);
  
  list.forEach(file => {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    
    if (stat && stat.isDirectory()) {
      // Skip node_modules and .next directories
      if (!file.startsWith('.') && file !== 'node_modules' && file !== '.next') {
        results = results.concat(getAllFiles(filePath, fileExtensions));
      }
    } else {
      if (fileExtensions.some(ext => file.endsWith(ext))) {
        results.push(filePath);
      }
    }
  });
  
  return results;
}

// Fix common quote escaping issues
function fixQuoteEscaping(content) {
  // Replace single quotes in JSX text with &apos;
  content = content.replace(/(\>[^<]*)'([^<]*\<)/g, '$1&apos;$2');
  
  // Replace double quotes in JSX text with &quot;
  content = content.replace(/(\>[^<]*)"([^<]*\<)/g, '$1&quot;$2');
  
  return content;
}

// Remove unused imports
function removeUnusedImports(content) {
  const lines = content.split('\n');
  const usedImports = new Set();
  const importLines = [];
  
  // Find all import statements
  lines.forEach((line, index) => {
    if (line.trim().startsWith('import ')) {
      importLines.push({ line, index });
    }
  });
  
  // Find all used identifiers in the code
  const codeWithoutImports = lines.slice(importLines.length).join('\n');
  
  // Simple regex to find used identifiers (this is basic, might need refinement)
  const identifierRegex = /\b[A-Z][a-zA-Z0-9_]*\b/g;
  const matches = codeWithoutImports.match(identifierRegex) || [];
  matches.forEach(match => usedImports.add(match));
  
  // Filter import lines to remove unused ones
  const filteredLines = lines.filter((line, index) => {
    if (line.trim().startsWith('import ')) {
      // Check if any imported identifier is used
      const importMatch = line.match(/import\s+(?:{([^}]+)}|\*\s+as\s+(\w+)|(\w+))/);
      if (importMatch) {
        const importedItems = importMatch[1] ? 
          importMatch[1].split(',').map(item => item.trim()) : 
          [importMatch[2] || importMatch[3]];
        
        return importedItems.some(item => usedImports.has(item));
      }
    }
    return true;
  });
  
  return filteredLines.join('\n');
}

// Fix <img> to <Image> tags
function fixImageTags(content) {
  // Add Image import if not present and img tags exist
  if (content.includes('<img') && !content.includes("import Image from 'next/image'")) {
    content = "import Image from 'next/image';\n" + content;
  }
  
  // Replace <img> with <Image> (basic replacement)
  content = content.replace(/<img\s+([^>]*)\s*\/?>(?:<\/img>)?/g, '<Image $1 />');
  
  return content;
}

// Fix unused variables
function fixUnusedVariables(content) {
  // This is a simple approach - comment out unused variable declarations
  // A more sophisticated approach would require AST parsing
  
  // Remove unused const declarations that are never referenced
  const lines = content.split('\n');
  const variableDeclarations = [];
  
  lines.forEach((line, index) => {
    const match = line.match(/^\s*const\s+(\w+)\s*=/);
    if (match) {
      variableDeclarations.push({ name: match[1], line: index });
    }
  });
  
  // Check if variables are used elsewhere
  const usedVariables = new Set();
  content.split('\n').forEach(line => {
    variableDeclarations.forEach(decl => {
      if (line.includes(decl.name) && !line.includes(`const ${decl.name}`)) {
        usedVariables.add(decl.name);
      }
    });
  });
  
  // Comment out unused variable declarations
  const filteredLines = lines.map(line => {
    const match = line.match(/^\s*const\s+(\w+)\s*=/);
    if (match && !usedVariables.has(match[1])) {
      return `// ${line} // UNUSED - commented out by auto-fix`;
    }
    return line;
  });
  
  return filteredLines.join('\n');
}

// Main function to fix a file
function fixFile(filePath) {
  try {
    let content = fs.readFileSync(filePath, 'utf8');
    
    console.log(`Fixing ${filePath}...`);
    
    // Apply fixes
    content = fixQuoteEscaping(content);
    // content = removeUnusedImports(content); // Commented out as it's complex
    content = fixImageTags(content);
    // content = fixUnusedVariables(content); // Commented out as it's complex
    
    // Write back the fixed content
    fs.writeFileSync(filePath, content);
    
    console.log(`✅ Fixed ${filePath}`);
  } catch (error) {
    console.error(`❌ Error fixing ${filePath}:`, error.message);
  }
}

// Main execution
const srcDir = path.join(__dirname, 'src');
const files = getAllFiles(srcDir);

console.log(`Found ${files.length} files to process...`);

files.forEach(fixFile);

console.log('✅ Auto-fix complete! Run npm run lint to see remaining issues.');
