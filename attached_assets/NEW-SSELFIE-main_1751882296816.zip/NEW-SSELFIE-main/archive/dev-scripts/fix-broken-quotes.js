#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

function fixBrokenQuotes(content) {
  // Fix broken &quot; inside JavaScript/TypeScript strings
  content = content.replace(/"([^"]*?)&quot;([^"]*?)"/g, '"$1"$2"');
  content = content.replace(/'([^']*?)&apos;([^']*?)'/g, "'$1'$2'");
  
  // Fix specific broken patterns
  content = content.replace(/&quot;,/g, '",');
  content = content.replace(/&quot;}/g, '"}');
  content = content.replace(/&quot;]/g, '"]');
  content = content.replace(/&quot;\)/g, '")');
  content = content.replace(/&quot;$/gm, '"');
  
  content = content.replace(/&apos;,/g, "',");
  content = content.replace(/&apos;}/g, "'}");
  content = content.replace(/&apos;]/g, "']");
  content = content.replace(/&apos;\)/g, "')");
  content = content.replace(/&apos;$/gm, "'");
  
  return content;
}

function fixFile(filePath) {
  try {
    let content = fs.readFileSync(filePath, 'utf8');
    const originalContent = content;
    
    content = fixBrokenQuotes(content);
    
    if (content !== originalContent) {
      fs.writeFileSync(filePath, content);
      console.log(`✅ Fixed ${filePath}`);
    }
  } catch (error) {
    console.error(`❌ Error fixing ${filePath}:`, error.message);
  }
}

function getAllFiles(dir, fileExtensions = ['.tsx', '.ts']) {
  let results = [];
  const list = fs.readdirSync(dir);
  
  list.forEach(file => {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    
    if (stat && stat.isDirectory()) {
      if (!file.startsWith('.') && file !== 'node_modules' && file !== '.next') {
        results = results.concat(getAllFiles(filePath, fileExtensions));
      }
    } else {
      if (fileExtensions.some(ext => file.endsWith(ext))) {
        results.push(filePath);
      }
    }
  });
  
  return results;
}

const srcDir = path.join(__dirname, 'src');
const files = getAllFiles(srcDir);

console.log(`Fixing broken quotes in ${files.length} files...`);
files.forEach(fixFile);
console.log('✅ Quote fix complete!');
