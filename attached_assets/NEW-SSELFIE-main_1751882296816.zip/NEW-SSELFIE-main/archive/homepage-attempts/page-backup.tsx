'use client'

import React, { useState, useEffect, useRef } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import dynamic from 'next/dynamic';

// Add a type-safe gtag function
function gtag(
  event: 'event',
  action: string,
  params: Record<string, unknown>
): void {
  if (typeof window !== 'undefined' && typeof (window as unknown as { gtag: () => void }).gtag === 'function') {
    (window as unknown as { gtag: () => void }).gtag(event, action, params);
  }
}

// ErrorBoundary component
class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { hasError: boolean }> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError() {
    return { hasError: true };
  }
  
  componentDidCatch(error: any, info: any) {
    // Log error to console or error reporting service
    console.error('Error caught by boundary:', error, info);
  }
  
  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-[#F1F1F1] text-[#171719] p-8">
          <h1 className="text-3xl font-bodoni mb-4">Something went wrong</h1>
          <p className="text-lg mb-8">Sorry, an unexpected error occurred. Please refresh the page or try again later.</p>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function HomeWithBoundary() {
  return <ErrorBoundary><Home /></ErrorBoundary>;
}

function Home() {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [cursorPos, setCursorPos] = useState({ x: 0, y: 0 });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitMessage, setSubmitMessage] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [emailError, setEmailError] = useState<string | null>(null);
  
  // Refs for cleanup

  // Handle scroll for nav backdrop
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Cursor follower effect (desktop only)
  useEffect(() => {
    if (window.innerWidth < 768) return;
    
    let lastUpdate = 0;
    const handleMouseMove = (e: MouseEvent) => {
      const now = Date.now();
      if (now - lastUpdate > 16) { // ~60fps
        setCursorPos({ x: e.clientX, y: e.clientY });
        lastUpdate = now;
      }
    };
    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  // Loading sequence with cleanup
  useEffect(() => {
    setIsLoading(false);
    setHeroLoaded(true);
    return () => {};
  }, []);

  // Intersection Observer for animations
  useEffect(() => {
    if (isLoading) return;
    
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -100px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in-view');
        }
      });
    }, observerOptions);

    const elementsToObserve = document.querySelectorAll('.observe-me');
    elementsToObserve.forEach(el => observer.observe(el));

    return () => {
      elementsToObserve.forEach(el => observer.unobserve(el));
      observer.disconnect();
    };
  }, [isLoading]);

  // Lock body scroll when mobile menu is open
  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileMenuOpen]);

  // Handle email form submission
  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitMessage('');
    setEmailError(null);
    
    // Import validation function dynamically to avoid SSR issues
    const { validateEmail, logEmailValidation } = await import('@/lib/email-validation');
    
    // Comprehensive email validation to prevent bounces
    const validation = validateEmail(email);
    logEmailValidation(email, validation.isValid, validation.error);
    
    if (!validation.isValid) {
      setEmailError(validation.error || 'Please enter a valid email address.');
      return;
    }
    
    setIsSubmitting(true);
    try {
      const response = await fetch('/api/signup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, source: 'homepage' }),
      });
      if (response.ok) {
        setSubmitMessage('Check your email for your free guide.');
        setEmail('');
        gtag('event', 'conversion', {
          send_to: 'SELFIE_AI/homepage_signup',
          value: 1.0,
          currency: 'USD'
        });
      } else {
        const data = await response.json();
        setSubmitMessage(data.error || 'Something went wrong. Please try again.');
      }
    } catch (error) {
      setSubmitMessage('Please check your connection and try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Loading Screen
  if (isLoading) {
    return (
      <div className="fixed inset-0 bg-[#F1F1F1] z-50 flex items-center justify-center">
        <div className="relative">
          <div className="font-playfair italic text-[120px] text-[#171719] opacity-0 animate-fadeIn">
            S
          </div>
          <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 w-32 h-[1px] bg-[#171719]/20">
            <div className="h-full bg-[#171719] animate-loadingLine"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white w-full">
      <style jsx>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: scale(0.9); }
          to { opacity: 1; transform: scale(1); }
        }
        
        @keyframes loadingLine {
          from { width: 0; }
          to { width: 100%; }
        }
        
        .animate-fadeIn {
          animation: fadeIn 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
        
        .animate-loadingLine {
          animation: loadingLine 1.5s cubic-bezier(0.4, 0, 0.2, 1) forwards;
        }
        
        @keyframes revealUp {
          from { 
            opacity: 0; 
            transform: translateY(30px);
          }
          to { 
            opacity: 1; 
            transform: translateY(0);
          }
        }
        
        .letter-reveal span {
          display: inline-block;
          opacity: 0;
          animation: revealUp 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards;
          animation-delay: calc(var(--index) * 50ms);
        }
        
        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(400%); }
        }

        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        
        @keyframes float {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }

        .animate-shimmer {
          animation: shimmer 3s infinite;
        }

        .animate-spin-slow {
          animation: spin-slow 20s linear infinite;
        }
        
        .animate-float {
          animation: float 6s ease-in-out infinite;
        }

        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }

        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }

        * {
          border-radius: 0 !important;
        }
        
        .film-grain::after {
          content: '';
          position: absolute;
          inset: 0;
          background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)' opacity='0.05'/%3E%3C/svg%3E");
          pointer-events: none;
          mix-blend-mode: overlay;
        }
        
        .blur-load {
          filter: blur(20px);
          transition: filter 0.8s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .blur-load.loaded {
          filter: blur(0);
        }
        
        .observe-me {
          opacity: 0;
          transform: translateY(40px);
          transition: all 0.8s cubic-bezier(0.16, 1, 0.3, 1);
        }
        
        .observe-me.in-view {
          opacity: 1;
          transform: translateY(0);
        }
        
        *:focus {
          outline: none;
        }
        
        *:focus-visible {
          outline: 2px solid currentColor;
          outline-offset: 4px;
        }
      `}</style>

      {/* Skip Navigation */}
      <a href="#main-content" className="absolute top-[-40px] left-0 bg-[#171719] text-white p-2 z-[100] focus:top-0">Skip to main content</a>

      {/* Subtle Cursor Follower (Desktop Only) */}
      {typeof window !== 'undefined' && window.innerWidth >= 768 && (
        <div 
          className="fixed w-96 h-96 pointer-events-none z-50 opacity-5 hidden md:block"
          style={{
            background: `radial-gradient(circle at center, #171719 0%, transparent 70%)`,
            transform: `translate(${cursorPos.x - 192}px, ${cursorPos.y - 192}px)`,
            transition: 'transform 0.2s ease-out'
          }}
          aria-hidden="true"
        />
      )}

      {/* HERO SECTION */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-[#171719]">
        {/* Background Image */}
        <div className="absolute inset-0 z-0">
          <Image
            src="https://i.postimg.cc/BbhKRQM7/out-1-15.webp"
            alt="Sandra - SELFIE Founder"
            fill
            className="object-cover"
            priority
            sizes="100vw"
          />
          {/* Add a subtle dark overlay for better text readability */}
          <div className="absolute inset-0 bg-[#171719]/50" />
        </div>

        {/* Navigation - absolute positioned */}
        <nav className="absolute top-0 left-0 right-0 z-50 px-6 md:px-16 lg:px-24 py-8">
          <div className="flex items-center justify-between">
            <div className="text-white">
              <Image src="https://i.postimg.cc/L88db1fc/White-transperent-logo.png" alt="SELFIE Logo" className="h-8" width={120} height={32} />
            </div>
            <div className="hidden md:flex items-center gap-12">
              <a href="/about" className="font-neue text-[11px] uppercase tracking-[0.3em] text-white/80 hover:text-white transition-colors">About</a>
              <a href="/tools" className="font-neue text-[11px] uppercase tracking-[0.3em] text-white/80 hover:text-white transition-colors">Tools</a>
              <a href="/stories" className="font-neue text-[11px] uppercase tracking-[0.3em] text-white/80 hover:text-white transition-colors">Stories</a>
            </div>
            <a href="/start-here" className="hidden md:inline-block bg-white text-[#171719] px-8 py-3 font-neue text-[11px] uppercase tracking-[0.3em] hover:bg-[#F1F1F1] transition-colors" aria-label="Navigate to start page">
              Let&apos;s Begin
            </a>
            {/* Hamburger for mobile */}
            <button
              className="md:hidden flex items-center justify-center w-10 h-10 text-white focus:outline-none"
              aria-label="Open menu"
              onClick={() => setMobileMenuOpen(true)}
            >
              <svg width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="feather feather-menu"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
            </button>
          </div>
          {/* Mobile Menu Drawer */}
          {mobileMenuOpen && (
            <div className="fixed inset-0 z-[100] bg-[#171719]/95 flex flex-col">
              <button
                className="absolute top-6 right-6 text-white text-3xl focus:outline-none"
                aria-label="Close menu"
                onClick={() => setMobileMenuOpen(false)}
              >
                &times;
              </button>
              <nav className="flex flex-col items-center justify-center flex-1 gap-10">
                <a href="/about" className="font-inter text-xl uppercase tracking-[0.3em] text-white/80 hover:text-white transition-colors" onClick={() => setMobileMenuOpen(false)}>About</a>
                <a href="/tools" className="font-inter text-xl uppercase tracking-[0.3em] text-white/80 hover:text-white transition-colors" onClick={() => setMobileMenuOpen(false)}>Tools</a>
                <a href="/stories" className="font-inter text-xl uppercase tracking-[0.3em] text-white/80 hover:text-white transition-colors" onClick={() => setMobileMenuOpen(false)}>Stories</a>
                <a href="/start-here" className="bg-white text-[#171719] px-8 py-3 font-inter text-[13px] uppercase tracking-[0.3em] hover:bg-[#F1F1F1] transition-colors" onClick={() => setMobileMenuOpen(false)} aria-label="Navigate to start page">
                  Let&apos;s Begin
                </a>
              </nav>
            </div>
          )}
        </nav>

        {/* Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 sm:py-32">
          <div className="max-w-3xl">
            {/* Small accent text - responsive sizing */}
            <p 
              className="text-xs sm:text-sm uppercase tracking-[0.3em] sm:tracking-[0.4em] text-white/80 mb-6 sm:mb-8 font-inter font-light"
              style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}
            >
              Stop hiding. Start posting. Watch it grow.
            </p>
            
            {/* Main headline - mobile-first responsive */}
            <h1 
              className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bodoni font-light leading-[1.1] mb-6 sm:mb-8 text-white"
              style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}
            >
              Build your entire personal brand<br/>from your phone
            </h1>
            
            {/* Subheadline - responsive sizing */}
            <p 
              className="text-lg sm:text-xl lg:text-2xl font-inter font-light italic text-white/90 mb-8 sm:mb-12 leading-relaxed"
              style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}
            >
              The same system that took me from zero to 120K.<br/>
              Now with AI tools that make it even easier.
            </p>

            {/* CTA Buttons - Mobile-first: stacked → inline */}
            <div className="flex flex-col sm:flex-row gap-4 sm:gap-6">
              {/* Primary Button */}
              <Link
                href="/free-guide"
                className="w-full sm:w-auto bg-white text-[#171719] px-8 py-5 sm:px-12 sm:py-4 font-inter text-sm uppercase tracking-wider hover:bg-white/90 transition-colors font-medium text-center min-h-[44px] flex items-center justify-center"
              >
                Get The Free Guide
              </Link>
              
              {/* Secondary Button */}
              <Link
                href="/tools"
                className="w-full sm:w-auto bg-transparent text-white px-8 py-5 sm:px-12 sm:py-4 font-inter text-sm uppercase tracking-wider border border-white hover:bg-white hover:text-[#171719] transition-all duration-300 font-medium text-center min-h-[44px] flex items-center justify-center"
              >
                Show Me Everything
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* TESTIMONIALS SECTION */}
      <TestimonialsSection />

      {/* OFFER LADDER SECTION */}
      <OfferLadderSection />

      {/* FOOTER CTA SECTION */}
      <section className="relative bg-white py-24 sm:py-32 md:py-48 overflow-hidden observe-me">
        <div className="absolute top-0 left-0 font-playfair italic text-[600px] md:text-[800px] text-[#171719]/[0.02] leading-none select-none pointer-events-none">
          S
        </div>

        <div className="relative max-w-[1000px] mx-auto px-4 sm:px-8 md:px-16 text-center">
          <h2 className="font-bodoni text-[40px] sm:text-[56px] md:text-[80px] leading-[0.9] text-[#171719] mb-8 md:mb-12">
            Ready to stop hiding and<br/>
            start building something real?
          </h2>

          <p className="font-inter text-lg md:text-xl text-[#4C4B4B] leading-relaxed mb-12 md:mb-16 max-w-2xl mx-auto">
            I get it. You&apos;ve been taking photos, deleting them, taking more. Watching everyone else blow up while you&apos;re still trying to find your &quot;good side.&quot;
          </p>

          <p className="font-inter text-lg md:text-xl text-[#4C4B4B] leading-relaxed mb-12 md:mb-16 max-w-2xl mx-auto">
            Here&apos;s the truth: I started with terrible selfies too. The difference? I kept going. And I figured out the system.
          </p>

          <p className="font-inter text-[10px] md:text-xs uppercase tracking-[0.3em] text-[#B5B5B3] mb-8">
            Start where you are. With whatever photos you have.
          </p>

          <form onSubmit={handleEmailSubmit} className="max-w-md mx-auto">
            <div className="relative">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Your best email"
                required
                disabled={isSubmitting}
                aria-label="Email address"
                className="w-full px-0 py-4 text-lg bg-transparent border-0 border-b-2 border-[#171719]/20 placeholder:text-[#B5B5B3] focus:border-[#171719] focus:outline-none font-inter transition-colors duration-300 disabled:opacity-50"
              />
            </div>
            {emailError && (
              <p className="mt-2 text-sm text-red-600">{emailError}</p>
            )}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full mt-8 bg-[#171719] text-white py-5 font-inter text-[11px] uppercase tracking-[0.3em] transition-all duration-500 hover:translate-y-[-2px] hover:shadow-lg disabled:opacity-50 disabled:hover:translate-y-0"
            >
              {isSubmitting ? 'SENDING...' : 'SEND ME THE FREE GUIDE'}
            </button>

            {submitMessage && (
              <p className={`mt-4 text-sm ${submitMessage.includes('Check') ? 'text-green-600' : 'text-red-600'}`}>
                {submitMessage}
              </p>
            )}
          </form>

          <p className="mt-6 font-inter text-[10px] uppercase tracking-[0.2em] text-[#B5B5B3]">
            Join 10,000+ women building real brands
          </p>
        </div>
      </section>
    </div>
  );
}

const TestimonialsSection = dynamic(() => import('./components/TestimonialsSection'), {
  loading: () => <div className="h-96 bg-gray-100 animate-pulse" />,
  ssr: false
});

const OfferLadderSection = dynamic(() => import('./components/OfferLadderSection'), {
  loading: () => <div className="h-[70vh] bg-gray-100 animate-pulse" />,
  ssr: false
});