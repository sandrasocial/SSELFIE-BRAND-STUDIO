'use client'

import React from 'react';
import Link from 'next/link';
import { SocialProof } from '@/components/marketing/SocialProof';
import { MOCK_DATA } from '@/lib/mock-data-clean';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-[#F1F1F1] text-[#171719]">
      {/* Minimal Navigation */}
      <nav className="px-6 md:px-16 lg:px-24 py-8">
        <div className="flex items-center justify-between">
          <div className="text-[#171719]">
            <span className="text-sm font-light tracking-[0.2em] uppercase">SSELFIE Studio</span>
          </div>
          <div className="hidden md:flex items-center gap-8">
            <Link href="/freebie" className="text-sm font-light tracking-wide text-[#B5B5B3] hover:text-[#171719] transition-colors">
              Free Guide
            </Link>
            <Link 
              href="/membership" 
              className="bg-[#171719] text-[#F1F1F1] px-6 py-3 text-sm font-light tracking-wide hover:opacity-90 transition-opacity"
            >
              Join Studio
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section - Editorial Magazine Feel */}
      <main className="px-6 md:px-16 lg:px-24">
        {/* Opening Hook - Raw & Emotional */}
        <section className="py-16 md:py-24 lg:py-32">
          <div className="max-w-5xl mx-auto">
            <div className="grid lg:grid-cols-12 gap-16 lg:gap-24 items-start">
              <div className="lg:col-span-8">
                {/* Pre-headline */}
                <p className="text-[#B5B5B3] text-sm font-light tracking-[0.15em] uppercase mb-8">
                  Okay, here&apos;s what actually happened
                </p>
                
                {/* Main Headline - Huge & Dramatic */}
                <h1 className="text-4xl md:text-6xl lg:text-7xl xl:text-8xl font-light leading-[0.9] tracking-[-0.02em] mb-12">
                  One year ago my marriage ended.
                </h1>
                
                {/* Story Continuation */}
                <div className="space-y-8 text-lg md:text-xl lg:text-2xl font-light leading-relaxed text-[#171719]">
                  <p>Single mom, three kids, zero plan.</p>
                  <p>But I had a phone. And I figured out that was all I needed.</p>
                  <p className="text-[#B5B5B3]">90 days later: 120K followers.</p>
                  <p className="text-[#B5B5B3]">Today: A business that actually works.</p>
                  <p><strong>Now: Teaching you exactly how I did it.</strong></p>
                </div>
              </div>
              
              {/* Side Content */}
              <div className="lg:col-span-4">
                <div className="space-y-8">
                  <div className="border-l-2 border-[#171719] pl-6">
                    <p className="text-sm font-light text-[#B5B5B3] mb-2 tracking-[0.1em] uppercase">
                      No fancy equipment
                    </p>
                    <p className="text-sm font-light text-[#B5B5B3] mb-2 tracking-[0.1em] uppercase">
                      No design degree
                    </p>
                    <p className="text-sm font-light text-[#171719] tracking-[0.1em] uppercase">
                      Just strategy, your story and AI
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Philosophy Statement */}
        <section className="py-16 md:py-24">
          <div className="max-w-4xl mx-auto text-center">
            <blockquote className="text-2xl md:text-3xl lg:text-4xl font-light leading-relaxed tracking-[-0.01em] text-[#171719] mb-8">
              &ldquo;Your mess is your message. Let&apos;s turn it into money.&rdquo;
            </blockquote>
            <cite className="text-sm font-light text-[#B5B5B3] tracking-[0.15em] uppercase">Sandra, SSELFIE Founder</cite>
          </div>
        </section>

        {/* Value Proposition */}
        <section className="py-16 md:py-24">
          <div className="max-w-6xl mx-auto">
            <div className="grid md:grid-cols-2 gap-16 md:gap-24">
              <div>
                <h2 className="text-3xl md:text-4xl lg:text-5xl font-light leading-tight tracking-[-0.01em] mb-8">
                  Every successful woman started with nothing but a vision
                </h2>
                <p className="text-lg md:text-xl font-light leading-relaxed text-[#B5B5B3] mb-8">
                  SSELFIE gives you the confidence and content to build that vision into reality.
                </p>
                <Link 
                  href="/membership" 
                  className="inline-block bg-[#171719] text-[#F1F1F1] px-8 py-4 text-lg font-light tracking-wide hover:opacity-90 transition-opacity"
                >
                  Let&apos;s build something real together
                </Link>
              </div>
              
              <div className="space-y-12">
                <div>
                  <h3 className="text-xl font-medium mb-4 tracking-[-0.01em]">Starting Over</h3>
                  <p className="text-[#B5B5B3] font-light leading-relaxed">
                    It&apos;s never too late to become who you&apos;re meant to be
                  </p>
                </div>
                <div>
                  <h3 className="text-xl font-medium mb-4 tracking-[-0.01em]">Self-Worth</h3>
                  <p className="text-[#B5B5B3] font-light leading-relaxed">
                    You deserve to see yourself as the queen you are
                  </p>
                </div>
                <div>
                  <h3 className="text-xl font-medium mb-4 tracking-[-0.01em]">Your Brand</h3>
                  <p className="text-[#B5B5B3] font-light leading-relaxed">
                    Your face IS your brand. Let&apos;s make it work for you
                  </p>
                </div>
                <div>
                  <h3 className="text-xl font-medium mb-4 tracking-[-0.01em]">Global Sisterhood</h3>
                  <p className="text-[#B5B5B3] font-light leading-relaxed">
                    We&apos;re building a movement of confident women
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Social Proof - Let the testimonials speak */}
        <section className="py-16 md:py-24">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-2xl md:text-3xl font-light tracking-[-0.01em] mb-4">
                Women just like you
              </h2>
              <p className="text-[#B5B5B3] font-light">
                Real transformations, real results
              </p>
            </div>
            <SocialProof testimonials={MOCK_DATA.testimonials} />
          </div>
        </section>

        {/* Final CTA - Simple & Direct */}
        <section className="py-16 md:py-24 lg:py-32">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-light leading-tight tracking-[-0.01em] mb-8">
              Ready to build your empire
            </h2>
            <p className="text-lg md:text-xl font-light text-[#B5B5B3] mb-12 leading-relaxed">
              One selfie at a time
            </p>
            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
              <Link 
                href="/freebie" 
                className="text-[#171719] border border-[#171719] px-8 py-4 text-lg font-light tracking-wide hover:bg-[#171719] hover:text-[#F1F1F1] transition-colors"
              >
                Start with the free guide
              </Link>
              <Link 
                href="/membership" 
                className="bg-[#171719] text-[#F1F1F1] px-8 py-4 text-lg font-light tracking-wide hover:opacity-90 transition-opacity"
              >
                Join SSELFIE Studio
              </Link>
            </div>
          </div>
        </section>
      </main>

      {/* Minimal Footer */}
      <footer className="px-6 md:px-16 lg:px-24 py-16 border-t border-[#B5B5B3]">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-8">
            <div>
              <span className="text-sm font-light tracking-[0.2em] uppercase text-[#171719]">
                SSELFIE Studio
              </span>
              <p className="text-sm font-light text-[#B5B5B3] mt-2">
                Where powerful women are made
              </p>
            </div>
            <div className="flex gap-8">
              <Link href="/pricing" className="text-sm font-light text-[#B5B5B3] hover:text-[#171719] transition-colors">
                Pricing
              </Link>
              <Link href="/freebie" className="text-sm font-light text-[#B5B5B3] hover:text-[#171719] transition-colors">
                Free Guide
              </Link>
              <Link href="/component-showcase" className="text-sm font-light text-[#B5B5B3] hover:text-[#171719] transition-colors">
                Components
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
