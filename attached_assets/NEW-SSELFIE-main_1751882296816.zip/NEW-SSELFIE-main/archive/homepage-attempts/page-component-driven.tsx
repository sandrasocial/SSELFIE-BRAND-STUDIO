'use client'

import React from 'react';
import Link from 'next/link';
import { PricingCard } from '@/components/business/PricingCard';
import { SocialProof } from '@/components/marketing/SocialProof';
import { FreebiePreview } from '@/components/marketing/FreebiePreview';
import { MOCK_DATA } from '@/lib/mock-data-clean';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-[#F1F1F1]">
      {/* Navigation */}
      <nav className="px-6 md:px-16 lg:px-24 py-8">
        <div className="flex items-center justify-between">
          <div className="text-[#171719]">
            <span className="text-lg font-light tracking-[0.1em] uppercase">SSELFIE Studio</span>
          </div>
          <div className="hidden md:flex items-center gap-8">
            <Link href="/pricing" className="text-sm font-light text-[#B5B5B3] hover:text-[#171719] transition-colors">
              Pricing
            </Link>
            <Link href="/freebie" className="text-sm font-light text-[#B5B5B3] hover:text-[#171719] transition-colors">
              Free Guide
            </Link>
            <Link 
              href="/membership" 
              className="bg-[#171719] text-[#F1F1F1] px-6 py-3 text-sm font-light hover:opacity-90 transition-opacity"
            >
              Join Studio
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="px-6 md:px-16 lg:px-24 py-16 md:py-24">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-light leading-tight tracking-[-0.02em] text-[#171719] mb-8">
            Power is the new pretty
          </h1>
          <p className="text-xl md:text-2xl font-light text-[#B5B5B3] mb-12 max-w-2xl mx-auto leading-relaxed">
            Your selfie is your brand. Let&apos;s make it work for you.
          </p>
          <Link 
            href="/get-started" 
            className="inline-block bg-[#171719] text-[#F1F1F1] px-8 py-4 text-lg font-light hover:opacity-90 transition-opacity"
          >
            Get started
          </Link>
        </div>
      </section>

      {/* Freebie Component */}
      <section className="px-6 md:px-16 lg:px-24 py-16 md:py-24">
        <FreebiePreview 
          title={MOCK_DATA.freebie.title}
          subtitle={MOCK_DATA.freebie.subtitle}
          totalValue={MOCK_DATA.freebie.totalValue}
          downloadCount={MOCK_DATA.freebie.downloadCount}
          items={MOCK_DATA.freebie.contents.map(content => ({
            name: content.title,
            description: content.description,
            type: 'chapter'
          }))}
        />
      </section>

      {/* Social Proof Component */}
      <section className="px-6 md:px-16 lg:px-24 py-16 md:py-24">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-light text-[#171719] mb-4 tracking-[-0.01em]">
            Real women, real results
          </h2>
          <p className="text-lg font-light text-[#B5B5B3]">
            See what happens when you stop hiding
          </p>
        </div>
        <SocialProof testimonials={MOCK_DATA.testimonials} />
      </section>

      {/* Pricing Component */}
      <section className="px-6 md:px-16 lg:px-24 py-16 md:py-24">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-light text-[#171719] mb-4 tracking-[-0.01em]">
            Choose your path
          </h2>
          <p className="text-lg font-light text-[#B5B5B3]">
            Every queen needs the right tools
          </p>
        </div>
        <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {MOCK_DATA.pricingTiers && MOCK_DATA.pricingTiers.length > 0 ? (
            MOCK_DATA.pricingTiers.map((tier) => (
              <PricingCard
                key={tier.id}
                tier={tier}
                isPopular={tier.popular || false}
                onSelect={() => console.log(`Selected ${tier.name}`)}
              />
            ))
          ) : (
            <div className="col-span-3 text-center py-8">
              <p className="text-[#B5B5B3]">Loading pricing tiers...</p>
            </div>
          )}
        </div>
      </section>

      {/* Final CTA */}
      <section className="px-6 md:px-16 lg:px-24 py-16 md:py-24">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-light text-[#171719] mb-8 tracking-[-0.01em]">
            Ready to build your empire
          </h2>
          <p className="text-lg font-light text-[#B5B5B3] mb-12">
            One selfie at a time
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link 
              href="/freebie" 
              className="border border-[#171719] text-[#171719] px-8 py-4 text-lg font-light hover:bg-[#171719] hover:text-[#F1F1F1] transition-colors"
            >
              Start with free guide
            </Link>
            <Link 
              href="/membership" 
              className="bg-[#171719] text-[#F1F1F1] px-8 py-4 text-lg font-light hover:opacity-90 transition-opacity"
            >
              Join SSELFIE Studio
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-6 md:px-16 lg:px-24 py-16 border-t border-[#B5B5B3]">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <div>
            <span className="text-lg font-light tracking-[0.1em] uppercase text-[#171719]">
              SSELFIE Studio
            </span>
            <p className="text-sm font-light text-[#B5B5B3] mt-2">
              Where powerful women are made
            </p>
          </div>
          <div className="flex gap-8">
            <Link href="/dashboard" className="text-sm font-light text-[#B5B5B3] hover:text-[#171719] transition-colors">
              Dashboard
            </Link>
            <Link href="/pricing" className="text-sm font-light text-[#B5B5B3] hover:text-[#171719] transition-colors">
              Pricing
            </Link>
            <Link href="/component-showcase" className="text-sm font-light text-[#B5B5B3] hover:text-[#171719] transition-colors">
              Components
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
