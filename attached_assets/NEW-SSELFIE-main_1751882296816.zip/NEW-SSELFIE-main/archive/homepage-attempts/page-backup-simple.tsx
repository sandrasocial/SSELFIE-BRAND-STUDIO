'use client'

import React from 'react';
import Link from 'next/link';

export default function Home() {
  return (
    <div className="min-h-screen bg-[#F1F1F1] text-[#171719]">
      {/* Navigation */}
      <nav className="px-6 md:px-16 lg:px-24 py-8">
        <div className="flex items-center justify-between">
          <div className="text-[#171719]">
            <h1 className="text-2xl font-bold">SSELFIE Studio</h1>
          </div>
          <div className="hidden md:flex items-center gap-8">
            <Link href="/membership" className="text-sm uppercase tracking-wide hover:opacity-70 transition-opacity">
              Membership
            </Link>
            <Link href="/pricing" className="text-sm uppercase tracking-wide hover:opacity-70 transition-opacity">
              Pricing
            </Link>
            <Link href="/freebie" className="text-sm uppercase tracking-wide hover:opacity-70 transition-opacity">
              Free Guide
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <main className="px-6 md:px-16 lg:px-24 py-16">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-light mb-8 leading-tight">
            Power is the new pretty
          </h1>
          <p className="text-xl md:text-2xl mb-12 text-[#B5B5B3] max-w-2xl mx-auto">
            Transform your selfies and personal brand with Sandra&apos;s strategic approach to visual storytelling.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link 
              href="/membership" 
              className="bg-[#171719] text-[#F1F1F1] px-8 py-4 text-lg hover:opacity-90 transition-opacity"
            >
              Join SSELFIE Studio
            </Link>
            <Link 
              href="/component-showcase" 
              className="border border-[#171719] text-[#171719] px-8 py-4 text-lg hover:bg-[#171719] hover:text-[#F1F1F1] transition-colors"
            >
              View Components
            </Link>
          </div>
        </div>

        {/* Development Links */}
        <div className="mt-24 max-w-2xl mx-auto">
          <h2 className="text-2xl font-light mb-8 text-center">Development Navigation</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <Link href="/dashboard" className="p-4 border border-[#B5B5B3] hover:bg-[#171719] hover:text-[#F1F1F1] transition-colors text-center">
              Dashboard
            </Link>
            <Link href="/pricing" className="p-4 border border-[#B5B5B3] hover:bg-[#171719] hover:text-[#F1F1F1] transition-colors text-center">
              Pricing
            </Link>
            <Link href="/freebie" className="p-4 border border-[#B5B5B3] hover:bg-[#171719] hover:text-[#F1F1F1] transition-colors text-center">
              Freebie
            </Link>
            <Link href="/get-started" className="p-4 border border-[#B5B5B3] hover:bg-[#171719] hover:text-[#F1F1F1] transition-colors text-center">
              Get Started
            </Link>
            <Link href="/component-showcase" className="p-4 border border-[#B5B5B3] hover:bg-[#171719] hover:text-[#F1F1F1] transition-colors text-center">
              Components
            </Link>
            <Link href="/membership" className="p-4 border border-[#B5B5B3] hover:bg-[#171719] hover:text-[#F1F1F1] transition-colors text-center">
              Membership
            </Link>
          </div>
        </div>
      </main>
    </div>
  );
}
