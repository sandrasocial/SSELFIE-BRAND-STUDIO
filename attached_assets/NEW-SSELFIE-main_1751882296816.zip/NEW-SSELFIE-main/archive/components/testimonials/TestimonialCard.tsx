import React from "react";
import clsx from "clsx";

interface TestimonialCardProps {
  quote: string;
  name: string;
  handle?: string;
  imageSrc?: string; // Optional client photo
  className?: string;
}

const TestimonialCard: React.FC<TestimonialCardProps> = ({
  quote,
  name,
  handle,
  imageSrc,
  className,
}) => (
  <div className={clsx("", className)}>
    <div className={""}>
      <blockquote className={""}>
        “{quote}”
      </blockquote>
      <div className={""}>
        {imageSrc && (
          <img src={imageSrc} alt={name} className={""} />
        )}
        <div>
          <div className={""}>{name}</div>
          {handle && <div className={""}>{handle}</div>}
        </div>
      </div>
    </div>
  </div>
);

export default TestimonialCard;