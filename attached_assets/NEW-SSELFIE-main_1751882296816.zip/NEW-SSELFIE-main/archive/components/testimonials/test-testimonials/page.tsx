'use client'

import React from 'react';
import { TestimonialCarousel } from '@/components/sections/testimonials/TestimonialCarousel';

export default function TestPage() {
  return (
    <div className="min-h-screen">
      <h1 className="text-center py-8 text-2xl">TestimonialsSection Component Test</h1>
      <TestimonialCarousel />
    </div>
  );
}
