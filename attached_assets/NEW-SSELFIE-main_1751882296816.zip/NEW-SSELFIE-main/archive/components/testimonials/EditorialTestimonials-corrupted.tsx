export             <blockquote className="luxury-headline text-[1.15rem] md:text-xl italic text-black/85 mb-8 leading-relaxed">
              &ldquo;Thank you for sharing your knowledge and being so true. I feel so motivated to start taking pictures of myself. I heard the words that I&apos;ve always wanted to say but never expressed before. Today, I posted three stories talking about my journey in a raw and authentic way. I&apos;m pursuing my dream. Thank you so much.&rdquo;
            </blockquote>
            <span className="section-label text-soft-gray">
              Olha
            </span>t function EditorialTestimonials() {
  return (
    <section className="py-16 md:py-28 bg-editorial-gray">
      <div className="max-width-editorial mx-auto px-6">
        <div className="grid md:grid-cols-3 gap-12">
          {/* Testimonial 1 */}
          <div className="flex flex-col items-center text-center">
            <blockquote className="font-serif text-[1.15rem] md:text-xl italic text-black/85 mb-8 leading-relaxed">
              “Thank you for sharing your knowledge and being so true. I feel so motivated to start taking pictures of myself. I heard the words that I’ve always wanted to say but never expressed before. Today, I posted three stories talking about my journey in a raw and authentic way. I’m pursuing my dream. Thank you so much.”
            </blockquote>
            <span className="font-sans text-[11px] tracking-[0.4em] uppercase text-[#666]">
              Olha
            </span>
          </div>

          {/* Testimonial 2 */}
          <div className="flex flex-col items-center text-center">
            <blockquote className="font-serif text-[1.15rem] md:text-xl italic text-black/85 mb-8 leading-relaxed">
              “You literally changed my picture taking from boring selfies to professional pictures. Like, HOW?”
            </blockquote>
            <span className="font-sans text-[11px] tracking-[0.4em] uppercase text-[#666]">
              Sarah on Instagram
            </span>
          </div>

          {/* Testimonial 3 */}
          <div className="flex flex-col items-center text-center">
            <blockquote className="font-serif text-[1.15rem] md:text-xl italic text-black/85 mb-8 leading-relaxed">
              “You’re helping me develop my ‘just do it’ attitude. No more waiting for perfect!”
            </blockquote>
            <span className="font-sans text-[11px] tracking-[0.4em] uppercase text-[#666]">
              Roxanne
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}