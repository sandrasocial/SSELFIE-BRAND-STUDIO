import React from "react";
import Image from "next/imag              <span className="luxury-headline text-[4rem] font-light text-black/10 absolute top-4 right-6 select-none">02</span>
              <h4 className="luxury-headline text-[1.8rem] md:text-[2.3rem] font-light text-black italic">Stop hiding.</h4>;
import Link from "next/link";
import { SandraImages } from "@/components/sandra-image-library";

export const PortfolioSection = () => {
  return (
    <section className="bg-white py-0" id="portfolio">
      <div className="max-width-moodboard mx-auto w-full">
        {/* Header */}
        <div className="text-center pt-24 pb-16 px-6 md:px-16">
          <span className="section-label block mb-8">
            THE VIBE WE&apos;RE CREATING
          </span>
          <h2 className="luxury-headline text-[clamp(2.8rem,6vw,6rem)] leading-[0.9] mb-6">
            <span className="block">Confident. Unapologetic.</span>
            <span className="block md:ml-[15%]">Magnetic.</span>
          </h2>
          <p className="body-copy text-lg text-soft-gray max-w-[600px] mx-auto mb-2">
            This is how it feels when you stop hiding. When you own your story. When you build something real.
          </p>
          <p className="body-copy text-base italic text-soft-gray opacity-60 mt-6">
            Your phone. Your rules. Your empire.
          </p>
        </div>

        {/* Editorial Grid */}
        <div className="grid grid-cols-1 md:grid-cols-6 lg:grid-cols-12 gap-2 px-2">
          {/* Feature Story 1 */}
          <div className="relative overflow-hidden bg-mid-gray col-span-12 lg:col-span-8 row-span-6 aspect-[4/3] group">
            <Image
              src={SandraImages.editorial.laptop1}
              alt="Build your brand with SSELFIE"
              fill
              className="object-cover transition-transform duration-1000 group-hover:scale-105"
              priority
              sizes="(max-width: 1024px) 100vw, 900px"
            />
            <div className="absolute bottom-10 left-10 z-10 text-white opacity-90 group-hover:opacity-100 transition-all">
              <h3 className="luxury-headline text-[2.5rem] md:text-[3.5rem] font-light mb-2">Build your brand,</h3>
              <p className="section-label text-white">one SSELFIE at a time</p>
            </div>
          </div>

          {/* Story 2 */}
          <div className="relative overflow-hidden bg-mid-gray col-span-12 md:col-span-4 lg:col-span-4 row-span-4 aspect-[4/5] group">
            <Image
              src={SandraImages.editorial.laptop2}
              alt="Confidence Transformation"
              fill
              className="object-cover transition-transform duration-1000 group-hover:scale-105"
              priority
              sizes="(max-width: 1024px) 100vw, 500px"
            />
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/80 opacity-0 group-hover:opacity-100 transition-all backdrop-blur">
              <span className="font-serif text-[4rem] font-[200] text-black/10 absolute top-4 right-6 select-none">02</span>
              <h4 className="font-serif text-[1.8rem] md:text-[2.3rem] font-[200] text-black italic">“Stop hiding.”</h4>
            </div>
          </div>

          {/* Story 3 - Text Block */}
          <div className="flex flex-col items-center justify-center text-center bg-black text-white col-span-12 md:col-span-4 lg:col-span-4 row-span-2 p-8 group transition-colors duration-500 hover:bg-white hover:text-black">
            <h3 className="font-serif text-[3rem] md:text-[4rem] font-[200] mb-2">REAL</h3>
            <p className="font-sans text-base md:text-lg font-light opacity-80 mb-2">
              transformation<br />starts here
            </p>
            <span className="font-sans text-[10px] tracking-[0.3em] uppercase opacity-60">NO FILTERS NEEDED</span>
          </div>

          {/* Story 4 */}
          <div className="relative overflow-hidden bg-[#fafafa] col-span-12 md:col-span-4 lg:col-span-4 row-span-4 aspect-square group">
            <Image
              src={SandraImages.editorial.phone1}
              alt="Magnetic Energy"
              fill
              className="object-cover transition-transform duration-1000 group-hover:scale-105"
              priority
              sizes="(max-width: 1024px) 100vw, 500px"
            />
          </div>

          {/* Story 5 - Wide */}
          <div className="flex flex-col md:flex-row col-span-12 lg:col-span-8 row-span-3 bg-[#fafafa]">
            <div className="relative flex-1 aspect-video">
              <Image
                src={SandraImages.editorial.mirror}
                alt="Own Your Story"
                fill
                className="object-cover"
                priority
                sizes="(max-width: 1024px) 100vw, 700px"
              />
            </div>
            <div className="flex flex-1 items-center justify-center p-8 bg-[#fafafa]">
              <blockquote>
                <p className="font-serif text-[1.7rem] md:text-[2.1rem] font-[200] text-black/90 mb-4 leading-tight">
                  “Own your story.<br />Build something<br />real.”
                </p>
                <cite className="font-sans text-xs tracking-[0.1em] not-italic text-[#666]">— This is your moment</cite>
              </blockquote>
            </div>
          </div>

          {/* Story 6 */}
          <div className="relative overflow-hidden bg-[#fafafa] col-span-12 md:col-span-4 lg:col-span-4 row-span-5 aspect-[2/3] group">
            <Image
              src={SandraImages.editorial.thinking}
              alt="Empire Builder"
              fill
              className="object-cover transition-transform duration-1000 group-hover:scale-105"
              priority
              sizes="(max-width: 1024px) 100vw, 400px"
            />
            <div className="absolute top-1/2 right-0 -translate-y-1/2 rotate-90 origin-center bg-black text-white px-8 py-2 font-sans text-[11px] tracking-[0.5em] uppercase">
              EMPIRE ENERGY
            </div>
          </div>

          {/* Story 7 - Editorial Feature */}
          <div className="relative overflow-hidden bg-[#fafafa] col-span-12 row-span-5 group">
            <Image
              src={SandraImages.editorial.laughing}
              alt="Sandra's Method"
              fill
              className="object-cover transition-transform duration-1000 group-hover:scale-105"
              priority
              sizes="(max-width: 1024px) 100vw, 1200px"
            />
            <div className="absolute inset-0 flex flex-col justify-center px-10 py-16 bg-white/80 group-hover:bg-white/95 transition-all">
              <h3 className="font-serif text-[clamp(2.5rem,7vw,6rem)] font-[200] mb-4 leading-[0.9]">
                THE<br />SSELFIE<br />METHOD
              </h3>
              <p className="font-sans text-lg tracking-[0.1em] opacity-80">
                Your phone + My strategy = Your empire
              </p>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="text-center py-20">
          <Link
            href="/transformations"
            className="inline-flex items-center gap-6 font-sans text-[13px] tracking-[0.2em] uppercase text-black border-b border-black/20 hover:border-black pb-1 transition-all duration-300"
          >
            <span>Join The Vibe</span>
            <span className="text-2xl font-light transition-transform duration-300 group-hover:translate-x-2">→</span>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default PortfolioSection;