'use client'

import React from 'react'

export function TimelineStats() {
  return (
    <section className="section-padding bg-mid-gray">
      <div className="max-width-cta px-6 text-center">
        <div className="grid grid-cols-1 md:grid-cols-3 grid-gap md:gap-16">
          {/* Stat 1 */}
          <div>
            <div className="stat-number mb-2">
              90
            </div>
            <div className="stat-label">
              Days to 120K
            </div>
          </div>
          {/* Stat 2 */}
          <div>
            <div className="stat-number mb-2">
              1
            </div>
            <div className="stat-label">
              Phone. That&apos;s it.
            </div>
          </div>
          {/* Stat 3 */}
          <div>
            <div className="stat-number mb-2">
              0
            </div>
            <div className="stat-label">
              Experience needed
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
