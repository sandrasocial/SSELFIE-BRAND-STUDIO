import React from 'react';
import Image from 'next/image';
import { cn } from '@/lib/utils';

interface ToolsHeroProps {
  headline?: string;
  subheadline?: string;
  imageSrc?: string;
  className?: string;
}

export const ToolsHero: React.FC<ToolsHeroProps> = ({
  headline = "Transform Your Story",
  subheadline = "These are your chapters. Let's write them together.",
  imageSrc = "https://i.postimg.cc/nrKdm7Vj/out-2-4.webp", // Sandra's mirror image
  className,
}) => {
  return (
    <section className={cn("relative w-full h-[70vh] lg:h-screen", className)}>
      {/* Background Image */}
      <div className="absolute inset-0 w-full h-full">
        <Image
          src={imageSrc}
          alt="Sandra's transformation tools"
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 to-black/60" />
      </div>
      
      {/* Content */}
      <div className="relative h-full w-full flex items-center justify-center">
        <div className="container mx-auto px-6 text-center text-white">
          <h1 className="font-bodoni text-5xl md:text-7xl lg:text-8xl mb-8 leading-tight">
            {headline}
          </h1>
          <p className="text-xl md:text-2xl max-w-2xl mx-auto font-light">
            {subheadline}
          </p>
        </div>
      </div>
    </section>
  );
};
