import React from 'react'
import Image from 'next/image'
import { SandraImages } from '@/components/sandra-image-library'

interface HeroFullBleedProps {
  backgroundImage: string
  tagline?: string // The small top text
  title: string | React.ReactNode
  subtitle?: string // For long last names or secondary text
  ctaText?: string
  ctaLink?: string
  overlay?: number
  alignment?: 'left' | 'center'
  fullHeight?: boolean
}

export const HeroFullBleed: React.FC<HeroFullBleedProps> = ({
  backgroundImage,
  tagline,
  title,
  subtitle,
  ctaText,
  ctaLink,
  overlay = 0.6,
  alignment = 'center',
  fullHeight = true
}) => {
  return (
    <section 
      className={`relative w-screen ${fullHeight ? 'h-screen' : 'min-h-[600px]'} flex items-center overflow-hidden`}
      style={{ 
        marginLeft: 'calc(-50vw + 50%)',
        marginRight: 'calc(-50vw + 50%)',
        maxWidth: '100vw'
      }}
    >
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <Image 
          src={backgroundImage} 
          alt=""
          fill
          className="object-cover"
          priority
          sizes="100vw"
        />
      </div>
      
      {/* Gradient Overlay */}
      <div 
        className="absolute inset-0 z-10"
        style={{
          background: `linear-gradient(to top, rgba(0,0,0,${overlay + 0.2}) 0%, rgba(0,0,0,${overlay * 0.3}) 40%, transparent 70%)`
        }}
      />
      
      {/* Content Container */}
      <div className="relative z-20 w-full h-full flex items-center justify-center">
        <div className={`container mx-auto px-6 md:px-12 lg:px-20 ${alignment === 'center' ? 'text-center' : ''}`}>
          
          {/* Top Tagline */}
          {tagline && (
            <p className="font-inter text-[11px] md:text-xs tracking-[0.4em] uppercase text-white/70 mb-6">
              {tagline}
            </p>
          )}
          
          {/* Main Title - HUGE & STRETCHED */}
          <h1 className="font-bodoni text-[clamp(4rem,12vw,10rem)] leading-[0.9] font-light text-white mb-6 tracking-[0.3em] md:tracking-[0.5em] break-words">
            {title}
          </h1>
          
          {/* Subtitle - For long names or secondary text */}
          {subtitle && (
            <p className="font-inter text-xs md:text-sm tracking-[0.5em] uppercase text-white/80 mb-10">
              {subtitle}
            </p>
          )}
          
          {/* CTA - Minimal Line Style */}
          {ctaText && ctaLink && (
            <a 
              href={ctaLink}
              className="inline-block font-inter text-xs tracking-[0.3em] uppercase text-white/90 pb-2 border-b border-white/30 transition-all duration-300 hover:border-white hover:tracking-[0.35em]"
            >
              {ctaText}
            </a>
          )}
        </div>
      </div>
    </section>
  )
}

// Usage Examples
export const HeroExamples = () => {
  return (
    <>
      {/* Homepage - Power Pose */}
      <HeroFullBleed
        backgroundImage={SandraImages.hero.homepage}
        tagline="Turn your selfies into a CEO shot"
        title="SSELFIE"
        subtitle="STUDIO"
        ctaText="START YOUR JOURNEY"
        ctaLink="/pricing"
      />
      
      {/* About Page - Vulnerable but Strong */}
      <HeroFullBleed
        backgroundImage={SandraImages.hero.about}
        tagline="The Icelandic Selfie Queen"
        title="SANDRA"
        subtitle="SIGURJONSDOTTIR"
        ctaText="MY STORY"
        ctaLink="#story"
      />
      
      {/* Course Page - Teaching Mode */}
      <HeroFullBleed
        backgroundImage={SandraImages.hero.course}
        tagline="90 days to your first 100K"
        title="SSELFIE"
        subtitle="METHOD"
        ctaText="ENROLL NOW"
        ctaLink="/pricing"
      />
      
      {/* Stories Page - Contemplative Editorial Shot */}
      <HeroFullBleed
        backgroundImage={SandraImages.editorial.thinking}
        tagline="From real women who did it"
        title="STORIES"
        ctaText="READ MORE"
        ctaLink="#stories"
      />
      
      {/* Contact - Approachable */}
      <HeroFullBleed
        backgroundImage={SandraImages.hero.contact}
        tagline="Let's build something real together"
        title="CONTACT"
      />
      
      {/* Transformation Page - Current Sandra */}
      <HeroFullBleed
        backgroundImage={SandraImages.journey.today}
        tagline="Your journey starts here"
        title="TRANSFORMATION"
        subtitle="ACADEMY"
        ctaText="GET STARTED"
        ctaLink="/academy"
      />
    </>
  )
}