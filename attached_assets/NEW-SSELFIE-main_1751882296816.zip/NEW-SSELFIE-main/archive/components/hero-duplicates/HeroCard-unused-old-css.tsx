import React from "react";
import clsx from "clsx";
import Image from "next/image";

export interface HeroCardProps {
  imageSrc: string;
  imageAlt: string;
  meta?: string;
  title: string;
  description?: string;
  textureOpacity?: number;
  className?: string;
}

export function HeroCard({
  imageSrc,
  imageAlt,
  meta,
  title,
  description,
  textureOpacity = 0.11,
  className,
}: HeroCardProps) {
  return (
    <div className={clsx("ss-card-hero", className)}>
      {/* Editorial image */}
      <div className="ss-card-hero-img">
        <Image
          src={imageSrc}
          alt={imageAlt}
          fill
          className="object-cover"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
        />
        {/* Texture overlay */}
        <div
          className="ss-card-hero-texture"
          style={{
            opacity: textureOpacity,
            backgroundImage: `url('/textures/flatlay-1.png')`,
          }}
        />
      </div>
      {/* Content */}
      <div className="ss-card-hero-content">
        {meta && (
          <div className="ss-card-hero-meta">{meta}</div>
        )}
        <h3 className="ss-card-hero-title">{title}</h3>
        {description && (
          <p className="ss-card-hero-desc">{description}</p>
        )}
      </div>
    </div>
  );
}
