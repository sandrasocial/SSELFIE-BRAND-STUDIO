# 🎨 CLAUDE VICTORIA COMPONENT GUIDE
*Essential Components for SSELFIE Design Implementation*

## 🎯 COMPONENT STRATEGY: CREATE ALL COMPONENTS FROM SCRATCH

**Last Updated**: June 26, 2025  
**Status**: Ready for complete redesign using Sandra's new Ultimate Design Manual  
**Next Phase**: Claude Victoria implementation from scratch  
**Design Reference**: `/admin/design-manual` - Sandra's ultimate design system

---

## 🚨 ALL COMPONENTS NEED TO BE CREATED FROM SCRATCH

### 🎨 NEW APPROACH: COMPLETE REDESIGN
**STATUS**: ❌ ALL COMPONENTS TO BE RECREATED - Using Sandra's new Ultimate Design Manual

**IMPORTANT**: Sandra has redesigned her complete design manual. All existing components need to be recreated from scratch using the new design system found in `/admin/design-manual`.

### 📚 Design References (Admin Pages):
```tsx
// 🎨 SANDRA'S DESIGN RESOURCES - USE THESE AS MASTER REFERENCE:
/admin/design-manual          // Ultimate Design Manual (HTML)
/admin/visual-content-bible   // Visual Content Bible (HTML)  
/admin/voice-guidelines       // Voice Guidelines (HTML)
```

### ⚠️ PREVIOUS COMPONENTS STATUS:
```tsx
// ❌ DO NOT USE EXISTING COMPONENTS - REDESIGN FROM SCRATCH:
// All components in src/components/ui/ need redesign
// All components in src/components/dashboard/ need redesign
// All components in src/components/globalfooter need redesign
// Follow Sandra's new Ultimate Design Manual instead
```

---

## 🎨 ALL COMPONENTS TO CREATE FROM SCRATCH

### 🧭 Core UI Components (NEW DESIGN SYSTEM)
**STATUS**: ❌ RECREATE FROM SCRATCH - Using Ultimate Design Manual

```tsx
// 🚨 CLAUDE VICTORIA MUST CREATE FROM SCRATCH:
/src/components/ui/
├── Button.tsx              // Luxury buttons per new design manual
├── Card.tsx                // Premium card designs per new standards
├── Input.tsx               // Form inputs with new luxury aesthetic
├── Progress.tsx            // Progress bars matching new design
├── Tabs.tsx                // Tab navigation per new system
├── Badge.tsx               // Status badges with new styling
├── Select.tsx              // Dropdown selections per new design
├── Textarea.tsx            // Text areas matching new aesthetic
├── Label.tsx               // Form labels per new standards
└── index.ts                // Export all UI components
```

### 🧭 Global Navigation Components
**STATUS**: ❌ CREATE FROM SCRATCH - Using Ultimate Design Manual

```tsx
// 🚨 CLAUDE VICTORIA MUST CREATE FROM SCRATCH:
/src/components/global/
├── Navigation.tsx           // Main site navigation per new design
├── MemberNavigation.tsx     // Dashboard navigation per new system
├── MobileMenu.tsx          // Mobile menu per new design manual
├── Footer.tsx              // Global footer per new standards
└── index.ts                // Export all global components
```

### 💎 Business Model Components
**STATUS**: ❌ CREATE FROM SCRATCH - Revenue-focused with new design

```tsx
// 🚨 CLAUDE VICTORIA MUST CREATE FROM SCRATCH:
/src/components/business/
├── PricingCard.tsx         // Subscription tiers per new design
├── UsageProgressBar.tsx    // Generation limits per new aesthetic
├── UpgradePrompt.tsx       // Conversion components per new system
├── SubscriptionStatus.tsx  // Billing status per new design
├── MembershipBadge.tsx     // Tier badges per new standards
├── PaymentMethod.tsx       // Payment info per new design
├── BillingHistory.tsx      // Invoice history per new aesthetic
└── index.ts                // Export all business components
```

### 🎁 Lead Generation Components
**STATUS**: ❌ CREATE FROM SCRATCH - Conversion-optimized with new design

```tsx
// 🚨 CLAUDE VICTORIA MUST CREATE FROM SCRATCH:
/src/components/lead-gen/
├── EmailCaptureForm.tsx    // Lead magnet forms per new design
├── SocialProof.tsx         // Testimonials per new aesthetic
├── DownloadCounter.tsx     // Social proof per new system
├── FreebiePreview.tsx      // Content previews per new design
├── TrustSignals.tsx        // Security badges per new standards
└── index.ts                // Export all lead-gen components
```

### 🔐 Authentication Components
**STATUS**: ❌ CREATE FROM SCRATCH - Secure design per new manual

```tsx
// 🚨 CLAUDE VICTORIA MUST CREATE FROM SCRATCH:
/src/components/auth/
├── LoginForm.tsx           // Member login per new design
├── SignupForm.tsx          // Account creation per new aesthetic
├── PasswordReset.tsx       // Password recovery per new system
├── EmailVerification.tsx   // Email confirmation per new design
├── AuthLayout.tsx          // Auth page wrapper per new standards
└── index.ts                // Export all auth components
```

### 📊 Dashboard Components
**STATUS**: ❌ RECREATE FROM SCRATCH - Using new design system

```tsx
// 🚨 CLAUDE VICTORIA MUST RECREATE FROM SCRATCH:
/src/components/dashboard/
├── DashboardLayout.tsx     // Main layout per new design manual
├── DashboardInsights.tsx   // Analytics per new aesthetic
├── QuickActions.tsx        // Action buttons per new system
├── ProgressAnimations.tsx  // Animations per new design
└── index.ts                // Export all dashboard components
```

---

## 🎨 DESIGN REQUIREMENTS FOR ALL NEW COMPONENTS

### 📚 MASTER DESIGN REFERENCE:
**PRIMARY SOURCE**: `/admin/design-manual` - Sandra's Ultimate Design Manual (HTML)
**SUPPORTING**: `/admin/visual-content-bible` - Visual content standards  
**VOICE**: `/admin/voice-guidelines` - Brand voice and messaging

### New Design System Standards:
- **Design Manual**: Follow Sandra's complete Ultimate Design Manual exactly
- **No Existing Components**: All components must be recreated from scratch
- **New Aesthetic**: Based on Sandra's redesigned luxury standards
- **Mobile-first** responsive design
- **Premium micro-interactions** per new design manual
- **Conversion optimization** features per new business model

### Component Creation Process:
1. **Review Sandra's Ultimate Design Manual** at `/admin/design-manual`
2. **Create visual preview** following new design system exactly
3. **Get Sandra's approval** on design preview
4. **Implement with TypeScript** following new standards
5. **Test mobile responsiveness** per new design manual

### Component Style Patterns:
```tsx
// Example luxury button pattern to follow:
const luxuryButton = `
  bg-luxury-black text-soft-white border border-luxury-black
  hover:bg-transparent hover:text-luxury-black
  before:absolute before:inset-0 before:bg-soft-white 
  before:transform before:scale-x-0 before:origin-left
  before:transition-transform before:duration-600 before:ease-out
  hover:before:scale-x-100 before:-z-10
`
```

---

### 📋 IMPLEMENTATION PRIORITY ORDER (FROM SCRATCH)

### Priority 1: CORE UI SYSTEM (Week 1)
1. **Button.tsx** - Foundation component per new design manual
2. **Card.tsx** - Container component per new aesthetic  
3. **Input.tsx** - Form foundation per new standards
4. **Navigation.tsx** - Site header per new design system

### Priority 2: BUSINESS CRITICAL (Week 1-2)
5. **PricingCard.tsx** - Revenue component per new design
6. **EmailCaptureForm.tsx** - Lead generation per new system
7. **LoginForm.tsx** - Authentication per new aesthetic
8. **UsageProgressBar.tsx** - Dashboard component per new manual

### Priority 3: SUPPORTING COMPONENTS (Week 2)
9. **Progress.tsx** - UI component per new standards
10. **Badge.tsx** - Status displays per new design
11. **SubscriptionStatus.tsx** - Billing per new aesthetic
12. **MobileMenu.tsx** - Mobile navigation per new system

---

## 🔧 COMPONENT CREATION GUIDELINES

### File Structure Template (New Design System):
```tsx
'use client'

import React from 'react'
// DO NOT import existing components - create from scratch per design manual

interface ComponentNameProps {
  // TypeScript props interface per new design system
}

/**
 * COMPONENT PURPOSE & BUSINESS CONTEXT
 * 
 * Design Reference: Sandra's Ultimate Design Manual (/admin/design-manual)
 * Revenue Impact: [How this affects conversions]
 * User Experience: [What user need this serves]
 * New Design Requirements: [Per Ultimate Design Manual]
 */

export function ComponentName({ props }: ComponentNameProps) {
  return (
    <div className="new-luxury-component">
      {/* Claude Victoria implementation per Sandra's new design manual */}
    </div>
  )
}

export default ComponentName
```

### Naming Convention:
- **PascalCase** for component names
- **Descriptive names** that indicate business purpose
- **Props interfaces** with clear TypeScript types
- **Business context comments** for revenue-focused components

---

## 🚀 INTEGRATION STRATEGY (COMPLETE REDESIGN)

### For Claude Victoria:
1. **Access Sandra's Ultimate Design Manual** at `/admin/design-manual`
2. **Create ALL components from scratch** - ignore existing components
3. **Follow new design system exactly** per Ultimate Design Manual
4. **Implement mobile-first** responsive design per new standards
5. **Focus on conversion optimization** per new business model

### For MAYA (Technical Integration):
1. **Replace all existing components** with new design system components
2. **Set up new component exports** in index.ts files
3. **Update all imports** across pages to use new components
4. **Test new component integration** across all pages

### For QUINN (QA Testing):
1. **Test new design system** across all devices
2. **Validate new luxury aesthetic** per Ultimate Design Manual
3. **Check conversion flows** with new components
4. **Performance testing** with complete new component system

---

## 📊 MOCK DATA FOR COMPONENT DESIGN

### Use Centralized Mock Data:
```tsx
// Import from centralized mock data
import { 
  MOCK_USER, 
  MOCK_SUBSCRIPTION, 
  MOCK_USAGE,
  MOCK_BILLING_HISTORY 
} from '@/lib/mock-data'

// Use in component design:
<PricingCard 
  currentPlan={MOCK_SUBSCRIPTION.plan}
  usage={MOCK_USAGE.aiGenerations}
  upgradeRecommended={true}
/>
```

---

## 🎯 SUCCESS CRITERIA

### Component Quality Gates:
- ✅ **Luxury aesthetic** matching existing design system
- ✅ **Mobile-responsive** with smooth interactions
- ✅ **TypeScript compliance** with proper interfaces
- ✅ **Performance optimized** with lazy loading where appropriate
- ✅ **Conversion focused** with clear business purpose
- ✅ **Accessible** with proper ARIA attributes

### Business Impact Metrics:
- **Conversion rates** on pages using new components
- **User engagement** with interactive elements
- **Mobile performance** and usability scores
- **Loading speeds** and Core Web Vitals

---

## 📞 COORDINATION PROTOCOL

### Before Creating Components:
1. **Review existing components** to avoid duplication
2. **Check business requirements** in page placeholder files
3. **Follow luxury design patterns** from existing UI components
4. **Create visual previews** before coding (as required)

### After Creating Components:
1. **Export in index.ts** files for clean imports
2. **Document props and usage** with TypeScript
3. **Test integration** with placeholder pages
4. **Update this guide** with new components

---

## 🎬 NEXT STEPS FOR CLAUDE VICTORIA (COMPLETE REDESIGN)

### Immediate Actions:
1. **Review Sandra's Ultimate Design Manual** at `/admin/design-manual`
2. **Create Button.tsx from scratch** - Foundation component first
3. **Design Card.tsx from scratch** - Per new design system
4. **Build Input.tsx from scratch** - Form foundation component

### Design Process:
1. **Study Ultimate Design Manual** completely before starting
2. **Create visual previews** for each component per new system
3. **Get Sandra's approval** on each design before coding
4. **Implement from scratch** - do not reference existing components

---

**🎯 CRITICAL CHANGE**: Sandra has a complete new Ultimate Design Manual. ALL existing components must be recreated from scratch using her new design system. Do not use any existing components as reference - only use Sandra's new Ultimate Design Manual at `/admin/design-manual`.

**📚 DESIGN REFERENCE ORDER**: 
1. **Primary**: `/admin/design-manual` (Ultimate Design Manual)
2. **Supporting**: `/admin/visual-content-bible` (Visual standards)  
3. **Voice**: `/admin/voice-guidelines` (Brand messaging)

**Next Update**: After Sandra imports her HTML design resources and Victoria begins complete redesign
